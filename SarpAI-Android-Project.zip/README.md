# SARP AI — personal AI agent for Android (Powered By WebWorldBD)

Native Android app (Kotlin + Jetpack Compose). Package: `com.webworldbd.sarpai`.
For personal use (sideloaded APK). No API key is stored in the code — add keys inside the app.

## Build the APK (from your phone, with GitHub)
1. Create a new GitHub repository and upload **all files of this ZIP** (keep the folder structure, including the hidden `.github` folder).
2. Open the **Actions** tab -> **Build SARP AI APK** -> **Run workflow** (it also runs on every push).
3. When it turns green, open the run and download the artifact **SarpAI-APK**. Unzip it and install `app-release.apk`.
   The APK is signed with the included `app/sarp-release.jks`, so future builds update the installed app without uninstalling.

## First run
1. Settings > **API Keys** > add a key (Gemini / OpenAI / Claude / DeepSeek / Groq / OpenRouter / custom). Tap **Test**.
2. Settings > **Permissions**: grant what you want, each one separately.
   - **Screen control (Accessibility)**: needed for tapping/typing in other apps. On Android 13+ first use App info > ⋮ > *Allow restricted settings*.
   - **Floating button**: "Display over other apps". **Battery**: allow background running.
3. Agent tab > switch **ON**. A floating logo button appears over all apps. Tap = pause/resume listening, long-press = open app, drag = move.

## Safety design
- The agent acts only on your command (voice or typed). Nothing starts by itself.
- Blocked apps/words are enforced **in code** (Settings > Safety & Rules), not only in the AI prompt.
- Sensitive actions (SMS, call, post, delete, pay, GitHub upload) ask for confirmation by default.
- Each capability needs the Android permission AND its in-app switch.

## Added in this version
- Image analysis: chat tab photo/camera buttons; agent actions `analyze_camera` (opens camera, you take the photo) and `analyze_screen` (screenshot, Android 11+). Needs a Gemini, OpenAI or Claude key.
- Image generation (`generate_image`): Gemini or OpenAI key; saved to Pictures/SARP AI.
- Email reading (`read_email`): IMAP, read-only, Gmail App Password. Settings > Integrations.

## Not included yet
Video creation/editing and sending email.
