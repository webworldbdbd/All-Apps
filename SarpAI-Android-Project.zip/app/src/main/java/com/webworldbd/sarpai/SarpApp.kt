package com.webworldbd.sarpai

import android.app.Application

class SarpApp : Application() {
    override fun onCreate() {
        super.onCreate()
        S.init(this)
        Speaker.init(this)
        ChatStore.load()
    }
}
