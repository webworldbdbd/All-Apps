package com.webworldbd.sarpai

import kotlinx.coroutines.CancellationException

enum class Task { CODING, SEARCH, SOCIAL, GENERAL }

/** Picks the best API key for the kind of work, with automatic failover. */
object Router {
    private val pref: Map<Task, List<Provider>> = mapOf(
        Task.CODING to listOf(Provider.ANTHROPIC, Provider.OPENAI, Provider.DEEPSEEK, Provider.GEMINI, Provider.OPENROUTER, Provider.GROQ),
        Task.SEARCH to listOf(Provider.GEMINI, Provider.OPENAI, Provider.ANTHROPIC, Provider.DEEPSEEK, Provider.OPENROUTER, Provider.GROQ),
        Task.SOCIAL to listOf(Provider.GROQ, Provider.OPENROUTER, Provider.GEMINI, Provider.OPENAI, Provider.ANTHROPIC, Provider.DEEPSEEK),
        Task.GENERAL to listOf(Provider.OPENAI, Provider.GEMINI, Provider.ANTHROPIC, Provider.DEEPSEEK, Provider.GROQ, Provider.OPENROUTER)
    )

    fun classify(text: String): Task {
        val s = text.lowercase()
        fun has(vararg w: String) = w.any { s.contains(it) }
        return when {
            has("code", "coding", "program", "script", "debug", "kotlin", "python", "javascript", "html", "css",
                "website", "github", "function", "compile", "কোড", "কোডিং", "প্রোগ্রাম", "ওয়েবসাইট", "এরর", "গিটহাব", "স্ক্রিপ্ট") -> Task.CODING
            has("facebook", "instagram", "tiktok", "caption", "viral", "reel", "social media", "ফেসবুক", "ইনস্টাগ্রাম", "টিকটক", "ক্যাপশন", "কনটেন্ট") -> Task.SOCIAL
            has("search", "google", "news", "latest", "weather", "price", "সার্চ", "গুগল", "খবর", "সংবাদ", "আজকের", "আবহাওয়া", "দাম", "রেট") -> Task.SEARCH
            else -> Task.GENERAL
        }
    }

    fun candidates(task: Task): List<ApiKey> {
        val enabled = S.keys.filter { it.enabled && it.key.isNotBlank() }
        if (S.routing != "auto") {
            val k = enabled.firstOrNull { it.id == S.routing }
            if (k != null) return listOf(k)
        }
        val p = pref.getValue(task)
        return enabled.sortedBy {
            val i = p.indexOf(Provider.of(it.provider))
            if (i < 0) 99 else i
        }
    }

    suspend fun run(task: Task, system: String, msgs: List<Msg>, search: Boolean = false): Pair<ApiKey, String> {
        val list = candidates(task)
        if (list.isEmpty()) {
            throw LlmException(
                tr(
                    "No API key added. Open Settings > API Keys and add one.",
                    "কোনো API Key দেওয়া নেই। সেটিংস > API Keys-এ গিয়ে একটি যোগ করুন।"
                )
            )
        }
        var last: Exception? = null
        for (k in list) {
            try {
                val useSearch = search && Provider.of(k.provider) == Provider.GEMINI
                return k to Llm.chat(k, system, msgs, useSearch)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                last = e
            }
        }
        throw LlmException("${tr("All keys failed", "সব key ব্যর্থ")}: ${last?.message}")
    }
}
