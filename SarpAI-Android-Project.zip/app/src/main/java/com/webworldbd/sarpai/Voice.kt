package com.webworldbd.sarpai

import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.MediaPlayer
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Base64
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import kotlin.coroutines.resume

/** Text-to-speech: phone voice or AI-provider voice, male / female. */
object Speaker {
    private var tts: TextToSpeech? = null
    private var ready = false
    private val waiters = ConcurrentHashMap<String, CompletableDeferred<Unit>>()
    private const val GEMINI_TTS_MODEL = "gemini-2.5-flash-preview-tts"
    private val JSON_MT = "application/json; charset=utf-8".toMediaType()

    fun init(ctx: Context) {
        if (tts != null) return
        tts = TextToSpeech(ctx.applicationContext) { status ->
            ready = status == TextToSpeech.SUCCESS
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) {
                    if (utteranceId != null) waiters.remove(utteranceId)?.complete(Unit)
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    if (utteranceId != null) waiters.remove(utteranceId)?.complete(Unit)
                }
            })
        }
    }

    fun stop() {
        try { tts?.stop() } catch (e: Exception) { }
        waiters.values.forEach { it.complete(Unit) }
        waiters.clear()
    }

    suspend fun speak(text: String) {
        val clean = text.replace(Regex("[*_`#]"), "").trim()
        if (clean.isBlank()) return
        val usedAi = if (S.voiceEngine == "ai") speakAi(clean) else false
        if (!usedAi) speakPhone(clean)
    }

    private suspend fun speakPhone(text: String) {
        val t = tts ?: return
        if (!ready) return
        val bn = text.any { it in '\u0980'..'\u09FF' }
        val loc = if (bn) Locale.forLanguageTag("bn-BD") else Locale.US
        if (t.isLanguageAvailable(loc) >= TextToSpeech.LANG_AVAILABLE) t.setLanguage(loc)
        val female = S.voiceGender == "female"
        var hinted = false
        try {
            val lang = t.getLanguage()?.language
            val vs = t.voices?.filter { it.locale.language == lang } ?: emptyList()
            val want = vs.firstOrNull {
                val n = it.name.lowercase()
                if (female) n.contains("female") else (n.contains("male") && !n.contains("female"))
            }
            if (want != null) {
                t.setVoice(want)
                hinted = true
            }
        } catch (e: Exception) { }
        t.setPitch(if (hinted) 1.0f else if (female) 1.15f else 0.8f)
        t.setSpeechRate(1.0f)

        val id = UUID.randomUUID().toString()
        val d = CompletableDeferred<Unit>()
        waiters[id] = d
        try {
            t.speak(text.take(3500), TextToSpeech.QUEUE_FLUSH, null, id)
            withTimeoutOrNull(90_000) { d.await() }
        } catch (e: CancellationException) {
            try { t.stop() } catch (x: Exception) { }
            throw e
        } finally {
            waiters.remove(id)
        }
    }

    private suspend fun speakAi(text: String): Boolean {
        val keys = S.keys.filter { it.enabled && it.key.isNotBlank() }
        val g = keys.firstOrNull { it.provider == "gemini" }
        val o = keys.firstOrNull { it.provider == "openai" }
        return try {
            when {
                g != null -> playGemini(g, text)
                o != null -> playOpenAi(o, text)
                else -> false
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            false
        }
    }

    private suspend fun playGemini(k: ApiKey, text: String): Boolean {
        val base = k.baseUrl.ifBlank { Provider.GEMINI.defBase }.trimEnd('/')
        val voice = if (S.voiceGender == "female") "Kore" else "Charon"
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", text)))))
            .put(
                "generationConfig", JSONObject()
                    .put("responseModalities", JSONArray().put("AUDIO"))
                    .put(
                        "speechConfig", JSONObject().put(
                            "voiceConfig", JSONObject().put(
                                "prebuiltVoiceConfig", JSONObject().put("voiceName", voice)
                            )
                        )
                    )
            )
        val pcm = withContext(Dispatchers.IO) {
            val resp = Llm.postJson(
                "$base/v1beta/models/$GEMINI_TTS_MODEL:generateContent",
                mapOf("x-goog-api-key" to k.key), body
            )
            val data = JSONObject(resp).optJSONArray("candidates")?.optJSONObject(0)
                ?.optJSONObject("content")?.optJSONArray("parts")?.optJSONObject(0)
                ?.optJSONObject("inlineData")?.optString("data").orEmpty()
            if (data.isBlank()) null else Base64.decode(data, Base64.DEFAULT)
        } ?: return false

        val at = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
            )
            .setAudioFormat(
                AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(24000).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
            )
            .setBufferSizeInBytes(pcm.size)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
        try {
            at.write(pcm, 0, pcm.size)
            at.play()
            delay(pcm.size / 2 * 1000L / 24000 + 300)
        } finally {
            try { at.stop() } catch (e: Exception) { }
            at.release()
        }
        return true
    }

    private suspend fun playOpenAi(k: ApiKey, text: String): Boolean {
        val base = k.baseUrl.ifBlank { Provider.OPENAI.defBase }.trimEnd('/')
        val voice = if (S.voiceGender == "female") "nova" else "onyx"
        val body = JSONObject().put("model", "tts-1").put("voice", voice)
            .put("input", text.take(3500)).put("response_format", "mp3")
        val file = withContext(Dispatchers.IO) {
            val req = Request.Builder().url("$base/audio/speech")
                .header("Authorization", "Bearer ${k.key}")
                .post(body.toString().toRequestBody(JSON_MT)).build()
            Llm.http.newCall(req).execute().use { r ->
                if (!r.isSuccessful) throw LlmException("TTS HTTP ${r.code}", r.code)
                val f = File(S.app.cacheDir, "tts.mp3")
                f.writeBytes(r.body!!.bytes())
                f
            }
        }
        withContext(Dispatchers.Main) {
            suspendCancellableCoroutine<Unit> { cont ->
                val mp = MediaPlayer()
                cont.invokeOnCancellation { try { mp.release() } catch (e: Exception) { } }
                try {
                    mp.setDataSource(file.absolutePath)
                    mp.setOnCompletionListener { m ->
                        m.release()
                        if (cont.isActive) cont.resume(Unit)
                    }
                    mp.setOnErrorListener { m, _, _ ->
                        m.release()
                        if (cont.isActive) cont.resume(Unit)
                        true
                    }
                    mp.prepare()
                    mp.start()
                } catch (e: Exception) {
                    try { mp.release() } catch (x: Exception) { }
                    if (cont.isActive) cont.resume(Unit)
                }
            }
        }
        return true
    }
}

/** Continuous speech recognition (restarts itself) used while the agent is switched on. */
class VoiceLoop(private val ctx: Context, private val onText: (String) -> Unit) {
    private val main = Handler(Looper.getMainLooper())
    private var rec: SpeechRecognizer? = null
    private var active = false
    private var paused = false      // paused while the agent is speaking
    var muted = false               // paused by the user (button)

    fun start() {
        active = true
        main.post { begin() }
    }

    fun stop() {
        active = false
        main.removeCallbacksAndMessages(null)
        main.post { destroy() }
    }

    fun pause() {
        paused = true
        main.removeCallbacksAndMessages(null)
        main.post { destroy() }
    }

    fun resume() {
        paused = false
        if (active) main.postDelayed({ begin() }, 500)
    }

    fun setMute(m: Boolean) {
        muted = m
        if (m) {
            main.removeCallbacksAndMessages(null)
            main.post { destroy() }
        } else if (active && !paused) {
            main.postDelayed({ begin() }, 300)
        }
    }

    private fun begin() {
        if (!active || paused || muted) return
        destroy()
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            Agent.addLog("error", tr("Speech recognition is not available on this phone (install/enable the Google app).",
                "এই ফোনে ভয়েস রিকগনিশন নেই (Google অ্যাপ ইনস্টল/চালু করুন)।"))
            active = false
            return
        }
        val r = SpeechRecognizer.createSpeechRecognizer(ctx)
        rec = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
            override fun onError(error: Int) {
                if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                    active = false
                    Agent.addLog("error", tr("Microphone permission missing.", "মাইক্রোফোনের পারমিশন নেই।"))
                    return
                }
                schedule(if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1500L else 500L)
            }

            override fun onResults(results: Bundle?) {
                val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!t.isNullOrBlank()) onText(t)
                schedule(300L)
            }
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, S.inputLang)
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        try { r.startListening(i) } catch (e: Exception) { schedule(1500L) }
    }

    private fun schedule(ms: Long) {
        if (active && !paused && !muted) main.postDelayed({ begin() }, ms)
    }

    private fun destroy() {
        try { rec?.destroy() } catch (e: Exception) { }
        rec = null
    }
}
