@file:OptIn(ExperimentalMaterial3Api::class)

package com.webworldbd.sarpai

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner

/** Increments every time the app comes back to the foreground (used to re-check permissions). */
@Composable
fun rememberResumeTick(): Int {
    var tick by remember { mutableIntStateOf(0) }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }
    return tick
}

@Composable
fun AgentScreen(onOpenPermissions: () -> Unit) {
    val ctx = LocalContext.current
    val running by Agent.serviceRunning.collectAsState()
    val state by Agent.state.collectAsState()
    val busy by Agent.busy.collectAsState()
    val log by Agent.log.collectAsState()
    val tick = rememberResumeTick()
    var cmd by remember { mutableStateOf("") }

    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) AgentOverlayService.start(ctx)
    }

    fun toggle(on: Boolean) {
        if (on) {
            if (!Caps.osGranted(ctx, Cap.MIC)) micLauncher.launch(Manifest.permission.RECORD_AUDIO)
            else AgentOverlayService.start(ctx)
        } else AgentOverlayService.stop(ctx)
    }

    val statusText = when (state) {
        AState.OFF -> tr("Agent is OFF", "এজেন্ট বন্ধ")
        AState.LISTENING -> tr("Listening…", "শুনছি…")
        AState.PAUSED -> tr("Paused", "বিরতিতে")
        AState.THINKING -> tr("Working…", "কাজ করছি…")
        AState.SPEAKING -> tr("Speaking…", "বলছি…")
    }

    LazyColumn(
        Modifier.fillMaxSize(), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        item {
            SCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Image(painterResource(R.drawable.logo), null, Modifier.size(52.dp))
                    Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                        Text("SARP AI Agent", style = MaterialTheme.typography.titleMedium)
                        Text(statusText, color = MaterialTheme.colorScheme.primary)
                    }
                    Switch(checked = running, onCheckedChange = { toggle(it) })
                }
                Text(
                    tr(
                        "When ON, the agent keeps listening and a floating logo button stays on your screen. It only does what you tell it.",
                        "চালু থাকলে এজেন্ট সব সময় শোনে এবং স্ক্রিনে ভাসমান লোগো বাটন থাকে। আপনি যা বলবেন শুধু সেটাই করবে।"
                    ),
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
        }
        item {
            SCard {
                Text(tr("Readiness", "প্রস্তুতি"), style = MaterialTheme.typography.titleSmall)
                listOf(Cap.MIC, Cap.OVERLAY, Cap.SCREEN, Cap.BATTERY).forEach { c ->
                    val ok = Caps.osGranted(ctx, c)
                    Text(
                        (if (ok) "✓  " else "✗  ") + c.label,
                        color = if (ok) Color(0xFF22C55E) else MaterialTheme.colorScheme.error,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
                if (tick >= 0) {
                    TextButton(onClick = onOpenPermissions) { Text(tr("Open Permissions", "পারমিশন সেন্টার খুলুন")) }
                }
            }
        }
        item {
            SCard {
                Text(tr("Quick voice settings", "দ্রুত ভয়েস সেটিংস"), style = MaterialTheme.typography.titleSmall)
                Text(tr("Voice", "কণ্ঠ"), style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(top = 8.dp, bottom = 4.dp))
                ChipRow(
                    listOf("female" to tr("Female", "মহিলা"), "male" to tr("Male", "পুরুষ")), S.voiceGender
                ) { S.voiceGender = it; S.save() }
                Text(tr("I speak to you in", "আমি যে ভাষায় বলব/শুনব"), style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(top = 8.dp, bottom = 4.dp))
                ChipRow(
                    listOf("bn-BD" to "বাংলা", "en-US" to "English"), S.inputLang
                ) { S.inputLang = it; S.save() }
            }
        }
        item {
            SCard {
                Text(tr("Give a command", "কমান্ড দিন"), style = MaterialTheme.typography.titleSmall)
                OutlinedTextField(
                    value = cmd, onValueChange = { cmd = it }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                    placeholder = { Text(tr("e.g. Open YouTube and search WebWorldBD", "যেমন: YouTube খুলে WebWorldBD সার্চ করো")) },
                    shape = RoundedCornerShape(16.dp), maxLines = 4
                )
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { Agent.submit(cmd); cmd = "" }, enabled = cmd.isNotBlank() && !busy) {
                        Text(tr("Run", "চালান"))
                    }
                    if (busy) {
                        OutlinedButton(onClick = { Agent.cancel() }) {
                            Icon(Icons.Filled.Stop, null)
                            Spacer(Modifier.size(4.dp))
                            Text(tr("Stop", "থামান"))
                        }
                    }
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                SectionTitle(tr("Activity", "কার্যক্রম"))
                Spacer(Modifier.weight(1f))
                TextButton(onClick = { Agent.clearLog() }) { Text(tr("Clear", "মুছুন")) }
            }
        }
        items(log.reversed()) { l ->
            val cs = MaterialTheme.colorScheme
            val (tag, col) = when (l.kind) {
                "user" -> tr("You", "আপনি") to cs.primary
                "agent" -> "SARP" to cs.secondary
                "action" -> tr("Action", "অ্যাকশন") to cs.tertiary
                "result" -> tr("Result", "ফলাফল") to cs.onSurfaceVariant
                else -> tr("Error", "সমস্যা") to cs.error
            }
            Row(Modifier.fillMaxWidth()) {
                Text("$tag  ", color = col, style = MaterialTheme.typography.labelMedium)
                Text(l.text, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
            }
        }
    }
}
