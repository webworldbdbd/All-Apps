package com.webworldbd.sarpai

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.FileProvider
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.File

/** Transparent helper activity: opens the system camera, saves the photo, hands the bytes back. */
class CameraCaptureActivity : ComponentActivity() {

    companion object {
        @Volatile
        private var pending: CompletableDeferred<File?>? = null

        /** Opens the camera; the user takes the photo. Returns a downsized JPEG or null. */
        suspend fun capture(ctx: Context): ByteArray? {
            val d = CompletableDeferred<File?>()
            pending = d
            ctx.startActivity(Intent(ctx, CameraCaptureActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            val f = withTimeoutOrNull(120_000) { d.await() }
            pending = null
            if (f == null || !f.exists()) return null
            return withContext(Dispatchers.IO) { Media.toJpeg(f.readBytes()) }
        }
    }

    private lateinit var file: File

    private val launcher = registerForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        pending?.complete(if (ok) file else null)
        finish()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dir = File(cacheDir, "photos").apply { mkdirs() }
        file = File(dir, "shot.jpg")
        if (file.exists()) file.delete()
        try {
            val uri = FileProvider.getUriForFile(this, "$packageName.files", file)
            launcher.launch(uri)
        } catch (e: Exception) {
            pending?.complete(null)
            finish()
        }
    }

    override fun onDestroy() {
        pending?.complete(null)
        super.onDestroy()
    }
}
