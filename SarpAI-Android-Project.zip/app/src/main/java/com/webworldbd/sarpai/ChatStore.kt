package com.webworldbd.sarpai

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class ChatMsg(val role: String, val text: String, val via: String = "", val time: Long = System.currentTimeMillis())

/** Plain AI chat (no phone control). Messages are kept in a private file. */
object ChatStore {
    val messages = MutableStateFlow<List<ChatMsg>>(emptyList())
    val sending = MutableStateFlow(false)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var job: Job? = null

    private fun file() = File(S.app.filesDir, "chat.json")

    fun load() {
        try {
            val f = file()
            if (!f.exists()) return
            val arr = JSONArray(f.readText())
            val l = mutableListOf<ChatMsg>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                l.add(ChatMsg(o.optString("role"), o.optString("text"), o.optString("via"), o.optLong("time")))
            }
            messages.value = l
        } catch (e: Exception) { }
    }

    private fun persist() {
        try {
            val arr = JSONArray()
            messages.value.takeLast(120).forEach {
                arr.put(JSONObject().put("role", it.role).put("text", it.text).put("via", it.via).put("time", it.time))
            }
            file().writeText(arr.toString())
        } catch (e: Exception) { }
    }

    fun clear() {
        job?.cancel()
        messages.value = emptyList()
        sending.value = false
        persist()
    }

    private fun add(m: ChatMsg) {
        messages.value = messages.value + m
        persist()
    }

    private fun system(): String {
        val bio = S.biodata.ifBlank { "(not provided)" }
        return "You are SARP AI, a smart, friendly and concise personal assistant. " +
            "Reply in the same language the user writes in (Bangla or English). Use plain text; use code blocks only for code.\n" +
            "About the user (use it silently, do not repeat it back): $bio"
    }

    fun sendImage(text: String, jpeg: ByteArray, speak: Boolean) {
        if (sending.value) return
        val q = text.trim().ifBlank { tr("Describe this image.", "এই ছবিটি বর্ণনা করো।") }
        add(ChatMsg("user", "📷 $q"))
        sending.value = true
        job = scope.launch {
            try {
                val (k, reply) = Media.vision(q, jpeg)
                add(ChatMsg("assistant", reply, "${k.title} · vision"))
                if (speak && S.speakReplies) Speaker.speak(reply)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                add(ChatMsg("error", e.message ?: "Error"))
            } finally {
                sending.value = false
            }
        }
    }

    fun send(text: String, speak: Boolean) {
        val t = text.trim()
        if (t.isEmpty() || sending.value) return
        add(ChatMsg("user", t))
        sending.value = true
        val hist = messages.value.filter { it.role == "user" || it.role == "assistant" }
            .takeLast(30).map { Msg(it.role, it.text) }
        job = scope.launch {
            try {
                val task = Router.classify(t)
                val (k, reply) = Router.run(task, system(), hist, task == Task.SEARCH)
                add(ChatMsg("assistant", reply, "${k.title} · ${k.model.ifBlank { Provider.of(k.provider).defModel }}"))
                if (speak && S.speakReplies) Speaker.speak(reply)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                add(ChatMsg("error", e.message ?: "Error"))
            } finally {
                sending.value = false
            }
        }
    }
}
