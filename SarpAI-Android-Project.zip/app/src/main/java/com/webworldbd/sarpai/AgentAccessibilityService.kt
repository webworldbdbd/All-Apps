package com.webworldbd.sarpai

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.io.ByteArrayOutputStream
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/** Lets the agent read the screen and tap / type / scroll. Only active when the user enables it in Android settings. */
class AgentAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: AgentAccessibilityService? = null
    }

    private var nodes: List<AccessibilityNodeInfo> = emptyList()

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        if (instance === this) instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        super.onDestroy()
    }

    fun currentPackage(): String? = rootInActiveWindow?.packageName?.toString()

    fun currentLabel(): String {
        val p = currentPackage() ?: return ""
        return try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(p, 0)).toString()
        } catch (e: Exception) {
            p
        }
    }

    private fun label(n: AccessibilityNodeInfo): String =
        listOf(n.text, n.contentDescription, n.hintText).firstOrNull { !it.isNullOrBlank() }?.toString().orEmpty()

    private fun collect(n: AccessibilityNodeInfo, out: MutableList<AccessibilityNodeInfo>, depth: Int = 0) {
        if (out.size >= 150 || depth > 30) return
        val show = n.isVisibleToUser && (label(n).isNotBlank() || n.isEditable || n.isScrollable)
        if (show) out.add(n)
        for (i in 0 until n.childCount) {
            val c = n.getChild(i) ?: continue
            collect(c, out, depth + 1)
        }
    }

    fun labelAt(index: Int): String = nodes.getOrNull(index)?.let { label(it) }.orEmpty()

    fun dump(): String {
        val root = rootInActiveWindow
            ?: return "ERROR: no active window (the screen may be locked or protected)."
        val list = mutableListOf<AccessibilityNodeInfo>()
        collect(root, list)
        nodes = list
        val sb = StringBuilder("APP: ${root.packageName}\n")
        list.forEachIndexed { i, n ->
            val flags = mutableListOf<String>()
            if (n.isClickable) flags.add("click")
            if (n.isEditable) flags.add("edit")
            if (n.isScrollable) flags.add("scroll")
            if (n.isChecked) flags.add("checked")
            val r = Rect()
            n.getBoundsInScreen(r)
            val cls = n.className?.toString()?.substringAfterLast('.') ?: ""
            val l = label(n).take(80).replace("\n", " ")
            sb.append("[$i] $cls \"$l\" (${flags.joinToString(",")}) @${r.centerX()},${r.centerY()}\n")
        }
        if (list.isEmpty()) sb.append("(no readable elements)\n")
        return sb.toString()
    }

    private suspend fun clickNode(n: AccessibilityNodeInfo): Boolean {
        var c: AccessibilityNodeInfo? = n
        var depth = 0
        while (c != null && depth < 8) {
            if (c.isClickable && c.isEnabled) {
                if (c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
                break
            }
            c = c.parent
            depth++
        }
        val r = Rect()
        n.getBoundsInScreen(r)
        if (r.isEmpty) return false
        return gesture(Path().apply { moveTo(r.exactCenterX(), r.exactCenterY()) }, 60)
    }

    suspend fun tapIndex(i: Int): String {
        val n = nodes.getOrNull(i) ?: return "ERROR: element [$i] not found. Call read_screen first."
        n.refresh()
        val ok = clickNode(n)
        delay(700)
        return if (ok) "Tapped [$i] \"${label(n)}\"" else "ERROR: tap on [$i] failed"
    }

    suspend fun tapText(text: String): String {
        val root = rootInActiveWindow ?: return "ERROR: no active window"
        val list = mutableListOf<AccessibilityNodeInfo>()
        collect(root, list)
        nodes = list
        val q = text.trim().lowercase()
        val n = list.firstOrNull { label(it).trim().lowercase() == q }
            ?: list.firstOrNull { label(it).lowercase().contains(q) }
            ?: return "ERROR: no element with text \"$text\". Call read_screen and use the index."
        val ok = clickNode(n)
        delay(700)
        return if (ok) "Tapped \"${label(n)}\"" else "ERROR: tap failed"
    }

    suspend fun tapXY(x: Float, y: Float): String {
        val ok = gesture(Path().apply { moveTo(x, y) }, 60)
        delay(600)
        return if (ok) "Tapped at $x,$y" else "ERROR: gesture failed"
    }

    suspend fun typeText(text: String, submit: Boolean): String {
        val root = rootInActiveWindow ?: return "ERROR: no active window"
        var target: AccessibilityNodeInfo? = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        if (target == null || !target.isEditable) {
            val l = mutableListOf<AccessibilityNodeInfo>()
            collect(root, l)
            target = l.firstOrNull { it.isEditable }
        }
        if (target == null) return "ERROR: no text field found. Tap the text field first."
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        if (!target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) return "ERROR: could not set text"
        var msg = "Typed \"${text.take(60)}\"."
        if (submit) {
            delay(500)
            var sent = false
            if (Build.VERSION.SDK_INT >= 30) {
                sent = target.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
            }
            msg += if (sent) " Submitted." else " Could not press Enter; tap the search button or a suggestion."
            delay(800)
        }
        return msg
    }

    suspend fun scroll(dir: String): String {
        val root = rootInActiveWindow ?: return "ERROR: no active window"
        val l = mutableListOf<AccessibilityNodeInfo>()
        collect(root, l)
        val fwd = dir != "up"
        val sc = l.firstOrNull { it.isScrollable }
        if (sc != null && sc.performAction(
                if (fwd) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
            )
        ) {
            delay(500)
            return "Scrolled $dir"
        }
        val dm = resources.displayMetrics
        val w = dm.widthPixels.toFloat()
        val h = dm.heightPixels.toFloat()
        val p = Path().apply {
            if (fwd) { moveTo(w / 2, h * 0.75f); lineTo(w / 2, h * 0.25f) }
            else { moveTo(w / 2, h * 0.25f); lineTo(w / 2, h * 0.75f) }
        }
        val ok = gesture(p, 350)
        delay(500)
        return if (ok) "Swiped $dir" else "ERROR: scroll failed"
    }

    fun press(key: String): String {
        val action = when (key) {
            "back" -> GLOBAL_ACTION_BACK
            "home" -> GLOBAL_ACTION_HOME
            "recents" -> GLOBAL_ACTION_RECENTS
            "notifications" -> GLOBAL_ACTION_NOTIFICATIONS
            else -> return "ERROR: unknown key '$key'"
        }
        return if (performGlobalAction(action)) "Pressed $key" else "ERROR: press failed"
    }

    /** Screenshot of the current screen as a JPEG (Android 11+). */
    suspend fun screenshotJpeg(): ByteArray? {
        if (Build.VERSION.SDK_INT < 30) return null
        return suspendCancellableCoroutine { cont ->
            takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
                override fun onSuccess(screenshot: ScreenshotResult) {
                    var result: ByteArray? = null
                    try {
                        val hb = screenshot.hardwareBuffer
                        val hw = Bitmap.wrapHardwareBuffer(hb, screenshot.colorSpace)
                        val soft = hw?.copy(Bitmap.Config.ARGB_8888, false)
                        hb.close()
                        if (soft != null) {
                            val bos = ByteArrayOutputStream()
                            soft.compress(Bitmap.CompressFormat.JPEG, 80, bos)
                            result = Media.toJpeg(bos.toByteArray())
                        }
                    } catch (e: Exception) { }
                    if (cont.isActive) cont.resume(result)
                }

                override fun onFailure(errorCode: Int) {
                    if (cont.isActive) cont.resume(null)
                }
            })
        }
    }

    private suspend fun gesture(path: Path, duration: Long): Boolean = suspendCancellableCoroutine { cont ->
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, duration)).build()
        val ok = dispatchGesture(g, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                if (cont.isActive) cont.resume(true)
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                if (cont.isActive) cont.resume(false)
            }
        }, null)
        if (!ok && cont.isActive) cont.resume(false)
    }
}
