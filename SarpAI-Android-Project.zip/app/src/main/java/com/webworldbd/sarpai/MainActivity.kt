@file:OptIn(ExperimentalMaterial3Api::class)

package com.webworldbd.sarpai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            SarpTheme { Root() }
        }
    }
}

@Composable
fun Root() {
    var splash by rememberSaveable { mutableStateOf(true) }
    if (splash) SplashScreen { splash = false } else MainShell()
}

@Composable
fun MainShell() {
    var tab by rememberSaveable { mutableStateOf(0) }
    var settingsPage by rememberSaveable { mutableStateOf("") }
    val confirm by Agent.confirm.collectAsState()

    Scaffold(
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = tab == 0, onClick = { tab = 0 },
                    icon = { Icon(Icons.Filled.ChatBubble, null) }, label = { Text(tr("Chat", "চ্যাট")) }
                )
                NavigationBarItem(
                    selected = tab == 1, onClick = { tab = 1 },
                    icon = { Icon(Icons.Filled.SmartToy, null) }, label = { Text(tr("Agent", "এজেন্ট")) }
                )
                NavigationBarItem(
                    selected = tab == 2, onClick = { tab = 2 },
                    icon = { Icon(Icons.Filled.Settings, null) }, label = { Text(tr("Settings", "সেটিংস")) }
                )
            }
        }
    ) { pad ->
        androidx.compose.foundation.layout.Box(Modifier.padding(pad)) {
            when (tab) {
                0 -> ChatScreen()
                1 -> AgentScreen(onOpenPermissions = { settingsPage = "perms"; tab = 2 })
                else -> SettingsScreen(settingsPage) { settingsPage = it }
            }
        }
    }

    val c = confirm
    if (c != null) {
        AlertDialog(
            onDismissRequest = { Agent.answerConfirm(false) },
            title = { Text(tr("Allow this action?", "এই কাজটি করতে দেবেন?")) },
            text = { Text(c.text) },
            confirmButton = { TextButton(onClick = { Agent.answerConfirm(true) }) { Text(tr("Allow", "অনুমতি দিন")) } },
            dismissButton = { TextButton(onClick = { Agent.answerConfirm(false) }) { Text(tr("Deny", "না")) } }
        )
    }
}
