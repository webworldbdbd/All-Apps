@file:OptIn(ExperimentalMaterial3Api::class)

package com.webworldbd.sarpai

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private val DarkColors = darkColorScheme(
    primary = Color(0xFF00D4FF), onPrimary = Color(0xFF00212B),
    secondary = Color(0xFFB36BFF), tertiary = Color(0xFF3D7BFF),
    background = Color(0xFF0B1020), onBackground = Color(0xFFE8ECFF),
    surface = Color(0xFF121A33), onSurface = Color(0xFFE8ECFF),
    surfaceVariant = Color(0xFF1B2547), onSurfaceVariant = Color(0xFFA9B4DD),
    primaryContainer = Color(0xFF12307A), onPrimaryContainer = Color(0xFFD6E4FF),
    errorContainer = Color(0xFF5A1A22), onErrorContainer = Color(0xFFFFDADA),
    outline = Color(0xFF3A4770)
)

private val LightColors = lightColorScheme(
    primary = Color(0xFF0A4DFF), onPrimary = Color.White,
    secondary = Color(0xFF8A00E0), tertiary = Color(0xFF0087B8),
    background = Color(0xFFF4F6FF), onBackground = Color(0xFF0B1020),
    surface = Color.White, onSurface = Color(0xFF0B1020),
    surfaceVariant = Color(0xFFE6EBFF), onSurfaceVariant = Color(0xFF45507A),
    primaryContainer = Color(0xFFDCE6FF), onPrimaryContainer = Color(0xFF001B5C),
    errorContainer = Color(0xFFFFDADA), onErrorContainer = Color(0xFF410002),
    outline = Color(0xFFB4BEE6)
)

@Composable
fun SarpTheme(content: @Composable () -> Unit) {
    val dark = when (S.theme) {
        "dark" -> true
        "light" -> false
        else -> isSystemInDarkTheme()
    }
    MaterialTheme(colorScheme = if (dark) DarkColors else LightColors, content = content)
}

@Composable
fun SectionTitle(t: String) {
    Text(
        t, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary,
        fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 16.dp, bottom = 6.dp)
    )
}

@Composable
fun SCard(content: @Composable ColumnScope.() -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
    ) {
        Column(Modifier.padding(14.dp), content = content)
    }
}

@Composable
fun SwitchRow(title: String, sub: String? = null, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 8.dp)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            if (sub != null) Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
fun <T> ChipRow(options: List<Pair<T, String>>, selected: T, onSelect: (T) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { (v, label) ->
            FilterChip(selected = v == selected, onClick = { onSelect(v) }, label = { Text(label) })
        }
    }
}

@Composable
fun SplashScreen(onDone: () -> Unit) {
    val fade = remember { Animatable(0f) }
    val sc = remember { Animatable(0.7f) }
    LaunchedEffect(Unit) {
        launch { fade.animateTo(1f, tween(900)) }
        launch { sc.animateTo(1f, tween(900, easing = FastOutSlowInEasing)) }
        delay(2200)
        onDone()
    }
    Box(
        Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF070B18), Color(0xFF111B3D))))
    ) {
        Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
            Image(
                painterResource(R.drawable.logo), contentDescription = null,
                modifier = Modifier.size(170.dp).scale(sc.value).alpha(fade.value)
            )
            Spacer(Modifier.size(18.dp))
            Text("SARP AI", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold, modifier = Modifier.alpha(fade.value))
            Text("Your personal AI agent", color = Color(0xFFA9B4DD), fontSize = 14.sp, modifier = Modifier.alpha(fade.value))
        }
        Text(
            "Powered By WebWorldBD", color = Color(0xFFA9B4DD), fontSize = 14.sp,
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 44.dp).alpha(fade.value)
        )
    }
}
