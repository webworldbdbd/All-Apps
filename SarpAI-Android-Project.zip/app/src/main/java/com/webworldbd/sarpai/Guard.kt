package com.webworldbd.sarpai

import org.json.JSONObject

/** Hard safety rules enforced in code (not just in the AI prompt). */
object Guard {
    private val groups = listOf(
        listOf("bkash", "বিকাশ"),
        listOf("nagad", "নগদ"),
        listOf("rocket", "রকেট")
    )

    private val riskyWords = listOf(
        "send", "post", "delete", "remove", "pay", "purchase", "buy", "confirm", "submit",
        "publish", "comment", "share", "subscribe",
        "পাঠান", "পোস্ট", "ডিলিট", "মুছ", "পেমেন্ট", "কিনুন", "সাবমিট", "শেয়ার", "কমেন্ট"
    )

    fun terms(): List<String> {
        val base = S.blocked.split("\n", ",", ";").map { it.trim().lowercase() }.filter { it.length >= 2 }
        val out = LinkedHashSet<String>(base)
        base.forEach { b ->
            groups.firstOrNull { g -> g.any { it == b } }?.let { out.addAll(it) }
        }
        return out.toList()
    }

    fun hit(text: String): String? {
        val t = text.lowercase()
        return terms().firstOrNull { t.contains(it) }
    }

    /** For actions that touch the screen: also checks which app is in the foreground. */
    fun checkAction(a: JSONObject): String? {
        hit(a.toString())?.let { return it }
        val svc = AgentAccessibilityService.instance ?: return null
        return hit(svc.currentLabel() + " " + (svc.currentPackage() ?: ""))
    }

    fun risky(text: String): String? {
        val l = text.lowercase()
        return riskyWords.firstOrNull { l.contains(it) }
    }
}
