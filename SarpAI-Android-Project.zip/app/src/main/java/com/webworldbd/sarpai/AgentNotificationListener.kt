package com.webworldbd.sarpai

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import java.util.concurrent.ConcurrentLinkedDeque

class AgentNotificationListener : NotificationListenerService() {
    companion object {
        val recent = ConcurrentLinkedDeque<String>()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null || sbn.packageName == packageName) return
        val e = sbn.notification.extras
        val title = e.getCharSequence("android.title") ?: ""
        val text = e.getCharSequence("android.text") ?: ""
        recent.addFirst("${sbn.packageName} | $title | $text")
        while (recent.size > 40) recent.removeLast()
    }
}
