package com.webworldbd.sarpai

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlin.math.abs

/**
 * Foreground service: keeps the agent listening and shows the floating logo button
 * on top of every app. Tap = pause/resume listening, long-press = open SARP AI.
 */
class AgentOverlayService : Service() {

    companion object {
        const val ACTION_START = "com.webworldbd.sarpai.START"
        const val ACTION_STOP = "com.webworldbd.sarpai.STOP"
        const val ACTION_TOGGLE = "com.webworldbd.sarpai.TOGGLE"
        private const val CHANNEL = "sarp_agent"
        private const val NOTIF_ID = 4711

        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, AgentOverlayService::class.java).setAction(ACTION_START))
        }

        fun stop(ctx: Context) {
            ctx.startService(Intent(ctx, AgentOverlayService::class.java).setAction(ACTION_STOP))
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var loop: VoiceLoop? = null
    private var wm: WindowManager? = null
    private var bubble: ImageView? = null
    private var running = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                shutdown()
                return START_NOT_STICKY
            }
            ACTION_TOGGLE -> {
                toggleMute()
                return START_STICKY
            }
        }
        if (!running) startAgent()
        return START_STICKY
    }

    private fun startAgent() {
        createChannel()
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                startForeground(NOTIF_ID, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            } else {
                startForeground(NOTIF_ID, buildNotification())
            }
        } catch (e: Exception) {
            Agent.addLog("error", "Cannot start agent: ${e.message}")
            stopSelf()
            return
        }
        running = true
        Agent.serviceRunning.value = true
        Agent.muted = false

        val l = VoiceLoop(this) { text -> Agent.handleSpoken(text) }
        loop = l
        Agent.pauseListening = { l.pause() }
        Agent.resumeListening = { l.resume() }
        l.start()
        Agent.state.value = AState.LISTENING
        Agent.addLog("agent", tr("Agent is ON. I am listening.", "এজেন্ট চালু। আমি শুনছি।"))

        showBubble()
        scope.launch { Agent.state.collect { updateRing(it) } }
    }

    private fun toggleMute() {
        val l = loop ?: return
        val m = !Agent.muted
        Agent.muted = m
        l.setMute(m)
        if (!Agent.busy.value) Agent.state.value = if (m) AState.PAUSED else AState.LISTENING
        Agent.addLog("agent", if (m) tr("Listening paused.", "শোনা বন্ধ রাখা হয়েছে।") else tr("Listening resumed.", "আবার শুনছি।"))
    }

    private fun shutdown() {
        loop?.stop()
        loop = null
        Agent.pauseListening = null
        Agent.resumeListening = null
        if (Agent.busy.value) Agent.cancel()
        removeBubble()
        running = false
        Agent.serviceRunning.value = false
        Agent.muted = false
        Agent.state.value = AState.OFF
        Agent.addLog("agent", tr("Agent is OFF.", "এজেন্ট বন্ধ।"))
        stopForeground(true)
        stopSelf()
    }

    override fun onDestroy() {
        if (running) {
            loop?.stop()
            removeBubble()
            running = false
            Agent.serviceRunning.value = false
            Agent.state.value = AState.OFF
        }
        scope.cancel()
        super.onDestroy()
    }

    // ------------------------------------------------------------ notification

    private fun createChannel() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "SARP AI Agent", NotificationManager.IMPORTANCE_LOW))
    }

    private fun buildNotification(): Notification {
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), flags)
        val toggle = PendingIntent.getService(this, 1, Intent(this, AgentOverlayService::class.java).setAction(ACTION_TOGGLE), flags)
        val off = PendingIntent.getService(this, 2, Intent(this, AgentOverlayService::class.java).setAction(ACTION_STOP), flags)
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("SARP AI")
            .setContentText(tr("Agent is on and listening", "এজেন্ট চালু আছে, শুনছে"))
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(0, tr("Pause / Resume", "বিরতি / চালু"), toggle)
            .addAction(0, tr("Turn off", "বন্ধ করুন"), off)
            .build()
    }

    // ------------------------------------------------------------ floating button

    private fun ring(color: Int): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(Color.parseColor("#E6101830"))
        setStroke((3 * resources.displayMetrics.density).toInt(), color)
    }

    private fun updateRing(s: AState) {
        val c = when (s) {
            AState.LISTENING -> Color.parseColor("#22C55E")
            AState.THINKING -> Color.parseColor("#B100FF")
            AState.SPEAKING -> Color.parseColor("#2563EB")
            else -> Color.parseColor("#9CA3AF")
        }
        bubble?.background = ring(c)
    }

    private fun showBubble() {
        if (!Settings.canDrawOverlays(this)) {
            Agent.addLog("error", tr("Overlay permission is off, so the floating button is hidden.", "ওভারলে পারমিশন বন্ধ, তাই ভাসমান বাটন দেখানো হচ্ছে না।"))
            return
        }
        val manager = getSystemService(WINDOW_SERVICE) as WindowManager
        wm = manager
        val d = resources.displayMetrics.density
        val size = (58 * d).toInt()
        val pad = (9 * d).toInt()
        val sp = getSharedPreferences("sarp_overlay", MODE_PRIVATE)

        val iv = ImageView(this).apply {
            setImageResource(R.drawable.logo)
            scaleType = ImageView.ScaleType.FIT_CENTER
            setPadding(pad, pad, pad, pad)
            background = ring(Color.parseColor("#22C55E"))
            elevation = 8 * d
        }
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = sp.getInt("x", (resources.displayMetrics.widthPixels - size - 16 * d).toInt())
            y = sp.getInt("y", (resources.displayMetrics.heightPixels * 0.35).toInt())
        }

        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false
        var downAt = 0L
        iv.setOnTouchListener { v: View, e: MotionEvent ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x; startY = lp.y
                    touchX = e.rawX; touchY = e.rawY
                    moved = false
                    downAt = System.currentTimeMillis()
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - touchX).toInt()
                    val dy = (e.rawY - touchY).toInt()
                    if (abs(dx) > 10 || abs(dy) > 10) moved = true
                    if (moved) {
                        lp.x = startX + dx
                        lp.y = startY + dy
                        manager.updateViewLayout(v, lp)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) {
                        sp.edit().putInt("x", lp.x).putInt("y", lp.y).apply()
                    } else if (System.currentTimeMillis() - downAt > 600) {
                        startActivity(
                            Intent(this, MainActivity::class.java)
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                        )
                    } else {
                        toggleMute()
                    }
                    true
                }
                else -> false
            }
        }
        try {
            manager.addView(iv, lp)
            bubble = iv
        } catch (e: Exception) {
            Agent.addLog("error", "Floating button failed: ${e.message}")
        }
    }

    private fun removeBubble() {
        try { bubble?.let { wm?.removeView(it) } } catch (e: Exception) { }
        bubble = null
    }
}
