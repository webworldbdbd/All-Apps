@file:OptIn(ExperimentalMaterial3Api::class)

package com.webworldbd.sarpai

import android.app.Activity
import android.content.Intent
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun ChatScreen() {
    val ctx = LocalContext.current
    val msgs by ChatStore.messages.collectAsState()
    val sending by ChatStore.sending.collectAsState()
    var input by remember { mutableStateOf("") }
    val ls = rememberLazyListState()

    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val t = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (r.resultCode == Activity.RESULT_OK && !t.isNullOrBlank()) ChatStore.send(t, true)
    }

    val scope = rememberCoroutineScope()
    val pickLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            scope.launch {
                val jpeg = withContext(Dispatchers.IO) {
                    try {
                        ctx.contentResolver.openInputStream(uri)?.use { Media.toJpeg(it.readBytes()) }
                    } catch (e: Exception) { null }
                }
                if (jpeg != null) {
                    ChatStore.sendImage(input, jpeg, false)
                    input = ""
                }
            }
        }
    }

    LaunchedEffect(msgs.size) {
        if (msgs.isNotEmpty()) ls.animateScrollToItem(msgs.lastIndex)
    }

    Column(Modifier.fillMaxSize()) {
        ChatHeader()
        if (msgs.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Image(painterResource(R.drawable.logo), null, Modifier.size(96.dp))
                    Text(
                        tr("Ask me anything", "যা খুশি জিজ্ঞেস করুন"),
                        style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 12.dp)
                    )
                    Text(
                        tr("Pick an AI at the top, or leave it on Auto.", "ওপরে AI বেছে নিন, অথবা Auto রাখুন।"),
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            LazyColumn(
                state = ls, modifier = Modifier.weight(1f).fillMaxWidth(),
                contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(msgs) { m -> Bubble(m) }
            }
        }
        if (sending) LinearProgressIndicator(Modifier.fillMaxWidth())
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f),
                placeholder = { Text(tr("Message…", "মেসেজ লিখুন…")) }, maxLines = 5,
                shape = RoundedCornerShape(24.dp)
            )
            IconButton(onClick = { pickLauncher.launch("image/*") }) {
                Icon(Icons.Filled.PhotoLibrary, tr("Photo", "ছবি"), tint = MaterialTheme.colorScheme.primary)
            }
            IconButton(onClick = {
                if (!Caps.osGranted(ctx, Cap.CAMERA)) {
                    Toast.makeText(ctx, tr("Grant Camera in Settings > Permissions", "সেটিংস > পারমিশনে ক্যামেরা দিন"), Toast.LENGTH_LONG).show()
                } else {
                    scope.launch {
                        val jpeg = CameraCaptureActivity.capture(ctx)
                        if (jpeg != null) { ChatStore.sendImage(input, jpeg, false); input = "" }
                    }
                }
            }) { Icon(Icons.Filled.CameraAlt, tr("Camera", "ক্যামেরা"), tint = MaterialTheme.colorScheme.primary) }
            IconButton(onClick = {
                val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE, S.inputLang)
                try { micLauncher.launch(i) } catch (e: Exception) {
                    Toast.makeText(ctx, tr("Voice input not available", "ভয়েস ইনপুট পাওয়া যাচ্ছে না"), Toast.LENGTH_SHORT).show()
                }
            }) { Icon(Icons.Filled.Mic, tr("Voice", "ভয়েস"), tint = MaterialTheme.colorScheme.primary) }
            IconButton(onClick = {
                if (input.isNotBlank()) {
                    ChatStore.send(input, false)
                    input = ""
                }
            }, enabled = !sending) { Icon(Icons.AutoMirrored.Filled.Send, tr("Send", "পাঠান"), tint = MaterialTheme.colorScheme.primary) }
        }
    }
}

@Composable
private fun ChatHeader() {
    var open by remember { mutableStateOf(false) }
    val cur = S.keys.firstOrNull { it.id == S.routing }?.title ?: tr("Auto", "অটো")
    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Image(painterResource(R.drawable.logo), null, Modifier.size(30.dp))
        Text("  SARP AI", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
        Box {
            TextButton(onClick = { open = true }) { Text("AI: $cur") }
            DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                DropdownMenuItem(
                    text = { Text(tr("Auto (best AI for the task)", "অটো (কাজ অনুযায়ী সেরা AI)")) },
                    onClick = { S.routing = "auto"; S.save(); open = false }
                )
                S.keys.forEach { k ->
                    DropdownMenuItem(
                        text = { Text("${k.title} · ${Provider.of(k.provider).label}") },
                        onClick = { S.routing = k.id; S.save(); open = false }
                    )
                }
            }
        }
        IconButton(onClick = { ChatStore.clear() }) { Icon(Icons.Filled.Delete, tr("Clear", "মুছুন")) }
    }
}

@Composable
private fun Bubble(m: ChatMsg) {
    val isUser = m.role == "user"
    val err = m.role == "error"
    val cs = MaterialTheme.colorScheme
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start) {
        Column(
            horizontalAlignment = if (isUser) Alignment.End else Alignment.Start,
            modifier = Modifier.widthIn(max = 330.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = when {
                    err -> cs.errorContainer
                    isUser -> cs.primaryContainer
                    else -> cs.surfaceVariant
                }
            ) {
                SelectionContainer {
                    Text(
                        m.text, modifier = Modifier.padding(12.dp),
                        color = when {
                            err -> cs.onErrorContainer
                            isUser -> cs.onPrimaryContainer
                            else -> cs.onSurface
                        }
                    )
                }
            }
            if (m.via.isNotBlank()) {
                Text(
                    m.via, style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
            }
        }
    }
}
