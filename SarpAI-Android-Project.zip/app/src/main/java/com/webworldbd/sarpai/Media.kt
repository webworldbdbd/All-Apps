package com.webworldbd.sarpai

import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.nio.charset.Charset
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory
import kotlin.math.max

/** Image understanding (camera / screen / gallery) and image generation. */
object Media {

    fun toJpeg(bytes: ByteArray, maxSide: Int = 1280): ByteArray {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / sample > maxSide * 2) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts) ?: return bytes
        val scale = maxSide.toFloat() / max(bmp.width, bmp.height)
        val out = if (scale < 1f) {
            Bitmap.createScaledBitmap(bmp, (bmp.width * scale).toInt(), (bmp.height * scale).toInt(), true)
        } else bmp
        val bos = ByteArrayOutputStream()
        out.compress(Bitmap.CompressFormat.JPEG, 82, bos)
        return bos.toByteArray()
    }

    // ------------------------------------------------------------ vision

    suspend fun vision(prompt: String, jpeg: ByteArray): Pair<ApiKey, String> {
        val order = listOf(Provider.GEMINI, Provider.OPENAI, Provider.ANTHROPIC)
        val keys = S.keys.filter { it.enabled && it.key.isNotBlank() && Provider.of(it.provider) in order }
            .sortedBy { order.indexOf(Provider.of(it.provider)) }
        if (keys.isEmpty()) {
            throw LlmException(
                tr(
                    "Image analysis needs a Gemini, OpenAI or Claude key.",
                    "ছবি বিশ্লেষণের জন্য Gemini, OpenAI বা Claude key লাগবে।"
                )
            )
        }
        val b64 = Base64.encodeToString(jpeg, Base64.NO_WRAP)
        var last: Exception? = null
        for (k in keys) {
            try {
                return k to withContext(Dispatchers.IO) { visionCall(k, prompt, b64) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                last = e
            }
        }
        throw LlmException("${tr("All keys failed", "সব key ব্যর্থ")}: ${last?.message}")
    }

    private fun visionCall(k: ApiKey, prompt: String, b64: String): String {
        val p = Provider.of(k.provider)
        val base = k.baseUrl.ifBlank { p.defBase }.trimEnd('/')
        val model = k.model.ifBlank { p.defModel }
        val q = "$prompt\n\n(Reply in the same language as the question.)"
        when (p) {
            Provider.GEMINI -> {
                val parts = JSONArray()
                    .put(JSONObject().put("text", q))
                    .put(JSONObject().put("inlineData", JSONObject().put("mimeType", "image/jpeg").put("data", b64)))
                val body = JSONObject().put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", parts)))
                val resp = Llm.postJson("$base/v1beta/models/$model:generateContent", mapOf("x-goog-api-key" to k.key), body)
                val arr = JSONObject(resp).optJSONArray("candidates")?.optJSONObject(0)
                    ?.optJSONObject("content")?.optJSONArray("parts") ?: throw LlmException("Empty response")
                val sb = StringBuilder()
                for (i in 0 until arr.length()) sb.append(arr.getJSONObject(i).optString("text"))
                if (sb.isBlank()) throw LlmException("Empty response")
                return sb.toString()
            }
            Provider.ANTHROPIC -> {
                val content = JSONArray()
                    .put(
                        JSONObject().put("type", "image").put(
                            "source", JSONObject().put("type", "base64").put("media_type", "image/jpeg").put("data", b64)
                        )
                    )
                    .put(JSONObject().put("type", "text").put("text", q))
                val body = JSONObject().put("model", model).put("max_tokens", 2048)
                    .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", content)))
                val resp = Llm.postJson(
                    "$base/v1/messages", mapOf("x-api-key" to k.key, "anthropic-version" to "2023-06-01"), body
                )
                val arr = JSONObject(resp).optJSONArray("content") ?: throw LlmException("Empty response")
                val sb = StringBuilder()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    if (o.optString("type") == "text") sb.append(o.optString("text"))
                }
                if (sb.isBlank()) throw LlmException("Empty response")
                return sb.toString()
            }
            else -> {
                val content = JSONArray()
                    .put(JSONObject().put("type", "text").put("text", q))
                    .put(
                        JSONObject().put("type", "image_url")
                            .put("image_url", JSONObject().put("url", "data:image/jpeg;base64,$b64"))
                    )
                val body = JSONObject().put("model", model)
                    .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", content)))
                val resp = Llm.postJson("$base/chat/completions", mapOf("Authorization" to "Bearer ${k.key}"), body)
                val t = JSONObject(resp).optJSONArray("choices")?.optJSONObject(0)
                    ?.optJSONObject("message")?.optString("content").orEmpty()
                if (t.isBlank() || t == "null") throw LlmException("Empty response")
                return t
            }
        }
    }

    // ------------------------------------------------------------ image generation

    suspend fun generateImage(prompt: String): String = withContext(Dispatchers.IO) {
        val keys = S.keys.filter { it.enabled && it.key.isNotBlank() }
        val g = keys.firstOrNull { it.provider == "gemini" }
        val o = keys.firstOrNull { it.provider == "openai" }
        if (g == null && o == null) {
            return@withContext "ERROR: image generation needs a Gemini or OpenAI key (Settings > API Keys)."
        }
        var err = ""
        if (g != null) {
            try {
                val base = g.baseUrl.ifBlank { Provider.GEMINI.defBase }.trimEnd('/')
                val body = JSONObject()
                    .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
                    .put("generationConfig", JSONObject().put("responseModalities", JSONArray().put("TEXT").put("IMAGE")))
                val resp = Llm.postJson(
                    "$base/v1beta/models/gemini-2.5-flash-image:generateContent", mapOf("x-goog-api-key" to g.key), body
                )
                val parts = JSONObject(resp).optJSONArray("candidates")?.optJSONObject(0)
                    ?.optJSONObject("content")?.optJSONArray("parts")
                if (parts != null) {
                    for (i in 0 until parts.length()) {
                        val inl = parts.getJSONObject(i).optJSONObject("inlineData") ?: continue
                        val data = inl.optString("data")
                        if (data.isNotBlank()) {
                            val loc = save(Base64.decode(data, Base64.DEFAULT), inl.optString("mimeType", "image/png"))
                            return@withContext "Image created and saved to $loc"
                        }
                    }
                }
                err = "Gemini returned no image"
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                err = "Gemini: ${e.message}"
            }
        }
        if (o != null) {
            try {
                val base = o.baseUrl.ifBlank { Provider.OPENAI.defBase }.trimEnd('/')
                val body = JSONObject().put("model", "gpt-image-1").put("prompt", prompt).put("size", "1024x1024")
                val resp = Llm.postJson("$base/images/generations", mapOf("Authorization" to "Bearer ${o.key}"), body)
                val b64 = JSONObject(resp).optJSONArray("data")?.optJSONObject(0)?.optString("b64_json").orEmpty()
                if (b64.isNotBlank()) {
                    val loc = save(Base64.decode(b64, Base64.DEFAULT), "image/png")
                    return@withContext "Image created and saved to $loc"
                }
                err = "OpenAI returned no image"
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                err = "OpenAI: ${e.message}"
            }
        }
        "ERROR: $err"
    }

    private fun save(bytes: ByteArray, mime: String): String {
        val ext = if (mime.contains("jpeg") || mime.contains("jpg")) "jpg" else "png"
        val name = "SARP_${System.currentTimeMillis()}.$ext"
        val ctx = S.app
        if (Build.VERSION.SDK_INT >= 29) {
            val cv = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, name)
                put(MediaStore.Images.Media.MIME_TYPE, if (ext == "jpg") "image/jpeg" else "image/png")
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/SARP AI")
            }
            val uri = ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)
                ?: throw IllegalStateException("Cannot create image file")
            ctx.contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
            return "Pictures/SARP AI/$name"
        }
        val dir = ctx.getExternalFilesDir(Environment.DIRECTORY_PICTURES) ?: ctx.filesDir
        File(dir, name).writeBytes(bytes)
        return "${dir.absolutePath}/$name"
    }
}

/** Read-only email access over IMAP (Gmail: use an App Password). */
object Mail {
    private fun esc(s: String) = s.replace("\\", "\\\\").replace("\"", "\\\"")

    private fun decodeMime(s: String): String =
        Regex("=\\?([^?]+)\\?([BbQq])\\?([^?]*)\\?=").replace(s) { m ->
            try {
                val cs = try { Charset.forName(m.groupValues[1]) } catch (e: Exception) { Charsets.UTF_8 }
                val txt = m.groupValues[3]
                if (m.groupValues[2].equals("B", true)) {
                    String(Base64.decode(txt, Base64.DEFAULT), cs)
                } else {
                    val bos = ByteArrayOutputStream()
                    val t = txt.replace('_', ' ')
                    var i = 0
                    while (i < t.length) {
                        if (t[i] == '=' && i + 2 < t.length) {
                            bos.write(t.substring(i + 1, i + 3).toInt(16)); i += 3
                        } else { bos.write(t[i].code); i++ }
                    }
                    String(bos.toByteArray(), cs)
                }
            } catch (e: Exception) {
                m.value
            }
        }

    suspend fun read(count: Int, unreadOnly: Boolean, search: String): String = withContext(Dispatchers.IO) {
        if (S.emailAddress.isBlank() || S.emailPassword.isBlank()) {
            return@withContext "ERROR: email is not set. Ask the user to add email + app password in Settings > Integrations."
        }
        val host = S.emailHost.ifBlank { "imap.gmail.com" }
        val sock = SSLSocketFactory.getDefault().createSocket(host, 993) as SSLSocket
        sock.soTimeout = 25000
        try {
            val r = BufferedReader(InputStreamReader(sock.getInputStream(), Charsets.UTF_8))
            val w = BufferedWriter(OutputStreamWriter(sock.getOutputStream(), Charsets.UTF_8))
            r.readLine()
            var n = 0
            fun cmd(c: String): String {
                n++
                val tag = "a$n"
                w.write("$tag $c\r\n")
                w.flush()
                val sb = StringBuilder()
                while (true) {
                    val line = r.readLine() ?: break
                    sb.append(line).append('\n')
                    if (line.startsWith("$tag ")) break
                }
                return sb.toString()
            }

            val login = cmd("LOGIN \"${esc(S.emailAddress)}\" \"${esc(S.emailPassword)}\"")
            if (!login.contains(" OK")) {
                return@withContext "ERROR: email login failed. Gmail needs IMAP enabled and an App Password."
            }
            cmd("SELECT INBOX")
            val crit = StringBuilder(if (unreadOnly) "UNSEEN" else "ALL")
            if (search.isNotBlank() && search.all { it.code < 128 }) crit.append(" TEXT \"${esc(search)}\"")
            val sr = cmd("SEARCH $crit")
            val ids = Regex("\\* SEARCH([\\d ]*)").find(sr)?.groupValues?.get(1)?.trim()
                ?.split(" ")?.filter { it.isNotEmpty() } ?: emptyList()
            if (ids.isEmpty()) {
                cmd("LOGOUT")
                return@withContext "No matching emails."
            }
            val out = StringBuilder("Total matching: ${ids.size}. Newest first:\n")
            for (id in ids.takeLast(count.coerceIn(1, 10)).reversed()) {
                val m = cmd("FETCH $id (BODY.PEEK[HEADER.FIELDS (FROM SUBJECT DATE)] BODY.PEEK[TEXT]<0.1500>)")
                val clean = m.lines()
                    .filter { !it.startsWith("* ") && !Regex("^a\\d+ ").containsMatchIn(it) && it.trim() != ")" }
                    .joinToString("\n") { decodeMime(it) }.trim()
                if (Guard.hit(clean) != null) out.append("--- [hidden by your safety rules]\n")
                else out.append("--- ").append(clean.take(1800)).append('\n')
            }
            cmd("LOGOUT")
            out.append("(Bodies may be raw MIME text.)")
            out.toString()
        } catch (e: Exception) {
            "ERROR: email failed: ${e.message}"
        } finally {
            try { sock.close() } catch (e: Exception) { }
        }
    }
}
