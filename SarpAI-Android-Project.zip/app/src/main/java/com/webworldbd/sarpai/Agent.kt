package com.webworldbd.sarpai

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class AState { OFF, LISTENING, PAUSED, THINKING, SPEAKING }

data class LogLine(val time: Long, val kind: String, val text: String)

class ConfirmReq(val text: String, val deferred: CompletableDeferred<Boolean>)

/** The agent brain: turns a spoken/typed goal into a loop of JSON actions. Acts only on what the user asked. */
object Agent {
    private const val MAX_STEPS = 20

    val state = MutableStateFlow(AState.OFF)
    val log = MutableStateFlow<List<LogLine>>(emptyList())
    val busy = MutableStateFlow(false)
    val confirm = MutableStateFlow<ConfirmReq?>(null)
    val serviceRunning = MutableStateFlow(false)

    var pauseListening: (() -> Unit)? = null
    var resumeListening: (() -> Unit)? = null
    var muted = false

    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var job: Job? = null
    private var history = mutableListOf<Msg>()
    private var awaitingAnswer = false

    fun addLog(kind: String, text: String) {
        log.update { (it + LogLine(System.currentTimeMillis(), kind, text)).takeLast(200) }
    }

    fun clearLog() { log.value = emptyList() }

    private fun idleState(): AState =
        if (!serviceRunning.value) AState.OFF else if (muted) AState.PAUSED else AState.LISTENING

    // ------------------------------------------------------------ input

    /** Called with every recognised sentence while the agent is switched on. */
    fun handleSpoken(raw: String) {
        val t = raw.trim()
        if (t.isEmpty()) return
        if (confirm.value != null) { answerConfirm(t); return }
        if (isStop(t)) { if (busy.value) cancel(); return }
        if (busy.value) return
        if (S.wakeWordOn) {
            val words = S.wakeWords.split(",").map { it.trim().lowercase() }.filter { it.isNotEmpty() }
            val low = t.lowercase()
            val w = words.firstOrNull { low.contains(it) } ?: return
            val rest = t.substring(low.indexOf(w) + w.length).trim().trimStart(',', '.', '।', ' ')
            if (rest.isNotBlank()) submit(rest)
        } else submit(t)
    }

    fun submit(text: String) {
        val t = text.trim()
        if (t.isEmpty()) return
        if (busy.value) {
            if (isStop(t)) cancel() else addLog("error", tr("Agent is busy. Stop it first.", "এজেন্ট ব্যস্ত আছে। আগে থামান।"))
            return
        }
        busy.value = true
        job = scope.launch { runTask(t) }
    }

    fun cancel() {
        job?.cancel()
        confirm.value?.deferred?.complete(false)
        Speaker.stop()
        addLog("error", tr("Stopped.", "থামানো হয়েছে।"))
    }

    private fun isStop(t: String): Boolean {
        val l = t.lowercase().trim().trimEnd('.', '।', '!')
        return l in setOf("stop", "cancel", "stop it", "থামো", "থামুন", "বন্ধ করো", "বন্ধ করুন", "বাতিল")
    }

    // ------------------------------------------------------------ confirmation

    suspend fun askConfirm(desc: String): Boolean {
        if (!S.confirmSensitive) return true
        val d = CompletableDeferred<Boolean>()
        confirm.value = ConfirmReq(desc, d)
        val q = tr("Confirm: $desc. Say yes or no.", "নিশ্চিত করুন: $desc। হ্যাঁ বা না বলুন।")
        addLog("action", q)
        val speakJob = scope.launch { if (S.speakReplies) speakRaw(q) }
        val ok = withTimeoutOrNull(60_000) { d.await() } ?: false
        confirm.value = null
        speakJob.cancel()
        Speaker.stop()
        addLog("result", if (ok) tr("Allowed", "অনুমতি দেওয়া হয়েছে") else tr("Denied", "অনুমতি দেওয়া হয়নি"))
        return ok
    }

    fun answerConfirm(yes: Boolean) { confirm.value?.deferred?.complete(yes) }

    fun answerConfirm(text: String) {
        val t = text.lowercase()
        val tokens = t.split(Regex("[\\s,.!?।]+")).filter { it.isNotEmpty() }
        val no = setOf("no", "nope", "cancel", "stop", "না", "নাহ", "বাতিল", "থামো")
        val yes = setOf("yes", "yeah", "yep", "ok", "okay", "sure", "confirm", "হ্যাঁ", "হ্যা", "হাঁ", "ঠিক", "করো", "করুন", "ওকে", "অনুমতি")
        when {
            tokens.any { it in no } || t.contains("করো না") || t.contains("করবে না") -> answerConfirm(false)
            tokens.any { it in yes } -> answerConfirm(true)
        }
    }

    // ------------------------------------------------------------ speaking

    suspend fun speakRaw(text: String) {
        pauseListening?.invoke()
        state.value = AState.SPEAKING
        try {
            Speaker.speak(text)
        } finally {
            state.value = if (busy.value) AState.THINKING else idleState()
            if (!muted) resumeListening?.invoke()
        }
    }

    private suspend fun say(text: String, speak: Boolean) {
        if (text.isBlank()) return
        addLog("agent", text)
        if (speak && S.speakReplies) speakRaw(text)
    }

    // ------------------------------------------------------------ main loop

    private suspend fun runTask(input: String) {
        addLog("user", input)
        try {
            val b = Guard.hit(input)
            if (b != null) {
                say(tr("Blocked by your safety rules: \"$b\".", "আপনার নিষেধাজ্ঞা অনুযায়ী বন্ধ: \"$b\"।"), true)
                return
            }
            if (!awaitingAnswer) history = mutableListOf()
            history.add(Msg("user", if (awaitingAnswer) "USER ANSWER: $input" else "GOAL: $input"))
            awaitingAnswer = false
            val task = Router.classify(input)

            var steps = 0
            var invalid = 0
            while (steps < MAX_STEPS) {
                steps++
                state.value = AState.THINKING
                val reply = Router.run(task, systemPrompt(), trim(history)).second
                history.add(Msg("assistant", reply))

                val obj = extractJson(reply)
                if (obj == null) {
                    invalid++
                    if (invalid >= 2) {
                        say(reply.trim().take(1500), true)
                        return
                    }
                    history.add(Msg("user", "RESULT: Invalid format. Reply with exactly ONE JSON object and nothing else."))
                    continue
                }
                invalid = 0
                val sayText = obj.optString("say")
                val action = obj.optJSONObject("action")
                val type = action?.optString("type").orEmpty()

                if (action == null || type == "finish" || type.isEmpty()) {
                    val msg = sayText.ifBlank { action?.optString("summary").orEmpty() }
                    say(msg.ifBlank { tr("Done.", "হয়ে গেছে।") }, true)
                    return
                }
                if (type == "ask") {
                    awaitingAnswer = true
                    say(action.optString("question").ifBlank { sayText }, true)
                    return
                }
                if (sayText.isNotBlank()) addLog("agent", sayText)
                addLog("action", action.toString().take(180))

                val result = try {
                    Actions.perform(action)
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    "ERROR: ${e.message}"
                }
                addLog("result", result.take(300))
                history.add(Msg("user", "RESULT: ${result.take(6000)}"))
            }
            say(tr("Step limit reached. Tell me how to continue.", "ধাপের সীমা শেষ। কীভাবে এগোব বলুন।"), true)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            val m = e.message ?: "error"
            addLog("error", m)
            try { speakRaw(tr("Sorry, something went wrong.", "দুঃখিত, একটি সমস্যা হয়েছে।")) } catch (x: Exception) { }
        } finally {
            busy.value = false
            state.value = idleState()
        }
    }

    private fun trim(h: List<Msg>): List<Msg> =
        if (h.size <= 22) h else listOf(h.first()) + h.takeLast(20)

    private fun extractJson(s: String): JSONObject? {
        val a = s.indexOf('{')
        val b = s.lastIndexOf('}')
        if (a < 0 || b <= a) return null
        return try { JSONObject(s.substring(a, b + 1)) } catch (e: Exception) { null }
    }

    private fun systemPrompt(): String {
        val capLines = Cap.values().joinToString(", ") { "${it.key}=${if (Caps.allowed(S.app, it)) "ON" else "OFF"}" }
        val now = SimpleDateFormat("EEEE, d MMMM yyyy, HH:mm", Locale.ENGLISH).format(Date())
        val bio = S.biodata.ifBlank { "(not provided)" }
        val rules = S.rules.ifBlank { "(none)" }
        val blocked = S.blocked.ifBlank { "(none)" }
        return """
You are SARP AI, a personal agent that operates the user's Android phone on their behalf. Current time: $now.

CORE RULES
- Do ONLY what the user asked in this task. Never start extra tasks or act on your own initiative.
- Obey the user's rules below at all times. If a request violates them, politely refuse and finish.
- If you need information you do not have, or you hit a CAPTCHA, OTP, login or payment screen, use the "ask" action. Never invent passwords, codes or personal data.
- Be efficient: use as few steps as possible.

OUTPUT FORMAT
Every reply must be exactly ONE JSON object and nothing else (no markdown, no code fences):
{"say":"<short text for the user, in the user's language>","action":{"type":"...", ...}}

ACTIONS
{"type":"open_app","name":"YouTube"}
{"type":"open_url","url":"https://..."}
{"type":"read_screen"}   -> numbered list of visible elements
{"type":"tap","index":N}   or   {"type":"tap_text","text":"Search"}   or   {"type":"tap_xy","x":100,"y":200}
{"type":"type","text":"hello","submit":true}   -> types into the focused/first text field; submit presses Enter/Search
{"type":"scroll","direction":"down"}   (down|up)
{"type":"press","key":"back"}   (back|home|recents|notifications)
{"type":"wait","seconds":2}
{"type":"send_sms","to":"number or contact name","text":"..."}
{"type":"call","to":"number or contact name"}
{"type":"find_contact","name":"..."}
{"type":"read_notifications"}
{"type":"location"}
{"type":"web_fetch","url":"https://..."}   -> text of a web page
{"type":"analyze_screen","question":"what is on the screen?"}   -> screenshot analysed by a vision AI
{"type":"analyze_camera","question":"what is in this photo?"}   -> opens the camera, the user takes a photo, a vision AI answers
{"type":"generate_image","prompt":"detailed English description"}   -> creates an image, saved in Pictures/SARP AI
{"type":"read_email","count":5,"unread_only":true,"search":""}   -> reads the inbox (read-only; bodies may be raw MIME)
{"type":"github_create_repo","name":"my-site","private":false}
{"type":"github_push","repo":"owner/name","path":"index.html","content":"<full file text>","message":"commit message"}
{"type":"github_pages","repo":"owner/name"}   -> publishes the repo as a website
{"type":"set_voice","gender":"male"}   (male|female)
{"type":"set_language","lang":"bn"}   (bn|en)
{"type":"clipboard","text":"..."}
{"type":"ask","question":"..."}   -> ask the user, then stop and wait
{"type":"finish","summary":"..."}   -> task complete; "say" is what the user hears
After every action you receive "RESULT: ...". Continue until the task is complete, then use finish.

UI AUTOMATION TIPS
- After every open_app/open_url/tap/type/scroll/press you automatically receive "SCREEN NOW" (the visible elements), so read_screen is rarely needed. Use tap with an element index, or tap_text with visible text.
- To type: tap the field first, then use type. Use analyze_screen only when you must SEE images or layout that text cannot show.
- Example (YouTube): open_app YouTube -> tap the search icon -> type the query with submit:true -> tap the Nth video title.
- To write code or build a website: write the full files yourself, then use github_create_repo, github_push for each file, and github_pages.
- Video creation/editing is NOT supported; say so honestly if asked.
- Reply in the same language the user used (Bangla or English).

USER BIODATA (use it so you do not need to ask): $bio

USER RULES (must obey): $rules
BLOCKED apps/words (never touch): $blocked

CAPABILITY STATUS: $capLines
Actions that need an OFF capability will be denied; tell the user to enable it in Settings > Permissions.
""".trimIndent()
    }
}
