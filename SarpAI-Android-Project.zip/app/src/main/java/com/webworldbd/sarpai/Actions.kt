package com.webworldbd.sarpai

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.location.Location
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.provider.ContactsContract
import android.telephony.SmsManager
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject

/** Executes one agent action. Every action passes: safety rules -> capability check -> confirmation. */
object Actions {
    private val ctx: Context get() = S.app
    private val JSON_MT = "application/json; charset=utf-8".toMediaType()

    private val autoObserve = setOf("open_app", "open_url", "tap", "tap_text", "tap_xy", "type", "scroll", "press")
    private val guardedUi = setOf("read_screen", "tap", "tap_text", "tap_xy", "type", "scroll", "analyze_screen")

    suspend fun perform(a: JSONObject): String {
        val type = a.optString("type")

        val blocked = if (type in guardedUi) Guard.checkAction(a) else Guard.hit(a.toString())
        if (blocked != null) {
            return "BLOCKED by the user's safety rules (matched \"$blocked\"). Do not retry. Tell the user."
        }

        val need: Cap? = when (type) {
            "read_screen", "tap", "tap_text", "tap_xy", "type", "scroll", "press", "analyze_screen" -> Cap.SCREEN
            "analyze_camera" -> Cap.CAMERA
            "generate_image" -> Cap.WEB
            "read_email" -> Cap.EMAIL
            "send_sms" -> Cap.SMS
            "call" -> Cap.CALL
            "find_contact" -> Cap.CONTACTS
            "location" -> Cap.LOCATION
            "read_notifications" -> Cap.NOTIF_ACCESS
            "web_fetch" -> Cap.WEB
            "github_create_repo", "github_push", "github_pages" -> Cap.GITHUB
            else -> null
        }
        if (need != null && !Caps.allowed(ctx, need)) {
            return "DENIED: the \"${need.en}\" capability is not granted or is switched off. " +
                "Tell the user to enable it in SARP AI > Settings > Permissions."
        }

        sensitive(type, a)?.let { desc ->
            if (!Agent.askConfirm(desc)) return "USER DENIED this action. Do not retry it. Tell the user it was cancelled."
        }

        val res: String = when (type) {
            "open_app" -> openApp(a.optString("name"))
            "open_url" -> openUrl(a.optString("url"))
            "read_screen" -> svc().dump()
            "tap" -> svc().tapIndex(a.optInt("index", -1))
            "tap_text" -> svc().tapText(a.optString("text"))
            "tap_xy" -> svc().tapXY(a.optDouble("x", 0.0).toFloat(), a.optDouble("y", 0.0).toFloat())
            "type" -> svc().typeText(a.optString("text"), a.optBoolean("submit", false))
            "scroll" -> svc().scroll(a.optString("direction", "down"))
            "press" -> svc().press(a.optString("key", "back"))
            "wait" -> {
                delay((a.optDouble("seconds", 1.0).coerceIn(0.2, 15.0) * 1000).toLong())
                "Waited."
            }
            "send_sms" -> sendSms(a.optString("to"), a.optString("text"))
            "call" -> call(a.optString("to"))
            "find_contact" -> {
                val r = findContacts(a.optString("name"))
                if (r.isEmpty()) "No contact found." else r.joinToString("\n") { "${it.first}: ${it.second}" }
            }
            "location" -> location()
            "read_notifications" -> {
                val l = AgentNotificationListener.recent.filter { Guard.hit(it) == null }.take(20)
                if (l.isEmpty()) "No recent notifications." else l.joinToString("\n")
            }
            "web_fetch" -> webFetch(a.optString("url"))
            "analyze_screen" -> {
                val jpeg = svc().screenshotJpeg()
                    ?: return "ERROR: screenshot not available (needs Android 11+ and Screen control)."
                Media.vision(a.optString("question").ifBlank { "Describe what is on this phone screen." }, jpeg).second
            }
            "analyze_camera" -> {
                Agent.addLog("agent", tr("Camera opened. Take a photo.", "ক্যামেরা খুলেছে। একটি ছবি তুলুন।"))
                val jpeg = CameraCaptureActivity.capture(ctx) ?: return "ERROR: no photo was taken."
                Media.vision(a.optString("question").ifBlank { "Describe this photo." }, jpeg).second
            }
            "generate_image" -> Media.generateImage(a.optString("prompt"))
            "read_email" -> Mail.read(a.optInt("count", 5), a.optBoolean("unread_only", true), a.optString("search"))
            "github_create_repo" -> ghCreateRepo(a.optString("name"), a.optBoolean("private", false))
            "github_push" -> ghPush(a.optString("repo"), a.optString("path"), a.optString("content"), a.optString("message", "Update via SARP AI"))
            "github_pages" -> ghPages(a.optString("repo"))
            "set_voice" -> {
                val g = a.optString("gender").lowercase()
                if (g == "male" || g == "female") {
                    S.voiceGender = g
                    S.save()
                    "Voice changed to $g."
                } else "ERROR: gender must be male or female"
            }
            "set_language" -> {
                val l = a.optString("lang").lowercase()
                if (l == "bn" || l == "en") {
                    S.language = l
                    S.inputLang = if (l == "bn") "bn-BD" else "en-US"
                    S.save()
                    "Language changed to $l."
                } else "ERROR: lang must be bn or en"
            }
            "clipboard" -> {
                val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("SARP AI", a.optString("text")))
                "Copied to clipboard."
            }
            else -> "ERROR: unknown action type \"$type\"."
        }

        // The agent "sees" the screen automatically after every UI action.
        if (type in autoObserve && !res.startsWith("ERROR") && !res.startsWith("BLOCKED") && Caps.allowed(ctx, Cap.SCREEN)) {
            delay(600)
            val s = AgentAccessibilityService.instance ?: return res
            val hidden = Guard.hit(s.currentLabel() + " " + (s.currentPackage() ?: ""))
            return if (hidden != null) {
                "$res\nSCREEN NOW: hidden, the foreground app matches a blocked rule ($hidden)."
            } else {
                "$res\nSCREEN NOW:\n${s.dump()}"
            }
        }
        return res
    }

    private fun svc(): AgentAccessibilityService =
        AgentAccessibilityService.instance ?: throw IllegalStateException("Accessibility service is not running")

    private fun sensitive(type: String, a: JSONObject): String? = when (type) {
        "send_sms" -> "SMS to ${a.optString("to")}: \"${a.optString("text").take(100)}\""
        "call" -> "Call ${a.optString("to")}"
        "github_create_repo" -> "Create GitHub repository ${a.optString("name")}"
        "github_push" -> "Upload ${a.optString("path")} to GitHub repo ${a.optString("repo")}"
        "github_pages" -> "Publish website for ${a.optString("repo")} (GitHub Pages)"
        "tap_text" -> {
            val t = a.optString("text")
            if (Guard.risky(t) != null) "Tap \"$t\"" else null
        }
        "tap" -> {
            val l = AgentAccessibilityService.instance?.labelAt(a.optInt("index", -1)).orEmpty()
            if (Guard.risky(l) != null) "Tap \"$l\"" else null
        }
        else -> null
    }

    // ---------------------------------------------------------------- apps

    private suspend fun openApp(name: String): String {
        val pm = ctx.packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(q, 0)
        val n = name.trim().lowercase()
        if (n.isEmpty()) return "ERROR: app name missing"
        val match = apps.firstOrNull { it.activityInfo.packageName.equals(n, true) }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == n }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(n) }
            ?: apps.firstOrNull { it.activityInfo.packageName.lowercase().contains(n.replace(" ", "")) }
            ?: return "ERROR: no installed app matches \"$name\""
        val label = match.loadLabel(pm).toString()
        Guard.hit("$label ${match.activityInfo.packageName}")?.let {
            return "BLOCKED by the user's safety rules (matched \"$it\"). Do not retry."
        }
        val launch = pm.getLaunchIntentForPackage(match.activityInfo.packageName)
            ?: return "ERROR: cannot launch $label"
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(launch)
        delay(1800)
        return "Opened $label. Call read_screen to see it."
    }

    private suspend fun openUrl(url: String): String {
        if (!url.startsWith("http://") && !url.startsWith("https://")) return "ERROR: only http(s) links are allowed"
        val i = Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
        delay(1500)
        return "Opened $url"
    }

    // ---------------------------------------------------------------- contacts / sms / call / location

    private fun findContacts(q: String): List<Pair<String, String>> {
        val out = mutableListOf<Pair<String, String>>()
        val nameCol = ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME
        val numCol = ContactsContract.CommonDataKinds.Phone.NUMBER
        ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(nameCol, numCol), "$nameCol LIKE ?", arrayOf("%$q%"), null
        )?.use { c ->
            while (c.moveToNext() && out.size < 5) out.add((c.getString(0) ?: "") to (c.getString(1) ?: ""))
        }
        return out
    }

    private fun resolveNumber(to: String): String? {
        val digits = to.filter { it.isDigit() || it == '+' }
        if (digits.count { it.isDigit() } >= 5 && to.count { it.isLetter() } == 0) return digits
        if (!Caps.allowed(ctx, Cap.CONTACTS)) return null
        return findContacts(to).firstOrNull()?.second?.filter { it.isDigit() || it == '+' }
    }

    @Suppress("DEPRECATION")
    private fun sendSms(to: String, text: String): String {
        if (text.isBlank()) return "ERROR: empty message"
        val num = resolveNumber(to) ?: return "ERROR: could not find a number for \"$to\" (Contacts permission may be off)."
        val sm: SmsManager = if (Build.VERSION.SDK_INT >= 31) ctx.getSystemService(SmsManager::class.java) else SmsManager.getDefault()
        sm.sendMultipartTextMessage(num, null, sm.divideMessage(text), null, null)
        return "SMS sent to $num."
    }

    private fun call(to: String): String {
        val num = resolveNumber(to) ?: return "ERROR: could not find a number for \"$to\""
        val i = Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(num))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
        return "Calling $num."
    }

    private fun location(): String {
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        var best: Location? = null
        for (p in lm.getProviders(true)) {
            val l = try { lm.getLastKnownLocation(p) } catch (e: SecurityException) { null }
            val b = best
            if (l != null && (b == null || l.time > b.time)) best = l
        }
        val b = best ?: return "ERROR: no location available yet. Open a maps app once and retry."
        val ageMin = (System.currentTimeMillis() - b.time) / 60000
        return "Latitude ${b.latitude}, longitude ${b.longitude}, accuracy ${b.accuracy.toInt()} m, ${ageMin} min old."
    }

    // ---------------------------------------------------------------- web

    private suspend fun webFetch(url: String): String = withContext(Dispatchers.IO) {
        if (!url.startsWith("http://") && !url.startsWith("https://")) return@withContext "ERROR: bad url"
        val req = Request.Builder().url(url).header("User-Agent", "Mozilla/5.0 (Linux; Android) SARP-AI").build()
        Llm.http.newCall(req).execute().use { r ->
            val body = r.body?.string().orEmpty()
            val text = body
                .replace(Regex("(?is)<(script|style)[^>]*>.*?</\\1>"), " ")
                .replace(Regex("<[^>]+>"), " ")
                .replace(Regex("\\s+"), " ").trim()
            "HTTP ${r.code}: ${text.take(5000)}"
        }
    }

    // ---------------------------------------------------------------- GitHub

    private suspend fun gh(method: String, path: String, body: JSONObject? = null): Pair<Int, String> =
        withContext(Dispatchers.IO) {
            val rb = Request.Builder().url("https://api.github.com$path")
                .header("Authorization", "Bearer ${S.githubToken}")
                .header("Accept", "application/vnd.github+json")
                .header("X-GitHub-Api-Version", "2022-11-28")
            val payload = (body ?: JSONObject()).toString().toRequestBody(JSON_MT)
            val req = when (method) {
                "PUT" -> rb.put(payload)
                "POST" -> rb.post(payload)
                else -> rb.get()
            }.build()
            Llm.http.newCall(req).execute().use { it.code to (it.body?.string().orEmpty()) }
        }

    private fun needToken(): String? =
        if (S.githubToken.isBlank()) "ERROR: GitHub token missing. Ask the user to add it in Settings > Integrations." else null

    private suspend fun login(): String {
        if (S.githubUser.isNotBlank()) return S.githubUser
        val (c, b) = gh("GET", "/user")
        if (c != 200) throw IllegalStateException("GitHub auth failed (HTTP $c)")
        val l = JSONObject(b).optString("login")
        S.githubUser = l
        S.save()
        return l
    }

    private suspend fun fullRepo(repo: String): String = if (repo.contains("/")) repo else "${login()}/$repo"

    private suspend fun ghCreateRepo(name: String, priv: Boolean): String {
        needToken()?.let { return it }
        val safe = name.trim().replace(Regex("[^A-Za-z0-9._-]"), "-")
        if (safe.isEmpty()) return "ERROR: repository name missing"
        val (c, b) = gh(
            "POST", "/user/repos",
            JSONObject().put("name", safe).put("private", priv).put("auto_init", true)
                .put("description", "Created with SARP AI")
        )
        return if (c == 201) "Created ${JSONObject(b).optString("full_name")} (${JSONObject(b).optString("html_url")})"
        else "ERROR: HTTP $c ${b.take(300)}"
    }

    private suspend fun ghPush(repo: String, path: String, content: String, message: String): String {
        needToken()?.let { return it }
        if (repo.isBlank() || path.isBlank()) return "ERROR: repo and path are required"
        val full = fullRepo(repo)
        val enc = path.trim('/').split("/").joinToString("/") { Uri.encode(it) }
        val (gc, gb) = gh("GET", "/repos/$full/contents/$enc")
        val body = JSONObject().put("message", message)
            .put("content", Base64.encodeToString(content.toByteArray(Charsets.UTF_8), Base64.NO_WRAP))
        if (gc == 200) body.put("sha", JSONObject(gb).optString("sha"))
        val (c, b) = gh("PUT", "/repos/$full/contents/$enc", body)
        return if (c == 200 || c == 201) "Pushed $path to $full." else "ERROR: HTTP $c ${b.take(300)}"
    }

    private suspend fun ghPages(repo: String): String {
        needToken()?.let { return it }
        val full = fullRepo(repo)
        val (c, b) = gh("POST", "/repos/$full/pages", JSONObject().put("source", JSONObject().put("branch", "main").put("path", "/")))
        val parts = full.split("/")
        val url = "https://${parts[0]}.github.io/${parts.getOrElse(1) { "" }}/"
        return if (c == 201 || c == 409) "GitHub Pages enabled. Site URL (may take 1-2 minutes): $url"
        else "ERROR: HTTP $c ${b.take(300)}"
    }
}
