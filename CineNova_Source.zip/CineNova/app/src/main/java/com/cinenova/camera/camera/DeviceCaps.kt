package com.cinenova.camera.camera

import android.app.ActivityManager
import android.content.Context
import android.graphics.ImageFormat
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CameraMetadata
import android.os.Build
import android.util.Range
import android.util.Size

enum class PerfTier { HIGH, MID, LOW }

/** One physical/logical back or front camera and what it can really do. */
data class CamInfo(
    val id: String,
    val facing: Int,                       // CameraCharacteristics.LENS_FACING_*
    val focalLength: Float,                // mm, 0 if unknown
    val hasFlash: Boolean,
    val photoSizes: List<Size>,            // JPEG sizes, largest first
    val manualSensor: Boolean,             // MANUAL_SENSOR capability
    val manualFocus: Boolean,
    val isoRange: Range<Int>?,
    val exposureRangeNs: Range<Long>?,
    val minFocusDistance: Float,           // diopters, 0 = fixed focus
    val hdrScene: Boolean,
    val nightScene: Boolean,
    val videoStab: Boolean,
    val opticalStab: Boolean,
    val maxZoom: Float,
    val awbModes: List<Int>,
    val aeCompRange: Range<Int>?,
    val aeCompStep: Float,
    val fpsRanges: List<Range<Int>>
) {
    val isFront get() = facing == CameraCharacteristics.LENS_FACING_FRONT
}

/** Read once at start-up. Everything shown in the UI as "available" comes from here. */
class DeviceCaps(context: Context) {
    val cameras: List<CamInfo>
    val tier: PerfTier
    val ramMb: Long
    val cores: Int

    init {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        ramMb = mi.totalMem / (1024 * 1024)
        cores = Runtime.getRuntime().availableProcessors()
        tier = when {
            am.isLowRamDevice || ramMb < 3000 || cores <= 4 -> PerfTier.LOW
            ramMb >= 6000 && cores >= 8 && Build.VERSION.SDK_INT >= 29 -> PerfTier.HIGH
            else -> PerfTier.MID
        }
        cameras = readCameras(context)
    }

    val hasAnyCamera get() = cameras.isNotEmpty()
    val backCameras get() = cameras.filter { !it.isFront }
    val frontCameras get() = cameras.filter { it.isFront }

    /** The "main" camera for a facing: the one with the widest set of sizes / mid focal length. */
    fun mainCamera(front: Boolean): CamInfo? {
        val list = if (front) frontCameras else backCameras
        if (list.isEmpty()) return null
        if (front) return list.first()
        val sorted = list.sortedBy { it.focalLength }
        // main lens is generally the shortest focal length that is NOT ultra-wide (<~3.5mm on phones)
        return sorted.firstOrNull { it.focalLength >= 3.5f } ?: sorted.last()
    }

    /** Resolve a lens label for UI. */
    fun lensKind(info: CamInfo): LensKind {
        if (info.isFront) return LensKind.FRONT
        val back = backCameras.sortedBy { it.focalLength }
        if (back.size < 2) return LensKind.WIDE
        return when {
            info.id == back.first().id && info.focalLength < 3.5f -> LensKind.ULTRA
            info.id == back.last().id && back.size >= 2 && info.focalLength > 6f -> LensKind.TELE
            else -> LensKind.WIDE
        }
    }

    /** Live cinematic blur preview is allowed on every device, rate adapts to [tier]. */
    val livePreviewIntervalMs: Long
        get() = when (tier) {
            PerfTier.HIGH -> 66
            PerfTier.MID -> 120
            PerfTier.LOW -> 220
        }

    private fun readCameras(context: Context): List<CamInfo> {
        val mgr = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val out = ArrayList<CamInfo>()
        try {
            for (id in mgr.cameraIdList) {
                val c = mgr.getCameraCharacteristics(id)
                val facing = c.get(CameraCharacteristics.LENS_FACING) ?: continue
                if (facing == CameraCharacteristics.LENS_FACING_EXTERNAL) continue
                val caps = c.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES) ?: intArrayOf()
                val manualSensor = caps.contains(CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_MANUAL_SENSOR)
                val map = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
                val sizes = map?.getOutputSizes(ImageFormat.JPEG)?.sortedByDescending { it.width.toLong() * it.height }
                    ?: emptyList()
                if (sizes.isEmpty()) continue
                val minFocus = c.get(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE) ?: 0f
                val afModes = c.get(CameraCharacteristics.CONTROL_AF_AVAILABLE_MODES) ?: intArrayOf()
                val scenes = c.get(CameraCharacteristics.CONTROL_AVAILABLE_SCENE_MODES) ?: intArrayOf()
                val stab = c.get(CameraCharacteristics.CONTROL_AVAILABLE_VIDEO_STABILIZATION_MODES) ?: intArrayOf()
                val ois = c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION) ?: intArrayOf()
                val awb = c.get(CameraCharacteristics.CONTROL_AWB_AVAILABLE_MODES) ?: intArrayOf()
                val maxDigital = c.get(CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM) ?: 1f
                val focal = c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)?.firstOrNull() ?: 0f
                out += CamInfo(
                    id = id,
                    facing = facing,
                    focalLength = focal,
                    hasFlash = c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true,
                    photoSizes = sizes,
                    manualSensor = manualSensor,
                    manualFocus = minFocus > 0f && afModes.contains(CameraMetadata.CONTROL_AF_MODE_OFF) &&
                        caps.contains(CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_MANUAL_SENSOR),
                    isoRange = if (manualSensor) c.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE) else null,
                    exposureRangeNs = if (manualSensor) c.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE) else null,
                    minFocusDistance = minFocus,
                    hdrScene = scenes.contains(CameraMetadata.CONTROL_SCENE_MODE_HDR),
                    nightScene = scenes.contains(CameraMetadata.CONTROL_SCENE_MODE_NIGHT),
                    videoStab = stab.contains(CameraMetadata.CONTROL_VIDEO_STABILIZATION_MODE_ON),
                    opticalStab = ois.contains(CameraMetadata.LENS_OPTICAL_STABILIZATION_MODE_ON),
                    maxZoom = maxDigital,
                    awbModes = awb.toList(),
                    aeCompRange = c.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE),
                    aeCompStep = c.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_STEP)?.toFloat() ?: 0f,
                    fpsRanges = c.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)?.toList() ?: emptyList()
                )
            }
        } catch (e: Exception) {
            // camera service not reachable: report no cameras, UI shows a message
        }
        return out
    }
}

enum class LensKind { FRONT, ULTRA, WIDE, TELE }
