package com.cinenova.camera.ui

import android.graphics.Bitmap
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cinenova.camera.R
import com.cinenova.camera.camera.DeviceCaps
import com.cinenova.camera.camera.PerfTier
import com.cinenova.camera.data.AppSettings
import com.cinenova.camera.imaging.Adjustments
import com.cinenova.camera.imaging.CropSpec
import com.cinenova.camera.imaging.FilterEngine
import com.cinenova.camera.imaging.FilterId
import com.cinenova.camera.imaging.Geometry
import com.cinenova.camera.imaging.Look
import com.cinenova.camera.imaging.PortraitEngine
import com.cinenova.camera.imaging.Segmenter
import com.cinenova.camera.imaging.SubjectMask
import com.cinenova.camera.media.MediaStoreHelper
import kotlin.math.max
import kotlin.math.roundToInt
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private data class Edit(
    val rot: Int = 0,
    val flipH: Boolean = false,
    val flipV: Boolean = false,
    val ratio: Float = 0f,
    val zoom: Float = 1f,
    val panX: Float = 0f,
    val panY: Float = 0f,
    val filter: FilterId = FilterId.NATURAL,
    val second: FilterId? = null,
    val intensity: Int = 100,
    val adj: Adjustments = Adjustments(),
    val blur: Int = 0
) {
    fun look() = Look(filter, intensity, second, adj, false)
}

/** The whole edit pipeline. Never modifies [base]. */
private fun renderEdit(base: Bitmap, mask: SubjectMask?, e: Edit): Bitmap {
    var cur = base
    var owned = false
    if (e.blur > 0 && mask != null) {
        cur = PortraitEngine.render(cur, mask, e.blur); owned = true
    }
    val look = e.look()
    if (!look.isIdentity) {
        val n = FilterEngine.apply(cur, look)
        if (owned) cur.recycle()
        cur = n; owned = true
    }
    val g = Geometry.transform(cur, e.rot, e.flipH, e.flipV, CropSpec(e.ratio, e.zoom, e.panX, e.panY))
    if (owned && g !== cur) cur.recycle()
    return if (g === base) base.copy(Bitmap.Config.ARGB_8888, false) else g
}

@Composable
fun PhotoEditorScreen(
    uri: Uri,
    media: MediaStoreHelper,
    appSettings: AppSettings,
    caps: DeviceCaps,
    onBack: () -> Unit
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val set by appSettings.state.collectAsState()
    var base by remember { mutableStateOf<Bitmap?>(null) }
    var mask by remember { mutableStateOf<SubjectMask?>(null) }
    var maskTried by remember { mutableStateOf(false) }
    var edit by remember { mutableStateOf(Edit()) }
    var shown by remember { mutableStateOf<ImageBitmap?>(null) }
    var showOriginal by remember { mutableStateOf(false) }
    var tab by remember { mutableIntStateOf(0) }
    var saving by remember { mutableStateOf(false) }
    var note by remember { mutableStateOf<Int?>(null) }
    val segmenter = remember { Segmenter() }
    DisposableEffect(Unit) { onDispose { segmenter.close() } }

    LaunchedEffect(uri) {
        val b = media.loadBitmap(uri, 1080)
        base = b
        if (b != null) {
            val s = 640f / max(b.width, b.height)
            val small = if (s < 1f) Bitmap.createScaledBitmap(b, (b.width * s).roundToInt(), (b.height * s).roundToInt(), true) else b
            val m = withContext(Dispatchers.Default) { segmenter.segment(small, streaming = false) }
            if (small !== b) small.recycle()
            mask = m
            maskTried = true
        }
    }
    LaunchedEffect(base, mask, edit) {
        val b = base ?: return@LaunchedEffect
        delay(40)
        val r = withContext(Dispatchers.Default) { renderEdit(b, mask, edit) }
        shown = r.asImageBitmap()
    }

    val canBlur = mask?.hasSubject == true

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).statusBarsPadding().navigationBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            RoundIcon(Icons.Filled.ArrowBack, stringResource(R.string.back), onBack)
            Text(
                stringResource(R.string.ed_title), fontSize = 18.sp, fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground, modifier = Modifier.padding(start = 12.dp).weight(1f)
            )
            RoundIcon(Icons.Filled.Undo, stringResource(R.string.ed_restore), { edit = Edit() }, enabled = edit != Edit())
            Box(Modifier.padding(start = 8.dp)) {
                RoundIcon(
                    Icons.Filled.Check, stringResource(R.string.ed_save_copy),
                    {
                        val b = base
                        if (b != null && !saving) {
                            saving = true
                            scope.launch {
                                try {
                                    val side = when (caps.tier) { PerfTier.LOW -> 2048; PerfTier.MID -> 3072; PerfTier.HIGH -> 4096 }
                                    val full = media.loadBitmap(uri, side) ?: throw IllegalStateException()
                                    val out = withContext(Dispatchers.Default) { renderEdit(full, mask, edit) }
                                    media.saveBitmap(out, set.imageFormat, "_edit")
                                    out.recycle(); full.recycle()
                                    note = R.string.ed_saved
                                } catch (e: CancellationException) {
                                    throw e
                                } catch (e: Exception) {
                                    note = R.string.ed_save_failed
                                } catch (e: OutOfMemoryError) {
                                    note = R.string.ed_save_failed
                                } finally { saving = false }
                            }
                        }
                    },
                    active = true, enabled = base != null && !saving
                )
            }
        }

        Box(
            Modifier.weight(1f).fillMaxWidth().padding(horizontal = 8.dp)
                .pointerInput(Unit) {
                    detectTapGestures(onPress = { showOriginal = true; tryAwaitRelease(); showOriginal = false })
                },
            contentAlignment = Alignment.Center
        ) {
            val img = if (showOriginal) base?.asImageBitmap() else shown
            if (img != null) Image(img, null, contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize())
            else CircularProgressIndicator(color = Gold)
            Text(
                stringResource(R.string.ed_before_after), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.align(Alignment.BottomCenter).padding(4.dp)
            )
            if (saving) CircularProgressIndicator(color = Gold, modifier = Modifier.align(Alignment.TopCenter).padding(12.dp))
        }
        note?.let {
            Text(stringResource(it), color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(horizontal = 16.dp, vertical = 2.dp), fontSize = 13.sp)
            LaunchedEffect(it) { delay(2500); note = null }
        }

        Row(Modifier.padding(horizontal = 12.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Pill(stringResource(R.string.ed_filters), tab == 0, { tab = 0 })
            Pill(stringResource(R.string.ed_adjust), tab == 1, { tab = 1 })
            Pill(stringResource(R.string.ed_crop), tab == 2, { tab = 2 })
            Pill(stringResource(R.string.adj_blur), tab == 3, { tab = 3 })
        }
        Column(
            Modifier.fillMaxWidth().heightIn(max = 230.dp).verticalScroll(rememberScrollState()).padding(horizontal = 14.dp, vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            when (tab) {
                0 -> {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(FilterId.values().size) { i ->
                            val f = FilterId.values()[i]
                            Pill(stringResource(f.nameRes), edit.filter == f, { edit = edit.copy(filter = f) })
                        }
                    }
                    LabeledSlider(
                        stringResource(R.string.filter_intensity), edit.intensity.toFloat(), 0f..100f,
                        { edit = edit.copy(intensity = it.roundToInt()) }, "${edit.intensity}%"
                    )
                    Text(stringResource(R.string.filter_second), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        item { Pill(stringResource(R.string.off), edit.second == null, { edit = edit.copy(second = null) }) }
                        items(FilterId.values().size) { i ->
                            val f = FilterId.values()[i]
                            Pill(stringResource(f.nameRes), edit.second == f, { edit = edit.copy(second = f) })
                        }
                    }
                }
                1 -> {
                    val a = edit.adj
                    LabeledSlider(stringResource(R.string.adj_brightness), a.brightness.toFloat(), -100f..100f, { edit = edit.copy(adj = a.copy(brightness = it.roundToInt())) }, "${a.brightness}")
                    LabeledSlider(stringResource(R.string.adj_contrast), a.contrast.toFloat(), -100f..100f, { edit = edit.copy(adj = a.copy(contrast = it.roundToInt())) }, "${a.contrast}")
                    LabeledSlider(stringResource(R.string.adj_saturation), a.saturation.toFloat(), -100f..100f, { edit = edit.copy(adj = a.copy(saturation = it.roundToInt())) }, "${a.saturation}")
                    LabeledSlider(stringResource(R.string.adj_sharpness), a.sharpness.toFloat(), 0f..100f, { edit = edit.copy(adj = a.copy(sharpness = it.roundToInt())) }, "${a.sharpness}")
                    LabeledSlider(stringResource(R.string.adj_temperature), a.temperature.toFloat(), -100f..100f, { edit = edit.copy(adj = a.copy(temperature = it.roundToInt())) }, "${a.temperature}")
                    LabeledSlider(stringResource(R.string.adj_denoise), a.denoise.toFloat(), 0f..100f, { edit = edit.copy(adj = a.copy(denoise = it.roundToInt())) }, "${a.denoise}")
                }
                2 -> {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        val opts = listOf(
                            0f to R.string.ed_crop_free, 1f to R.string.ed_crop_square, 4f / 3f to R.string.ed_crop_43,
                            3f / 4f to R.string.ed_crop_34, 16f / 9f to R.string.ed_crop_169, 9f / 16f to R.string.ed_crop_916
                        )
                        items(opts.size) { i ->
                            Pill(stringResource(opts[i].second), edit.ratio == opts[i].first, { edit = edit.copy(ratio = opts[i].first, panX = 0f, panY = 0f) })
                        }
                    }
                    LabeledSlider(stringResource(R.string.ed_crop), edit.zoom, 1f..3f, { edit = edit.copy(zoom = it) }, String.format(java.util.Locale.US, "%.1fx", edit.zoom))
                    LabeledSlider("X", edit.panX, -1f..1f, { edit = edit.copy(panX = it) }, String.format(java.util.Locale.US, "%.1f", edit.panX))
                    LabeledSlider("Y", edit.panY, -1f..1f, { edit = edit.copy(panY = it) }, String.format(java.util.Locale.US, "%.1f", edit.panY))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Pill(stringResource(R.string.ed_rotate), false, { edit = edit.copy(rot = (edit.rot + 1) % 4) })
                        Pill(stringResource(R.string.ed_flip_h), edit.flipH, { edit = edit.copy(flipH = !edit.flipH) })
                        Pill(stringResource(R.string.ed_flip_v), edit.flipV, { edit = edit.copy(flipV = !edit.flipV) })
                    }
                }
                else -> {
                    when {
                        !maskTried -> Text(stringResource(R.string.loading), color = MaterialTheme.colorScheme.onSurfaceVariant)
                        !canBlur -> Text(stringResource(R.string.ed_blur_unavailable), color = MaterialTheme.colorScheme.primary)
                        else -> LabeledSlider(
                            stringResource(R.string.adj_blur), edit.blur.toFloat(), 0f..100f,
                            { edit = edit.copy(blur = it.roundToInt()) }, "${edit.blur}%"
                        )
                    }
                }
            }
        }
    }
}
