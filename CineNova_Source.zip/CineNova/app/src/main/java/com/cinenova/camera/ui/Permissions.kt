package com.cinenova.camera.ui

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat

fun Context.granted(p: String): Boolean =
    ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

/** Camera permission, plus storage write on Android 8/9 (newer Android needs none to save its own media). */
fun cameraPermissions(): Array<String> =
    if (Build.VERSION.SDK_INT < 29) arrayOf(Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE)
    else arrayOf(Manifest.permission.CAMERA)

/** Permissions used to read the user's CineNova media back, by Android version. */
fun mediaReadPermissions(): Array<String> = when {
    Build.VERSION.SDK_INT >= 33 -> arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO)
    else -> arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
}

fun Context.hasMediaRead(): Boolean = mediaReadPermissions().all { granted(it) }
