package com.cinenova.camera.camera

import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Matrix
import android.graphics.RectF
import android.hardware.camera2.CaptureRequest
import android.hardware.camera2.CameraMetadata
import android.media.MediaActionSound
import android.net.Uri
import android.os.Build
import android.os.SystemClock
import android.provider.MediaStore
import android.util.Range
import android.util.Size
import androidx.annotation.StringRes
import androidx.camera.camera2.interop.Camera2CameraControl
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.camera2.interop.Camera2Interop
import androidx.camera.camera2.interop.CaptureRequestOptions
import androidx.camera.core.AspectRatio
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.core.UseCase
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import com.cinenova.camera.R
import com.cinenova.camera.data.AppSettings
import com.cinenova.camera.imaging.FilterEngine
import com.cinenova.camera.imaging.PortraitEngine
import com.cinenova.camera.imaging.PortraitLight
import com.cinenova.camera.imaging.SubjectMask
import com.cinenova.camera.imaging.Segmenter
import com.cinenova.camera.imaging.awaitResult
import com.cinenova.camera.imaging.toLook
import com.cinenova.camera.media.MediaStoreHelper
import com.cinenova.camera.media.StorageFullException
import com.cinenova.camera.media.VideoProcessor
import com.google.common.util.concurrent.ListenableFuture
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import com.google.mlkit.vision.face.FaceLandmark
import java.io.File
import java.io.IOException
import java.util.concurrent.Executor
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

enum class CamMode { PHOTO, PORTRAIT, VIDEO, PRO }

data class UiMessage(val id: Long, @StringRes val res: Int, val arg: Int? = null)

data class CamState(
    val cameraId: String = "",
    val front: Boolean = false,
    val bound: Boolean = false,
    val zoom: Float = 1f,
    val minZoom: Float = 1f,
    val maxZoom: Float = 1f,
    val evIndex: Int = 0,
    val evMin: Int = 0,
    val evMax: Int = 0,
    val focusLocked: Boolean = false,
    val focusPoint: Pair<Float, Float>? = null,
    val countdown: Int = 0,
    val busy: Boolean = false,
    val recording: Boolean = false,
    val paused: Boolean = false,
    val recordMs: Long = 0,
    val processingPct: Int = -1,
    val faceBox: RectF? = null,
    val overlay: Bitmap? = null,
    val peaking: Bitmap? = null,
    val message: UiMessage? = null,
    // portrait
    val blur: Int = 45,
    val light: PortraitLight = PortraitLight.NONE,
    val night: Boolean = false,
    // video
    val cinematic: Boolean = false,
    val videoQualities: List<String> = emptyList(),
    val fpsOptions: List<Int> = listOf(24, 30),
    // pro
    val peakingOn: Boolean = false,
    val proIso: Int = 0,           // 0 = auto
    val proShutterNs: Long = 0L,   // 0 = auto
    val proFocus: Float = -1f,     // -1 = auto, else 0 (far) .. 1 (near)
    val proWb: Int = CameraMetadata.CONTROL_AWB_MODE_AUTO,
    // last saved item, for gallery thumbnail refresh
    val savedCounter: Int = 0,
    val rebindTick: Int = 0
)

private suspend fun <T> ListenableFuture<T>.awaitFuture(): T = suspendCancellableCoroutine { c ->
    addListener({
        try { c.resume(get()) } catch (e: Exception) { c.resumeWithException(e) }
    }, Executor { it.run() })
}

/**
 * Owns CameraX. Everything the UI shows as available is read from [DeviceCaps].
 * No Android view is held except the PreviewView needed for tap-to-focus mapping.
 */
class CameraController(
    private val app: Context,
    val caps: DeviceCaps,
    private val settings: AppSettings,
    private val media: MediaStoreHelper
) {
    private val mainExecutor = ContextCompat.getMainExecutor(app)
    private val analysisExecutor = Executors.newSingleThreadExecutor()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val bgScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val analysisScope = CoroutineScope(SupervisorJob() + analysisExecutor.asCoroutineDispatcher())

    private val _state = MutableStateFlow(
        CamState(blur = settings.value.defaultBlur)
    )
    val state: StateFlow<CamState> = _state.asStateFlow()

    private var provider: ProcessCameraProvider? = null
    private var camera: Camera? = null
    private var imageCapture: ImageCapture? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var recording: Recording? = null
    private var mode = CamMode.PHOTO
    private var previewView: PreviewView? = null
    private var timerJob: Job? = null
    private var processingJob: Job? = null
    private var msgId = 0L
    private var shutterSound: MediaActionSound? = null

    private val segmenter = Segmenter()
    private val faceDetector by lazy {
        FaceDetection.getClient(
            FaceDetectorOptions.Builder()
                .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
                .setLandmarkMode(FaceDetectorOptions.LANDMARK_MODE_ALL)
                .setMinFaceSize(0.12f)
                .build()
        )
    }
    private val videoProcessor = VideoProcessor(app, media)

    @Volatile private var analyzing = false
    @Volatile private var lastAnalysis = 0L
    private var prevMask: SubjectMask? = null
    private var lastFocusTarget: Pair<Float, Float>? = null
    private var lastFocusAt = 0L
    private var missedFaces = 0
    private var noSubjectFrames = 0

    // ------------------------------------------------------------------ helpers

    private fun say(@StringRes res: Int, arg: Int? = null) {
        _state.update { it.copy(message = UiMessage(++msgId, res, arg)) }
    }

    fun currentInfo(): CamInfo? = caps.cameras.firstOrNull { it.id == _state.value.cameraId }

    fun hasMic(): Boolean =
        ContextCompat.checkSelfPermission(app, android.Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    /** 4:3 JPEG sizes the camera really offers, a handful of distinct megapixel levels. */
    fun photoSizeOptions(): List<Size> {
        val info = currentInfo() ?: return emptyList()
        val seen = HashSet<Int>()
        return info.photoSizes
            .filter { abs(it.width.toFloat() / it.height - 4f / 3f) < 0.02f && it.width * it.height >= 2_000_000 }
            .filter { seen.add((it.width.toLong() * it.height / 100_000L).toInt()) }
            .take(5)
    }

    /** The size used when the user hasn't chosen one: biggest up to ~12.5 MP. */
    private fun autoPhotoSize(info: CamInfo): Size? =
        info.photoSizes.firstOrNull {
            abs(it.width.toFloat() / it.height - 4f / 3f) < 0.02f && it.width.toLong() * it.height <= 12_600_000L
        }

    private fun targetPhotoSize(info: CamInfo): Size? {
        val chosen = settings.value.photoSize
        if (chosen.isNotEmpty()) {
            val p = chosen.split("x")
            if (p.size == 2) {
                val w = p[0].toIntOrNull()
                val h = p[1].toIntOrNull()
                if (w != null && h != null && info.photoSizes.any { it.width == w && it.height == h }) return Size(w, h)
            }
        }
        return autoPhotoSize(info)
    }

    // ------------------------------------------------------------------ binding

    private var wantedId = ""

    private fun chooseCameraId(): String {
        if (wantedId.isNotEmpty() && caps.cameras.any { it.id == wantedId }) return wantedId
        val wantFront = settings.value.lens == "front"
        return (caps.mainCamera(wantFront) ?: caps.mainCamera(!wantFront))?.id ?: ""
    }

    /** (Re)binds the camera for [newMode]. Safe to call repeatedly. */
    suspend fun bind(owner: LifecycleOwner, view: PreviewView, newMode: CamMode) {
        previewView = view
        mode = newMode
        if (!caps.hasAnyCamera) { say(R.string.no_camera); return }
        val camId = chooseCameraId()
        val info = caps.cameras.firstOrNull { it.id == camId } ?: run { say(R.string.no_camera); return }
        val prov = try {
            provider ?: ProcessCameraProvider.getInstance(app).awaitFuture().also { provider = it }
        } catch (e: Exception) { say(R.string.camera_error); return }

        val s = settings.value
        prov.unbindAll()
        recording = null
        analyzing = false
        prevMask = null
        _state.update {
            it.copy(
                cameraId = camId, front = info.isFront, bound = false, overlay = null, peaking = null,
                faceBox = null, recording = false, paused = false, recordMs = 0, focusLocked = false,
                focusPoint = null
            )
        }

        val selector = CameraSelector.Builder()
            .addCameraFilter { list -> list.filter { Camera2CameraInfo.from(it).cameraId == info.id } }
            .build()
        val avail = selector.filter(prov.availableCameraInfos)
        val camInfo = avail.firstOrNull()
        val supportedQ = if (camInfo != null) QualitySelector.getSupportedQualities(camInfo) else emptyList()
        val qualityKeys = listOf(Quality.HD to "HD", Quality.FHD to "FHD", Quality.UHD to "UHD")
            .filter { supportedQ.contains(it.first) }.map { it.second }
            .ifEmpty { if (supportedQ.contains(Quality.SD)) listOf("SD") else emptyList() }
        val fps = ArrayList<Int>().apply {
            add(24); add(30)
            if (info.fpsRanges.any { it.upper >= 60 && it.lower <= 60 }) add(60)
        }
        _state.update { it.copy(videoQualities = qualityKeys, fpsOptions = fps) }

        val ratio = if (mode == CamMode.VIDEO) AspectRatio.RATIO_16_9 else AspectRatio.RATIO_4_3
        val aspect = AspectRatioStrategy(ratio, AspectRatioStrategy.FALLBACK_RULE_AUTO)

        fun build(withAnalysis: Boolean, fpsTarget: Int): List<UseCase> {
            val list = ArrayList<UseCase>()
            val previewB = Preview.Builder()
                .setResolutionSelector(ResolutionSelector.Builder().setAspectRatioStrategy(aspect).build())
            if (mode == CamMode.VIDEO && s.stabilization && info.videoStab) {
                Camera2Interop.Extender(previewB).setCaptureRequestOption(
                    CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE,
                    CameraMetadata.CONTROL_VIDEO_STABILIZATION_MODE_ON
                )
            }
            val preview = previewB.build().also { it.setSurfaceProvider(view.surfaceProvider) }
            list += preview

            if (mode == CamMode.VIDEO) {
                val q = when (s.videoQuality) { "UHD" -> Quality.UHD; "HD" -> Quality.HD; "SD" -> Quality.SD; else -> Quality.FHD }
                val baseRate = when (q) {
                    Quality.UHD -> 48_000_000
                    Quality.FHD -> 18_000_000
                    Quality.HD -> 9_000_000
                    else -> 3_500_000
                }
                val bitrate = if (fpsTarget >= 50) baseRate * 3 / 2 else baseRate
                val recorder = Recorder.Builder()
                    .setQualitySelector(QualitySelector.from(q, FallbackStrategy.lowerQualityOrHigherThan(q)))
                    .setTargetVideoEncodingBitRate(bitrate)
                    .build()
                val vb = VideoCapture.Builder(recorder)
                Camera2Interop.Extender(vb).setCaptureRequestOption(
                    CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, Range(fpsTarget, fpsTarget)
                )
                if (s.stabilization && info.videoStab) {
                    Camera2Interop.Extender(vb).setCaptureRequestOption(
                        CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE,
                        CameraMetadata.CONTROL_VIDEO_STABILIZATION_MODE_ON
                    )
                }
                val vc = vb.build()
                videoCapture = vc
                imageCapture = null
                list += vc
            } else {
                val rsB = ResolutionSelector.Builder().setAspectRatioStrategy(aspect)
                val target = targetPhotoSize(info)
                if (target != null) {
                    rsB.setResolutionFilter { sizes, _ ->
                        val ordered = ArrayList(sizes)
                        val idx = ordered.indexOfFirst { it.width == target.width && it.height == target.height }
                        if (idx > 0) { val t = ordered.removeAt(idx); ordered.add(0, t) }
                        else if (idx < 0) {
                            ordered.sortBy { abs(it.width.toLong() * it.height - target.width.toLong() * target.height) }
                        }
                        ordered
                    }
                }
                val ic = ImageCapture.Builder()
                    .setResolutionSelector(rsB.build())
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                    .setJpegQuality(95)
                    .build()
                imageCapture = ic
                videoCapture = null
                list += ic
            }

            if (withAnalysis) {
                val ia = ImageAnalysis.Builder()
                    .setResolutionSelector(
                        ResolutionSelector.Builder()
                            .setAspectRatioStrategy(aspect)
                            .setResolutionStrategy(
                                ResolutionStrategy(Size(640, 480), ResolutionStrategy.FALLBACK_RULE_CLOSEST_LOWER_THEN_HIGHER)
                            ).build()
                    )
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                    .build()
                ia.setAnalyzer(analysisExecutor) { onFrame(it) }
                list += ia
            }
            return list
        }

        val wantedFps = if (s.videoFps in _state.value.fpsOptions) s.videoFps else 30
        var bound: Camera? = null
        val attempts = listOf(true to wantedFps, false to wantedFps, false to 30)
        for ((analysis, f) in attempts) {
            try {
                prov.unbindAll()
                val cases = build(analysis, f)
                bound = prov.bindToLifecycle(owner, selector, *cases.toTypedArray())
                if (f != wantedFps) say(R.string.camera_error)
                break
            } catch (e: Exception) {
                bound = null
            }
        }
        if (bound == null) { say(R.string.camera_error); return }
        camera = bound

        val z = bound.cameraInfo.zoomState.value
        val ev = bound.cameraInfo.exposureState
        val range = ev.exposureCompensationRange
        _state.update {
            it.copy(
                bound = true,
                zoom = z?.minZoomRatio?.coerceAtLeast(1f) ?: 1f,
                minZoom = z?.minZoomRatio ?: 1f,
                maxZoom = min(z?.maxZoomRatio ?: 1f, 10f),
                evIndex = 0, evMin = range.lower, evMax = range.upper
            )
        }
        applyFlash()
        applyCaptureOptions()
        val startZoom = z?.minZoomRatio?.coerceAtLeast(1f) ?: 1f
        bound.cameraControl.setZoomRatio(startZoom)
        bound.cameraControl.setExposureCompensationIndex(0)
    }

    fun unbind() {
        timerJob?.cancel()
        if (_state.value.recording) stopRecording()
        provider?.unbindAll()
        camera = null
        _state.update { it.copy(bound = false, overlay = null, peaking = null, faceBox = null) }
    }

    fun release() {
        unbind()
        segmenter.close()
        runCatching { faceDetector.close() }
        shutterSound?.release()
        analysisExecutor.shutdown()
    }

    // ------------------------------------------------------------------ camera selection

    fun switchFacing() {
        val s = _state.value
        val target = caps.mainCamera(!s.front) ?: return
        settings.update { it.copy(lens = if (target.isFront) "front" else "back") }
        wantedId = target.id
        _state.update { it.copy(rebindTick = it.rebindTick + 1) }
    }

    /** Used by Settings: make the main camera of that facing the active one. */
    fun selectDefaultLens(front: Boolean) {
        val target = caps.mainCamera(front) ?: return
        if (target.id == wantedId) return
        wantedId = target.id
        _state.update { it.copy(rebindTick = it.rebindTick + 1) }
    }

    fun selectCamera(id: String) {
        if (caps.cameras.none { it.id == id } || id == wantedId) return
        wantedId = id
        _state.update { it.copy(rebindTick = it.rebindTick + 1) }
    }

    // ------------------------------------------------------------------ simple controls

    fun setZoom(ratio: Float) {
        val s = _state.value
        val z = ratio.coerceIn(s.minZoom, s.maxZoom)
        camera?.cameraControl?.setZoomRatio(z)
        _state.update { it.copy(zoom = z) }
    }

    fun setEvIndex(idx: Int) {
        val s = _state.value
        val i = idx.coerceIn(s.evMin, s.evMax)
        camera?.cameraControl?.setExposureCompensationIndex(i)
        _state.update { it.copy(evIndex = i) }
    }

    fun evLabel(): String {
        val step = camera?.cameraInfo?.exposureState?.exposureCompensationStep?.toFloat() ?: 0f
        val v = _state.value.evIndex * step
        return String.format(java.util.Locale.US, "%+.1f", v)
    }

    fun tapFocus(x: Float, y: Float, viewW: Float, viewH: Float) {
        val v = previewView ?: return
        val cam = camera ?: return
        val pt = v.meteringPointFactory.createPoint(x, y)
        val builder = FocusMeteringAction.Builder(pt, FocusMeteringAction.FLAG_AF or FocusMeteringAction.FLAG_AE)
        if (_state.value.focusLocked) builder.disableAutoCancel() else builder.setAutoCancelDuration(4, TimeUnit.SECONDS)
        cam.cameraControl.startFocusAndMetering(builder.build())
        _state.update { it.copy(focusPoint = x / viewW to y / viewH) }
        lastFocusTarget = null
    }

    fun toggleFocusLock() {
        val cam = camera ?: return
        val locked = _state.value.focusLocked
        if (locked) {
            cam.cameraControl.cancelFocusAndMetering()
            _state.update { it.copy(focusLocked = false) }
            say(R.string.focus_unlocked)
        } else {
            val v = previewView ?: return
            val p = _state.value.focusPoint ?: (0.5f to 0.5f)
            val pt = v.meteringPointFactory.createPoint(p.first * v.width, p.second * v.height)
            cam.cameraControl.startFocusAndMetering(
                FocusMeteringAction.Builder(pt, FocusMeteringAction.FLAG_AF or FocusMeteringAction.FLAG_AE)
                    .disableAutoCancel().build()
            )
            _state.update { it.copy(focusLocked = true, focusPoint = p) }
            say(R.string.focus_locked)
        }
    }

    fun setFlash(value: Int) {
        val info = currentInfo()
        if (info == null || !info.hasFlash) { say(R.string.flash_unavailable); return }
        settings.update { it.copy(flash = value) }
        applyFlash()
    }

    fun applyFlash() {
        val info = currentInfo() ?: return
        val f = settings.value.flash
        if (!info.hasFlash) { camera?.cameraControl?.enableTorch(false); return }
        imageCapture?.flashMode = when (f) {
            1 -> ImageCapture.FLASH_MODE_AUTO
            2 -> ImageCapture.FLASH_MODE_ON
            else -> ImageCapture.FLASH_MODE_OFF
        }
        camera?.cameraControl?.enableTorch(mode == CamMode.VIDEO && f == 2)
    }

    fun notifyHdrUnsupported() = say(R.string.hdr_unsupported)
    fun notifyNightUnsupported() = say(R.string.night_unsupported)

    fun setBlur(v: Int) = _state.update { it.copy(blur = v.coerceIn(0, 100)) }
    fun setLight(l: PortraitLight) = _state.update { it.copy(light = l) }
    fun setNight(on: Boolean) { _state.update { it.copy(night = on) }; applyCaptureOptions() }
    fun setCinematic(on: Boolean) = _state.update { it.copy(cinematic = on, overlay = null) }
    fun setPeaking(on: Boolean) = _state.update { it.copy(peakingOn = on, peaking = null) }

    // ------------------------------------------------------------------ Pro controls

    fun setIso(v: Int) { _state.update { it.copy(proIso = v) }; applyCaptureOptions() }
    fun setShutter(ns: Long) { _state.update { it.copy(proShutterNs = ns) }; applyCaptureOptions() }
    fun setManualFocus(v: Float) { _state.update { it.copy(proFocus = v) }; applyCaptureOptions() }
    fun setWb(mode: Int) { _state.update { it.copy(proWb = mode) }; applyCaptureOptions() }
    fun resetPro() {
        _state.update {
            it.copy(proIso = 0, proShutterNs = 0L, proFocus = -1f, proWb = CameraMetadata.CONTROL_AWB_MODE_AUTO)
        }
        applyCaptureOptions()
    }

    /** Applies the user's settings and Pro values straight to the camera sensor (Camera2 interop). */
    fun applyCaptureOptions() {
        val cam = camera ?: return
        val info = currentInfo() ?: return
        val s = _state.value
        val set = settings.value
        val b = CaptureRequestOptions.Builder()

        var afOff = false
        if (mode == CamMode.PRO) {
            if (info.manualSensor && (s.proIso > 0 || s.proShutterNs > 0L)) {
                val isoR = info.isoRange
                val expR = info.exposureRangeNs
                val iso = if (s.proIso > 0) s.proIso else 100
                val ns = if (s.proShutterNs > 0L) s.proShutterNs else 16_666_666L
                b.setCaptureRequestOption(CaptureRequest.CONTROL_AE_MODE, CameraMetadata.CONTROL_AE_MODE_OFF)
                b.setCaptureRequestOption(
                    CaptureRequest.SENSOR_SENSITIVITY, if (isoR != null) iso.coerceIn(isoR.lower, isoR.upper) else iso
                )
                b.setCaptureRequestOption(
                    CaptureRequest.SENSOR_EXPOSURE_TIME, if (expR != null) ns.coerceIn(expR.lower, expR.upper) else ns
                )
            }
            if (info.manualFocus && s.proFocus >= 0f) {
                afOff = true
                b.setCaptureRequestOption(CaptureRequest.CONTROL_AF_MODE, CameraMetadata.CONTROL_AF_MODE_OFF)
                b.setCaptureRequestOption(CaptureRequest.LENS_FOCUS_DISTANCE, s.proFocus * info.minFocusDistance)
            }
            if (s.proWb != CameraMetadata.CONTROL_AWB_MODE_AUTO && info.awbModes.contains(s.proWb)) {
                b.setCaptureRequestOption(CaptureRequest.CONTROL_AWB_MODE, s.proWb)
            }
        }
        if (!afOff && !set.autofocus) {
            b.setCaptureRequestOption(CaptureRequest.CONTROL_AF_MODE, CameraMetadata.CONTROL_AF_MODE_AUTO)
        }
        if (s.night && info.nightScene && mode != CamMode.VIDEO && mode != CamMode.PRO) {
            b.setCaptureRequestOption(CaptureRequest.CONTROL_MODE, CameraMetadata.CONTROL_MODE_USE_SCENE_MODE)
            b.setCaptureRequestOption(CaptureRequest.CONTROL_SCENE_MODE, CameraMetadata.CONTROL_SCENE_MODE_NIGHT)
        } else if (set.hdr && info.hdrScene && mode != CamMode.VIDEO) {
            b.setCaptureRequestOption(CaptureRequest.CONTROL_MODE, CameraMetadata.CONTROL_MODE_USE_SCENE_MODE)
            b.setCaptureRequestOption(CaptureRequest.CONTROL_SCENE_MODE, CameraMetadata.CONTROL_SCENE_MODE_HDR)
        }
        try { Camera2CameraControl.from(cam.cameraControl).setCaptureRequestOptions(b.build()) } catch (_: Exception) {}
    }

    // ------------------------------------------------------------------ live analysis

    private fun onFrame(proxy: ImageProxy) {
        val st = _state.value
        val set = settings.value
        val wantBlur = (mode == CamMode.PORTRAIT) || (mode == CamMode.VIDEO && st.cinematic)
        val wantFaces = (set.focusTracking && mode != CamMode.PRO) || wantBlur
        val wantPeak = mode == CamMode.PRO && st.peakingOn
        val now = SystemClock.elapsedRealtime()
        if ((!wantBlur && !wantFaces && !wantPeak) || analyzing || now - lastAnalysis < caps.livePreviewIntervalMs) {
            proxy.close(); return
        }
        lastAnalysis = now
        val rot = proxy.imageInfo.rotationDegrees
        val bmp = try { rgbaToBitmap(proxy) } catch (e: Exception) { null }
        proxy.close()
        if (bmp == null) return
        analyzing = true
        analysisScope.launch {
            try { processFrame(bmp, rot, wantBlur, wantFaces, wantPeak) } catch (e: Exception) {
                // a bad frame must never crash the camera
            } finally { analyzing = false }
        }
    }

    /** ImageAnalysis frame (RGBA_8888) -> Bitmap, honouring row padding. */
    private fun rgbaToBitmap(proxy: ImageProxy): Bitmap {
        val plane = proxy.planes[0]
        val buf = plane.buffer
        val pixelStride = plane.pixelStride.coerceAtLeast(1)
        val rowPixels = plane.rowStride / pixelStride
        val w = proxy.width
        val h = proxy.height
        val full = Bitmap.createBitmap(max(rowPixels, w), h, Bitmap.Config.ARGB_8888)
        buf.rewind()
        full.copyPixelsFromBuffer(buf)
        if (full.width == w) return full
        val cropped = Bitmap.createBitmap(full, 0, 0, w, h)
        full.recycle()
        return cropped
    }

    private fun smallUpright(src: Bitmap, rot: Int, longSide: Int): Bitmap {
        val s = longSide.toFloat() / max(src.width, src.height)
        val m = Matrix().apply { postRotate(rot.toFloat()); postScale(s, s) }
        return Bitmap.createBitmap(src, 0, 0, src.width, src.height, m, true)
    }

    private suspend fun processFrame(raw: Bitmap, rot: Int, blur: Boolean, faces: Boolean, peak: Boolean) {
        val long = when (caps.tier) { PerfTier.HIGH -> 384; PerfTier.MID -> 320; PerfTier.LOW -> 256 }
        val small = smallUpright(raw, rot, long)
        raw.recycle()

        if (faces) detectFace(small)

        if (blur) {
            val m = segmenter.segment(small, streaming = true)
            if (m != null && m.hasSubject) {
                noSubjectFrames = 0
                val mixed = smoothMask(m)
                val ov = PortraitEngine.overlay(small, mixed, _state.value.blur)
                _state.update { it.copy(overlay = ov) }
            } else {
                // no person in view: do not blur anything (keep the last frame for a moment so it doesn't flicker)
                noSubjectFrames++
                if (noSubjectFrames >= 3) {
                    prevMask = null
                    if (_state.value.overlay != null) _state.update { it.copy(overlay = null) }
                }
            }
        } else if (_state.value.overlay != null) {
            _state.update { it.copy(overlay = null) }
        }

        if (peak) {
            val ov = peakingOverlay(small)
            _state.update { it.copy(peaking = ov) }
        } else if (_state.value.peaking != null) {
            _state.update { it.copy(peaking = null) }
        }
        small.recycle()
    }

    /** Temporal smoothing so the blur edge doesn't flicker between frames. */
    private fun smoothMask(m: SubjectMask): SubjectMask {
        val p = prevMask
        prevMask = m
        if (p == null || p.w != m.w || p.h != m.h) return m
        val out = FloatArray(m.a.size) { m.a[it] * 0.65f + p.a[it] * 0.35f }
        return SubjectMask(m.w, m.h, out)
    }

    private suspend fun detectFace(small: Bitmap) {
        val list = try { faceDetector.process(InputImage.fromBitmap(small, 0)).awaitResult() } catch (e: Exception) { emptyList() }
        val f = list.maxByOrNull { it.boundingBox.width() * it.boundingBox.height() }
        if (f == null) {
            missedFaces++
            if (missedFaces >= 2) _state.update { it.copy(faceBox = null) }
            return
        }
        missedFaces = 0
        val w = small.width.toFloat()
        val h = small.height.toFloat()
        val bb = f.boundingBox
        val box = RectF(bb.left / w, bb.top / h, bb.right / w, bb.bottom / h)
        _state.update { it.copy(faceBox = box) }

        // focus tracking: aim at the eyes when found, otherwise the face centre
        if (!settings.value.focusTracking || _state.value.focusLocked || _state.value.recording && _state.value.paused) return
        val le = f.getLandmark(FaceLandmark.LEFT_EYE)?.position
        val re = f.getLandmark(FaceLandmark.RIGHT_EYE)?.position
        val tx: Float
        val ty: Float
        if (le != null && re != null) { tx = (le.x + re.x) / 2f / w; ty = (le.y + re.y) / 2f / h }
        else { tx = box.centerX(); ty = box.centerY() }
        val last = lastFocusTarget
        val now = SystemClock.elapsedRealtime()
        val moved = last == null || abs(tx - last.first) > 0.07f || abs(ty - last.second) > 0.07f
        if (moved && now - lastFocusAt > 1800 || now - lastFocusAt > 6000) {
            lastFocusAt = now
            lastFocusTarget = tx to ty
            val front = _state.value.front
            scope.launch { focusNormalized(if (front) 1f - tx else tx, ty) }
        }
    }

    private fun focusNormalized(u: Float, v: Float) {
        val pv = previewView ?: return
        val cam = camera ?: return
        if (pv.width == 0 || pv.height == 0) return
        val pt = pv.meteringPointFactory.createPoint(u * pv.width, v * pv.height)
        cam.cameraControl.startFocusAndMetering(
            FocusMeteringAction.Builder(pt, FocusMeteringAction.FLAG_AF or FocusMeteringAction.FLAG_AE)
                .setAutoCancelDuration(3, TimeUnit.SECONDS).build()
        )
    }

    /** Gold edge map for focus peaking. */
    private fun peakingOverlay(src: Bitmap): Bitmap {
        val w = src.width
        val h = src.height
        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)
        val lum = IntArray(w * h) {
            val p = px[it]
            (((p shr 16) and 0xFF) * 77 + ((p shr 8) and 0xFF) * 150 + (p and 0xFF) * 29) shr 8
        }
        val out = IntArray(w * h)
        for (y in 1 until h - 1) {
            for (x in 1 until w - 1) {
                val i = y * w + x
                val gx = lum[i + 1] - lum[i - 1]
                val gy = lum[i + w] - lum[i - w]
                if (abs(gx) + abs(gy) > 70) out[i] = 0xE6FFD24A.toInt()
            }
        }
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        bmp.setPixels(out, 0, w, 0, 0, w, h)
        return bmp
    }

    // ------------------------------------------------------------------ photo capture

    fun capture(feedback: () -> Unit) {
        if (_state.value.busy || _state.value.countdown > 0) return
        timerJob = scope.launch {
            val t = settings.value.timer
            for (i in t downTo 1) {
                _state.update { it.copy(countdown = i) }
                delay(1000)
            }
            _state.update { it.copy(countdown = 0) }
            feedback()
            doCapture()
        }
    }

    fun cancelTimer() {
        timerJob?.cancel()
        _state.update { it.copy(countdown = 0) }
    }

    private suspend fun doCapture() {
        val ic = imageCapture ?: return
        _state.update { it.copy(busy = true) }
        val file = File(app.cacheDir, "cap_${System.nanoTime()}.jpg")
        try {
            if (settings.value.sound) playShutter()
            val ok = suspendCancellableCoroutine<Boolean> { c ->
                ic.takePicture(
                    ImageCapture.OutputFileOptions.Builder(file).build(), mainExecutor,
                    object : ImageCapture.OnImageSavedCallback {
                        override fun onImageSaved(output: ImageCapture.OutputFileResults) { if (c.isActive) c.resume(true) }
                        override fun onError(e: ImageCaptureException) { if (c.isActive) c.resume(false) }
                    }
                )
            }
            if (!ok) { say(R.string.camera_error); return }
            val msg = withContext(Dispatchers.Default) { processCaptured(file) }
            _state.update { it.copy(savedCounter = it.savedCounter + 1) }
            say(msg)
        } catch (e: StorageFullException) {
            say(R.string.storage_full)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            say(R.string.save_failed)
        } catch (e: OutOfMemoryError) {
            say(R.string.save_failed)
        } finally {
            file.delete()
            _state.update { it.copy(busy = false) }
        }
    }

    private fun playShutter() {
        val snd = shutterSound ?: MediaActionSound().also { shutterSound = it }
        snd.play(MediaActionSound.SHUTTER_CLICK)
    }

    private suspend fun processCaptured(file: File): Int {
        val s = settings.value
        val st = _state.value
        val look = s.toLook()
        val portrait = mode == CamMode.PORTRAIT
        val maxSide = when (caps.tier) { PerfTier.LOW -> 2048; PerfTier.MID -> 3072; PerfTier.HIGH -> 4096 }
        val isJpeg = s.imageFormat.equals("JPEG", true)

        if (!portrait && look.isIdentity && isJpeg) {
            media.saveJpegFile(file)
            return R.string.saved_photo
        }
        val processed = portrait || !look.isIdentity
        if (processed && s.saveOriginal) media.saveJpegFile(file)

        var out = media.loadBitmap(Uri.fromFile(file), maxSide) ?: throw IOException("decode failed")
        var msg = R.string.saved_photo
        var didPortrait = false
        if (portrait) {
            val mask = segmentForCapture(out)
            if (mask != null && mask.hasSubject) {
                val r = PortraitEngine.render(out, mask, st.blur, st.light)
                out.recycle(); out = r
                didPortrait = true
                msg = R.string.portrait_saved
            } else {
                msg = R.string.portrait_no_subject
            }
        }
        if (!look.isIdentity) {
            val f = FilterEngine.apply(out, look)
            out.recycle(); out = f
        }
        val suffix = when {
            didPortrait -> "_portrait"
            !look.isIdentity -> "_edit"
            else -> ""
        }
        media.saveBitmap(out, s.imageFormat, suffix)
        out.recycle()
        return msg
    }

    private suspend fun segmentForCapture(bmp: Bitmap): SubjectMask? {
        val s = 640f / max(bmp.width, bmp.height)
        val small = if (s < 1f) Bitmap.createScaledBitmap(bmp, (bmp.width * s).roundToInt(), (bmp.height * s).roundToInt(), true) else bmp
        val m = segmenter.segment(small, streaming = false)
        if (small !== bmp) small.recycle()
        return m
    }

    // ------------------------------------------------------------------ video

    fun startRecording() {
        val vc = videoCapture ?: return
        if (recording != null) return
        if (media.freeBytes() < 100L * 1024 * 1024) { say(R.string.storage_full); return }
        val name = "CineNova_${MediaStoreHelper.timestamp()}.mp4"
        val opts = MediaStoreOutputOptions.Builder(app.contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI)
            .setContentValues(media.newVideoContentValues(name)).build()
        var pending = vc.output.prepareRecording(app, opts)
        val wantAudio = settings.value.audio
        if (wantAudio) {
            if (hasMic()) pending = pending.withAudioEnabled() else say(R.string.perm_mic_denied)
        }
        if (settings.value.sound) shutterSound?.play(MediaActionSound.START_VIDEO_RECORDING)
        recording = pending.start(mainExecutor) { ev -> onRecordEvent(ev) }
        _state.update { it.copy(recording = true, paused = false, recordMs = 0) }
    }

    private fun onRecordEvent(ev: VideoRecordEvent) {
        when (ev) {
            is VideoRecordEvent.Status -> {
                val ms = ev.recordingStats.recordedDurationNanos / 1_000_000L
                _state.update { it.copy(recordMs = ms) }
            }
            is VideoRecordEvent.Finalize -> {
                recording = null
                _state.update { it.copy(recording = false, paused = false) }
                val err = ev.error
                val valid = err == VideoRecordEvent.Finalize.ERROR_NONE ||
                    err == VideoRecordEvent.Finalize.ERROR_DURATION_LIMIT_REACHED ||
                    err == VideoRecordEvent.Finalize.ERROR_FILE_SIZE_LIMIT_REACHED ||
                    err == VideoRecordEvent.Finalize.ERROR_SOURCE_INACTIVE
                if (err == VideoRecordEvent.Finalize.ERROR_INSUFFICIENT_STORAGE) say(R.string.storage_full)
                if (!valid) {
                    if (err != VideoRecordEvent.Finalize.ERROR_INSUFFICIENT_STORAGE) say(R.string.video_failed)
                    runCatching { media.discard(ev.outputResults.outputUri) }
                    return
                }
                _state.update { it.copy(savedCounter = it.savedCounter + 1) }
                say(R.string.video_saved)
                afterVideo(ev.outputResults.outputUri)
            }
            else -> {}
        }
    }

    private fun afterVideo(uri: Uri) {
        val set = settings.value
        val look = set.toLook()
        val cine = _state.value.cinematic
        val applyLook = set.liveFilter && !look.isIdentity
        if (!cine && !applyLook) return
        val blur = if (cine) set.videoBlur else 0
        val suffix = if (cine) "_cine" else "_edit"
        processingJob?.cancel()
        processingJob = bgScope.launch {
            _state.update { it.copy(processingPct = 0) }
            try {
                val params = VideoProcessor.Params(
                    input = uri,
                    look = if (applyLook) look else com.cinenova.camera.imaging.Look(),
                    blurPct = blur,
                    shortSide = if (cine) (when (caps.tier) { PerfTier.LOW -> 720; PerfTier.MID -> 1080; PerfTier.HIGH -> 0 }) else 0,
                    suffix = suffix
                )
                videoProcessor.process(params) { p -> _state.update { it.copy(processingPct = p) } }
                _state.update { it.copy(savedCounter = it.savedCounter + 1) }
                say(R.string.cine_done)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                say(R.string.cine_failed)
            } finally {
                _state.update { it.copy(processingPct = -1) }
            }
        }
    }

    fun cancelProcessing() { processingJob?.cancel() }

    fun stopRecording() {
        val r = recording ?: return
        if (settings.value.sound) shutterSound?.play(MediaActionSound.STOP_VIDEO_RECORDING)
        r.stop()
    }

    fun togglePause() {
        val r = recording ?: return
        if (_state.value.paused) { r.resume(); _state.update { it.copy(paused = false) } }
        else { r.pause(); _state.update { it.copy(paused = true) } }
    }

    fun prepareSounds() {
        if (shutterSound == null) shutterSound = MediaActionSound().also {
            it.load(MediaActionSound.SHUTTER_CLICK)
            it.load(MediaActionSound.START_VIDEO_RECORDING)
            it.load(MediaActionSound.STOP_VIDEO_RECORDING)
        }
    }
}
