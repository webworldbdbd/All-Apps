package com.cinenova.camera.ui

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cinenova.camera.R
import com.cinenova.camera.camera.CameraController
import com.cinenova.camera.camera.PerfTier
import com.cinenova.camera.data.AppSettings
import com.cinenova.camera.media.MediaStoreHelper
import kotlin.math.roundToInt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

fun Context.findActivity(): Activity? {
    var c: Context? = this
    while (c is ContextWrapper) { if (c is Activity) return c; c = c.baseContext }
    return null
}

@Composable
private fun SwitchRow(title: String, checked: Boolean, onChange: (Boolean) -> Unit, enabled: Boolean = true, subtitle: String? = null) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = MaterialTheme.colorScheme.onBackground.copy(alpha = if (enabled) 1f else 0.45f), fontSize = 15.sp)
            if (subtitle != null) Text(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp)
        }
        Switch(
            checked = checked, onCheckedChange = onChange, enabled = enabled,
            colors = SwitchDefaults.colors(checkedThumbColor = Ink, checkedTrackColor = Gold)
        )
    }
}

@Composable
private fun ChoiceRow(title: String, options: List<Pair<String, Boolean>>, onPick: (Int) -> Unit) {
    Column(Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
        Text(title, color = MaterialTheme.colorScheme.onBackground, fontSize = 15.sp, modifier = Modifier.padding(bottom = 6.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(options.size) { i -> Pill(options[i].first, options[i].second, { onPick(i) }) }
        }
    }
}

@Composable
private fun InfoRow(title: String, value: String, onClick: (() -> Unit)? = null) {
    Column(
        Modifier.fillMaxWidth()
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(horizontal = 16.dp, vertical = 10.dp)
    ) {
        Text(title, color = MaterialTheme.colorScheme.onBackground, fontSize = 15.sp)
        if (value.isNotEmpty()) Text(value, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
    }
}

@Composable
fun SettingsScreen(
    appSettings: AppSettings,
    camera: CameraController,
    media: MediaStoreHelper,
    onBack: () -> Unit
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val set by appSettings.state.collectAsState()
    val cam by camera.state.collectAsState()
    val caps = camera.caps
    var usedBytes by remember { mutableLongStateOf(0L) }
    var freeBytes by remember { mutableLongStateOf(0L) }
    var note by remember { mutableStateOf<String?>(null) }
    var dialog by remember { mutableStateOf<String?>(null) }
    val info = camera.currentInfo()

    LaunchedEffect(Unit) {
        usedBytes = media.usedBytes()
        freeBytes = media.freeBytes()
    }
    val versionName = remember { runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull() ?: "1.0.0" }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).statusBarsPadding().navigationBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            RoundIcon(Icons.Filled.ArrowBack, stringResource(R.string.back), onBack)
            Text(
                stringResource(R.string.nav_settings), fontSize = 20.sp, fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground, modifier = Modifier.padding(start = 12.dp)
            )
        }
        note?.let {
            Text(it, color = MaterialTheme.colorScheme.primary, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 16.dp))
            LaunchedEffect(it) { delay(2500); note = null }
        }

        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            // ---------------------------------------------------------------- camera
            SectionTitle(stringResource(R.string.set_camera))
            val sizes = camera.photoSizeOptions()
            if (sizes.isNotEmpty()) {
                val opts = listOf("") + sizes.map { "${it.width}x${it.height}" }
                val labels = listOf(stringResource(R.string.auto)) + sizes.map { stringResource(R.string.mp_n, it.width * it.height / 1_000_000f) }
                ChoiceRow(stringResource(R.string.set_photo_res), opts.indices.map { labels[it] to (set.photoSize == opts[it]) }) { i ->
                    appSettings.update { it.copy(photoSize = opts[i]) }
                }
            }
            if (cam.videoQualities.isNotEmpty()) {
                ChoiceRow(
                    stringResource(R.string.set_video_res),
                    cam.videoQualities.map { q -> (when (q) { "UHD" -> "4K"; "FHD" -> "1080p"; "HD" -> "720p"; else -> "480p" }) to (set.videoQuality == q) }
                ) { i -> appSettings.update { it.copy(videoQuality = cam.videoQualities[i]) } }
            }
            ChoiceRow(
                stringResource(R.string.set_fps),
                cam.fpsOptions.map { stringResource(R.string.fps_n, it) to (set.videoFps == it) }
            ) { i -> appSettings.update { it.copy(videoFps = cam.fpsOptions[i]) } }

            if (caps.frontCameras.isNotEmpty() && caps.backCameras.isNotEmpty()) {
                ChoiceRow(
                    stringResource(R.string.set_lens),
                    listOf(stringResource(R.string.lens_back) to (set.lens == "back"), stringResource(R.string.lens_front) to (set.lens == "front"))
                ) { i -> appSettings.update { it.copy(lens = if (i == 0) "back" else "front") }; camera.selectDefaultLens(i == 1) }
            }
            SwitchRow(stringResource(R.string.set_autofocus), set.autofocus, { v -> appSettings.update { it.copy(autofocus = v) } })
            SwitchRow(stringResource(R.string.set_grid), set.grid, { v -> appSettings.update { it.copy(grid = v) } })
            ChoiceRow(
                stringResource(R.string.set_timer),
                listOf(0, 3, 5, 10).map { (if (it == 0) stringResource(R.string.off) else stringResource(R.string.timer_n, it)) to (set.timer == it) }
            ) { i -> appSettings.update { it.copy(timer = listOf(0, 3, 5, 10)[i]) } }
            ChoiceRow(
                stringResource(R.string.set_flash),
                listOf(R.string.off, R.string.auto, R.string.on).mapIndexed { idx, r -> stringResource(r) to (set.flash == idx) }
            ) { i -> if (info?.hasFlash == true) appSettings.update { it.copy(flash = i) } else note = ctx.getString(R.string.flash_unavailable) }

            // ---------------------------------------------------------------- photo
            SectionTitle(stringResource(R.string.set_photo))
            Column(Modifier.padding(horizontal = 16.dp)) {
                LabeledSlider(stringResource(R.string.set_default_blur), set.defaultBlur.toFloat(), 0f..100f, { v -> appSettings.update { it.copy(defaultBlur = v.roundToInt()) } }, "${set.defaultBlur}%")
                LabeledSlider(stringResource(R.string.set_filter_intensity), set.filterIntensity.toFloat(), 0f..100f, { v -> appSettings.update { it.copy(filterIntensity = v.roundToInt()) } }, "${set.filterIntensity}%")
            }
            SwitchRow(stringResource(R.string.set_beauty), set.beauty, { v -> appSettings.update { it.copy(beauty = v) } })
            SwitchRow(
                stringResource(R.string.set_hdr), set.hdr && info?.hdrScene == true, { v -> appSettings.update { it.copy(hdr = v) } },
                enabled = info?.hdrScene == true, subtitle = if (info?.hdrScene == true) null else stringResource(R.string.hdr_unsupported)
            )
            ChoiceRow(
                stringResource(R.string.set_format),
                listOf("JPEG" to R.string.format_jpeg, "PNG" to R.string.format_png, "WEBP" to R.string.format_webp)
                    .map { stringResource(it.second) to (set.imageFormat == it.first) }
            ) { i -> appSettings.update { it.copy(imageFormat = listOf("JPEG", "PNG", "WEBP")[i]) } }
            SwitchRow(stringResource(R.string.set_save_original), set.saveOriginal, { v -> appSettings.update { it.copy(saveOriginal = v) } })

            // ---------------------------------------------------------------- video
            SectionTitle(stringResource(R.string.set_video))
            Column(Modifier.padding(horizontal = 16.dp)) {
                LabeledSlider(stringResource(R.string.set_video_blur), set.videoBlur.toFloat(), 0f..100f, { v -> appSettings.update { it.copy(videoBlur = v.roundToInt()) } }, "${set.videoBlur}%")
            }
            SwitchRow(
                stringResource(R.string.stabilization), set.stabilization && info?.videoStab == true, { v -> appSettings.update { it.copy(stabilization = v) } },
                enabled = info?.videoStab == true, subtitle = if (info?.videoStab == true) null else stringResource(R.string.stabilization_unsupported)
            )
            SwitchRow(stringResource(R.string.set_live_filter), set.liveFilter, { v -> appSettings.update { it.copy(liveFilter = v) } })
            SwitchRow(stringResource(R.string.set_audio), set.audio, { v -> appSettings.update { it.copy(audio = v) } })
            SwitchRow(stringResource(R.string.set_focus_tracking), set.focusTracking, { v -> appSettings.update { it.copy(focusTracking = v) } })

            // ---------------------------------------------------------------- app
            SectionTitle(stringResource(R.string.set_app))
            ChoiceRow(
                stringResource(R.string.set_language),
                listOf(stringResource(R.string.lang_en) to (set.language == "en"), stringResource(R.string.lang_bn) to (set.language == "bn"))
            ) { i ->
                val l = if (i == 0) "en" else "bn"
                if (l != set.language) {
                    appSettings.update { it.copy(language = l) }
                    ctx.findActivity()?.recreate()
                }
            }
            ChoiceRow(
                stringResource(R.string.set_theme),
                listOf(
                    stringResource(R.string.set_theme_dark) to (set.theme == "dark"),
                    stringResource(R.string.set_theme_light) to (set.theme == "light"),
                    stringResource(R.string.set_theme_system) to (set.theme == "system")
                )
            ) { i -> appSettings.update { it.copy(theme = listOf("dark", "light", "system")[i]) } }
            SwitchRow(stringResource(R.string.set_haptic), set.haptic, { v -> appSettings.update { it.copy(haptic = v) } })
            SwitchRow(stringResource(R.string.set_sound), set.sound, { v -> appSettings.update { it.copy(sound = v) } })
            InfoRow(stringResource(R.string.set_save_location), stringResource(R.string.set_save_location_value))
            InfoRow(
                stringResource(R.string.set_storage_info),
                stringResource(R.string.set_storage_used, MediaStoreHelper.formatSize(usedBytes), MediaStoreHelper.formatSize(freeBytes))
            )
            InfoRow(stringResource(R.string.set_cache), "", onClick = {
                scope.launch {
                    val freed = withContext(Dispatchers.IO) {
                        var n = 0L
                        ctx.cacheDir.listFiles()?.forEach { f -> n += f.walkTopDown().filter { it.isFile }.sumOf { it.length() }; f.deleteRecursively() }
                        n
                    }
                    note = ctx.getString(R.string.set_cache_cleared, MediaStoreHelper.formatSize(freed))
                }
            })
            InfoRow(stringResource(R.string.set_reset), "", onClick = { dialog = "reset" })
            InfoRow(stringResource(R.string.set_about), "", onClick = { dialog = "about" })
            InfoRow(stringResource(R.string.set_privacy), "", onClick = { dialog = "privacy" })

            // ---------------------------------------------------------------- device report
            SectionTitle(stringResource(R.string.set_device_caps))
            val yes = stringResource(R.string.cap_yes)
            val no = stringResource(R.string.cap_no)
            fun yn(b: Boolean) = if (b) yes else no
            val tier = stringResource(when (caps.tier) { PerfTier.HIGH -> R.string.tier_high; PerfTier.MID -> R.string.tier_mid; PerfTier.LOW -> R.string.tier_low })
            Column(Modifier.padding(horizontal = 16.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                listOf(
                    stringResource(R.string.cap_manual, yn(caps.cameras.any { it.manualSensor })),
                    stringResource(R.string.cap_manual_focus, yn(caps.cameras.any { it.manualFocus })),
                    stringResource(R.string.cap_hdr, yn(caps.cameras.any { it.hdrScene })),
                    stringResource(R.string.cap_stabilization, yn(caps.cameras.any { it.videoStab })),
                    stringResource(R.string.cap_live_blur, yn(true)),
                    stringResource(R.string.cap_live_blur_tier, tier)
                ).forEach { Text(it, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp) }
            }
            Column(Modifier.padding(bottom = 24.dp)) {}
        }
    }

    when (dialog) {
        "reset" -> AlertDialog(
            onDismissRequest = { dialog = null },
            title = { Text(stringResource(R.string.set_reset)) },
            text = { Text(stringResource(R.string.set_reset_confirm)) },
            confirmButton = {
                TextButton(onClick = {
                    dialog = null
                    appSettings.resetAll()
                    note = ctx.getString(R.string.set_reset_done)
                    ctx.findActivity()?.recreate()
                }) { Text(stringResource(R.string.reset)) }
            },
            dismissButton = { TextButton(onClick = { dialog = null }) { Text(stringResource(R.string.cancel)) } }
        )
        "about" -> AlertDialog(
            onDismissRequest = { dialog = null },
            title = { Text(stringResource(R.string.app_name)) },
            text = { Text(stringResource(R.string.about_body, versionName)) },
            confirmButton = { TextButton(onClick = { dialog = null }) { Text(stringResource(R.string.ok)) } }
        )
        "privacy" -> AlertDialog(
            onDismissRequest = { dialog = null },
            title = { Text(stringResource(R.string.set_privacy)) },
            text = { Column(Modifier.verticalScroll(rememberScrollState())) { Text(stringResource(R.string.privacy_body)) } },
            confirmButton = { TextButton(onClick = { dialog = null }) { Text(stringResource(R.string.ok)) } }
        )
    }
}
