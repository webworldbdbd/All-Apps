package com.cinenova.camera.ui

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.LruCache
import android.util.Size
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cinenova.camera.media.MediaItem
import com.cinenova.camera.media.MediaKind
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Round icon button used all over the camera UI. Minimum 44dp touch target. */
@Composable
fun RoundIcon(
    icon: ImageVector,
    desc: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    tint: Color = Color.Unspecified,
    active: Boolean = false,
    enabled: Boolean = true,
    size: Int = 44
) {
    val base = if (tint == Color.Unspecified) MaterialTheme.colorScheme.onSurface else tint
    Box(
        modifier = modifier
            .size(size.dp)
            .clip(CircleShape)
            .background(if (active) Gold.copy(alpha = 0.25f) else base.copy(alpha = 0.08f))
            .clickable(enabled = enabled, role = Role.Button, onClick = onClick)
            .semantics { contentDescription = desc },
        contentAlignment = Alignment.Center
    ) {
        Icon(
            icon, contentDescription = null,
            tint = if (!enabled) base.copy(alpha = 0.3f) else if (active) Gold else base,
            modifier = Modifier.size((size * 0.5f).dp)
        )
    }
}

@Composable
fun Pill(
    text: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true
) {
    val on = MaterialTheme.colorScheme.onSurface
    val bg = if (selected) Gold else on.copy(alpha = 0.1f)
    val fg = if (selected) Ink else on.copy(alpha = if (enabled) 1f else 0.4f)
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(50))
            .background(bg)
            .clickable(enabled = enabled, role = Role.Button, onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = fg, fontSize = 13.sp, maxLines = 1, softWrap = false, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal)
    }
}

/** Labelled slider in the gold style. [valueText] is shown at the right. */
@Composable
fun LabeledSlider(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onChange: (Float) -> Unit,
    valueText: String,
    modifier: Modifier = Modifier,
    steps: Int = 0,
    enabled: Boolean = true
) {
    val textColor = MaterialTheme.colorScheme.onSurface
    Column(modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, color = textColor.copy(alpha = if (enabled) 0.85f else 0.4f), fontSize = 12.sp)
            Text(valueText, color = Gold, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        }
        Slider(
            value = value.coerceIn(range.start, range.endInclusive),
            onValueChange = onChange,
            valueRange = range,
            steps = steps,
            enabled = enabled,
            colors = SliderDefaults.colors(
                thumbColor = Gold, activeTrackColor = Gold,
                inactiveTrackColor = textColor.copy(alpha = 0.2f),
                disabledThumbColor = Color.Gray, disabledActiveTrackColor = Color.Gray
            )
        )
    }
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Text(
        text, color = MaterialTheme.colorScheme.primary, fontSize = 13.sp, fontWeight = FontWeight.Bold,
        modifier = modifier.padding(start = 16.dp, top = 18.dp, bottom = 6.dp)
    )
}

@Composable
fun GoldCard(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
        border = BorderStroke(0.5.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
    ) { content() }
}

// ---------------------------------------------------------------- thumbnails

private val thumbCache = object : LruCache<String, Bitmap>(48) {}

@Suppress("DEPRECATION")
suspend fun loadThumbnail(ctx: Context, item: MediaItem, px: Int = 256): Bitmap? {
    val key = "${item.id}_${item.kind}_$px"
    thumbCache.get(key)?.let { return it }
    val bmp = withContext(Dispatchers.IO) {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                ctx.contentResolver.loadThumbnail(item.uri, Size(px, px), null)
            } else if (item.kind == MediaKind.PHOTO) {
                MediaStore.Images.Thumbnails.getThumbnail(
                    ctx.contentResolver, item.id, MediaStore.Images.Thumbnails.MINI_KIND, null
                )
            } else {
                MediaStore.Video.Thumbnails.getThumbnail(
                    ctx.contentResolver, item.id, MediaStore.Video.Thumbnails.MINI_KIND, null
                )
            }
        } catch (e: Exception) { null }
    }
    if (bmp != null) thumbCache.put(key, bmp)
    return bmp
}

@Composable
fun rememberThumb(ctx: Context, item: MediaItem, px: Int = 256): ImageBitmap? {
    var bmp by remember(item.id, item.kind) { mutableStateOf<ImageBitmap?>(null) }
    LaunchedEffect(item.id, item.kind, item.size) { bmp = loadThumbnail(ctx, item, px)?.asImageBitmap() }
    return bmp
}

fun formatDuration(ms: Long): String {
    val total = ms / 1000
    val m = total / 60
    val s = total % 60
    return String.format(java.util.Locale.US, "%02d:%02d", m, s)
}
