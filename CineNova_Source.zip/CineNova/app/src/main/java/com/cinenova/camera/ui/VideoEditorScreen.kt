package com.cinenova.camera.ui

import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.widget.VideoView
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RangeSlider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.cinenova.camera.R
import com.cinenova.camera.data.AppSettings
import com.cinenova.camera.imaging.Adjustments
import com.cinenova.camera.imaging.FilterEngine
import com.cinenova.camera.imaging.FilterId
import com.cinenova.camera.imaging.Look
import com.cinenova.camera.imaging.PortraitEngine
import com.cinenova.camera.imaging.Segmenter
import com.cinenova.camera.imaging.SubjectMask
import com.cinenova.camera.media.VideoProcessor
import kotlin.math.max
import kotlin.math.roundToInt
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
fun VideoEditorScreen(
    uri: Uri,
    processor: VideoProcessor,
    appSettings: AppSettings,
    onBack: () -> Unit
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val set by appSettings.state.collectAsState()

    var durationMs by remember { mutableLongStateOf(0L) }
    var origFps by remember { mutableIntStateOf(30) }
    var origShort by remember { mutableIntStateOf(0) }
    var trimStart by remember { mutableFloatStateOf(0f) }
    var trimEnd by remember { mutableFloatStateOf(1f) }
    var previewPos by remember { mutableFloatStateOf(0f) }

    var filter by remember { mutableStateOf(FilterId.NATURAL) }
    var intensity by remember { mutableIntStateOf(100) }
    var adj by remember { mutableStateOf(Adjustments()) }
    var blur by remember { mutableIntStateOf(0) }
    var resOpt by remember { mutableIntStateOf(0) }    // 0 original, else short side
    var fpsOpt by remember { mutableIntStateOf(0) }    // 0 original, else fps

    var tab by remember { mutableIntStateOf(0) }
    var frame by remember { mutableStateOf<Bitmap?>(null) }
    var mask by remember { mutableStateOf<SubjectMask?>(null) }
    var preview by remember { mutableStateOf<ImageBitmap?>(null) }
    var playing by remember { mutableStateOf(false) }
    var progress by remember { mutableIntStateOf(-1) }
    var note by remember { mutableStateOf<Int?>(null) }
    var job by remember { mutableStateOf<Job?>(null) }

    val retriever = remember { MediaMetadataRetriever() }
    val segmenter = remember { Segmenter() }
    DisposableEffect(Unit) {
        onDispose {
            job?.cancel()
            runCatching { retriever.release() }
            segmenter.close()
        }
    }

    LaunchedEffect(uri) {
        withContext(Dispatchers.IO) {
            try {
                retriever.setDataSource(ctx, uri)
                durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                val w = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
                val h = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
                origShort = minOf(w, h)
                val fr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_CAPTURE_FRAMERATE)?.toFloatOrNull()
                if (fr != null && fr > 1f) origFps = fr.roundToInt()
            } catch (e: Exception) { note = R.string.ve_failed }
        }
    }

    // grab a real frame at the preview position
    LaunchedEffect(previewPos, durationMs) {
        if (durationMs <= 0) return@LaunchedEffect
        delay(120)
        val f = withContext(Dispatchers.IO) {
            try {
                val raw = retriever.getFrameAtTime((previewPos * durationMs * 1000L).toLong(), MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                if (raw == null) null else {
                    val s = 640f / max(raw.width, raw.height)
                    if (s < 1f) Bitmap.createScaledBitmap(raw, (raw.width * s).roundToInt(), (raw.height * s).roundToInt(), true) else raw
                }
            } catch (e: Exception) { null }
        }
        if (f != null) { frame = f; mask = null }
    }
    // segmentation for the preview frame, only when cinematic blur is on
    LaunchedEffect(frame, blur > 0) {
        val f = frame
        if (f != null && blur > 0 && mask == null) mask = withContext(Dispatchers.Default) { segmenter.segment(f, streaming = false) }
    }
    LaunchedEffect(frame, mask, filter, intensity, adj, blur) {
        val f = frame ?: return@LaunchedEffect
        delay(30)
        preview = withContext(Dispatchers.Default) {
            var cur: Bitmap = f
            val m = mask
            if (blur > 0 && m != null && m.hasSubject) cur = PortraitEngine.render(cur, m, blur)
            val look = Look(filter, intensity, null, adj.copy(sharpness = 0, denoise = 0), false)
            if (!look.isIdentity) cur = FilterEngine.apply(cur, look)
            cur.asImageBitmap()
        }
    }

    val fpsChoices = buildList { add(0); if (origFps > 30) add(30); if (origFps > 24) add(24) }
    val resChoices = buildList { add(0); for (r in listOf(1080, 720, 480)) if (origShort > r) add(r) }
    val barColor = MaterialTheme.colorScheme.onBackground

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).statusBarsPadding().navigationBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            RoundIcon(Icons.Filled.ArrowBack, stringResource(R.string.back), onBack)
            Text(
                stringResource(R.string.ve_title), fontSize = 18.sp, fontWeight = FontWeight.Bold, color = barColor,
                modifier = Modifier.padding(start = 12.dp).weight(1f)
            )
        }

        Box(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 8.dp), contentAlignment = Alignment.Center) {
            val img = preview
            if (img != null) Image(img, null, contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize())
            else CircularProgressIndicator(color = Gold)
            RoundIcon(
                Icons.Filled.PlayArrow, stringResource(R.string.gal_play), { playing = true },
                tint = Color.White, modifier = Modifier.align(Alignment.Center), size = 56
            )
            if (playing) {
                TrimPlayer(uri, (trimStart * durationMs).toInt(), (trimEnd * durationMs).toInt()) { playing = false }
            }
        }

        // trim
        Column(Modifier.padding(horizontal = 14.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("${stringResource(R.string.ve_start)} ${formatDuration((trimStart * durationMs).toLong())}", color = Gold, fontSize = 12.sp)
                Text("${stringResource(R.string.ve_end)} ${formatDuration((trimEnd * durationMs).toLong())}", color = Gold, fontSize = 12.sp)
            }
            RangeSlider(
                value = trimStart..trimEnd,
                onValueChange = { r ->
                    if (r.start != trimStart) previewPos = r.start else if (r.endInclusive != trimEnd) previewPos = r.endInclusive
                    trimStart = r.start; trimEnd = r.endInclusive
                },
                valueRange = 0f..1f,
                colors = SliderDefaults.colors(thumbColor = Gold, activeTrackColor = Gold)
            )
        }

        Row(Modifier.padding(horizontal = 12.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Pill(stringResource(R.string.ve_look), tab == 0, { tab = 0 })
            Pill(stringResource(R.string.ed_adjust), tab == 1, { tab = 1 })
            Pill(stringResource(R.string.ve_cinematic_blur), tab == 2, { tab = 2 })
            Pill(stringResource(R.string.ve_export), tab == 3, { tab = 3 })
        }
        Column(
            Modifier.fillMaxWidth().heightIn(max = 210.dp).verticalScroll(rememberScrollState()).padding(horizontal = 14.dp, vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            when (tab) {
                0 -> {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(FilterId.values().size) { i ->
                            val f = FilterId.values()[i]
                            Pill(stringResource(f.nameRes), filter == f, { filter = f })
                        }
                    }
                    LabeledSlider(stringResource(R.string.filter_intensity), intensity.toFloat(), 0f..100f, { intensity = it.roundToInt() }, "$intensity%")
                }
                1 -> {
                    LabeledSlider(stringResource(R.string.adj_brightness), adj.brightness.toFloat(), -100f..100f, { adj = adj.copy(brightness = it.roundToInt()) }, "${adj.brightness}")
                    LabeledSlider(stringResource(R.string.adj_contrast), adj.contrast.toFloat(), -100f..100f, { adj = adj.copy(contrast = it.roundToInt()) }, "${adj.contrast}")
                    LabeledSlider(stringResource(R.string.adj_saturation), adj.saturation.toFloat(), -100f..100f, { adj = adj.copy(saturation = it.roundToInt()) }, "${adj.saturation}")
                    LabeledSlider(stringResource(R.string.adj_temperature), adj.temperature.toFloat(), -100f..100f, { adj = adj.copy(temperature = it.roundToInt()) }, "${adj.temperature}")
                }
                2 -> {
                    LabeledSlider(stringResource(R.string.ve_cinematic_blur), blur.toFloat(), 0f..100f, { blur = it.roundToInt() }, "$blur%")
                    if (blur > 0) Text(stringResource(R.string.ve_blur_slow), fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                    Text(stringResource(R.string.cine_post_note), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                else -> {
                    Text(stringResource(R.string.ve_export_res), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(resChoices.size) { i ->
                            val r = resChoices[i]
                            Pill(if (r == 0) stringResource(R.string.ve_original_res) else "${r}p", resOpt == r, { resOpt = r })
                        }
                    }
                    Text(stringResource(R.string.ve_export_fps), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(fpsChoices.size) { i ->
                            val f = fpsChoices[i]
                            Pill(if (f == 0) stringResource(R.string.ve_original_res) else stringResource(R.string.fps_n, f), fpsOpt == f, { fpsOpt = f })
                        }
                    }
                }
            }
        }

        note?.let {
            Text(stringResource(it), color = MaterialTheme.colorScheme.primary, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 16.dp))
            LaunchedEffect(it) { delay(3000); note = null }
        }

        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (progress >= 0) {
                Text(stringResource(R.string.ve_exporting, progress), color = Gold, modifier = Modifier.weight(1f))
                Pill(stringResource(R.string.ve_cancel_export), false, { job?.cancel() })
            } else {
                Button(
                    onClick = {
                        if (durationMs <= 0) return@Button
                        val look = Look(filter, intensity, null, adj.copy(sharpness = 0, denoise = 0), false)
                        val params = VideoProcessor.Params(
                            input = uri,
                            look = look,
                            blurPct = blur,
                            startUs = (trimStart * durationMs * 1000L).toLong(),
                            endUs = (trimEnd * durationMs * 1000L).toLong(),
                            shortSide = resOpt,
                            fps = fpsOpt,
                            suffix = if (blur > 0) "_cine" else "_edit"
                        )
                        job = scope.launch {
                            progress = 0
                            try {
                                processor.process(params) { p -> progress = p }
                                note = R.string.ve_done
                            } catch (e: CancellationException) {
                                note = R.string.ve_cancelled
                                throw e
                            } catch (e: Exception) {
                                note = R.string.ve_failed
                            } finally { progress = -1 }
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = durationMs > 0 && trimEnd > trimStart,
                    colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Ink)
                ) { Text(stringResource(R.string.ve_export), fontWeight = FontWeight.Bold) }
            }
        }
    }
}

/** Plays the original video from the trim start and stops at the trim end. */
@Composable
private fun TrimPlayer(uri: Uri, startMs: Int, endMs: Int, onClose: () -> Unit) {
    val handler = remember { Handler(Looper.getMainLooper()) }
    var view by remember { mutableStateOf<VideoView?>(null) }
    DisposableEffect(view) {
        val v = view
        val checker = object : Runnable {
            override fun run() {
                if (v != null && v.isPlaying && v.currentPosition >= endMs) { v.pause(); onClose(); return }
                handler.postDelayed(this, 100)
            }
        }
        handler.post(checker)
        onDispose { handler.removeCallbacks(checker); v?.stopPlayback() }
    }
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { c ->
                VideoView(c).apply {
                    setVideoURI(uri)
                    setOnPreparedListener { seekTo(startMs); start() }
                    setOnCompletionListener { onClose() }
                }.also { view = it }
            }
        )
        RoundIcon(
            Icons.Filled.Close, stringResource(R.string.close), onClose, tint = Color.White,
            modifier = Modifier.align(Alignment.TopEnd).padding(8.dp)
        )
    }
}
