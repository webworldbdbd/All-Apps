package com.cinenova.camera.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Gold = Color(0xFFD4AF37)
val GoldLight = Color(0xFFF1D27A)
val GoldDark = Color(0xFF9C7A1B)
val Ink = Color(0xFF000000)
val InkSoft = Color(0xFF0D0D0D)
val InkRaised = Color(0xFF1A1A1A)
val RecordRed = Color(0xFFE53935)

private val Dark = darkColorScheme(
    primary = Gold, onPrimary = Ink, secondary = GoldLight, onSecondary = Ink,
    background = Ink, onBackground = Color.White,
    surface = InkSoft, onSurface = Color.White,
    surfaceVariant = InkRaised, onSurfaceVariant = Color(0xFFCFCFCF),
    outline = GoldDark, error = RecordRed
)

private val Light = lightColorScheme(
    primary = GoldDark, onPrimary = Color.White, secondary = Gold, onSecondary = Ink,
    background = Color(0xFFFAF7F0), onBackground = Color(0xFF14110A),
    surface = Color.White, onSurface = Color(0xFF14110A),
    surfaceVariant = Color(0xFFEFE8D6), onSurfaceVariant = Color(0xFF4B4636),
    outline = Gold, error = RecordRed
)

@Composable
fun isDarkFor(theme: String): Boolean = when (theme) {
    "light" -> false
    "system" -> isSystemInDarkTheme()
    else -> true
}

@Composable
fun CineNovaTheme(theme: String, content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isDarkFor(theme)) Dark else Light,
        typography = Typography(),
        content = content
    )
}
