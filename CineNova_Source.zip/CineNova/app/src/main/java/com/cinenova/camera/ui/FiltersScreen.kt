package com.cinenova.camera.ui

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cinenova.camera.R
import com.cinenova.camera.data.AppSettings
import com.cinenova.camera.imaging.Adjustments
import com.cinenova.camera.imaging.FilterEngine
import com.cinenova.camera.imaging.FilterId
import com.cinenova.camera.imaging.Look
import com.cinenova.camera.media.MediaKind
import com.cinenova.camera.media.MediaStoreHelper
import kotlin.math.roundToInt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** A colourful generated picture used when the user has no photo yet. */
private fun generatedSample(): Bitmap {
    val w = 240
    val h = 320
    val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    val c = Canvas(b)
    val p = Paint(Paint.ANTI_ALIAS_FLAG)
    p.shader = LinearGradient(0f, 0f, 0f, h.toFloat(), intArrayOf(0xFF4A90D9.toInt(), 0xFFF5C98A.toInt(), 0xFF3B7A4B.toInt()), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
    c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
    p.shader = null
    p.color = 0xFFE8A07A.toInt(); c.drawCircle(120f, 150f, 52f, p)
    p.color = 0xFFC0392B.toInt(); c.drawRoundRect(60f, 205f, 180f, 300f, 30f, 30f, p)
    p.color = 0xFFFFF3C4.toInt(); c.drawCircle(190f, 50f, 24f, p)
    return b
}

@Composable
fun FiltersScreen(appSettings: AppSettings, media: MediaStoreHelper, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    val set by appSettings.state.collectAsState()
    var sample by remember { mutableStateOf<Bitmap?>(null) }
    var note by remember { mutableStateOf<Int?>(null) }

    LaunchedEffect(Unit) {
        val photo = media.listAll().firstOrNull { it.kind == MediaKind.PHOTO }
        sample = (if (photo != null) media.loadBitmap(photo.uri, 256) else null) ?: generatedSample()
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) scope.launch { media.loadBitmap(uri, 256)?.let { sample = it } }
    }

    val previews by produceState<Map<FilterId, ImageBitmap>>(emptyMap(), sample, set.filterIntensity, set.secondFilterId) {
        val s = sample ?: return@produceState
        value = withContext(Dispatchers.Default) {
            val second = set.secondFilterId.takeIf { it.isNotEmpty() }?.let { FilterId.fromKey(it) }
            FilterId.values().associateWith { f ->
                FilterEngine.apply(s, Look(f, set.filterIntensity, second, Adjustments(), set.beauty)).asImageBitmap()
            }
        }
    }

    val ordered = remember(set.favoriteFilters) {
        val all = FilterId.values().toList()
        all.filter { set.favoriteFilters.contains(it.key) } + all.filter { !set.favoriteFilters.contains(it.key) }
    }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).statusBarsPadding().navigationBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            RoundIcon(Icons.Filled.ArrowBack, stringResource(R.string.back), onBack)
            Text(
                stringResource(R.string.nav_filters), fontSize = 20.sp, fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground, modifier = Modifier.padding(start = 12.dp).weight(1f)
            )
            Pill(stringResource(R.string.filter_pick_media), false, { picker.launch("image/*") })
        }
        Text(
            stringResource(R.string.filters_screen_hint), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 16.dp)
        )
        Column(Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) {
            LabeledSlider(
                stringResource(R.string.filter_intensity), set.filterIntensity.toFloat(), 0f..100f,
                { v -> appSettings.update { it.copy(filterIntensity = v.roundToInt()) } }, "${set.filterIntensity}%"
            )
            Text(stringResource(R.string.filter_second), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item { Pill(stringResource(R.string.off), set.secondFilterId.isEmpty(), { appSettings.update { it.copy(secondFilterId = "") } }) }
                items(FilterId.values().size) { i ->
                    val f = FilterId.values()[i]
                    Pill(stringResource(f.nameRes), set.secondFilterId == f.key, { appSettings.update { it.copy(secondFilterId = f.key) } })
                }
            }
        }
        note?.let {
            Text(stringResource(it), color = MaterialTheme.colorScheme.primary, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 16.dp))
            LaunchedEffect(it) { delay(1800); note = null }
        }
        LazyVerticalGrid(
            columns = GridCells.Fixed(2), modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(ordered, key = { it.key }) { f ->
                val selected = set.filterId == f.key
                val fav = set.favoriteFilters.contains(f.key)
                Column(
                    Modifier.clip(RoundedCornerShape(14.dp))
                        .border(if (selected) 2.dp else 0.5.dp, if (selected) Gold else MaterialTheme.colorScheme.outline.copy(alpha = 0.4f), RoundedCornerShape(14.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .clickable {
                            appSettings.update { it.copy(filterId = f.key) }
                            note = R.string.filter_default_set
                        }
                ) {
                    Box(Modifier.fillMaxWidth().aspectRatio(0.85f)) {
                        val img = previews[f]
                        if (img != null) Image(img, null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                        Icon(
                            if (fav) Icons.Filled.Star else Icons.Filled.StarBorder,
                            stringResource(if (fav) R.string.filter_favorite_remove else R.string.filter_favorite_add),
                            tint = if (fav) Gold else Color.White,
                            modifier = Modifier.align(Alignment.TopEnd).padding(6.dp)
                                .clip(RoundedCornerShape(50)).background(Color.Black.copy(alpha = 0.35f)).padding(4.dp)
                                .clickable {
                                    appSettings.update { s ->
                                        s.copy(favoriteFilters = if (fav) s.favoriteFilters - f.key else s.favoriteFilters + f.key)
                                    }
                                }
                        )
                    }
                    Text(
                        stringResource(f.nameRes), fontSize = 13.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                        color = if (selected) Gold else MaterialTheme.colorScheme.onSurface, modifier = Modifier.padding(10.dp)
                    )
                }
            }
        }
    }
}
