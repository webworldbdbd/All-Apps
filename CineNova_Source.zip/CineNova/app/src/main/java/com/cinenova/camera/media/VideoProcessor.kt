package com.cinenova.camera.media

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.media.Image
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.os.ParcelFileDescriptor
import com.cinenova.camera.imaging.FilterEngine
import com.cinenova.camera.imaging.Look
import com.cinenova.camera.imaging.PortraitEngine
import com.cinenova.camera.imaging.Segmenter
import com.cinenova.camera.imaging.SubjectMask
import java.io.IOException
import java.nio.ByteBuffer
import kotlin.coroutines.coroutineContext
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext

/**
 * Offline video pipeline: decode -> (cinematic blur) -> (filters) -> encode, with trim, scale and fps control.
 * The source video is only ever read. Output goes to a NEW file in Movies/CineNova.
 *
 * Pure MediaCodec/MediaExtractor/MediaMuxer. Frames are processed on the CPU, so speed depends on the phone;
 * the UI warns about this and the work can be cancelled at any time.
 */
class VideoProcessor(private val ctx: Context, private val media: MediaStoreHelper) {

    data class Params(
        val input: Uri,
        val look: Look,
        val blurPct: Int,
        val startUs: Long = 0L,
        val endUs: Long = Long.MAX_VALUE,
        val shortSide: Int = 0,      // 0 = keep original size
        val fps: Int = 0,            // 0 = keep original frame rate
        val suffix: String = "_edit"
    )

    suspend fun process(p: Params, onProgress: (Int) -> Unit): Uri =
        withContext(Dispatchers.Default) { run(p, onProgress) }

    private fun fmtInt(f: MediaFormat, key: String, def: Int): Int =
        if (!f.containsKey(key)) def
        else try { f.getInteger(key) } catch (e: Exception) {
            try { f.getFloat(key).roundToInt() } catch (e2: Exception) { def }
        }

    private suspend fun run(p: Params, onProgress: (Int) -> Unit): Uri {
        val outUri = media.createVideoEntry(p.suffix) ?: throw StorageFullException()
        var pfd: ParcelFileDescriptor? = null
        var muxer: MediaMuxer? = null
        var vx: MediaExtractor? = null
        var ax: MediaExtractor? = null
        var decoder: MediaCodec? = null
        var encoder: MediaCodec? = null
        val segmenter = if (p.blurPct > 0) Segmenter() else null
        var finished = false
        try {
            // ---------- inputs
            val vEx = MediaExtractor().also { it.setDataSource(ctx, p.input, null); vx = it }
            var vTrack = -1
            for (i in 0 until vEx.trackCount) {
                val mime = vEx.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("video/")) { vTrack = i; break }
            }
            if (vTrack < 0) throw IOException("no video track")
            vEx.selectTrack(vTrack)
            val vf = vEx.getTrackFormat(vTrack)

            var aTrack = -1
            val aEx = MediaExtractor().also { it.setDataSource(ctx, p.input, null); ax = it }
            for (i in 0 until aEx.trackCount) {
                val mime = aEx.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("audio/")) { aTrack = i; break }
            }
            if (aTrack >= 0) aEx.selectTrack(aTrack)

            val inW = vf.getInteger(MediaFormat.KEY_WIDTH)
            val inH = vf.getInteger(MediaFormat.KEY_HEIGHT)
            val rotation = fmtInt(vf, MediaFormat.KEY_ROTATION, 0)
            val inFps = fmtInt(vf, MediaFormat.KEY_FRAME_RATE, 30).coerceIn(1, 120)
            val durationUs = if (vf.containsKey(MediaFormat.KEY_DURATION)) vf.getLong(MediaFormat.KEY_DURATION) else 0L

            val swap = rotation == 90 || rotation == 270
            val dispW = if (swap) inH else inW
            val dispH = if (swap) inW else inH
            var scale = 1f
            if (p.shortSide > 0 && min(dispW, dispH) > p.shortSide) scale = p.shortSide.toFloat() / min(dispW, dispH)
            val outW = max(16, ((dispW * scale).roundToInt() / 2) * 2)
            val outH = max(16, ((dispH * scale).roundToInt() / 2) * 2)

            val startUs = p.startUs.coerceAtLeast(0L)
            val endUs = when {
                p.endUs != Long.MAX_VALUE -> p.endUs
                durationUs > 0 -> durationUs
                else -> Long.MAX_VALUE
            }
            val totalUs = if (endUs != Long.MAX_VALUE) (endUs - startUs).coerceAtLeast(1L) else 0L
            val outFps = if (p.fps in 1..120) p.fps else min(inFps, 60)
            val dropFrames = p.fps in 1 until inFps
            val frameGapUs = 1_000_000L / outFps

            // ---------- decoder (flexible YUV, read as Image)
            val mime = vf.getString(MediaFormat.KEY_MIME) ?: throw IOException("no mime")
            val dec = MediaCodec.createDecoderByType(mime).also { decoder = it }
            vf.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible)
            dec.configure(vf, null, null, 0)
            dec.start()
            if (startUs > 0) vEx.seekTo(startUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)

            // ---------- encoder (H.264, fed with YUV images so we control timestamps)
            val bitrate = (outW.toLong() * outH * outFps * 0.11).toLong().coerceIn(2_000_000L, 40_000_000L).toInt()
            val ef = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, outW, outH).apply {
                setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible)
                setInteger(MediaFormat.KEY_BIT_RATE, bitrate)
                setInteger(MediaFormat.KEY_FRAME_RATE, outFps)
                setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
            }
            val enc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC).also { encoder = it }
            enc.configure(ef, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            enc.start()

            // ---------- muxer
            pfd = ctx.contentResolver.openFileDescriptor(outUri, "rw") ?: throw IOException("no fd")
            val mux = MediaMuxer(pfd.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4).also { muxer = it }
            var audioOut = -1
            if (aTrack >= 0) {
                audioOut = try { mux.addTrack(aEx.getTrackFormat(aTrack)) } catch (e: Exception) { -1 }
            }
            var videoOut = -1
            var muxStarted = false
            var encDone = false
            val einfo = MediaCodec.BufferInfo()

            fun drainEncoder(wait: Boolean) {
                var spins = 0
                while (true) {
                    val idx = enc.dequeueOutputBuffer(einfo, if (wait) 10_000L else 0L)
                    when {
                        idx == MediaCodec.INFO_TRY_AGAIN_LATER -> {
                            if (!wait || encDone) return
                            if (++spins > 600) throw IOException("encoder stalled")
                        }
                        idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                            videoOut = mux.addTrack(enc.outputFormat)
                            mux.start()
                            muxStarted = true
                        }
                        idx >= 0 -> {
                            val buf = enc.getOutputBuffer(idx)
                            if (einfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) einfo.size = 0
                            if (einfo.size > 0 && muxStarted && buf != null) {
                                buf.position(einfo.offset)
                                buf.limit(einfo.offset + einfo.size)
                                mux.writeSampleData(videoOut, buf, einfo)
                            }
                            enc.releaseOutputBuffer(idx, false)
                            if (einfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) { encDone = true; return }
                        }
                    }
                }
            }

            fun feedEncoder(argb: IntArray, ptsUs: Long) {
                var tries = 0
                while (true) {
                    val i = enc.dequeueInputBuffer(10_000L)
                    if (i >= 0) {
                        val img = enc.getInputImage(i) ?: throw IOException("no input image")
                        Yuv.fillFromArgb(img, argb, outW, outH)
                        enc.queueInputBuffer(i, 0, outW * outH * 3 / 2, ptsUs, 0)
                        drainEncoder(false)
                        return
                    }
                    drainEncoder(false)
                    if (++tries > 600) throw IOException("encoder input stalled")
                }
            }

            // ---------- main loop
            val dinfo = MediaCodec.BufferInfo()
            var inputDone = false
            var decDone = false
            var nextKeepUs = 0L
            var lastOutPts = 0L
            var prevMask: SubjectMask? = null
            val argbOut = IntArray(outW * outH)

            while (!decDone) {
                coroutineContext.ensureActive()
                if (!inputDone) {
                    val ii = dec.dequeueInputBuffer(10_000L)
                    if (ii >= 0) {
                        val ib = dec.getInputBuffer(ii) ?: throw IOException("no input buffer")
                        val sz = vEx.readSampleData(ib, 0)
                        val t = vEx.sampleTime
                        if (sz < 0 || (endUs != Long.MAX_VALUE && t > endUs)) {
                            dec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            dec.queueInputBuffer(ii, 0, sz, t, 0)
                            vEx.advance()
                        }
                    }
                }
                val oi = dec.dequeueOutputBuffer(dinfo, 10_000L)
                if (oi >= 0) {
                    val eos = dinfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0
                    val pts = dinfo.presentationTimeUs
                    val inRange = pts >= startUs && (endUs == Long.MAX_VALUE || pts <= endUs)
                    if (dinfo.size > 0 && inRange) {
                        val rel = pts - startUs
                        val keep = !dropFrames || rel >= nextKeepUs
                        if (keep) {
                            if (dropFrames) nextKeepUs = max(nextKeepUs, rel - frameGapUs) + frameGapUs
                            val image = dec.getOutputImage(oi)
                            if (image != null) {
                                var frame: Bitmap = Yuv.imageToBitmap(image)
                                image.close()
                                // upright + target size
                                if (rotation != 0) {
                                    val m = Matrix().apply { postRotate(rotation.toFloat()) }
                                    val r = Bitmap.createBitmap(frame, 0, 0, frame.width, frame.height, m, true)
                                    frame.recycle(); frame = r
                                }
                                if (frame.width != outW || frame.height != outH) {
                                    val s = Bitmap.createScaledBitmap(frame, outW, outH, true)
                                    if (s !== frame) frame.recycle()
                                    frame = s
                                }
                                // cinematic blur
                                if (segmenter != null && p.blurPct > 0) {
                                    val sc = 320f / max(frame.width, frame.height)
                                    val small = Bitmap.createScaledBitmap(
                                        frame, max(8, (frame.width * sc).roundToInt()), max(8, (frame.height * sc).roundToInt()), true
                                    )
                                    val raw = segmenter.segment(small, streaming = true)
                                    small.recycle()
                                    if (raw != null) {
                                        val prev = prevMask
                                        val mask = if (prev != null && prev.w == raw.w && prev.h == raw.h)
                                            SubjectMask(raw.w, raw.h, FloatArray(raw.a.size) { raw.a[it] * 0.65f + prev.a[it] * 0.35f })
                                        else raw
                                        prevMask = mask
                                        if (mask.hasSubject) {
                                            val r = PortraitEngine.render(frame, mask, p.blurPct)
                                            frame.recycle(); frame = r
                                        }
                                    }
                                }
                                if (!p.look.isIdentity) {
                                    val f = FilterEngine.apply(frame, p.look)
                                    frame.recycle(); frame = f
                                }
                                frame.getPixels(argbOut, 0, outW, 0, 0, outW, outH)
                                frame.recycle()
                                val outPts = max(rel, lastOutPts + 1)
                                lastOutPts = outPts
                                feedEncoder(argbOut, outPts)
                                if (totalUs > 0) onProgress(((rel * 100L) / totalUs).toInt().coerceIn(0, 99))
                            }
                        }
                    }
                    dec.releaseOutputBuffer(oi, false)
                    if (eos) decDone = true
                }
            }

            // ---------- finish video
            var tries = 0
            while (true) {
                val i = enc.dequeueInputBuffer(10_000L)
                if (i >= 0) {
                    enc.queueInputBuffer(i, 0, 0, lastOutPts + 1, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                    break
                }
                drainEncoder(false)
                if (++tries > 600) throw IOException("encoder stalled at end")
            }
            drainEncoder(true)
            if (!muxStarted) throw IOException("no video frames were written")

            // ---------- audio passthrough (trimmed)
            if (aTrack >= 0 && audioOut >= 0) {
                aEx.seekTo(startUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
                val buf = ByteBuffer.allocate(512 * 1024)
                val bi = MediaCodec.BufferInfo()
                while (true) {
                    coroutineContext.ensureActive()
                    buf.clear()
                    val sz = aEx.readSampleData(buf, 0)
                    if (sz < 0) break
                    val t = aEx.sampleTime
                    if (endUs != Long.MAX_VALUE && t > endUs) break
                    if (t >= startUs) {
                        bi.set(
                            0, sz, t - startUs,
                            if (aEx.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC != 0) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0
                        )
                        mux.writeSampleData(audioOut, buf, bi)
                    }
                    aEx.advance()
                }
            }
            mux.stop()
            muxer?.release(); muxer = null
            onProgress(100)
            media.finishVideo(outUri)
            finished = true
            return outUri
        } finally {
            runCatching { decoder?.stop() }; runCatching { decoder?.release() }
            runCatching { encoder?.stop() }; runCatching { encoder?.release() }
            runCatching { muxer?.release() }
            runCatching { vx?.release() }; runCatching { ax?.release() }
            runCatching { pfd?.close() }
            segmenter?.close()
            if (!finished) media.discard(outUri)
        }
    }
}

/** YUV_420_888 <-> ARGB helpers (BT.709, limited range). */
object Yuv {

    fun imageToBitmap(img: Image): Bitmap {
        val crop = img.cropRect
        val w = crop.width()
        val h = crop.height()
        val yP = img.planes[0]
        val uP = img.planes[1]
        val vP = img.planes[2]
        val yb = ByteArray(yP.buffer.remaining()).also { yP.buffer.get(it) }
        val ub = ByteArray(uP.buffer.remaining()).also { uP.buffer.get(it) }
        val vb = ByteArray(vP.buffer.remaining()).also { vP.buffer.get(it) }
        val out = IntArray(w * h)
        for (y in 0 until h) {
            val sy = y + crop.top
            val yRow = sy * yP.rowStride
            val uRow = (sy shr 1) * uP.rowStride
            val vRow = (sy shr 1) * vP.rowStride
            for (x in 0 until w) {
                val sx = x + crop.left
                val yy = yb[yRow + sx * yP.pixelStride].toInt() and 0xFF
                val uu = (ub[uRow + (sx shr 1) * uP.pixelStride].toInt() and 0xFF) - 128
                val vv = (vb[vRow + (sx shr 1) * vP.pixelStride].toInt() and 0xFF) - 128
                val c = max(0, yy - 16) * 298
                val r = ((c + 459 * vv + 128) shr 8).coerceIn(0, 255)
                val g = ((c - 55 * uu - 136 * vv + 128) shr 8).coerceIn(0, 255)
                val b = ((c + 541 * uu + 128) shr 8).coerceIn(0, 255)
                out[y * w + x] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
            }
        }
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        bmp.setPixels(out, 0, w, 0, 0, w, h)
        return bmp
    }

    fun fillFromArgb(img: Image, argb: IntArray, w: Int, h: Int) {
        val yP = img.planes[0]
        val uP = img.planes[1]
        val vP = img.planes[2]
        val yBuf = yP.buffer
        val uBuf = uP.buffer
        val vBuf = vP.buffer
        for (y in 0 until h) {
            val row = y * yP.rowStride
            for (x in 0 until w) {
                val p = argb[y * w + x]
                val r = (p shr 16) and 0xFF
                val g = (p shr 8) and 0xFF
                val b = p and 0xFF
                val yy = ((47 * r + 157 * g + 16 * b + 128) shr 8) + 16
                yBuf.put(row + x * yP.pixelStride, yy.coerceIn(16, 235).toByte())
            }
        }
        for (y in 0 until h / 2) {
            for (x in 0 until w / 2) {
                val i0 = (2 * y) * w + 2 * x
                val p0 = argb[i0]
                val p1 = argb[i0 + 1]
                val p2 = argb[i0 + w]
                val p3 = argb[i0 + w + 1]
                val r = (((p0 shr 16) and 0xFF) + ((p1 shr 16) and 0xFF) + ((p2 shr 16) and 0xFF) + ((p3 shr 16) and 0xFF)) shr 2
                val g = (((p0 shr 8) and 0xFF) + ((p1 shr 8) and 0xFF) + ((p2 shr 8) and 0xFF) + ((p3 shr 8) and 0xFF)) shr 2
                val b = ((p0 and 0xFF) + (p1 and 0xFF) + (p2 and 0xFF) + (p3 and 0xFF)) shr 2
                val u = ((-26 * r - 87 * g + 112 * b + 128) shr 8) + 128
                val v = ((112 * r - 102 * g - 10 * b + 128) shr 8) + 128
                uBuf.put(y * uP.rowStride + x * uP.pixelStride, u.coerceIn(16, 240).toByte())
                vBuf.put(y * vP.rowStride + x * vP.pixelStride, v.coerceIn(16, 240).toByte())
            }
        }
    }
}
