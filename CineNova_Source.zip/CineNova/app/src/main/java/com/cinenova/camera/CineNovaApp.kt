package com.cinenova.camera

import android.app.Application
import com.cinenova.camera.camera.DeviceCaps
import com.cinenova.camera.data.AppSettings
import com.cinenova.camera.media.MediaStoreHelper
import java.io.File

class CineNovaApp : Application() {
    val settings by lazy { AppSettings(this) }
    val media by lazy { MediaStoreHelper(this) }
    val caps by lazy { DeviceCaps(this) }

    override fun onCreate() {
        super.onCreate()
        // Crash handling: keep the last crash locally (never uploaded), then let Android finish normally.
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            runCatching { File(cacheDir, "last_crash.txt").writeText(e.stackTraceToString()) }
            previous?.uncaughtException(t, e)
        }
    }
}
