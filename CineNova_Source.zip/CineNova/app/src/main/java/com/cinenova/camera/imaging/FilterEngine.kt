package com.cinenova.camera.imaging

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import androidx.annotation.StringRes
import com.cinenova.camera.R

/** The 13 CineNova looks. Each is a real colour transform (4x5 matrix) plus optional softness. */
enum class FilterId(val key: String, @StringRes val nameRes: Int) {
    NATURAL("natural", R.string.filter_natural),
    PORTRAIT_GLOW("portrait_glow", R.string.filter_portrait_glow),
    HOLLYWOOD("hollywood", R.string.filter_hollywood),
    TEAL_ORANGE("teal_orange", R.string.filter_teal_orange),
    VINTAGE("vintage", R.string.filter_vintage),
    BW("bw", R.string.filter_bw),
    GOLDEN_HOUR("golden_hour", R.string.filter_golden_hour),
    MOODY("moody", R.string.filter_moody),
    CINE_BLUE("cine_blue", R.string.filter_cine_blue),
    SOFT_SKIN("soft_skin", R.string.filter_soft_skin),
    MOVIE("movie", R.string.filter_movie),
    WARM("warm", R.string.filter_warm),
    COOL("cool", R.string.filter_cool);

    companion object {
        fun fromKey(k: String?): FilterId = values().firstOrNull { it.key == k } ?: NATURAL
    }
}

/** User-adjustable values, each -100..100 (sharpness 0..100). */
data class Adjustments(
    val brightness: Int = 0,
    val contrast: Int = 0,
    val saturation: Int = 0,
    val sharpness: Int = 0,
    val temperature: Int = 0,
    val denoise: Int = 0
) {
    val isIdentity get() = this == Adjustments()
}

/** Everything that defines a "look": filter(s) + intensity + adjustments. */
data class Look(
    val filter: FilterId = FilterId.NATURAL,
    val intensity: Int = 100,
    val second: FilterId? = null,
    val adjustments: Adjustments = Adjustments(),
    val beauty: Boolean = false
) {
    val isIdentity: Boolean
        get() = (filter == FilterId.NATURAL || intensity == 0) &&
            (second == null || second == FilterId.NATURAL) &&
            adjustments.isIdentity && !beauty
}

object FilterEngine {

    private val IDENTITY = floatArrayOf(
        1f, 0f, 0f, 0f, 0f,
        0f, 1f, 0f, 0f, 0f,
        0f, 0f, 1f, 0f, 0f,
        0f, 0f, 0f, 1f, 0f
    )

    private fun cm(arr: FloatArray) = ColorMatrix(arr)

    private fun saturation(s: Float): ColorMatrix = ColorMatrix().apply { setSaturation(s) }

    /** contrast c (1 = none) around mid-grey, plus offset in 0..255 units. */
    private fun contrastBrightness(c: Float, offset: Float): ColorMatrix {
        val t = 128f * (1f - c) + offset
        return cm(
            floatArrayOf(
                c, 0f, 0f, 0f, t,
                0f, c, 0f, 0f, t,
                0f, 0f, c, 0f, t,
                0f, 0f, 0f, 1f, 0f
            )
        )
    }

    private fun channels(r: Float, g: Float, b: Float, ro: Float = 0f, go: Float = 0f, bo: Float = 0f) = cm(
        floatArrayOf(
            r, 0f, 0f, 0f, ro,
            0f, g, 0f, 0f, go,
            0f, 0f, b, 0f, bo,
            0f, 0f, 0f, 1f, 0f
        )
    )

    private fun concat(vararg ms: ColorMatrix): ColorMatrix {
        val out = ColorMatrix()
        for (m in ms) out.postConcat(m)
        return out
    }

    /** The full-strength colour matrix for one filter. */
    fun matrixFor(id: FilterId): ColorMatrix = when (id) {
        FilterId.NATURAL -> concat(contrastBrightness(1.03f, 0f), saturation(1.03f))
        FilterId.PORTRAIT_GLOW -> concat(channels(1.04f, 1.0f, 0.98f, 6f, 3f, 0f), contrastBrightness(0.95f, 8f), saturation(1.05f))
        FilterId.HOLLYWOOD -> concat(channels(1.06f, 1.0f, 0.94f), contrastBrightness(1.2f, -8f), saturation(1.1f))
        FilterId.TEAL_ORANGE -> concat(
            cm(
                floatArrayOf(
                    1.12f, 0.02f, -0.06f, 0f, 8f,
                    -0.02f, 0.98f, 0.06f, 0f, 0f,
                    -0.12f, 0.10f, 1.18f, 0f, 6f,
                    0f, 0f, 0f, 1f, 0f
                )
            ),
            contrastBrightness(1.1f, -4f), saturation(1.12f)
        )
        FilterId.VINTAGE -> concat(
            cm(
                floatArrayOf(
                    0.393f + 0.3f, 0.769f * 0.5f, 0.189f * 0.5f, 0f, 14f,
                    0.349f * 0.5f, 0.686f + 0.2f, 0.168f * 0.5f, 0f, 10f,
                    0.272f * 0.5f, 0.534f * 0.5f, 0.131f + 0.55f, 0f, 6f,
                    0f, 0f, 0f, 1f, 0f
                )
            ),
            contrastBrightness(0.9f, 12f), saturation(0.85f)
        )
        FilterId.BW -> concat(saturation(0f), contrastBrightness(1.12f, -4f))
        FilterId.GOLDEN_HOUR -> concat(channels(1.12f, 1.02f, 0.80f, 8f, 0f, 0f), contrastBrightness(1.05f, 6f), saturation(1.1f))
        FilterId.MOODY -> concat(channels(0.96f, 1.0f, 1.06f), contrastBrightness(1.25f, -18f), saturation(0.8f))
        FilterId.CINE_BLUE -> concat(channels(0.88f, 0.98f, 1.16f, 0f, 0f, 4f), contrastBrightness(1.1f, -4f), saturation(1.05f))
        FilterId.SOFT_SKIN -> concat(channels(1.03f, 1.0f, 0.98f, 4f, 2f, 0f), contrastBrightness(0.92f, 7f), saturation(0.95f))
        FilterId.MOVIE -> concat(channels(1.02f, 1.0f, 1.04f, 0f, 2f, 3f), contrastBrightness(1.15f, -8f), saturation(1.2f))
        FilterId.WARM -> channels(1.08f, 1.0f, 0.92f, 4f, 0f, 0f)
        FilterId.COOL -> channels(0.93f, 1.0f, 1.08f, 0f, 0f, 4f)
    }

    /** Skin softening strength used by Soft Skin / Portrait Glow / beauty (0..1). */
    fun softness(id: FilterId): Float = when (id) {
        FilterId.SOFT_SKIN -> 0.55f
        FilterId.PORTRAIT_GLOW -> 0.30f
        else -> 0f
    }

    private fun lerp(a: FloatArray, b: FloatArray, t: Float) =
        FloatArray(20) { a[it] + (b[it] - a[it]) * t }

    fun blended(id: FilterId, intensity: Int): FloatArray {
        val t = (intensity / 100f).coerceIn(0f, 1f)
        return lerp(IDENTITY, matrixFor(id).array, t)
    }

    private fun adjustmentMatrix(a: Adjustments): ColorMatrix {
        val sat = saturation((1f + a.saturation / 100f).coerceIn(0f, 2f))
        val c = (1f + a.contrast / 100f).coerceIn(0.2f, 2f)
        val cb = contrastBrightness(c, a.brightness * 1.6f)
        val t = a.temperature / 100f
        val temp = channels(1f + 0.18f * t, 1f + 0.02f * t, 1f - 0.18f * t)
        return concat(temp, sat, cb)
    }

    /** Final colour matrix for a Look (filter, optional second filter, adjustments). */
    fun colorMatrixFor(look: Look): ColorMatrix {
        val out = ColorMatrix()
        out.postConcat(ColorMatrix(blended(look.filter, look.intensity)))
        val s = look.second
        if (s != null && s != FilterId.NATURAL) out.postConcat(ColorMatrix(blended(s, look.intensity)))
        if (!look.adjustments.isIdentity) out.postConcat(adjustmentMatrix(look.adjustments))
        return out
    }

    fun colorFilterFor(look: Look): ColorMatrixColorFilter = ColorMatrixColorFilter(colorMatrixFor(look))

    /** Skin-softening amount (0..1) for a look. */
    fun softnessFor(look: Look): Float {
        var s = softness(look.filter) * look.intensity / 100f
        look.second?.let { s += softness(it) * look.intensity / 100f }
        if (look.beauty) s += 0.35f
        return s.coerceIn(0f, 0.9f)
    }

    /**
     * Applies a [Look] to [src] and returns a NEW bitmap (the source is never modified).
     * Order: denoise -> softness -> colour matrix -> sharpen.
     */
    fun apply(src: Bitmap, look: Look): Bitmap {
        if (look.isIdentity) return src.copy(Bitmap.Config.ARGB_8888, false)
        var work = src
        var owned = false

        if (look.adjustments.denoise > 0) {
            val n = Denoise.apply(work, look.adjustments.denoise / 100f)
            work = n; owned = true
        }
        val soft = softnessFor(look)
        if (soft > 0.01f) {
            val n = Smoothing.soften(work, soft)
            if (owned) work.recycle()
            work = n; owned = true
        }

        val out = Bitmap.createBitmap(work.width, work.height, Bitmap.Config.ARGB_8888)
        val paint = Paint(Paint.FILTER_BITMAP_FLAG).apply { colorFilter = colorFilterFor(look) }
        Canvas(out).drawBitmap(work, 0f, 0f, paint)
        if (owned) work.recycle()

        if (look.adjustments.sharpness > 0) {
            val sharp = Sharpen.unsharp(out, look.adjustments.sharpness / 100f)
            out.recycle()
            return sharp
        }
        return out
    }
}
