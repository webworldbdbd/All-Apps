package com.cinenova.camera.imaging

import com.cinenova.camera.data.Settings

/** The look the camera applies, built from the saved settings. */
fun Settings.toLook(): Look = Look(
    filter = FilterId.fromKey(filterId),
    intensity = filterIntensity,
    second = secondFilterId.takeIf { it.isNotEmpty() }?.let { FilterId.fromKey(it) },
    adjustments = Adjustments(),
    beauty = beauty
)
