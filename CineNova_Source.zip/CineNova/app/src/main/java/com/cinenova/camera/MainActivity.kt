package com.cinenova.camera

import android.content.Context
import android.content.res.Configuration
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.cinenova.camera.camera.CameraController
import com.cinenova.camera.media.VideoProcessor
import com.cinenova.camera.ui.CameraScreen
import com.cinenova.camera.ui.CineNovaTheme
import com.cinenova.camera.ui.FiltersScreen
import com.cinenova.camera.ui.GalleryScreen
import com.cinenova.camera.ui.Gold
import com.cinenova.camera.ui.Ink
import com.cinenova.camera.ui.PhotoEditorScreen
import com.cinenova.camera.ui.SettingsScreen
import com.cinenova.camera.ui.VideoEditorScreen
import java.util.Locale

private sealed interface Screen {
    object Camera : Screen
    object Gallery : Screen
    object Filters : Screen
    object Settings : Screen
    data class PhotoEditor(val uri: String) : Screen
    data class VideoEditor(val uri: String) : Screen
}

class MainActivity : ComponentActivity() {

    private lateinit var camera: CameraController

    /** Applies the language chosen in Settings (English / বাংলা) to the whole UI. */
    override fun attachBaseContext(base: Context) {
        val lang = base.getSharedPreferences("cinenova_prefs", MODE_PRIVATE).getString("language", "en") ?: "en"
        val cfg = Configuration(base.resources.configuration)
        cfg.setLocale(Locale(lang))
        super.attachBaseContext(base.createConfigurationContext(cfg))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val app = application as CineNovaApp
        camera = CameraController(applicationContext, app.caps, app.settings, app.media)
        val processor = VideoProcessor(applicationContext, app.media)

        setContent {
            val set by app.settings.state.collectAsState()
            var screen by remember { mutableStateOf<Screen>(Screen.Camera) }
            var splash by rememberSaveable { mutableStateOf(true) }

            CineNovaTheme(set.theme) {
                Box(Modifier.fillMaxSize().background(Ink)) {
                    when (val s = screen) {
                        Screen.Camera -> CineNovaTheme("dark") {
                            CameraScreen(
                                camera = camera, appSettings = app.settings, media = app.media,
                                onGallery = { screen = Screen.Gallery },
                                onFilters = { screen = Screen.Filters },
                                onSettings = { screen = Screen.Settings }
                            )
                        }
                        Screen.Gallery -> {
                            BackHandler { screen = Screen.Camera }
                            GalleryScreen(
                                media = app.media, appSettings = app.settings,
                                onBack = { screen = Screen.Camera },
                                onEditPhoto = { screen = Screen.PhotoEditor(it.toString()) },
                                onEditVideo = { screen = Screen.VideoEditor(it.toString()) }
                            )
                        }
                        Screen.Filters -> {
                            BackHandler { screen = Screen.Camera }
                            FiltersScreen(app.settings, app.media) { screen = Screen.Camera }
                        }
                        Screen.Settings -> {
                            BackHandler { screen = Screen.Camera }
                            SettingsScreen(app.settings, camera, app.media) { screen = Screen.Camera }
                        }
                        is Screen.PhotoEditor -> {
                            BackHandler { screen = Screen.Gallery }
                            PhotoEditorScreen(Uri.parse(s.uri), app.media, app.settings, app.caps) { screen = Screen.Gallery }
                        }
                        is Screen.VideoEditor -> {
                            BackHandler { screen = Screen.Gallery }
                            VideoEditorScreen(Uri.parse(s.uri), processor, app.settings) { screen = Screen.Gallery }
                        }
                    }
                    if (splash) SplashOverlay { splash = false }
                }
            }
        }
    }

    override fun onStop() {
        super.onStop()
        // finish any recording cleanly if the app goes to the background
        if (camera.state.value.recording) camera.stopRecording()
    }

    override fun onDestroy() {
        super.onDestroy()
        if (isFinishing) camera.release() else camera.unbind()
    }
}

/** Short branded splash drawn over the camera while it starts underneath. */
@Composable
private fun SplashOverlay(onDone: () -> Unit) {
    val fadeA = remember { Animatable(1f) }
    val pop = remember { Animatable(0.85f) }
    LaunchedEffect(Unit) {
        pop.animateTo(1f, tween(600))
        kotlinx.coroutines.delay(500)
        fadeA.animateTo(0f, tween(300))
        onDone()
    }
    Box(Modifier.fillMaxSize().background(Ink.copy(alpha = fadeA.value)), contentAlignment = Alignment.Center) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.graphicsLayer { this.alpha = fadeA.value; scaleX = pop.value; scaleY = pop.value }
        ) {
            Image(painterResource(R.drawable.logo_cinenova), null, modifier = Modifier.size(170.dp))
            Text(stringResource(R.string.app_name), color = Gold, fontSize = 34.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 4.dp))
            Text(stringResource(R.string.tagline), color = Color.White.copy(alpha = 0.8f), fontSize = 14.sp, modifier = Modifier.padding(top = 6.dp))
        }
    }
}
