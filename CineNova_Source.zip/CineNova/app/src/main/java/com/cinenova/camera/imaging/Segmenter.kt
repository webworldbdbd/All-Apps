package com.cinenova.camera.imaging

import android.graphics.Bitmap
import com.google.android.gms.tasks.Task
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.segmentation.Segmentation
import com.google.mlkit.vision.segmentation.Segmenter as MlSegmenter
import com.google.mlkit.vision.segmentation.selfie.SelfieSegmenterOptions
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlinx.coroutines.suspendCancellableCoroutine

/** Person-vs-background confidence mask, values 0..1, size w x h. */
class SubjectMask(val w: Int, val h: Int, val a: FloatArray) {
    /** Share of pixels that are confidently "person". */
    val coverage: Float
        get() {
            var n = 0
            for (v in a) if (v > 0.6f) n++
            return n.toFloat() / a.size
        }

    /** True when a person is really present (more than ~1.5% of the frame). */
    val hasSubject: Boolean get() = coverage > 0.015f
}

suspend fun <T> Task<T>.awaitResult(): T = suspendCancellableCoroutine { c ->
    addOnSuccessListener { c.resume(it) }
    addOnFailureListener { c.resumeWithException(it) }
    addOnCanceledListener { c.cancel() }
}

/** On-device ML Kit selfie segmentation (bundled model, works offline). */
class Segmenter {
    private val single: MlSegmenter by lazy {
        Segmentation.getClient(
            SelfieSegmenterOptions.Builder()
                .setDetectorMode(SelfieSegmenterOptions.SINGLE_IMAGE_MODE)
                .build()
        )
    }
    private val stream: MlSegmenter by lazy {
        Segmentation.getClient(
            SelfieSegmenterOptions.Builder()
                .setDetectorMode(SelfieSegmenterOptions.STREAM_MODE)
                .build()
        )
    }

    /**
     * Segments [bmp]. Keep the bitmap small (<= ~640 px long side) for speed; the model
     * works at 256x256 internally anyway. Returns null if the model could not run.
     */
    suspend fun segment(bmp: Bitmap, streaming: Boolean = false): SubjectMask? {
        return try {
            val client = if (streaming) stream else single
            val m = client.process(InputImage.fromBitmap(bmp, 0)).awaitResult()
            val w = m.width
            val h = m.height
            val buf = m.buffer
            buf.rewind()
            val data = FloatArray(w * h)
            for (i in data.indices) data[i] = buf.float
            SubjectMask(w, h, data)
        } catch (e: Exception) {
            null
        }
    }

    fun close() {
        runCatching { single.close() }
        runCatching { stream.close() }
    }
}
