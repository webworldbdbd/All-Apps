package com.cinenova.camera.imaging

import android.graphics.Bitmap
import androidx.annotation.StringRes
import com.cinenova.camera.R
import kotlin.math.max
import kotlin.math.min

enum class PortraitLight(val key: String, @StringRes val nameRes: Int) {
    NONE("none", R.string.light_none),
    STUDIO("studio", R.string.light_studio),
    CONTOUR("contour", R.string.light_contour),
    STAGE("stage", R.string.light_stage)
}

/**
 * Portrait / cinematic compositor.
 *  - refines the raw mask (smoothstep + feather) so hair edges look natural
 *  - blurs the background using normalised convolution so subject colour never bleeds into bokeh
 *  - adds a soft highlight bloom for a bokeh feel, plus optional portrait lighting
 */
private fun bilerp(p00: Int, p10: Int, p01: Int, p11: Int, sh8: Int, fx: Float, fy: Float): Float {
    val a = ((p00 shr sh8) and 0xFF) * (1 - fx) + ((p10 shr sh8) and 0xFF) * fx
    val c = ((p01 shr sh8) and 0xFF) * (1 - fx) + ((p11 shr sh8) and 0xFF) * fx
    return a * (1 - fy) + c * fy
}

object PortraitEngine {

    /** Hair/edge refinement: sharpen confidence transition, then feather slightly. */
    fun refine(mask: SubjectMask): SubjectMask {
        val n = mask.a.size
        val packed = IntArray(n)
        for (i in 0 until n) {
            val m = mask.a[i]
            val t = ((m - 0.30f) / 0.50f).coerceIn(0f, 1f)
            val s = t * t * (3f - 2f * t)
            val g = (s * 255f).toInt()
            packed[i] = (0xFF shl 24) or (g shl 16) or (g shl 8) or g
        }
        val feather = max(1, min(mask.w, mask.h) / 128)
        val blurred = FastBlur.blur(packed, mask.w, mask.h, feather, 1)
        val out = FloatArray(n) { (blurred[it] and 0xFF) / 255f }
        return SubjectMask(mask.w, mask.h, out)
    }

    /** Bilinear sample of mask at normalised coordinates. */
    private fun sample(m: SubjectMask, u: Float, v: Float): Float {
        val x = (u * (m.w - 1)).coerceIn(0f, (m.w - 1).toFloat())
        val y = (v * (m.h - 1)).coerceIn(0f, (m.h - 1).toFloat())
        val x0 = x.toInt()
        val y0 = y.toInt()
        val x1 = min(x0 + 1, m.w - 1)
        val y1 = min(y0 + 1, m.h - 1)
        val fx = x - x0
        val fy = y - y0
        val a = m.a[y0 * m.w + x0] * (1 - fx) + m.a[y0 * m.w + x1] * fx
        val b = m.a[y1 * m.w + x0] * (1 - fx) + m.a[y1 * m.w + x1] * fx
        return a * (1 - fy) + b * fy
    }

    /**
     * Renders the portrait. [src] is never modified. [blurPct] 0..100.
     * The mask can come from any resolution; it is stretched to the bitmap.
     */
    fun render(
        src: Bitmap,
        rawMask: SubjectMask,
        blurPct: Int,
        light: PortraitLight = PortraitLight.NONE,
        refined: Boolean = false
    ): Bitmap {
        val mask = if (refined) rawMask else refine(rawMask)
        val w = src.width
        val h = src.height
        val pct = blurPct.coerceIn(0, 100) / 100f

        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)

        // ---- background blur at 1/4 scale, normalised by background weight ----
        val bg: IntArray?
        var sw = 1
        var sh = 1
        if (pct > 0.01f) {
            val scale = 4
            sw = max(8, w / scale)
            sh = max(8, h / scale)
            val small = Bitmap.createScaledBitmap(src, sw, sh, true)
            val sp = IntArray(sw * sh)
            small.getPixels(sp, 0, sw, 0, 0, sw, sh)
            small.recycle()

            val weighted = IntArray(sw * sh)
            val weightPx = IntArray(sw * sh)
            for (y in 0 until sh) {
                val v = y / (sh - 1f)
                for (x in 0 until sw) {
                    val i = y * sw + x
                    val wgt = 1f - sample(mask, x / (sw - 1f), v)
                    val p = sp[i]
                    val r = (((p shr 16) and 0xFF) * wgt).toInt()
                    val g = (((p shr 8) and 0xFF) * wgt).toInt()
                    val b = ((p and 0xFF) * wgt).toInt()
                    weighted[i] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
                    val wv = (wgt * 255f).toInt()
                    weightPx[i] = (0xFF shl 24) or (wv shl 16) or (wv shl 8) or wv
                }
            }
            val radius = max(1, (pct * min(sw, sh) * 0.09f).toInt())
            val bc = FastBlur.blur(weighted, sw, sh, radius, 3)
            val bw = FastBlur.blur(weightPx, sw, sh, radius, 3)
            val res = IntArray(sw * sh)
            for (i in res.indices) {
                val wv = max(1, bw[i] and 0xFF) / 255f
                // fall back to plain small image where there is no background nearby
                val r = min(255, (((bc[i] shr 16) and 0xFF) / wv).toInt())
                val g = min(255, (((bc[i] shr 8) and 0xFF) / wv).toInt())
                val b = min(255, ((bc[i] and 0xFF) / wv).toInt())
                res[i] = if ((bw[i] and 0xFF) < 4) sp[i] else (0xFF shl 24) or (r shl 16) or (g shl 8) or b
            }
            bg = res
        } else bg = null

        // ---- composite ----
        val out = IntArray(w * h)
        for (y in 0 until h) {
            val v = y / (h - 1f)
            val by = if (bg != null) (v * (sh - 1)) else 0f
            val y0 = by.toInt()
            val y1 = min(y0 + 1, sh - 1)
            val fy = by - y0
            for (x in 0 until w) {
                val i = y * w + x
                val u = x / (w - 1f)
                val m = sample(mask, u, v)
                val p = px[i]
                var r = (p shr 16) and 0xFF
                var g = (p shr 8) and 0xFF
                var b = p and 0xFF

                var br = r.toFloat()
                var bgG = g.toFloat()
                var bb = b.toFloat()
                if (bg != null && m < 0.999f) {
                    val bx = u * (sw - 1)
                    val x0 = bx.toInt()
                    val x1 = min(x0 + 1, sw - 1)
                    val fx = bx - x0
                    val p00 = bg[y0 * sw + x0]; val p10 = bg[y0 * sw + x1]
                    val p01 = bg[y1 * sw + x0]; val p11 = bg[y1 * sw + x1]
                    br = bilerp(p00, p10, p01, p11, 16, fx, fy)
                    bgG = bilerp(p00, p10, p01, p11, 8, fx, fy)
                    bb = bilerp(p00, p10, p01, p11, 0, fx, fy)
                    // bokeh bloom: bright blurred areas glow a little
                    val l = 0.299f * br + 0.587f * bgG + 0.114f * bb
                    if (l > 190f) {
                        val k = (l - 190f) / 65f * 26f * pct
                        br += k; bgG += k; bb += k
                    }
                }

                // portrait lighting
                var sr = r.toFloat(); var sg = g.toFloat(); var sb = b.toFloat()
                when (light) {
                    PortraitLight.STUDIO -> { sr = sr * 1.07f + 4f; sg = sg * 1.06f + 3f; sb = sb * 1.03f }
                    PortraitLight.CONTOUR -> {
                        val shade = 1f - 0.22f * u
                        sr = (sr - 128f) * 1.12f * shade + 128f
                        sg = (sg - 128f) * 1.12f * shade + 128f
                        sb = (sb - 128f) * 1.12f * shade + 128f
                    }
                    PortraitLight.STAGE -> { sr *= 1.05f; sg *= 1.04f }
                    PortraitLight.NONE -> {}
                }
                if (light == PortraitLight.STAGE) { br *= 0.35f; bgG *= 0.35f; bb *= 0.38f }
                if (light == PortraitLight.STUDIO) {
                    val dx = u - 0.5f
                    val dy = v - 0.5f
                    val vig = 1f - 0.35f * (dx * dx + dy * dy) * 2f
                    br *= vig; bgG *= vig; bb *= vig
                }

                r = (sr * m + br * (1 - m)).toInt().coerceIn(0, 255)
                g = (sg * m + bgG * (1 - m)).toInt().coerceIn(0, 255)
                b = (sb * m + bb * (1 - m)).toInt().coerceIn(0, 255)
                out[i] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
            }
        }
        val res = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        res.setPixels(out, 0, w, 0, 0, w, h)
        return res
    }

    /**
     * Transparent overlay holding ONLY the blurred background (alpha = 1 - subject mask).
     * Drawn above the live camera preview so the person stays sharp at full preview resolution.
     */
    fun overlay(src: Bitmap, raw: SubjectMask, blurPct: Int): Bitmap {
        val mask = refine(raw)
        val comp = render(src, mask, blurPct, PortraitLight.NONE, refined = true)
        val w = comp.width
        val h = comp.height
        val px = IntArray(w * h)
        comp.getPixels(px, 0, w, 0, 0, w, h)
        comp.recycle()
        for (y in 0 until h) {
            val v = y / (h - 1f).coerceAtLeast(1f)
            for (x in 0 until w) {
                val m = sample(mask, x / (w - 1f).coerceAtLeast(1f), v)
                val a = ((1f - m) * 255f).toInt().coerceIn(0, 255)
                val i = y * w + x
                px[i] = (a shl 24) or (px[i] and 0xFFFFFF)
            }
        }
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        out.setPixels(px, 0, w, 0, 0, w, h)
        return out
    }
}
