package com.cinenova.camera.imaging

import android.graphics.Bitmap
import android.graphics.Matrix
import kotlin.math.max
import kotlin.math.min

/** Crop description: [ratio] = width/height (0 = keep the picture's own ratio). */
data class CropSpec(val ratio: Float = 0f, val zoom: Float = 1f, val panX: Float = 0f, val panY: Float = 0f) {
    val isIdentity get() = ratio == 0f && zoom <= 1.001f
}

object Geometry {
    /** Rotate (quarter turns), flip, then crop. Returns [src] itself when nothing changes. */
    fun transform(src: Bitmap, quarterTurns: Int, flipH: Boolean, flipV: Boolean, crop: CropSpec): Bitmap {
        val turns = ((quarterTurns % 4) + 4) % 4
        var cur = src
        if (turns != 0 || flipH || flipV) {
            val m = Matrix()
            m.postRotate(turns * 90f)
            m.postScale(if (flipH) -1f else 1f, if (flipV) -1f else 1f)
            cur = Bitmap.createBitmap(src, 0, 0, src.width, src.height, m, true)
        }
        if (crop.isIdentity) return cur
        val w = cur.width.toFloat()
        val h = cur.height.toFloat()
        val a = if (crop.ratio > 0f) crop.ratio else w / h
        var cw: Float
        var ch: Float
        if (w / h > a) { ch = h; cw = h * a } else { cw = w; ch = w / a }
        val z = max(1f, crop.zoom)
        cw /= z; ch /= z
        val left = ((w - cw) / 2f * (1f + crop.panX.coerceIn(-1f, 1f))).coerceIn(0f, w - cw)
        val top = ((h - ch) / 2f * (1f + crop.panY.coerceIn(-1f, 1f))).coerceIn(0f, h - ch)
        val out = Bitmap.createBitmap(
            cur, left.toInt(), top.toInt(),
            max(1, min(cw.toInt(), cur.width - left.toInt())), max(1, min(ch.toInt(), cur.height - top.toInt()))
        )
        if (cur !== src && out !== cur) cur.recycle()
        return out
    }
}
