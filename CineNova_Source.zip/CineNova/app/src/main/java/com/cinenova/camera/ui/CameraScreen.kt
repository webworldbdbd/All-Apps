package com.cinenova.camera.ui

import android.Manifest
import android.hardware.camera2.CameraMetadata
import android.view.HapticFeedbackConstants
import android.view.View
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.view.PreviewView
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FlashAuto
import androidx.compose.material.icons.filled.FlashOff
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.FlipCameraAndroid
import androidx.compose.material.icons.filled.GridOn
import androidx.compose.material.icons.filled.HdrOn
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.cinenova.camera.R
import com.cinenova.camera.camera.CamMode
import com.cinenova.camera.camera.CameraController
import com.cinenova.camera.camera.LensKind
import com.cinenova.camera.camera.PerfTier
import com.cinenova.camera.data.AppSettings
import com.cinenova.camera.imaging.FilterEngine
import com.cinenova.camera.imaging.FilterId
import com.cinenova.camera.imaging.PortraitLight
import com.cinenova.camera.imaging.toLook
import com.cinenova.camera.media.MediaItem
import com.cinenova.camera.media.MediaStoreHelper
import kotlin.math.roundToInt
import kotlinx.coroutines.delay

private val SHUTTER_STOPS_NS = listOf(
    125_000L, 250_000L, 500_000L, 1_000_000L, 2_000_000L, 4_000_000L, 8_000_000L, 16_666_666L,
    33_333_333L, 66_666_666L, 125_000_000L, 250_000_000L, 500_000_000L
)
private val SHUTTER_LABELS = listOf(
    "1/8000", "1/4000", "1/2000", "1/1000", "1/500", "1/250", "1/125", "1/60", "1/30", "1/15", "1/8", "1/4", "1/2"
)

@Composable
fun CameraScreen(
    camera: CameraController,
    appSettings: AppSettings,
    media: MediaStoreHelper,
    onGallery: () -> Unit,
    onFilters: () -> Unit,
    onSettings: () -> Unit
) {
    val ctx = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val view = LocalView.current
    val st by camera.state.collectAsState()
    val set by appSettings.state.collectAsState()
    var mode by rememberSaveable { mutableStateOf(CamMode.PHOTO) }
    var hasCam by remember { mutableStateOf(ctx.granted(Manifest.permission.CAMERA)) }
    var pv by remember { mutableStateOf<PreviewView?>(null) }
    var latest by remember { mutableStateOf<MediaItem?>(null) }
    var tab by rememberSaveable { mutableStateOf(0) }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        hasCam = ctx.granted(Manifest.permission.CAMERA)
    }
    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    LaunchedEffect(Unit) {
        camera.prepareSounds()
        if (!hasCam) permLauncher.launch(cameraPermissions())
    }
    // microphone permission is requested only when recording video with audio on
    LaunchedEffect(mode, set.audio) {
        if (mode == CamMode.VIDEO && set.audio && !ctx.granted(Manifest.permission.RECORD_AUDIO)) {
            micLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }
    LaunchedEffect(st.savedCounter) { latest = media.listAll().firstOrNull() }
    LaunchedEffect(mode) {
        camera.setBlur(if (mode == CamMode.VIDEO) set.videoBlur else set.defaultBlur)
        if (mode != CamMode.PRO) camera.resetPro()
    }
    LaunchedEffect(pv, mode, st.rebindTick, set.videoQuality, set.videoFps, set.photoSize, set.stabilization, hasCam) {
        val v = pv
        if (hasCam && v != null) camera.bind(owner, v, mode)
    }
    LaunchedEffect(st.bound, set.autofocus, set.hdr, set.flash) {
        if (st.bound) { camera.applyCaptureOptions(); camera.applyFlash() }
    }
    DisposableEffect(Unit) { onDispose { camera.unbind() } }

    if (!hasCam) {
        PermissionPrompt { permLauncher.launch(cameraPermissions()) }
        return
    }

    val look = remember(set.filterId, set.filterIntensity, set.secondFilterId, set.beauty) { set.toLook() }
    val applyLive = mode != CamMode.VIDEO || set.liveFilter
    val liveFilter = applyLive && !look.isIdentity
    val paint = remember(look, liveFilter) {
        android.graphics.Paint().apply { if (liveFilter) colorFilter = FilterEngine.colorFilterFor(look) }
    }
    val overlayFilter = remember(look, liveFilter) {
        if (liveFilter) ColorFilter.colorMatrix(ColorMatrix(FilterEngine.colorMatrixFor(look).array)) else null
    }
    val info = camera.currentInfo()

    fun haptic() { if (set.haptic) view.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY) }

    val onShutter = {
        if (st.countdown > 0) camera.cancelTimer()
        else if (mode == CamMode.VIDEO) {
            haptic()
            if (st.recording) camera.stopRecording() else camera.startRecording()
        } else camera.capture { haptic() }
    }

    var panelOpen by rememberSaveable { mutableStateOf(false) }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        // ---------------------------------------------------------------- full-screen viewfinder
        Box(
            Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectTapGestures(onTap = { o -> camera.tapFocus(o.x, o.y, size.width.toFloat(), size.height.toFloat()) })
                }
                .pointerInput(Unit) {
                    val zoomNow = { st.zoom }
                    detectTransformGestures { _, _, zoom, _ -> if (zoom != 1f) camera.setZoom(zoomNow() * zoom) }
                }
        ) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { c ->
                        PreviewView(c).apply {
                            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
                            scaleType = PreviewView.ScaleType.FILL_CENTER
                        }.also { pv = it }
                    },
                    update = { v ->
                        if (liveFilter) v.setLayerType(View.LAYER_TYPE_HARDWARE, paint)
                        else v.setLayerType(View.LAYER_TYPE_NONE, null)
                    }
                )

                // live background blur (only the background is drawn, so the person stays sharp)
                st.overlay?.let { ov ->
                    val img = remember(ov) { ov.asImageBitmap() }
                    Image(
                        bitmap = img, contentDescription = null, contentScale = ContentScale.Crop,
                        colorFilter = overlayFilter,
                        modifier = Modifier.fillMaxSize().graphicsLayer { scaleX = if (st.front) -1f else 1f }
                    )
                }
                st.peaking?.let { pk ->
                    val img = remember(pk) { pk.asImageBitmap() }
                    Image(
                        bitmap = img, contentDescription = null, contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize().graphicsLayer { scaleX = if (st.front) -1f else 1f }
                    )
                }

                if (set.grid) Canvas(Modifier.fillMaxSize()) {
                    val c = Color.White.copy(alpha = 0.35f)
                    for (i in 1..2) {
                        drawLine(c, Offset(size.width * i / 3f, 0f), Offset(size.width * i / 3f, size.height), 1.5f)
                        drawLine(c, Offset(0f, size.height * i / 3f), Offset(size.width, size.height * i / 3f), 1.5f)
                    }
                }

                st.faceBox?.let { b ->
                    Canvas(Modifier.fillMaxSize()) {
                        val l = if (st.front) 1f - b.right else b.left
                        val r = if (st.front) 1f - b.left else b.right
                        // the preview is centre-cropped to fill the screen; map frame coordinates accordingly
                        val fa = if (mode == CamMode.VIDEO) 9f / 16f else 3f / 4f
                        val sc = maxOf(size.width / fa, size.height)
                        val fw = fa * sc
                        val fh = sc
                        val ox = (size.width - fw) / 2f
                        val oy = (size.height - fh) / 2f
                        drawRoundRect(
                            color = Gold, topLeft = Offset(ox + l * fw, oy + b.top * fh),
                            size = androidx.compose.ui.geometry.Size((r - l) * fw, (b.bottom - b.top) * fh),
                            cornerRadius = CornerRadius(16f), style = Stroke(3f, cap = StrokeCap.Round)
                        )
                    }
                }

                // focus indicator
                var showFocus by remember { mutableStateOf(false) }
                LaunchedEffect(st.focusPoint, st.focusLocked) {
                    if (st.focusPoint != null) {
                        showFocus = true
                        if (!st.focusLocked) { delay(1500); showFocus = false }
                    }
                }
                val fp = st.focusPoint
                if (showFocus && fp != null) Canvas(Modifier.fillMaxSize()) {
                    drawCircle(
                        Gold, radius = 38f, center = Offset(fp.first * size.width, fp.second * size.height),
                        style = Stroke(if (st.focusLocked) 6f else 3f)
                    )
                }

                // recording / countdown / busy
                if (st.recording) {
                    Row(
                        Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(top = 64.dp).padding(10.dp).clip(RoundedCornerShape(50))
                            .background(Color.Black.copy(alpha = 0.6f)).padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(Modifier.size(10.dp).clip(CircleShape).background(if (st.paused) Color.Gray else RecordRed))
                        Text(formatDuration(st.recordMs), color = Color.White, fontWeight = FontWeight.SemiBold)
                    }
                }
                if (st.countdown > 0) Text(
                    "${st.countdown}", color = Color.White, fontSize = 96.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.align(Alignment.Center)
                )
                if (st.busy) StatusPill(stringResource(R.string.portrait_working), Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(top = 64.dp))
                if (st.processingPct >= 0) {
                    Row(
                        Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(top = 64.dp).padding(10.dp).clip(RoundedCornerShape(50))
                            .background(Color.Black.copy(alpha = 0.7f))
                            .clickable { camera.cancelProcessing() }
                            .padding(horizontal = 14.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(stringResource(R.string.cine_processing, st.processingPct), color = Gold, fontSize = 13.sp)
                        Text("  ✕", color = Color.White, fontSize = 13.sp)
                    }
                }
                if (st.faceBox != null) Text(
                    stringResource(R.string.face_detected), color = Gold, fontSize = 11.sp,
                    modifier = Modifier.align(Alignment.TopStart).statusBarsPadding().padding(top = 64.dp).padding(10.dp)
                )

                // messages
                var shown by remember { mutableStateOf<com.cinenova.camera.camera.UiMessage?>(null) }
                LaunchedEffect(st.message?.id) {
                    val m = st.message
                    if (m != null) { shown = m; delay(3000); if (shown?.id == m.id) shown = null }
                }
                shown?.let { m ->
                    val text = if (m.arg != null) stringResource(m.res, m.arg) else stringResource(m.res)
                    Text(
                        text, color = Color.White, fontSize = 13.sp, textAlign = TextAlign.Center,
                        modifier = Modifier.align(Alignment.Center).padding(24.dp).clip(RoundedCornerShape(12.dp))
                            .background(Color.Black.copy(alpha = 0.75f)).padding(horizontal = 14.dp, vertical = 10.dp)
                    )
                }
        }

        // ---------------------------------------------------------------- top bar (floating)
        Column(
            Modifier.align(Alignment.TopCenter).fillMaxWidth()
                .background(Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.55f), Color.Transparent)))
                .statusBarsPadding()
        ) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val flashIcon = when (set.flash) { 1 -> Icons.Filled.FlashAuto; 2 -> Icons.Filled.FlashOn; else -> Icons.Filled.FlashOff }
            val flashDesc = stringResource(when (set.flash) { 1 -> R.string.flash_auto; 2 -> R.string.flash_on; else -> R.string.flash_off })
            RoundIcon(flashIcon, flashDesc, { camera.setFlash((set.flash + 1) % 3) }, active = set.flash != 0, enabled = info?.hasFlash == true)
            RoundIcon(
                Icons.Filled.Timer,
                if (set.timer == 0) stringResource(R.string.timer_off) else stringResource(R.string.timer_n, set.timer),
                {
                    val next = when (set.timer) { 0 -> 3; 3 -> 5; 5 -> 10; else -> 0 }
                    appSettings.update { it.copy(timer = next) }
                },
                active = set.timer != 0
            )
            if (set.timer != 0) Text("${set.timer}s", color = Gold, fontSize = 12.sp)
            RoundIcon(Icons.Filled.GridOn, stringResource(R.string.grid), { appSettings.update { it.copy(grid = !it.grid) } }, active = set.grid)
            RoundIcon(
                Icons.Filled.HdrOn, stringResource(R.string.hdr),
                {
                    if (info?.hdrScene == true) appSettings.update { it.copy(hdr = !it.hdr) }
                    else camera.notifyHdrUnsupported()
                },
                active = set.hdr && info?.hdrScene == true
            )
            Box(Modifier.weight(1f))
            RoundIcon(Icons.Filled.AutoAwesome, stringResource(R.string.nav_filters), onFilters)
            RoundIcon(Icons.Filled.Settings, stringResource(R.string.nav_settings), onSettings)
        }
        }

        // ---------------------------------------------------------------- bottom controls (floating)
        Column(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.75f))))
                .navigationBarsPadding()
                .padding(top = 12.dp)
        ) {
            // zoom + focus lock
            Row(
                Modifier.fillMaxWidth().padding(bottom = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Pill(stringResource(R.string.zoom_x, st.zoom), selected = false, onClick = { camera.setZoom(1f) })
                RoundIcon(
                    if (st.focusLocked) Icons.Filled.Lock else Icons.Filled.LockOpen,
                    stringResource(R.string.focus_lock), { camera.toggleFocusLock() }, active = st.focusLocked, size = 36
                )
            }
            Row(Modifier.padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Pill(stringResource(R.string.controls), selected = panelOpen && tab == 0, onClick = {
                    if (panelOpen && tab == 0) panelOpen = false else { tab = 0; panelOpen = true }
                })
                Pill(stringResource(R.string.nav_filters), selected = panelOpen && tab == 1, onClick = {
                    if (panelOpen && tab == 1) panelOpen = false else { tab = 1; panelOpen = true }
                })
            }
            if (panelOpen) {
                Box(
                    Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp)
                        .clip(RoundedCornerShape(16.dp)).background(Color.Black.copy(alpha = 0.6f))
                        .heightIn(max = 230.dp).verticalScroll(rememberScrollState())
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    if (tab == 1) FilterStrip(appSettings, set)
                    else when (mode) {
                        CamMode.PHOTO -> PhotoControls(camera, appSettings, set, st, info)
                        CamMode.PORTRAIT -> PortraitControls(camera, st)
                        CamMode.VIDEO -> VideoControls(camera, appSettings, set, st, info)
                        CamMode.PRO -> ProControls(camera, st, info)
                    }
                }
            }

            // mode strip
            Row(
                Modifier.fillMaxWidth().padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                listOf(
                    CamMode.PHOTO to R.string.nav_camera, CamMode.PORTRAIT to R.string.nav_portrait,
                    CamMode.VIDEO to R.string.nav_video, CamMode.PRO to R.string.nav_pro
                ).forEach { (m, label) ->
                    val sel = m == mode
                    Text(
                        stringResource(label).uppercase(), color = if (sel) Gold else Color.White.copy(alpha = 0.7f),
                        fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal, fontSize = 13.sp,
                        modifier = Modifier.clip(RoundedCornerShape(8.dp))
                            .clickable(enabled = !st.recording) { mode = m }
                            .padding(horizontal = 10.dp, vertical = 8.dp)
                    )
                }
            }

            // shutter row
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Box(
                    Modifier.size(52.dp).clip(RoundedCornerShape(12.dp)).border(1.dp, Gold, RoundedCornerShape(12.dp))
                        .background(InkRaised).clickable(onClick = onGallery),
                    contentAlignment = Alignment.Center
                ) {
                    val item = latest
                    val thumb = if (item != null) rememberThumb(ctx, item, 160) else null
                    if (thumb != null) Image(thumb, stringResource(R.string.nav_gallery), contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                    else Icon(Icons.Filled.PhotoLibrary, stringResource(R.string.nav_gallery), tint = Gold)
                }

                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    if (st.recording) RoundIcon(
                        if (st.paused) Icons.Filled.PlayArrow else Icons.Filled.Pause,
                        stringResource(if (st.paused) R.string.record_resume else R.string.record_pause),
                        { camera.togglePause() }, size = 44
                    )
                    ShutterButton(
                        video = mode == CamMode.VIDEO, recording = st.recording,
                        enabled = !st.busy && st.bound,
                        desc = stringResource(
                            if (mode == CamMode.VIDEO) (if (st.recording) R.string.record_stop else R.string.record_start) else R.string.capture
                        ),
                        onClick = onShutter
                    )
                    if (st.recording) Box(Modifier.size(44.dp))
                }

                RoundIcon(
                    Icons.Filled.FlipCameraAndroid, stringResource(R.string.switch_camera),
                    { camera.switchFacing() }, enabled = !st.recording && camera.caps.frontCameras.isNotEmpty() && camera.caps.backCameras.isNotEmpty(),
                    size = 52
                )
            }
        }
    }
}

@Composable
private fun StatusPill(text: String, modifier: Modifier) {
    Text(
        text, color = Gold, fontSize = 13.sp,
        modifier = modifier.padding(10.dp).clip(RoundedCornerShape(50))
            .background(Color.Black.copy(alpha = 0.7f)).padding(horizontal = 14.dp, vertical = 8.dp)
    )
}

@Composable
private fun PermissionPrompt(onGrant: () -> Unit) {
    Column(
        Modifier.fillMaxSize().background(Ink).padding(32.dp),
        verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(Icons.Filled.AutoAwesome, null, tint = Gold, modifier = Modifier.size(56.dp))
        Text(stringResource(R.string.perm_camera_title), color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(top = 16.dp))
        Text(stringResource(R.string.perm_camera_body), color = Color.White.copy(alpha = 0.75f), textAlign = TextAlign.Center,
            modifier = Modifier.padding(vertical = 12.dp))
        Button(onClick = onGrant, colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Ink)) {
            Text(stringResource(R.string.perm_grant))
        }
    }
}

@Composable
private fun ShutterButton(video: Boolean, recording: Boolean, enabled: Boolean, desc: String, onClick: () -> Unit) {
    Box(
        Modifier.size(78.dp).clip(CircleShape).border(4.dp, if (enabled) Color.White else Color.Gray, CircleShape)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Box(
            Modifier.size(if (recording) 30.dp else 60.dp)
                .clip(if (recording) RoundedCornerShape(6.dp) else CircleShape)
                .background(if (video) RecordRed else Color.White)
        )
    }
}

// ------------------------------------------------------------------------ per-mode control panels

@Composable
private fun LensRow(camera: CameraController, st: com.cinenova.camera.camera.CamState) {
    val caps = camera.caps
    val list = if (st.front) caps.frontCameras else caps.backCameras
    if (list.size < 2) return
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        list.forEach { c ->
            val label = when (caps.lensKind(c)) {
                LensKind.ULTRA -> R.string.lens_ultra
                LensKind.TELE -> R.string.lens_tele
                LensKind.FRONT -> R.string.lens_front
                LensKind.WIDE -> R.string.lens_wide
            }
            Pill(stringResource(label), selected = c.id == st.cameraId, onClick = { camera.selectCamera(c.id) })
        }
    }
}

@Composable
private fun ResolutionPill(camera: CameraController, appSettings: AppSettings, set: com.cinenova.camera.data.Settings) {
    val sizes = camera.photoSizeOptions()
    if (sizes.isEmpty()) return
    val cycle = listOf("") + sizes.map { "${it.width}x${it.height}" }
    val label = if (set.photoSize.isEmpty()) stringResource(R.string.auto)
    else sizes.firstOrNull { "${it.width}x${it.height}" == set.photoSize }
        ?.let { stringResource(R.string.mp_n, it.width * it.height / 1_000_000f) } ?: stringResource(R.string.auto)
    Pill("${stringResource(R.string.resolution)}: $label", selected = false, onClick = {
        val i = cycle.indexOf(set.photoSize).coerceAtLeast(0)
        appSettings.update { it.copy(photoSize = cycle[(i + 1) % cycle.size]) }
    })
}

@Composable
private fun EvSlider(camera: CameraController, st: com.cinenova.camera.camera.CamState) {
    val enabled = st.evMax > st.evMin
    LabeledSlider(
        stringResource(R.string.exposure), st.evIndex.toFloat(),
        st.evMin.toFloat()..st.evMax.toFloat().coerceAtLeast(st.evMin + 1f),
        { camera.setEvIndex(it.roundToInt()) }, camera.evLabel(), enabled = enabled
    )
}

@Composable
private fun PhotoControls(
    camera: CameraController, appSettings: AppSettings, set: com.cinenova.camera.data.Settings,
    st: com.cinenova.camera.camera.CamState, info: com.cinenova.camera.camera.CamInfo?
) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            ResolutionPill(camera, appSettings, set)
        }
        LensRow(camera, st)
        EvSlider(camera, st)
    }
}

@Composable
private fun PortraitControls(camera: CameraController, st: com.cinenova.camera.camera.CamState) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        LabeledSlider(stringResource(R.string.portrait_blur), st.blur.toFloat(), 0f..100f, { camera.setBlur(it.roundToInt()) }, "${st.blur}%")
        Text(stringResource(R.string.portrait_light), color = Color.White.copy(alpha = 0.85f), fontSize = 12.sp)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PortraitLight.values().forEach { l ->
                Pill(stringResource(l.nameRes), selected = st.light == l, onClick = { camera.setLight(l) })
            }
        }
        LensRow(camera, st)
        EvSlider(camera, st)
    }
}

@Composable
private fun VideoControls(
    camera: CameraController, appSettings: AppSettings, set: com.cinenova.camera.data.Settings,
    st: com.cinenova.camera.camera.CamState, info: com.cinenova.camera.camera.CamInfo?
) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Pill(stringResource(R.string.video_standard), selected = !st.cinematic, onClick = { camera.setCinematic(false) }, enabled = !st.recording)
            Pill(stringResource(R.string.video_cinematic), selected = st.cinematic, onClick = { camera.setCinematic(true) }, enabled = !st.recording)
        }
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            st.videoQualities.forEach { q ->
                val label = when (q) { "UHD" -> "4K"; "FHD" -> "1080p"; "HD" -> "720p"; else -> "480p" }
                Pill(label, selected = set.videoQuality == q, onClick = { appSettings.update { it.copy(videoQuality = q) } }, enabled = !st.recording)
            }
            st.fpsOptions.forEach { f ->
                Pill(stringResource(R.string.fps_n, f), selected = set.videoFps == f, onClick = { appSettings.update { it.copy(videoFps = f) } }, enabled = !st.recording)
            }
        }
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Pill(
                stringResource(R.string.stabilization),
                selected = set.stabilization && info?.videoStab == true,
                enabled = !st.recording,
                onClick = {
                    if (info?.videoStab == true) appSettings.update { it.copy(stabilization = !it.stabilization) }
                }
            )
            Pill(stringResource(R.string.audio), selected = set.audio, onClick = { appSettings.update { it.copy(audio = !it.audio) } }, enabled = !st.recording)
            Pill(stringResource(R.string.focus_tracking), selected = set.focusTracking, onClick = { appSettings.update { it.copy(focusTracking = !it.focusTracking) } })
        }
        if (info?.videoStab != true) Text(stringResource(R.string.stabilization_unsupported), color = Color.White.copy(alpha = 0.55f), fontSize = 11.sp)
        if (st.cinematic) {
            LabeledSlider(
                stringResource(R.string.set_video_blur), set.videoBlur.toFloat(), 0f..100f,
                { camera.setBlur(it.roundToInt()); appSettings.update { s -> s.copy(videoBlur = it.roundToInt()) } }, "${set.videoBlur}%"
            )
            Text(stringResource(R.string.cine_post_note), color = Color.White.copy(alpha = 0.6f), fontSize = 11.sp)
            if (camera.caps.tier == PerfTier.LOW) Text(stringResource(R.string.cine_realtime_slow), color = Gold.copy(alpha = 0.8f), fontSize = 11.sp)
        }
        LensRow(camera, st)
        EvSlider(camera, st)
    }
}

@Composable
private fun ProControls(camera: CameraController, st: com.cinenova.camera.camera.CamState, info: com.cinenova.camera.camera.CamInfo?) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        val manual = info?.manualSensor == true
        if (!manual) Text(stringResource(R.string.pro_manual_unsupported), color = Gold.copy(alpha = 0.85f), fontSize = 12.sp)
        else {
            val iso = info!!.isoRange
            if (iso != null) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Pill(stringResource(R.string.auto), selected = st.proIso == 0, onClick = { camera.setIso(0) })
                    Box(Modifier.weight(1f)) {
                        LabeledSlider(
                            stringResource(R.string.pro_iso), (if (st.proIso == 0) iso.lower else st.proIso).toFloat(),
                            iso.lower.toFloat()..iso.upper.toFloat(), { camera.setIso(it.roundToInt()) },
                            if (st.proIso == 0) stringResource(R.string.auto) else "${st.proIso}"
                        )
                    }
                }
            }
            val ex = info.exposureRangeNs
            if (ex != null) {
                val idxs = SHUTTER_STOPS_NS.indices.filter { SHUTTER_STOPS_NS[it] in ex.lower..ex.upper }
                if (idxs.size >= 2) {
                    val cur = idxs.indexOfFirst { SHUTTER_STOPS_NS[it] == st.proShutterNs }.let { if (it < 0) idxs.size / 2 else it }
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Pill(stringResource(R.string.auto), selected = st.proShutterNs == 0L, onClick = { camera.setShutter(0L) })
                        Box(Modifier.weight(1f)) {
                            LabeledSlider(
                                stringResource(R.string.pro_shutter), cur.toFloat(), 0f..(idxs.size - 1).toFloat(),
                                { camera.setShutter(SHUTTER_STOPS_NS[idxs[it.roundToInt()]]) },
                                if (st.proShutterNs == 0L) stringResource(R.string.auto) else SHUTTER_LABELS[idxs[cur]],
                                steps = (idxs.size - 2).coerceAtLeast(0)
                            )
                        }
                    }
                }
            }
        }
        if (info?.manualFocus == true) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Pill(stringResource(R.string.auto), selected = st.proFocus < 0f, onClick = { camera.setManualFocus(-1f) })
                Box(Modifier.weight(1f)) {
                    LabeledSlider(
                        stringResource(R.string.pro_focus), st.proFocus.coerceAtLeast(0f), 0f..1f, { camera.setManualFocus(it) },
                        if (st.proFocus < 0f) stringResource(R.string.auto) else "${(st.proFocus * 100).roundToInt()}%"
                    )
                }
            }
        } else Text(stringResource(R.string.pro_focus_unsupported), color = Color.White.copy(alpha = 0.55f), fontSize = 11.sp)

        val wbModes = listOf(
            CameraMetadata.CONTROL_AWB_MODE_AUTO to R.string.wb_auto,
            CameraMetadata.CONTROL_AWB_MODE_DAYLIGHT to R.string.wb_daylight,
            CameraMetadata.CONTROL_AWB_MODE_CLOUDY_DAYLIGHT to R.string.wb_cloudy,
            CameraMetadata.CONTROL_AWB_MODE_INCANDESCENT to R.string.wb_incandescent,
            CameraMetadata.CONTROL_AWB_MODE_FLUORESCENT to R.string.wb_fluorescent,
            CameraMetadata.CONTROL_AWB_MODE_SHADE to R.string.wb_shade
        ).filter { info?.awbModes?.contains(it.first) == true }
        if (wbModes.size > 1) {
            Text(stringResource(R.string.pro_wb), color = Color.White.copy(alpha = 0.85f), fontSize = 12.sp)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(wbModes.size) { i ->
                    val (m, label) = wbModes[i]
                    Pill(stringResource(label), selected = st.proWb == m, onClick = { camera.setWb(m) })
                }
            }
        } else Text(stringResource(R.string.pro_wb_unsupported), color = Color.White.copy(alpha = 0.55f), fontSize = 11.sp)

        EvSlider(camera, st)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Pill(stringResource(R.string.pro_peaking), selected = st.peakingOn, onClick = { camera.setPeaking(!st.peakingOn) })
            Pill(stringResource(R.string.reset), selected = false, onClick = { camera.resetPro() })
        }
        LensRow(camera, st)
    }
}

@Composable
private fun FilterStrip(appSettings: AppSettings, set: com.cinenova.camera.data.Settings) {
    var favOnly by remember { mutableStateOf(false) }
    val all = FilterId.values().toList()
    val list = if (favOnly) all.filter { set.favoriteFilters.contains(it.key) } else all
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            item { Pill("★ " + stringResource(R.string.filter_favorites), selected = favOnly, onClick = { favOnly = !favOnly }) }
            items(list.size) { i ->
                val f = list[i]
                Pill(stringResource(f.nameRes), selected = set.filterId == f.key, onClick = {
                    appSettings.update { it.copy(filterId = f.key, secondFilterId = "") }
                })
            }
        }
        LabeledSlider(
            stringResource(R.string.filter_intensity), set.filterIntensity.toFloat(), 0f..100f,
            { v -> appSettings.update { it.copy(filterIntensity = v.roundToInt()) } }, "${set.filterIntensity}%"
        )
    }
}
