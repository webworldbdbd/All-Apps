package com.cinenova.camera.ui

import android.content.Intent
import android.net.Uri
import android.widget.MediaController
import android.widget.VideoView
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.cinenova.camera.R
import com.cinenova.camera.data.AppSettings
import com.cinenova.camera.media.MediaItem
import com.cinenova.camera.media.MediaKind
import com.cinenova.camera.media.MediaStoreHelper
import java.text.DateFormat
import java.util.Date
import kotlinx.coroutines.launch

private enum class GalTab { PHOTOS, VIDEOS, ALBUMS, RECENT, FAVORITES }

@Composable
fun GalleryScreen(
    media: MediaStoreHelper,
    appSettings: AppSettings,
    onBack: () -> Unit,
    onEditPhoto: (Uri) -> Unit,
    onEditVideo: (Uri) -> Unit
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val set by appSettings.state.collectAsState()
    var items by remember { mutableStateOf<List<MediaItem>>(emptyList()) }
    var loaded by remember { mutableStateOf(false) }
    var tab by remember { mutableStateOf(GalTab.PHOTOS) }
    var typeFilter by remember { mutableIntStateOf(0) }   // 0 all, 1 originals, 2 edited
    var album by remember { mutableStateOf<String?>(null) }
    var viewIndex by remember { mutableIntStateOf(-1) }
    var needPerm by remember { mutableStateOf(!ctx.hasMediaRead()) }
    var note by remember { mutableStateOf<Int?>(null) }

    fun reload() { scope.launch { items = media.listAll(); loaded = true } }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        needPerm = !ctx.hasMediaRead()
        reload()
    }
    LaunchedEffect(Unit) {
        reload()
        if (!ctx.hasMediaRead()) permLauncher.launch(mediaReadPermissions())
    }

    val shown = remember(items, tab, typeFilter, album, set.favoriteMedia) {
        var l = when (tab) {
            GalTab.PHOTOS -> items.filter { it.kind == MediaKind.PHOTO }
            GalTab.VIDEOS -> items.filter { it.kind == MediaKind.VIDEO }
            GalTab.ALBUMS -> if (album != null) items.filter { it.album == album } else emptyList()
            GalTab.RECENT -> items.take(30)
            GalTab.FAVORITES -> items.filter { set.favoriteMedia.contains(it.uri.toString()) }
        }
        l = when (typeFilter) { 1 -> l.filter { !it.isEdited }; 2 -> l.filter { it.isEdited }; else -> l }
        l
    }

    Column(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).statusBarsPadding().navigationBarsPadding()
    ) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            RoundIcon(Icons.Filled.ArrowBack, stringResource(R.string.back), onBack)
            Text(
                stringResource(R.string.nav_gallery), fontSize = 20.sp, fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground, modifier = Modifier.padding(start = 12.dp)
            )
        }
        LazyRow(Modifier.padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            item { Pill(stringResource(R.string.gal_all_photos), tab == GalTab.PHOTOS, { tab = GalTab.PHOTOS; album = null }) }
            item { Pill(stringResource(R.string.gal_all_videos), tab == GalTab.VIDEOS, { tab = GalTab.VIDEOS; album = null }) }
            item { Pill(stringResource(R.string.gal_albums), tab == GalTab.ALBUMS, { tab = GalTab.ALBUMS; album = null }) }
            item { Pill(stringResource(R.string.gal_recent), tab == GalTab.RECENT, { tab = GalTab.RECENT; album = null }) }
            item { Pill(stringResource(R.string.gal_favorites), tab == GalTab.FAVORITES, { tab = GalTab.FAVORITES; album = null }) }
        }
        Row(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Pill(stringResource(R.string.all), typeFilter == 0, { typeFilter = 0 })
            Pill(stringResource(R.string.gal_originals), typeFilter == 1, { typeFilter = 1 })
            Pill(stringResource(R.string.gal_edited), typeFilter == 2, { typeFilter = 2 })
        }
        if (needPerm && items.isEmpty()) {
            Text(
                stringResource(R.string.perm_media_needed), color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(16.dp).clickable { permLauncher.launch(mediaReadPermissions()) }
            )
        }
        note?.let {
            Text(stringResource(it), color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
        }

        if (tab == GalTab.ALBUMS && album == null) {
            val groups = items.groupBy { it.album }
            LazyColumn(Modifier.fillMaxSize()) {
                groups.entries.toList().let { list ->
                    items(list.size) { i ->
                        val (name, group) = list[i].toPair()
                        Row(
                            Modifier.fillMaxWidth().clickable { album = name }.padding(horizontal = 16.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            val thumb = rememberThumb(ctx, group.first(), 160)
                            Box(Modifier.size(64.dp).clip(RoundedCornerShape(10.dp)).background(MaterialTheme.colorScheme.surfaceVariant)) {
                                if (thumb != null) Image(thumb, null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                            }
                            Column(Modifier.padding(start = 14.dp)) {
                                Text(name, color = MaterialTheme.colorScheme.onBackground, fontWeight = FontWeight.SemiBold)
                                Text(stringResource(R.string.gal_count_n, group.size), color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        } else if (shown.isEmpty() && loaded) {
            Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                Text(stringResource(R.string.empty_gallery), color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(112.dp), modifier = Modifier.fillMaxSize(),
                horizontalArrangement = Arrangement.spacedBy(3.dp), verticalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                items(shown, key = { "${it.kind}_${it.id}" }) { item ->
                    Box(Modifier.aspectRatio(1f).background(MaterialTheme.colorScheme.surfaceVariant).clickable { viewIndex = shown.indexOf(item) }) {
                        val t = rememberThumb(ctx, item)
                        if (t != null) Image(t, null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                        if (item.kind == MediaKind.VIDEO) {
                            Icon(Icons.Filled.PlayArrow, null, tint = Color.White, modifier = Modifier.align(Alignment.Center).size(30.dp))
                            Text(
                                formatDuration(item.durationMs), color = Color.White, fontSize = 11.sp,
                                modifier = Modifier.align(Alignment.BottomEnd).padding(4.dp)
                                    .background(Color.Black.copy(alpha = 0.55f), RoundedCornerShape(4.dp)).padding(horizontal = 4.dp)
                            )
                        }
                        if (set.favoriteMedia.contains(item.uri.toString())) {
                            Icon(Icons.Filled.Favorite, null, tint = Gold, modifier = Modifier.align(Alignment.TopEnd).padding(4.dp).size(16.dp))
                        }
                    }
                }
            }
        }
    }

    if (viewIndex in shown.indices) {
        Viewer(
            list = shown, start = viewIndex, media = media, appSettings = appSettings,
            onClose = { viewIndex = -1 },
            onChanged = { reload() },
            onEditPhoto = { viewIndex = -1; onEditPhoto(it) },
            onEditVideo = { viewIndex = -1; onEditVideo(it) }
        )
    }
}

@Composable
private fun Viewer(
    list: List<MediaItem>,
    start: Int,
    media: MediaStoreHelper,
    appSettings: AppSettings,
    onClose: () -> Unit,
    onChanged: () -> Unit,
    onEditPhoto: (Uri) -> Unit,
    onEditVideo: (Uri) -> Unit
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val set by appSettings.state.collectAsState()
    val pager = rememberPagerState(initialPage = start) { list.size }
    var zoomed by remember { mutableStateOf(false) }
    var playing by remember { mutableStateOf<MediaItem?>(null) }
    var showDelete by remember { mutableStateOf(false) }
    var showRename by remember { mutableStateOf(false) }
    var showInfo by remember { mutableStateOf(false) }
    var toast by remember { mutableStateOf<Int?>(null) }
    val item = list.getOrNull(pager.currentPage)

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        HorizontalPager(state = pager, userScrollEnabled = !zoomed, modifier = Modifier.fillMaxSize()) { page ->
            val m = list[page]
            Page(m, media, onZoomChange = { z -> if (page == pager.currentPage) zoomed = z }, onPlay = { playing = m })
        }

        if (item != null) {
            Row(
                Modifier.align(Alignment.TopStart).statusBarsPadding().fillMaxWidth().padding(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                RoundIcon(Icons.Filled.ArrowBack, stringResource(R.string.back), onClose, tint = Color.White)
                Text(item.name, color = Color.White, fontSize = 13.sp, maxLines = 1, modifier = Modifier.padding(start = 10.dp).weight(1f))
            }
            val fav = set.favoriteMedia.contains(item.uri.toString())
            Row(
                Modifier.align(Alignment.BottomCenter).navigationBarsPadding().fillMaxWidth()
                    .background(Color.Black.copy(alpha = 0.6f)).padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                RoundIcon(
                    if (fav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                    stringResource(if (fav) R.string.gal_favorite_remove else R.string.gal_favorite_add),
                    {
                        val key = item.uri.toString()
                        appSettings.update { s ->
                            s.copy(favoriteMedia = if (fav) s.favoriteMedia - key else s.favoriteMedia + key)
                        }
                    },
                    tint = Color.White, active = fav
                )
                RoundIcon(Icons.Filled.Edit, stringResource(R.string.gal_edit), {
                    if (item.kind == MediaKind.PHOTO) onEditPhoto(item.uri) else onEditVideo(item.uri)
                }, tint = Color.White)
                RoundIcon(Icons.Filled.Share, stringResource(R.string.share), {
                    ctx.startActivity(Intent.createChooser(media.shareIntent(item), ctx.getString(R.string.gal_share_via)))
                }, tint = Color.White)
                RoundIcon(Icons.Filled.Info, stringResource(R.string.details), { showInfo = true }, tint = Color.White)
                RoundIcon(Icons.Filled.Delete, stringResource(R.string.delete), { showDelete = true }, tint = Color.White)
            }
            toast?.let {
                Text(
                    stringResource(it), color = Color.White,
                    modifier = Modifier.align(Alignment.Center).background(Color.Black.copy(alpha = 0.75f), RoundedCornerShape(12.dp)).padding(12.dp)
                )
                LaunchedEffect(it) { kotlinx.coroutines.delay(2000); toast = null }
            }
        }

        playing?.let { p -> VideoPlayer(p.uri) { playing = null } }
    }

    if (showDelete && item != null) {
        AlertDialog(
            onDismissRequest = { showDelete = false },
            title = { Text(stringResource(R.string.delete)) },
            text = { Text(stringResource(R.string.gal_confirm_delete)) },
            confirmButton = {
                TextButton(onClick = {
                    showDelete = false
                    scope.launch {
                        val ok = media.delete(item)
                        toast = if (ok) R.string.gal_deleted else R.string.gal_delete_failed
                        if (ok) { onChanged(); onClose() }
                    }
                }) { Text(stringResource(R.string.delete)) }
            },
            dismissButton = { TextButton(onClick = { showDelete = false }) { Text(stringResource(R.string.cancel)) } }
        )
    }
    if (showRename && item != null) {
        var text by remember(item.id) { mutableStateOf(item.name.substringBeforeLast('.')) }
        AlertDialog(
            onDismissRequest = { showRename = false },
            title = { Text(stringResource(R.string.rename)) },
            text = { OutlinedTextField(value = text, onValueChange = { text = it }, singleLine = true) },
            confirmButton = {
                TextButton(onClick = {
                    showRename = false
                    scope.launch {
                        val ok = media.rename(item, text)
                        toast = if (ok) R.string.gal_renamed else R.string.gal_rename_failed
                        if (ok) { onChanged(); onClose() }
                    }
                }) { Text(stringResource(R.string.save)) }
            },
            dismissButton = { TextButton(onClick = { showRename = false }) { Text(stringResource(R.string.cancel)) } }
        )
    }
    if (showInfo && item != null) {
        val fmt = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT)
        AlertDialog(
            onDismissRequest = { showInfo = false },
            title = { Text(stringResource(R.string.details)) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    DetailRow(stringResource(R.string.gal_name), item.name)
                    DetailRow(stringResource(R.string.gal_size), MediaStoreHelper.formatSize(item.size))
                    DetailRow(stringResource(R.string.gal_resolution), "${item.width} × ${item.height}")
                    DetailRow(stringResource(R.string.gal_date), fmt.format(Date(item.dateMillis)))
                    if (item.kind == MediaKind.VIDEO) DetailRow(stringResource(R.string.gal_duration), formatDuration(item.durationMs))
                    DetailRow(stringResource(R.string.gal_path), item.relativePath)
                    DetailRow("", stringResource(if (item.isEdited) R.string.gal_type_edited else R.string.gal_type_original))
                }
            },
            confirmButton = { TextButton(onClick = { showInfo = false }) { Text(stringResource(R.string.ok)) } },
            dismissButton = { TextButton(onClick = { showInfo = false; showRename = true }) { Text(stringResource(R.string.rename)) } }
        )
    }
}

@Composable
private fun DetailRow(label: String, value: String) {
    Column {
        if (label.isNotEmpty()) Text(label, fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
        Text(value, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
    }
}

@Composable
private fun Page(item: MediaItem, media: MediaStoreHelper, onZoomChange: (Boolean) -> Unit, onPlay: () -> Unit) {
    val ctx = LocalContext.current
    var bmp by remember(item.id, item.kind) { mutableStateOf<androidx.compose.ui.graphics.ImageBitmap?>(null) }
    var scale by remember(item.id) { mutableStateOf(1f) }
    var ox by remember(item.id) { mutableStateOf(0f) }
    var oy by remember(item.id) { mutableStateOf(0f) }

    LaunchedEffect(item.id, item.kind) {
        bmp = if (item.kind == MediaKind.PHOTO) media.loadBitmap(item.uri, 2048)?.asImageBitmap()
        else loadThumbnail(ctx, item, 720)?.asImageBitmap()
    }
    Box(
        Modifier.fillMaxSize()
            .pointerInput(item.id) {
                if (item.kind == MediaKind.PHOTO) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        scale = (scale * zoom).coerceIn(1f, 5f)
                        if (scale > 1.01f) { ox += pan.x; oy += pan.y } else { ox = 0f; oy = 0f }
                        onZoomChange(scale > 1.01f)
                    }
                }
            }
            .pointerInput(item.id) {
                detectTapGestures(onDoubleTap = {
                    if (item.kind == MediaKind.PHOTO) {
                        scale = if (scale > 1.01f) 1f else 2.5f
                        ox = 0f; oy = 0f
                        onZoomChange(scale > 1.01f)
                    }
                })
            },
        contentAlignment = Alignment.Center
    ) {
        bmp?.let {
            Image(
                it, null, contentScale = ContentScale.Fit,
                modifier = Modifier.fillMaxSize().graphicsLayer { scaleX = scale; scaleY = scale; translationX = ox; translationY = oy }
            )
        }
        if (item.kind == MediaKind.VIDEO) {
            RoundIcon(Icons.Filled.PlayArrow, stringResource(R.string.gal_play), onPlay, tint = Color.White, size = 72)
        }
    }
}

@Composable
private fun VideoPlayer(uri: Uri, onClose: () -> Unit) {
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { c ->
                VideoView(c).apply {
                    val mc = MediaController(c)
                    mc.setAnchorView(this)
                    setMediaController(mc)
                    setVideoURI(uri)
                    setOnPreparedListener { start() }
                    setOnCompletionListener { }
                }
            },
            onRelease = { it.stopPlayback() }
        )
        RoundIcon(
            Icons.Filled.Close, stringResource(R.string.close), onClose, tint = Color.White,
            modifier = Modifier.align(Alignment.TopEnd).statusBarsPadding().padding(8.dp)
        )
    }
}
