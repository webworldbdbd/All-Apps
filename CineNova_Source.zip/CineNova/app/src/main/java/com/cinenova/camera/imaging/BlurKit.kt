package com.cinenova.camera.imaging

import android.graphics.Bitmap
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** CPU blur used for background bokeh, skin softening, denoise and sharpening. */
object FastBlur {

    private fun pass(src: IntArray, dst: IntArray, w: Int, h: Int, r: Int, horizontal: Boolean) {
        val len = if (horizontal) w else h
        val lines = if (horizontal) h else w
        val step = if (horizontal) 1 else w
        val div = 2 * r + 1
        for (line in 0 until lines) {
            val base = if (horizontal) line * w else line
            var sr = 0
            var sg = 0
            var sb = 0
            for (k in -r..r) {
                val i = min(max(k, 0), len - 1)
                val p = src[base + i * step]
                sr += (p shr 16) and 0xFF
                sg += (p shr 8) and 0xFF
                sb += p and 0xFF
            }
            for (i in 0 until len) {
                dst[base + i * step] =
                    (0xFF shl 24) or ((sr / div) shl 16) or ((sg / div) shl 8) or (sb / div)
                val outP = src[base + min(max(i - r, 0), len - 1) * step]
                val inP = src[base + min(max(i + r + 1, 0), len - 1) * step]
                sr += ((inP shr 16) and 0xFF) - ((outP shr 16) and 0xFF)
                sg += ((inP shr 8) and 0xFF) - ((outP shr 8) and 0xFF)
                sb += (inP and 0xFF) - (outP and 0xFF)
            }
        }
    }

    /** Approximate gaussian blur: [passes] box blurs in both directions. Returns a new array. */
    fun blur(src: IntArray, w: Int, h: Int, radius: Int, passes: Int = 3): IntArray {
        if (radius < 1) return src.copyOf()
        var a = src.copyOf()
        var b = IntArray(src.size)
        repeat(passes) {
            pass(a, b, w, h, radius, true)
            pass(b, a, w, h, radius, false)
        }
        return a
    }

    fun blurBitmap(bmp: Bitmap, radius: Int, passes: Int = 3): Bitmap {
        val w = bmp.width
        val h = bmp.height
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)
        val out = blur(px, w, h, radius, passes)
        val res = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        res.setPixels(out, 0, w, 0, 0, w, h)
        return res
    }
}

private fun lum(p: Int): Float =
    0.299f * ((p shr 16) and 0xFF) + 0.587f * ((p shr 8) and 0xFF) + 0.114f * (p and 0xFF)

private fun mix(a: Int, b: Int, t: Float): Int {
    val r = (((a shr 16) and 0xFF) + ((((b shr 16) and 0xFF) - ((a shr 16) and 0xFF)) * t)).toInt()
    val g = (((a shr 8) and 0xFF) + ((((b shr 8) and 0xFF) - ((a shr 8) and 0xFF)) * t)).toInt()
    val bl = ((a and 0xFF) + (((b and 0xFF) - (a and 0xFF)) * t)).toInt()
    return (0xFF shl 24) or (r.coerceIn(0, 255) shl 16) or (g.coerceIn(0, 255) shl 8) or bl.coerceIn(0, 255)
}

/** Edge-preserving skin softening: blends toward a blur only where the image is smooth. */
object Smoothing {
    fun soften(src: Bitmap, amount: Float): Bitmap {
        val w = src.width
        val h = src.height
        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)
        val radius = max(2, min(w, h) / 240)
        val blurred = FastBlur.blur(px, w, h, radius, 2)
        val out = IntArray(px.size)
        for (i in px.indices) {
            val d = abs(lum(px[i]) - lum(blurred[i]))
            val edgeGuard = 1f - min(1f, d / 28f)
            out[i] = mix(px[i], blurred[i], amount * edgeGuard)
        }
        val res = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        res.setPixels(out, 0, w, 0, 0, w, h)
        return res
    }
}

/** Light edge-preserving noise reduction. */
object Denoise {
    fun apply(src: Bitmap, strength: Float): Bitmap {
        val w = src.width
        val h = src.height
        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)
        val blurred = FastBlur.blur(px, w, h, 1, 2)
        val out = IntArray(px.size)
        val thr = 10f + 30f * strength
        for (i in px.indices) {
            val d = abs(lum(px[i]) - lum(blurred[i]))
            val wgt = (1f - min(1f, d / thr)) * strength
            out[i] = mix(px[i], blurred[i], wgt)
        }
        val res = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        res.setPixels(out, 0, w, 0, 0, w, h)
        return res
    }
}

/** Unsharp mask. */
object Sharpen {
    fun unsharp(src: Bitmap, amount: Float): Bitmap {
        val w = src.width
        val h = src.height
        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)
        val radius = max(1, min(w, h) / 700)
        val blurred = FastBlur.blur(px, w, h, radius, 2)
        val k = amount * 1.6f
        val out = IntArray(px.size)
        for (i in px.indices) {
            val p = px[i]
            val b = blurred[i]
            val r = ((p shr 16) and 0xFF) + k * (((p shr 16) and 0xFF) - ((b shr 16) and 0xFF))
            val g = ((p shr 8) and 0xFF) + k * (((p shr 8) and 0xFF) - ((b shr 8) and 0xFF))
            val bl = (p and 0xFF) + k * ((p and 0xFF) - (b and 0xFF))
            out[i] = (0xFF shl 24) or (r.toInt().coerceIn(0, 255) shl 16) or
                (g.toInt().coerceIn(0, 255) shl 8) or bl.toInt().coerceIn(0, 255)
        }
        val res = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        res.setPixels(out, 0, w, 0, 0, w, h)
        return res
    }
}
