package com.cinenova.camera.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** All user preferences. Every field here is read by real app code. */
data class Settings(
    // Camera
    val photoSize: String = "",          // "" = automatic (largest 4:3 that is safe), else "WxH"
    val videoQuality: String = "FHD",    // SD, HD, FHD, UHD
    val videoFps: Int = 30,              // 24 / 30 / 60 (only if device supports it)
    val lens: String = "back",           // back / front
    val autofocus: Boolean = true,
    val grid: Boolean = false,
    val timer: Int = 0,                  // 0, 3, 5, 10
    val flash: Int = 0,                  // 0 off, 1 auto, 2 on
    // Photo
    val defaultBlur: Int = 45,           // 0..100
    val filterId: String = "natural",
    val filterIntensity: Int = 100,      // 0..100
    val secondFilterId: String = "",     // optional combination
    val beauty: Boolean = false,
    val hdr: Boolean = false,
    val imageFormat: String = "JPEG",    // JPEG / PNG / WEBP
    val saveOriginal: Boolean = true,
    // Video
    val videoBlur: Int = 55,             // cinematic blur strength 0..100
    val liveFilter: Boolean = true,
    val audio: Boolean = true,
    val focusTracking: Boolean = true,
    val stabilization: Boolean = true,
    // App
    val language: String = "en",         // en / bn
    val theme: String = "dark",          // dark / light / system
    val haptic: Boolean = true,
    val sound: Boolean = true,
    val favoriteFilters: Set<String> = emptySet(),
    val favoriteMedia: Set<String> = emptySet()
)

class AppSettings(context: Context) {
    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences("cinenova_prefs", Context.MODE_PRIVATE)

    private val _state = MutableStateFlow(load())
    val state: StateFlow<Settings> = _state.asStateFlow()
    val value: Settings get() = _state.value

    private fun load(): Settings {
        val d = Settings()
        return Settings(
            photoSize = prefs.getString("photoSize", d.photoSize) ?: d.photoSize,
            videoQuality = prefs.getString("videoQuality", d.videoQuality) ?: d.videoQuality,
            videoFps = prefs.getInt("videoFps", d.videoFps),
            lens = prefs.getString("lens", d.lens) ?: d.lens,
            autofocus = prefs.getBoolean("autofocus", d.autofocus),
            grid = prefs.getBoolean("grid", d.grid),
            timer = prefs.getInt("timer", d.timer),
            flash = prefs.getInt("flash", d.flash),
            defaultBlur = prefs.getInt("defaultBlur", d.defaultBlur),
            filterId = prefs.getString("filterId", d.filterId) ?: d.filterId,
            filterIntensity = prefs.getInt("filterIntensity", d.filterIntensity),
            secondFilterId = prefs.getString("secondFilterId", d.secondFilterId) ?: "",
            beauty = prefs.getBoolean("beauty", d.beauty),
            hdr = prefs.getBoolean("hdr", d.hdr),
            imageFormat = prefs.getString("imageFormat", d.imageFormat) ?: d.imageFormat,
            saveOriginal = prefs.getBoolean("saveOriginal", d.saveOriginal),
            videoBlur = prefs.getInt("videoBlur", d.videoBlur),
            liveFilter = prefs.getBoolean("liveFilter", d.liveFilter),
            audio = prefs.getBoolean("audio", d.audio),
            focusTracking = prefs.getBoolean("focusTracking", d.focusTracking),
            stabilization = prefs.getBoolean("stabilization", d.stabilization),
            language = prefs.getString("language", d.language) ?: d.language,
            theme = prefs.getString("theme", d.theme) ?: d.theme,
            haptic = prefs.getBoolean("haptic", d.haptic),
            sound = prefs.getBoolean("sound", d.sound),
            favoriteFilters = prefs.getStringSet("favoriteFilters", emptySet())?.toSet() ?: emptySet(),
            favoriteMedia = prefs.getStringSet("favoriteMedia", emptySet())?.toSet() ?: emptySet()
        )
    }

    /** Applies a change, persists everything, publishes the new state. */
    fun update(block: (Settings) -> Settings) {
        val s = block(_state.value)
        _state.value = s
        prefs.edit()
            .putString("photoSize", s.photoSize)
            .putString("videoQuality", s.videoQuality)
            .putInt("videoFps", s.videoFps)
            .putString("lens", s.lens)
            .putBoolean("autofocus", s.autofocus)
            .putBoolean("grid", s.grid)
            .putInt("timer", s.timer)
            .putInt("flash", s.flash)
            .putInt("defaultBlur", s.defaultBlur)
            .putString("filterId", s.filterId)
            .putInt("filterIntensity", s.filterIntensity)
            .putString("secondFilterId", s.secondFilterId)
            .putBoolean("beauty", s.beauty)
            .putBoolean("hdr", s.hdr)
            .putString("imageFormat", s.imageFormat)
            .putBoolean("saveOriginal", s.saveOriginal)
            .putInt("videoBlur", s.videoBlur)
            .putBoolean("liveFilter", s.liveFilter)
            .putBoolean("audio", s.audio)
            .putBoolean("focusTracking", s.focusTracking)
            .putBoolean("stabilization", s.stabilization)
            .putString("language", s.language)
            .putString("theme", s.theme)
            .putBoolean("haptic", s.haptic)
            .putBoolean("sound", s.sound)
            .putStringSet("favoriteFilters", s.favoriteFilters)
            .putStringSet("favoriteMedia", s.favoriteMedia)
            .apply()
    }

    fun resetAll() {
        val keepFav = _state.value.favoriteMedia
        prefs.edit().clear().apply()
        _state.value = Settings(favoriteMedia = keepFav)
        update { it }
    }
}
