package com.cinenova.camera.media

import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.provider.MediaStore
import androidx.exifinterface.media.ExifInterface
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

enum class MediaKind { PHOTO, VIDEO }

data class MediaItem(
    val id: Long,
    val uri: Uri,
    val kind: MediaKind,
    val name: String,
    val size: Long,
    val width: Int,
    val height: Int,
    val dateMillis: Long,
    val durationMs: Long,
    val album: String,
    val relativePath: String
) {
    /** Edited media is saved with an "_edit"/"_portrait"/"_cine" suffix. */
    val isEdited: Boolean
        get() = name.contains("_edit") || name.contains("_portrait") || name.contains("_cine")
}

class StorageFullException : IOException("Storage full")

/** All reading/writing of CineNova media, through MediaStore (scoped-storage safe). */
class MediaStoreHelper(private val context: Context) {

    companion object {
        const val PHOTO_DIR = "Pictures/CineNova"
        const val VIDEO_DIR = "Movies/CineNova"
        private val NAME_FMT = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US)

        fun timestamp(): String = NAME_FMT.format(Date())

        fun formatSize(bytes: Long): String = when {
            bytes >= 1L shl 30 -> String.format(Locale.US, "%.2f GB", bytes / (1024.0 * 1024 * 1024))
            bytes >= 1L shl 20 -> String.format(Locale.US, "%.1f MB", bytes / (1024.0 * 1024))
            bytes >= 1L shl 10 -> String.format(Locale.US, "%.0f KB", bytes / 1024.0)
            else -> "$bytes B"
        }
    }

    private val resolver get() = context.contentResolver

    /** Android 8/9 ignore RELATIVE_PATH, so write an explicit file path there. */
    @Suppress("DEPRECATION")
    private fun legacyPath(values: ContentValues, video: Boolean, name: String) {
        if (Build.VERSION.SDK_INT >= 29) return
        val root = Environment.getExternalStoragePublicDirectory(
            if (video) Environment.DIRECTORY_MOVIES else Environment.DIRECTORY_PICTURES
        )
        val dir = File(root, "CineNova")
        dir.mkdirs()
        values.put(MediaStore.MediaColumns.DATA, File(dir, name).absolutePath)
    }

    /** Copies a JPEG file (e.g. straight from the camera) into Pictures/CineNova, keeping EXIF. */
    suspend fun saveJpegFile(file: File, suffix: String = ""): Uri = withContext(Dispatchers.IO) {
        if (freeBytes() < file.length() + 10L * 1024 * 1024) throw StorageFullException()
        val name = "CineNova_${timestamp()}$suffix.jpg"
        val values = newPhotoContentValues(name).apply {
            if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IOException("insert failed")
        try {
            resolver.openOutputStream(uri)?.use { os -> file.inputStream().use { it.copyTo(os) } }
                ?: throw IOException("no stream")
            if (Build.VERSION.SDK_INT >= 29) {
                resolver.update(uri, ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) }, null, null)
            }
            uri
        } catch (e: Exception) {
            runCatching { resolver.delete(uri, null, null) }
            if (freeBytes() < 5L * 1024 * 1024) throw StorageFullException()
            throw e
        }
    }

    fun freeBytes(): Long = try {
        StatFs(Environment.getExternalStorageDirectory().path).availableBytes
    } catch (e: Exception) { Long.MAX_VALUE }

    private fun imageExt(format: String) = when (format.uppercase(Locale.US)) {
        "PNG" -> "png"; "WEBP" -> "webp"; else -> "jpg"
    }

    private fun imageMime(format: String) = when (format.uppercase(Locale.US)) {
        "PNG" -> "image/png"; "WEBP" -> "image/webp"; else -> "image/jpeg"
    }

    /** Saves a bitmap as a new image. Returns its Uri. [suffix] e.g. "" / "_portrait" / "_edit". */
    suspend fun saveBitmap(bmp: Bitmap, format: String, suffix: String = "", quality: Int = 95): Uri =
        withContext(Dispatchers.IO) {
            if (freeBytes() < 20L * 1024 * 1024) throw StorageFullException()
            val name = "CineNova_${timestamp()}$suffix.${imageExt(format)}"
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, name)
                put(MediaStore.Images.Media.MIME_TYPE, imageMime(format))
                put(MediaStore.Images.Media.DATE_TAKEN, System.currentTimeMillis())
                if (Build.VERSION.SDK_INT >= 29) {
                    put(MediaStore.Images.Media.RELATIVE_PATH, PHOTO_DIR)
                    put(MediaStore.Images.Media.IS_PENDING, 1)
                }
                legacyPath(this, false, name)
            }
            val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw IOException("insert failed")
            try {
                resolver.openOutputStream(uri)?.use { os ->
                    val cf = when (format.uppercase(Locale.US)) {
                        "PNG" -> Bitmap.CompressFormat.PNG
                        "WEBP" -> if (Build.VERSION.SDK_INT >= 30) Bitmap.CompressFormat.WEBP_LOSSY else Bitmap.CompressFormat.WEBP
                        else -> Bitmap.CompressFormat.JPEG
                    }
                    if (!bmp.compress(cf, quality, os)) throw IOException("compress failed")
                } ?: throw IOException("no stream")
                if (Build.VERSION.SDK_INT >= 29) {
                    val done = ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) }
                    resolver.update(uri, done, null, null)
                }
                uri
            } catch (e: Exception) {
                runCatching { resolver.delete(uri, null, null) }
                if (freeBytes() < 5L * 1024 * 1024) throw StorageFullException()
                throw e
            }
        }

    /** Creates a pending image entry that CameraX writes into directly (full-quality JPEG). */
    fun newPhotoContentValues(name: String): ContentValues = ContentValues().apply {
        put(MediaStore.Images.Media.DISPLAY_NAME, name)
        put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
        put(MediaStore.Images.Media.DATE_TAKEN, System.currentTimeMillis())
        if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Images.Media.RELATIVE_PATH, PHOTO_DIR)
        legacyPath(this, false, name)
    }

    fun newVideoContentValues(name: String): ContentValues = ContentValues().apply {
        put(MediaStore.Video.Media.DISPLAY_NAME, name)
        put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
        put(MediaStore.Video.Media.DATE_TAKEN, System.currentTimeMillis())
        if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Video.Media.RELATIVE_PATH, VIDEO_DIR)
        legacyPath(this, true, name)
    }

    /** Creates a video entry for a processed video; caller writes to the returned Uri then calls [finishVideo]. */
    fun createVideoEntry(suffix: String): Uri? {
        if (freeBytes() < 50L * 1024 * 1024) return null
        val values = newVideoContentValues("CineNova_${timestamp()}$suffix.mp4").apply {
            if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        return resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
    }

    fun finishVideo(uri: Uri) {
        if (Build.VERSION.SDK_INT >= 29) {
            resolver.update(uri, ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }, null, null)
        }
    }

    fun discard(uri: Uri) {
        runCatching { resolver.delete(uri, null, null) }
    }

    /** Lists CineNova photos and videos, newest first. */
    suspend fun listAll(): List<MediaItem> = withContext(Dispatchers.IO) {
        val out = ArrayList<MediaItem>()
        out += query(MediaKind.PHOTO)
        out += query(MediaKind.VIDEO)
        out.sortedByDescending { it.dateMillis }
    }

    private fun query(kind: MediaKind): List<MediaItem> {
        val isPhoto = kind == MediaKind.PHOTO
        val base = if (isPhoto) MediaStore.Images.Media.EXTERNAL_CONTENT_URI else MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val projection = if (isPhoto) arrayOf(
            MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME, MediaStore.Images.Media.SIZE,
            MediaStore.Images.Media.WIDTH, MediaStore.Images.Media.HEIGHT, MediaStore.Images.Media.DATE_ADDED,
            MediaStore.Images.Media.DATE_TAKEN, MediaStore.Images.Media.DATA
        ) else arrayOf(
            MediaStore.Video.Media._ID, MediaStore.Video.Media.DISPLAY_NAME, MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.WIDTH, MediaStore.Video.Media.HEIGHT, MediaStore.Video.Media.DATE_ADDED,
            MediaStore.Video.Media.DATE_TAKEN, MediaStore.Video.Media.DATA, MediaStore.Video.Media.DURATION
        )
        val result = ArrayList<MediaItem>()
        try {
            resolver.query(base, projection, null, null, "${MediaStore.MediaColumns.DATE_ADDED} DESC")?.use { c ->
                val iId = c.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
                val iName = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
                val iSize = c.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)
                val iW = c.getColumnIndexOrThrow(MediaStore.MediaColumns.WIDTH)
                val iH = c.getColumnIndexOrThrow(MediaStore.MediaColumns.HEIGHT)
                val iAdded = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_ADDED)
                val iTaken = c.getColumnIndex(MediaStore.MediaColumns.DATE_TAKEN)
                val iData = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA)
                val iDur = if (isPhoto) -1 else c.getColumnIndex(MediaStore.Video.Media.DURATION)
                while (c.moveToNext()) {
                    val data = c.getString(iData) ?: continue
                    // CineNova folder only
                    if (!data.contains("/CineNova/")) continue
                    val id = c.getLong(iId)
                    val taken = if (iTaken >= 0) c.getLong(iTaken) else 0L
                    val date = if (taken > 0) taken else c.getLong(iAdded) * 1000L
                    val parent = File(data).parentFile
                    result += MediaItem(
                        id = id,
                        uri = ContentUris.withAppendedId(base, id),
                        kind = kind,
                        name = c.getString(iName) ?: "",
                        size = c.getLong(iSize),
                        width = c.getInt(iW),
                        height = c.getInt(iH),
                        dateMillis = date,
                        durationMs = if (iDur >= 0) c.getLong(iDur) else 0L,
                        album = parent?.name ?: "CineNova",
                        relativePath = parent?.path ?: ""
                    )
                }
            }
        } catch (e: SecurityException) {
            // media permission not granted: show nothing rather than crash
        }
        return result
    }

    suspend fun delete(item: MediaItem): Boolean = withContext(Dispatchers.IO) {
        try { resolver.delete(item.uri, null, null) > 0 } catch (e: Exception) { false }
    }

    suspend fun rename(item: MediaItem, newBaseName: String): Boolean = withContext(Dispatchers.IO) {
        val ext = item.name.substringAfterLast('.', "")
        val clean = newBaseName.trim().replace(Regex("[\\\\/:*?\"<>|]"), "_")
        if (clean.isEmpty()) return@withContext false
        val newName = if (ext.isEmpty()) clean else "$clean.$ext"
        try {
            val v = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, newName)
            }
            resolver.update(item.uri, v, null, null) > 0
        } catch (e: Exception) { false }
    }

    fun shareIntent(item: MediaItem): Intent {
        val mime = if (item.kind == MediaKind.PHOTO) "image/*" else "video/*"
        return Intent(Intent.ACTION_SEND).apply {
            type = mime
            putExtra(Intent.EXTRA_STREAM, item.uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }

    /** Reads EXIF orientation-corrected, downsampled bitmap for editing/preview. */
    suspend fun loadBitmap(uri: Uri, maxSide: Int): Bitmap? = withContext(Dispatchers.IO) {
        try {
            val bounds = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
            resolver.openInputStream(uri)?.use { android.graphics.BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (max(bounds.outWidth, bounds.outHeight) / sample > maxSide * 2) sample *= 2
            val opts = android.graphics.BitmapFactory.Options().apply {
                inSampleSize = sample
                inPreferredConfig = Bitmap.Config.ARGB_8888
            }
            var bmp = resolver.openInputStream(uri)?.use { android.graphics.BitmapFactory.decodeStream(it, null, opts) }
                ?: return@withContext null
            val orientation = resolver.openInputStream(uri)?.use {
                ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
            } ?: ExifInterface.ORIENTATION_NORMAL
            val m = android.graphics.Matrix()
            when (orientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
                ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
                ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
                ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
                ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
            }
            if (!m.isIdentity) bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            val longSide = max(bmp.width, bmp.height)
            if (longSide > maxSide) {
                val s = maxSide.toFloat() / longSide
                bmp = Bitmap.createScaledBitmap(bmp, (bmp.width * s).toInt(), (bmp.height * s).toInt(), true)
            }
            bmp
        } catch (e: Exception) { null } catch (e: OutOfMemoryError) { null }
    }

    private fun max(a: Int, b: Int) = if (a > b) a else b

    /** Total bytes used by CineNova media. */
    suspend fun usedBytes(): Long = withContext(Dispatchers.IO) { listAll().sumOf { it.size } }
}
