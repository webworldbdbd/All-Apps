# CineNova — Capture Beyond Limits.

Native Android camera app (Kotlin, Jetpack Compose, CameraX + Camera2 interop, ML Kit).
Package: `com.cinenova.camera` · minSdk 26 (Android 8.0) · target/compile SDK 34 · free, no ads, no login, no internet permission.

## App icon
The launcher icon, splash logo and Play Store icon (`store/icon-512.png`) all use the lens image supplied by the owner (adaptive icon: `res/drawable-nodpi/ic_launcher_foreground.png` on a black background; splash: `logo_cinenova.png`). The Android 13 themed (monochrome) icon is not provided because this artwork is full-colour.

## How to build (Android Studio)
1. Install **Android Studio Koala (2024.1) or newer** (JDK 17 is bundled).
2. `File > Open` and choose this folder (`CineNova`). Let Gradle sync (needs internet once, to download dependencies).
3. Connect a phone (USB debugging on) and press **Run**.
   Debug APK from the terminal: `./gradlew assembleDebug` -> `app/build/outputs/apk/debug/`.
4. If Gradle reports a version problem, use *Android Studio > Settings > Build > Gradle* and let the IDE upgrade the Android Gradle Plugin. Tell me the exact error and I will fix it.

## IMPORTANT — honest status
This project was written without an Android SDK, so **it has NOT been compiled, run, or tested on any device**.
I only ran a Kotlin syntax scan, which found no syntax errors; type-checking against Android and CameraX was impossible.
Expect a few compile errors on the first build (typical for ~5,000 lines of untested code). Send me the error list from Android Studio and I will fix them.
Nothing below should be treated as "tested".

## What is implemented (all in code)
| Area | What exists |
|---|---|
| Camera | CameraX preview, photo capture, front/back, lens picker (from real camera list), tap-to-focus, focus lock, continuous-AF setting, pinch zoom, exposure, flash, timer 3/5/10 s, grid, HDR (only if the camera has HDR scene mode), photo resolution choice, face detection + eye-aimed focus tracking |
| Portrait photo | ML Kit selfie segmentation, mask refinement + feathering, background-only blur 0–100 %, bokeh bloom, 3 lighting looks, live blurred-background preview, saved as `_portrait` with the original kept, post-capture blur in the editor |
| Video | CameraX recording, 720p/1080p/4K and 24/30/60 fps (only options the device reports), stabilization (only if supported), audio toggle, pause/resume, safe finalize on interruption, torch |
| Cinematic video | Live blurred-background preview while recording, then an automatic MediaCodec pass that writes a **new** `_cine` file. Original is kept. On weaker phones the pass runs at 720p |
| Filters | 13 looks as real colour matrices (+ skin softening where relevant), intensity 0–100, combine two, favorites, live preview, applied to photos, to video (post-pass), and in both editors |
| Pro mode | ISO, shutter, manual focus, white-balance presets via Camera2 interop, EV, focus peaking — each control appears only if the camera reports support |
| Gallery | Photos / Videos / Albums / Recent / Favorites, originals vs edited, full-screen pager with zoom, video playback, delete, share, rename, details |
| Photo editor | Crop (ratio, zoom, pan), rotate, flip, brightness, contrast, saturation, sharpness, temperature, noise reduction, filters, background blur, hold-to-compare, restore, save as new |
| Video editor | Trim (range slider), real frame preview with look, trimmed playback, filters/adjust, cinematic blur, export resolution + fps, cancel, saved as new file |
| Settings | Every setting is persisted and read by code; English + Bengali (switches live); dark / light / system; storage info, cache clear, reset, about, privacy |

## Known limits (by design, please read)
- Real-time blur is a **preview** effect. The recorded file is processed after you stop, so the cinematic result appears seconds later (depends on the phone). Blur is CPU-based, not GPU.
- Filters on the live viewfinder use a hardware layer colour filter; spatial effects (skin softening, sharpening) are applied only to the saved result.
- Selfie segmentation finds **people**; pets/objects are not separated.
- "Subject tracking" is face/eye based. Eye detection uses ML Kit landmarks.
- Video editor preview is a still frame, not a full real-time player with filters.
- Not done: GPU shaders, Play Store screenshots/feature graphic (needs a real device), automated tests, a signed AAB (needs your own keystore), PDF documentation.

## Folder map
`app/src/main/java/com/cinenova/camera/` — `camera/` (CameraX, device capabilities), `imaging/` (filters, segmentation, portrait, blur), `media/` (MediaStore, video processor), `data/` (settings), `ui/` (all screens).
Strings: `res/values/` (English), `res/values-bn/` (Bengali, same keys in both files).
See `RELEASE.md` for signing + Play Store steps, `PRIVACY_POLICY.md`, `store/PLAY_LISTING.md`.
