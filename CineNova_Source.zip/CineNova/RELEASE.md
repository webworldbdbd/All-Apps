# Release guide

## 1. Create a signing key (once, keep it safe — never commit it)
```
keytool -genkey -v -keystore cinenova-release.jks -keyalg RSA -keysize 2048 -validity 10000 -alias cinenova
```
Copy `keystore.properties.example` to `keystore.properties` and fill in the real values. Both files are git-ignored. Back up the `.jks` and passwords: losing them means you cannot update the app. (Or enrol in Play App Signing and keep only an upload key.)

## 2. Build
- Release AAB (for Play): `./gradlew bundleRelease` -> `app/build/outputs/bundle/release/app-release.aab`
- Release APK: `./gradlew assembleRelease`
Version: edit `versionCode` (must increase every upload) and `versionName` in `app/build.gradle.kts`.

## 3. Before uploading
- Check Google Play's *current* target-API requirement (policy changes yearly) and raise `targetSdk`/`compileSdk` if needed.
- Test on at least: one low-end phone, one mid-range, one flagship (Pixel 6 is a good primary). Test: permissions denied, storage full, camera used by another app, front/back, video 1080p/4K, cinematic video, Bengali UI, rotation.
- Play Console > App content: privacy policy URL (host `PRIVACY_POLICY.md` as a web page), Data safety = "no data collected / no data shared", permissions declarations (Camera, Microphone, Photos & Videos read access).
- Prepare: 512x512 icon (`store/icon-512.png`), 1024x500 feature graphic, 2–8 real screenshots from your phone.

## 4. Permissions used
CAMERA, RECORD_AUDIO (only when audio is on), READ_MEDIA_IMAGES / READ_MEDIA_VIDEO (Android 13+) or READ_EXTERNAL_STORAGE (<=12) to show the gallery, WRITE_EXTERNAL_STORAGE (Android 8–9 only), VIBRATE. No INTERNET permission.
