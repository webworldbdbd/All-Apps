# CineNova Privacy Policy
CineNova does not collect, upload, share or sell personal data. The app has no internet permission and no account or login.
Photos and videos are saved only on your device (Pictures/CineNova and Movies/CineNova). Camera permission is used to take photos and video; microphone permission only when audio recording is on; photo/video read permission only to show your CineNova gallery. Portrait, filter and face processing happens fully on your device. If the app crashes, a short error text is kept only in the app's private cache on your phone and is never sent anywhere. You can clear it from Settings > Clear cache.
Contact: add your support email here before publishing.
