# Play Store text
**Short (80):** Portrait photos, cinematic video and pro controls. Free, no ads, offline.
**Short (বাংলা):** পোর্ট্রেট ছবি, সিনেমাটিক ভিডিও ও প্রো কন্ট্রোল। ফ্রি, বিজ্ঞাপনহীন, অফলাইন।

**Full:**
CineNova — Capture Beyond Limits.
A premium black-and-gold camera for every phone, including budget models.
• Portrait photos with adjustable background blur (0–100 %), portrait lighting, and post-capture blur editing
• Cinematic video: see the blurred-background look live, get a finished cinematic copy after recording (your original is always kept)
• 13 professional filters with intensity, favorites and combinations — for photos and videos
• Pro mode: ISO, shutter, manual focus, white balance, focus peaking (shown only if your camera supports them)
• Built-in photo and video editors, gallery with albums and favorites
• English and বাংলা, dark and light themes
• 100 % free, no ads, no login, works offline, your media never leaves your phone
Results depend on your phone's hardware; features your camera does not support are hidden or disabled with an explanation.
