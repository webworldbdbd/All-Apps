# SARP AI — Master (complete)

Personal AI assistant for Android (Kotlin + Jetpack Compose). Package `com.webworldbd.sarpai`. Powered By WebWorldBD.
You bring your own API keys (Gemini, OpenAI, Claude, DeepSeek, Groq, OpenRouter or any OpenAI-compatible one). Nothing is hard-coded.

## Build the APK
1. Put this ZIP in your GitHub repository (keep the file as it is) together with `.github/workflows/main.yml`.
2. Actions > "Build SARP AI APK" > Run workflow. Download the artifact `SarpAI-APK`, install `app-release.apk`.
   (If Play Protect blocks the install, turn "Scan apps with Play Protect" off just for the install, then on again.)
3. Open the app: Settings > Permissions > "Open App info" > menu > "Allow restricted settings", then grant each permission you want.
4. Settings > API Keys: add a key and press Test. For Gemini use the model name `gemini-3.8-flash`.

## What it does
1  Voice assistant: Bangla / English, male / female voice (phone voice or AI voice), classic mode or LIVE conversation (Gemini Live), Soul = name + personality (Jarvis style), remembers recent conversation.
2  Screen intelligence: reads the screen, screenshot analysis (whole screen or top / bottom / left / right / center), translate / summarize what is on screen, share your screen live.
3  App control: open and close apps, tap / type / scroll in any app (YouTube, Facebook, Messenger, WhatsApp, Telegram…), the agent sees the screen after every step.
4  Messaging: SMS (confirmed), WhatsApp message prefilled then Send (confirmed), email drafts, read email (IMAP, read-only), read and summarize notifications.
5  Internet: web search with sources, news, weather, read web pages, compare.
6  Daily assistant: to-do list, reminders, alarms, timers, calendar events, routines, scheduled / repeating agent tasks.
7  Camera & vision: photo analysis, OCR, maths from a photo, documents, live camera.
8  Writing: Facebook posts, YouTube scripts / titles / descriptions / hashtags, emails, applications, blogs, translation, grammar.
9  Student: maths, physics, chemistry, electronics, notes, MCQs, exam plans. Exact calculator action.
10 Files: find files, read PDF / Word / Excel / text / images, summarize, compare, create text documents (txt, md, csv, html, json).
11 Phone controls: flashlight, volume, brightness, Do Not Disturb, battery, network, storage, settings screens, Wi-Fi / Bluetooth via the settings panel.
12 Memory: remembers preferences and facts (encrypted), notes, view / add / delete anything, "delete all my data".
13 Automation: multi-step tasks, scheduled and repeating tasks (survive reboot), progress and failure reasons, result checking.
14 Entertainment: stories, quizzes, riddles, jokes, find songs and videos on YouTube.
15 Privacy & safety: every permission separate (Android + in-app switch), hard-block list for apps / words, confirmation (also from a notification) before sending, calling, paying, deleting, publishing; OTP codes and password fields hidden from the AI.
16 Floating interface: floating logo button, mini chat window over any app, quick actions, resizable.
17 Extras: translator, calculator, code assistant, research, business, finance, travel, shopping, health information (no diagnosis), meeting notes, summarizer, learning.
+  Home screen "HUD" with animated orb, Memory / Chat / Soul / Settings nodes, headlines, tasks and a pixel-art Agent Town.
+  Image generation and video generation (Gemini; video probably needs a paid key).

## Honest limits
- Android does not allow apps to switch Wi-Fi / Bluetooth on or off directly; the agent opens the panel and taps the switch.
- Banking / payment / password screens are blocked by Android itself; the agent cannot see them.
- Scheduled app-control tasks need the phone unlocked at that time.
- Live camera works while the app is on screen. Screen sharing uses screenshots every few seconds (Android 11+).
- Editing existing videos is not supported. Sending email is not supported (drafts only).
- Free API keys have limits and can be busy; the app retries and falls back to other keys / models.
