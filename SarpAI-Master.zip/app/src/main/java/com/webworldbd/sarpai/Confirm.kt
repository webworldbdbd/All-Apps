package com.webworldbd.sarpai

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

/** Heads-up notification with Allow / Deny buttons, so sensitive actions can be confirmed from any app. */
object ConfirmNotifier {
    const val CH = "sarp_confirm"
    const val ID = 4712
    const val YES = "com.webworldbd.sarpai.CONFIRM_YES"
    const val NO = "com.webworldbd.sarpai.CONFIRM_NO"

    fun show(desc: String) {
        val c = S.app
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CH, "Confirmations", NotificationManager.IMPORTANCE_HIGH))
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val yes = PendingIntent.getBroadcast(c, 10, Intent(c, ConfirmReceiver::class.java).setAction(YES), flags)
        val no = PendingIntent.getBroadcast(c, 11, Intent(c, ConfirmReceiver::class.java).setAction(NO), flags)
        val open = PendingIntent.getActivity(c, 12, Intent(c, MainActivity::class.java), flags)
        val n = NotificationCompat.Builder(c, CH)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle(tr("Allow this action?", "এই কাজটি করতে দেবেন?"))
            .setContentText(desc)
            .setStyle(NotificationCompat.BigTextStyle().bigText(desc))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(open)
            .addAction(0, tr("Allow", "অনুমতি দিন"), yes)
            .addAction(0, tr("Deny", "না"), no)
            .build()
        try {
            NotificationManagerCompat.from(c).notify(ID, n)
        } catch (e: SecurityException) { }
    }

    fun cancel() {
        try { NotificationManagerCompat.from(S.app).cancel(ID) } catch (e: Exception) { }
    }
}

class ConfirmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Agent.answerConfirm(i.action == ConfirmNotifier.YES)
        ConfirmNotifier.cancel()
    }
}
