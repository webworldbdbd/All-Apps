package com.webworldbd.sarpai

import android.graphics.Paint
import android.graphics.Typeface
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlin.math.sin

private data class Worker(val key: String, val label: String, val color: Color, val x: Float, val y: Float)

private val WORKERS = listOf(
    Worker("planner", "PLANNER", HudViolet, 3f, 3f),
    Worker("eyes", "EYES", HudCyan, 9f, 3f),
    Worker("hands", "HANDS", HudGreen, 15f, 3f),
    Worker("web", "BROWSER", HudOrange, 21f, 3f),
    Worker("coder", "CODER", HudYellow, 6f, 8f),
    Worker("memory", "MEMORY", Color(0xFFFF6FB5), 12f, 8f),
    Worker("comms", "COMMS", Color(0xFF7BD88F), 18f, 8f)
)

private fun roleOf(type: String): String = when {
    type in setOf("read_screen", "analyze_screen", "analyze_camera") -> "eyes"
    type in setOf("web_fetch", "search", "news", "weather", "generate_image", "generate_video") -> "web"
    type.startsWith("github") || type in setOf("find_files", "read_file") -> "coder"
    type in setOf(
        "remember", "save_note", "forget", "list_memory", "add_task", "complete_task", "list_tasks",
        "set_reminder", "set_alarm", "set_timer", "add_event", "list_events"
    ) -> "memory"
    type in setOf(
        "send_sms", "call", "find_contact", "whatsapp_message", "compose_email", "read_email", "read_notifications"
    ) -> "comms"
    type in setOf(
        "tap", "tap_text", "tap_xy", "type", "scroll", "press", "open_app", "open_url", "wait", "open_settings",
        "flashlight", "volume", "brightness", "dnd", "clipboard", "device_status", "set_voice", "set_language", "location"
    ) -> "hands"
    else -> "planner"
}

/** A small pixel-art office. Each worker lights up when the agent does a kind of job (looking, tapping, browsing, coding…). */
@Composable
fun AgentTown(modifier: Modifier = Modifier) {
    val ev by Agent.currentAction.collectAsState()
    val state by Agent.state.collectAsState()
    var activeKey by remember { mutableStateOf<String?>(null) }
    var label by remember { mutableStateOf("") }
    LaunchedEffect(ev) {
        val e = ev
        if (e != null) {
            activeKey = roleOf(e.type)
            label = e.type
            delay(1800)
            activeKey = null
        }
    }
    val planning = activeKey == null && state == AState.THINKING
    val t = rememberInfiniteTransition(label = "town")
    val phase by t.animateFloat(0f, 6.2831855f, infiniteRepeatable(tween(1300, easing = LinearEasing)), label = "ph")
    val paint = remember {
        Paint().apply {
            isAntiAlias = true
            typeface = Typeface.MONOSPACE
            textAlign = Paint.Align.CENTER
        }
    }

    Canvas(modifier.fillMaxWidth().aspectRatio(24f / 13f).clip(RoundedCornerShape(8.dp))) {
        val c = size.width / 24f
        drawRect(Color(0xFF0A1410))
        for (gx in 0 until 24) for (gy in 0 until 13) {
            if ((gx + gy) % 2 == 0) drawRect(Color(0xFF0D1A15), Offset(gx * c, gy * c), Size(c, c))
        }
        drawRect(Color(0xFF14261E), Offset(0f, 0f), Size(size.width, c * 1.5f))
        for (i in 0..3) drawRect(Color(0xFF1B3A5C), Offset((2f + i * 6f) * c, c * 0.3f), Size(3f * c, c * 0.8f))
        // plants and a rug
        drawRoundRect(Color(0xFF16322A), Offset(9f * c, 11f * c), Size(6f * c, 1.6f * c), CornerRadius(c * 0.3f))
        drawRect(Color(0xFF2E7D4F), Offset(0.6f * c, 11f * c), Size(0.9f * c, 1.2f * c))
        drawRect(Color(0xFF2E7D4F), Offset(22.5f * c, 11f * c), Size(0.9f * c, 1.2f * c))

        for (w in WORKERS) {
            val active = w.key == activeKey || (planning && w.key == "planner")
            val bob = if (active) sin(phase * 2f) * c * 0.18f else 0f
            val cx = w.x * c
            val top = w.y * c
            // glow
            if (active) drawCircle(w.color.copy(alpha = 0.20f), 2.8f * c, Offset(cx, top - 0.3f * c))
            // person (behind the desk)
            drawRect(Color(0xFFE8B98F), Offset(cx - 0.6f * c, top - 2.1f * c + bob), Size(1.2f * c, 1.1f * c))
            drawRect(Color(0xFF2B1B10), Offset(cx - 0.6f * c, top - 2.1f * c + bob), Size(1.2f * c, 0.4f * c))
            drawRect(w.color, Offset(cx - 0.95f * c, top - 1.0f * c + bob), Size(1.9f * c, 1.3f * c))
            // desk
            drawRect(Color(0xFF5B3A1E), Offset(cx - 2f * c, top + 0.2f * c), Size(4f * c, 1.7f * c))
            drawRect(Color(0xFF7A5230), Offset(cx - 2f * c, top + 0.2f * c), Size(4f * c, 0.35f * c))
            // monitor
            drawRect(Color(0xFF111111), Offset(cx - 0.9f * c, top - 0.5f * c), Size(1.8f * c, 1.1f * c))
            drawRect(if (active) w.color else Color(0xFF223B33), Offset(cx - 0.75f * c, top - 0.4f * c), Size(1.5f * c, 0.8f * c))
            // label
            paint.textSize = c * 0.72f
            paint.color = w.color.copy(alpha = if (active) 1f else 0.55f).toArgbInt()
            drawIntoCanvas { it.nativeCanvas.drawText(w.label, cx, top + 3.1f * c, paint) }
            // speech bubble
            if (active) {
                val text = if (w.key == activeKey) label else "…"
                paint.textSize = c * 0.7f
                val tw = paint.measureText(text) + c * 0.8f
                drawRoundRect(Color(0xE6000000), Offset(cx - tw / 2, top - 3.9f * c + bob), Size(tw, c * 1.15f), CornerRadius(c * 0.3f))
                paint.color = w.color.toArgbInt()
                drawIntoCanvas { it.nativeCanvas.drawText(text, cx, top - 3.05f * c + bob, paint) }
            }
        }
    }
}

private fun Color.toArgbInt(): Int = this.toArgb()
