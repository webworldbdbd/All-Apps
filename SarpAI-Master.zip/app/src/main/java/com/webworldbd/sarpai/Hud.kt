@file:OptIn(ExperimentalMaterial3Api::class)

package com.webworldbd.sarpai

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.LocalLifecycleOwner
import kotlinx.coroutines.launch
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

val HudBg = Color(0xFF020807)
val HudPanel = Color(0xFF06130E)
val HudGreen = Color(0xFF00FF9C)
val HudCyan = Color(0xFF22D3EE)
val HudOrange = Color(0xFFFF8A2B)
val HudViolet = Color(0xFFB36BFF)
val HudYellow = Color(0xFFFFD43B)
val HudGray = Color(0xFF7A8C85)
val HudRed = Color(0xFFFF4D5E)

/** Starts / stops the always-listening agent (asks for the microphone first when needed). */
fun toggleAgent(ctx: Context, on: Boolean, askMic: () -> Unit) {
    if (on) {
        if (!Caps.osGranted(ctx, Cap.MIC)) askMic() else AgentOverlayService.start(ctx)
    } else AgentOverlayService.stop(ctx)
}

@Composable
fun HudButton(text: String, color: Color = HudGreen, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(6.dp)
    androidx.compose.foundation.layout.Box(
        modifier.clip(shape).border(1.dp, color, shape).background(color.copy(alpha = 0.08f))
            .clickable { onClick() }.padding(vertical = 10.dp, horizontal = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text, color = color, fontSize = 11.sp, fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold, letterSpacing = 1.sp
        )
    }
}

@Composable
fun HudPanelBox(title: String, accent: Color = HudGreen, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(10.dp)
    Column(
        Modifier.fillMaxWidth().clip(shape).background(HudPanel)
            .border(BorderStroke(1.dp, accent.copy(alpha = 0.55f)), shape).padding(12.dp)
    ) {
        Text(title, color = accent, fontSize = 10.sp, fontFamily = FontFamily.Monospace, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        content()
    }
}

@Composable
fun Orb(state: AState, modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "orb")
    val rot by t.animateFloat(0f, 360f, infiniteRepeatable(tween(16000, easing = LinearEasing)), label = "rot")
    val pulse by t.animateFloat(
        0.92f, 1.08f, infiniteRepeatable(tween(850, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pulse"
    )
    val color = when (state) {
        AState.LISTENING -> HudGreen
        AState.SPEAKING -> HudYellow
        AState.THINKING -> HudViolet
        AState.PAUSED -> HudGray
        AState.OFF -> Color(0xFF2E4A3F)
    }
    val active = state == AState.LISTENING || state == AState.SPEAKING || state == AState.THINKING
    Canvas(modifier) {
        val cx = size.width / 2
        val cy = size.height / 2
        val r = min(size.width, size.height) / 2 * 0.82f * (if (active) pulse else 1f)
        drawCircle(color.copy(alpha = 0.07f), r * 1.15f, Offset(cx, cy))
        drawCircle(color.copy(alpha = 0.16f), r * 0.55f, Offset(cx, cy))
        val rotRad = Math.toRadians(rot.toDouble()).toFloat()
        val n = 170
        for (i in 0 until n) {
            val y = 1f - 2f * (i + 0.5f) / n
            val rad = sqrt(1f - y * y)
            val th = i * 2.3999632f + rotRad
            val x = cos(th) * rad
            val z = sin(th) * rad
            val depth = (z + 1f) / 2f
            drawCircle(
                color.copy(alpha = 0.2f + 0.8f * depth),
                1.2.dp.toPx() + 2.2.dp.toPx() * depth,
                Offset(cx + x * r, cy + y * r)
            )
        }
        rotate(rot * 1.6f, Offset(cx, cy)) {
            drawOval(
                color.copy(alpha = 0.55f), Offset(cx - r * 1.05f, cy - r * 0.32f),
                androidx.compose.ui.geometry.Size(r * 2.1f, r * 0.64f), style = Stroke(1.2.dp.toPx())
            )
        }
        rotate(-rot * 1.1f + 60f, Offset(cx, cy)) {
            drawOval(
                color.copy(alpha = 0.4f), Offset(cx - r * 1.0f, cy - r * 0.45f),
                androidx.compose.ui.geometry.Size(r * 2.0f, r * 0.9f), style = Stroke(1.dp.toPx())
            )
        }
    }
}

@Composable
private fun HudNode(label: String, color: Color, modifier: Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(18.dp)
    androidx.compose.foundation.layout.Box(
        modifier.height(34.dp).clip(shape).border(1.dp, color, shape).background(Color(0xFF05100C)).clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = color, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
    }
}

@Composable
fun HudScreen(onNavigate: (Int, String) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val running by Agent.serviceRunning.collectAsState()
    val state by Agent.state.collectAsState()
    val busy by Agent.busy.collectAsState()
    val log by Agent.log.collectAsState()
    val news by News.headlines.collectAsState()
    val newsLoading by News.loading.collectAsState()
    val tasks by TaskStore.items.collectAsState()
    val liveActive by Live.active.collectAsState()
    val camOn by Live.cameraOn.collectAsState()
    val screenOn by Live.screenOn.collectAsState()
    val owner = LocalLifecycleOwner.current
    var camFront by remember { mutableStateOf(true) }
    var newTask by remember { mutableStateOf("") }

    LaunchedEffect(S.language) { News.refresh() }

    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) AgentOverlayService.start(ctx)
    }

    val status = when (state) {
        AState.OFF -> tr("OFFLINE", "বন্ধ")
        AState.LISTENING -> tr("LISTENING", "শুনছি")
        AState.PAUSED -> tr("PAUSED", "বিরতি")
        AState.THINKING -> tr("THINKING", "ভাবছি")
        AState.SPEAKING -> tr("SPEAKING", "বলছি")
    }

    Column(Modifier.fillMaxSize().background(HudBg).verticalScroll(rememberScrollState()).padding(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "◉ ${S.soulName.ifBlank { "SARP" }.uppercase()}", color = HudGreen, fontSize = 16.sp,
                fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, letterSpacing = 3.sp,
                modifier = Modifier.weight(1f)
            )
            Text(if (liveActive) "LIVE · $status" else status, color = if (running) HudGreen else HudGray, fontSize = 11.sp, fontFamily = FontFamily.Monospace, letterSpacing = 2.sp)
        }
        Spacer(Modifier.height(10.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            HudButton(tr("PHOTO", "ছবি"), modifier = Modifier.weight(1f)) {
                if (!Caps.osGranted(ctx, Cap.CAMERA)) {
                    Toast.makeText(ctx, tr("Grant Camera in Settings > Permissions", "সেটিংস > পারমিশনে ক্যামেরা দিন"), Toast.LENGTH_LONG).show()
                } else {
                    scope.launch {
                        val jpeg = CameraCaptureActivity.capture(ctx)
                        if (jpeg != null) Agent.analyzeImage(jpeg, tr("Describe this photo and read any text in it.", "এই ছবিটি বর্ণনা করো এবং এতে কোনো লেখা থাকলে পড়ো।"))
                    }
                }
            }
            HudButton(tr("SCREEN", "স্ক্রিন"), modifier = Modifier.weight(1f)) {
                (ctx as? Activity)?.moveTaskToBack(true)
                Agent.submit("Wait 2 seconds, then use analyze_screen to explain briefly what is on my screen.")
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            HudButton(
                if (camOn) tr("STOP CAMERA", "ক্যামেরা বন্ধ") else tr("LIVE CAMERA", "লাইভ ক্যামেরা"),
                color = if (camOn) HudRed else HudCyan, modifier = Modifier.weight(1f)
            ) {
                if (camOn) {
                    LiveCamera.stop()
                } else if (!Caps.osGranted(ctx, Cap.CAMERA)) {
                    Toast.makeText(ctx, tr("Grant Camera in Settings > Permissions", "সেটিংস > পারমিশনে ক্যামেরা দিন"), Toast.LENGTH_LONG).show()
                } else if (!Caps.osGranted(ctx, Cap.MIC)) {
                    micLauncher.launch(Manifest.permission.RECORD_AUDIO)
                } else {
                    if (!liveActive) AgentOverlayService.start(ctx, live = true)
                    LiveCamera.start(ctx, owner, camFront) { msg -> Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show() }
                }
            }
            HudButton(
                if (screenOn) tr("STOP SHARING", "শেয়ার বন্ধ") else tr("SHARE SCREEN", "স্ক্রিন শেয়ার"),
                color = if (screenOn) HudRed else HudCyan, modifier = Modifier.weight(1f)
            ) {
                if (screenOn) {
                    Live.setScreenShare(false)
                } else if (!Caps.allowed(ctx, Cap.SCREEN)) {
                    Toast.makeText(ctx, tr("Grant Screen control in Settings > Permissions", "সেটিংস > পারমিশনে স্ক্রিন কন্ট্রোল দিন"), Toast.LENGTH_LONG).show()
                } else if (!Caps.osGranted(ctx, Cap.MIC)) {
                    micLauncher.launch(Manifest.permission.RECORD_AUDIO)
                } else {
                    if (!liveActive) AgentOverlayService.start(ctx, live = true)
                    Live.setScreenShare(true)
                }
            }
        }
        if (camOn || liveActive) {
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (camOn) {
                    HudButton(tr("FLIP CAMERA", "ক্যামেরা উল্টান"), color = HudCyan, modifier = Modifier.weight(1f)) {
                        camFront = !camFront
                        LiveCamera.stop()
                        LiveCamera.start(ctx, owner, camFront) { msg -> Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show() }
                    }
                }
                if (liveActive) {
                    HudButton(tr("HUSH", "চুপ করান"), color = HudOrange, modifier = Modifier.weight(1f)) { Live.interrupt() }
                }
            }
        }
        Spacer(Modifier.height(10.dp))

        HudPanelBox("TRANSCRIPT") {
            val lines = log.filter { it.kind == "user" || it.kind == "agent" }.takeLast(3)
            if (lines.isEmpty()) {
                Text(tr("Say something or type a command in the Agent tab…", "কিছু বলুন বা Agent ট্যাবে কমান্ড লিখুন…"), color = HudGray, fontSize = 12.sp)
            } else {
                lines.forEach { l ->
                    Row(Modifier.padding(vertical = 2.dp)) {
                        Text(
                            if (l.kind == "user") "YOU  " else "${S.soulName.ifBlank { "SARP" }.uppercase()}  ",
                            color = if (l.kind == "user") HudCyan else HudGreen, fontSize = 11.sp, fontFamily = FontFamily.Monospace
                        )
                        Text(l.text, color = Color(0xFFE6FFF4), fontSize = 13.sp, modifier = Modifier.weight(1f))
                    }
                }
            }
        }
        Spacer(Modifier.height(10.dp))

        BoxWithConstraints(Modifier.fillMaxWidth().height(250.dp)) {
            val h = maxHeight
            val orbSize = 190.dp
            val nodeW = 100.dp
            val fr = listOf(0.14f, 0.38f, 0.62f, 0.86f)
            val nodeColors = listOf(HudCyan, HudOrange, Color.White, HudGreen)
            Canvas(Modifier.fillMaxSize()) {
                val orbCx = size.width - orbSize.toPx() / 2 - 2.dp.toPx()
                val orbCy = size.height / 2
                fr.forEachIndexed { i, f ->
                    val sx = nodeW.toPx()
                    val sy = size.height * f
                    val ex = orbCx - orbSize.toPx() / 2 * 0.78f
                    val ey = orbCy + (i - 1.5f) * 9.dp.toPx()
                    val path = Path().apply {
                        moveTo(sx, sy)
                        cubicTo(sx + (ex - sx) * 0.55f, sy, sx + (ex - sx) * 0.45f, ey, ex, ey)
                    }
                    drawPath(path, nodeColors[i].copy(alpha = 0.85f), style = Stroke(width = 1.8.dp.toPx(), cap = StrokeCap.Round))
                }
            }
            val labels = listOf("MEMORY", "CHAT", "SOUL", "SETTINGS")
            labels.forEachIndexed { i, label ->
                HudNode(label, nodeColors[i], Modifier.offset(0.dp, h * fr[i] - 17.dp).width(nodeW)) {
                    when (i) {
                        0 -> onNavigate(3, "memory")
                        1 -> onNavigate(1, "")
                        2 -> onNavigate(3, "soul")
                        else -> onNavigate(3, "")
                    }
                }
            }
            Orb(state, Modifier.align(Alignment.CenterEnd).size(orbSize))
        }
        Spacer(Modifier.height(8.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            HudButton(
                if (running) tr("TERMINATE", "বন্ধ করুন") else tr("ACTIVATE", "চালু করুন"),
                color = if (running) HudRed else HudGreen, modifier = Modifier.weight(1f)
            ) { toggleAgent(ctx, !running) { micLauncher.launch(Manifest.permission.RECORD_AUDIO) } }
            if (busy) HudButton(tr("STOP TASK", "কাজ থামান"), color = HudOrange, modifier = Modifier.weight(1f)) { Agent.cancel() }
        }
        Spacer(Modifier.height(12.dp))

        HudPanelBox("AGENT TOWN", HudViolet) {
            AgentTown()
        }
        Spacer(Modifier.height(12.dp))

        HudPanelBox(tr("TODAY HEADLINES", "আজকের খবর"), HudCyan) {
            if (news.isEmpty()) {
                Text(if (newsLoading) "…" else tr("No headlines (check internet)", "খবর পাওয়া যায়নি (ইন্টারনেট দেখুন)"), color = HudGray, fontSize = 12.sp)
            } else {
                news.forEach { h ->
                    Text(
                        "▸ ${h.title}", color = Color(0xFFD9F7FF), fontSize = 12.sp,
                        modifier = Modifier.fillMaxWidth().clickable {
                            try {
                                ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(h.link)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                            } catch (e: Exception) { }
                        }.padding(vertical = 4.dp)
                    )
                }
            }
            Text(
                tr("↻ refresh", "↻ রিফ্রেশ"), color = HudCyan, fontSize = 11.sp, fontFamily = FontFamily.Monospace,
                modifier = Modifier.padding(top = 6.dp).clickable { scope.launch { News.refresh(true) } }
            )
        }
        Spacer(Modifier.height(12.dp))

        HudPanelBox(tr("TODAY TASKS", "আজকের কাজ"), HudYellow) {
            tasks.takeLast(6).forEach { t ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(
                        checked = t.done, onCheckedChange = { TaskStore.toggle(t.id) },
                        colors = CheckboxDefaults.colors(checkedColor = HudYellow, uncheckedColor = HudGray, checkmarkColor = Color.Black)
                    )
                    Text(
                        t.text, color = if (t.done) HudGray else Color(0xFFFFF6D6), fontSize = 13.sp,
                        modifier = Modifier.weight(1f)
                    )
                    Text("✕", color = HudGray, modifier = Modifier.clickable { TaskStore.remove(t.id) }.padding(8.dp))
                }
            }
            if (tasks.isEmpty()) Text(tr("No tasks yet.", "এখনও কোনো কাজ নেই।"), color = HudGray, fontSize = 12.sp)
            Row(Modifier.padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                TextField(
                    value = newTask, onValueChange = { newTask = it }, singleLine = true, modifier = Modifier.weight(1f),
                    placeholder = { Text(tr("Add a task…", "কাজ যোগ করুন…"), fontSize = 12.sp) },
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Color(0xFF0B1B14), unfocusedContainerColor = Color(0xFF0B1B14),
                        focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                        focusedIndicatorColor = HudYellow, unfocusedIndicatorColor = HudGray
                    )
                )
                HudButton("+", HudYellow, Modifier.padding(start = 8.dp).width(48.dp)) {
                    TaskStore.add(newTask)
                    newTask = ""
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        Text(
            "Powered By WebWorldBD", color = HudGray, fontSize = 11.sp, fontFamily = FontFamily.Monospace,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )
        Spacer(Modifier.height(8.dp))
    }
}
