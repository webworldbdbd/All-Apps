package com.webworldbd.sarpai

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.location.Location
import android.location.LocationManager
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.provider.Settings
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

/** Phone controls that Android allows an app to do (each one is also gated by a capability). */
object Device {
    private val ctx: Context get() = S.app

    fun parseTime(s: String): Long? {
        for (f in listOf("yyyy-MM-dd HH:mm", "yyyy-MM-dd'T'HH:mm")) {
            try {
                val d = SimpleDateFormat(f, Locale.US).parse(s.trim())
                if (d != null) return d.time
            } catch (e: Exception) { }
        }
        return null
    }

    private fun launch(i: Intent): Boolean = try {
        ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        true
    } catch (e: Exception) {
        false
    }

    fun lastLocation(): Pair<Double, Double>? {
        if (!Caps.allowed(ctx, Cap.LOCATION)) return null
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        var best: Location? = null
        for (p in lm.getProviders(true)) {
            val l = try { lm.getLastKnownLocation(p) } catch (e: SecurityException) { null }
            val b = best
            if (l != null && (b == null || l.time > b.time)) best = l
        }
        val r = best ?: return null
        return r.latitude to r.longitude
    }

    // ------------------------------------------------------------ flashlight / volume / brightness / dnd

    fun flashlight(on: Boolean): String {
        return try {
            val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return "ERROR: this phone has no flashlight."
            cm.setTorchMode(id, on)
            "Flashlight is ${if (on) "on" else "off"}."
        } catch (e: Exception) {
            "ERROR: flashlight failed: ${e.message}"
        }
    }

    fun volume(stream: String, level: String): String {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val st = when (stream.lowercase()) {
            "ring" -> AudioManager.STREAM_RING
            "alarm" -> AudioManager.STREAM_ALARM
            "notification" -> AudioManager.STREAM_NOTIFICATION
            "call" -> AudioManager.STREAM_VOICE_CALL
            else -> AudioManager.STREAM_MUSIC
        }
        val max = am.getStreamMaxVolume(st).coerceAtLeast(1)
        return try {
            when (level.lowercase().trim()) {
                "up" -> am.adjustStreamVolume(st, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
                "down" -> am.adjustStreamVolume(st, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
                "mute" -> am.adjustStreamVolume(st, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI)
                "unmute" -> am.adjustStreamVolume(st, AudioManager.ADJUST_UNMUTE, AudioManager.FLAG_SHOW_UI)
                else -> {
                    val pct = level.trim().toIntOrNull() ?: return "ERROR: level must be 0-100, up, down, mute or unmute."
                    am.setStreamVolume(st, (pct.coerceIn(0, 100) * max / 100.0).roundToInt(), AudioManager.FLAG_SHOW_UI)
                }
            }
            "${stream.ifBlank { "media" }} volume is now ${am.getStreamVolume(st) * 100 / max}%."
        } catch (e: SecurityException) {
            "ERROR: Android blocked this (ring volume may need Do Not Disturb access)."
        } catch (e: Exception) {
            "ERROR: volume failed: ${e.message}"
        }
    }

    fun brightness(level: String): String {
        if (!Settings.System.canWrite(ctx)) {
            return "ERROR: 'Change system settings' permission is not granted (Settings > Permissions)."
        }
        return try {
            val cr = ctx.contentResolver
            val l = level.lowercase().trim()
            if (l == "auto") {
                Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_AUTOMATIC)
                return "Adaptive brightness is on."
            }
            val cur = Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS, 128) * 100 / 255
            val pct = when (l) {
                "up" -> cur + 20
                "down" -> cur - 20
                else -> l.toIntOrNull() ?: return "ERROR: level must be 0-100, up, down or auto."
            }.coerceIn(1, 100)
            Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
            Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS, pct * 255 / 100)
            "Brightness is now $pct%."
        } catch (e: Exception) {
            "ERROR: brightness failed: ${e.message}"
        }
    }

    fun dnd(on: Boolean): String {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (!nm.isNotificationPolicyAccessGranted) return "ERROR: Do Not Disturb access is not granted (Settings > Permissions)."
        nm.setInterruptionFilter(
            if (on) NotificationManager.INTERRUPTION_FILTER_PRIORITY else NotificationManager.INTERRUPTION_FILTER_ALL
        )
        return "Do Not Disturb is ${if (on) "on" else "off"}."
    }

    fun status(): String {
        val sb = StringBuilder()
        try {
            val bi = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            if (bi != null) {
                val lvl = bi.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                val sc = bi.getIntExtra(BatteryManager.EXTRA_SCALE, 100).coerceAtLeast(1)
                val st = bi.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
                val charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
                sb.append("Battery: ${lvl * 100 / sc}%${if (charging) " (charging)" else ""}\n")
            }
        } catch (e: Exception) { }
        try {
            val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val caps = cm.getNetworkCapabilities(cm.activeNetwork)
            val net = when {
                caps == null -> "offline"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "mobile data"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "ethernet"
                else -> "connected"
            }
            val ok = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) == true
            sb.append("Network: $net, internet ${if (ok) "working" else "not confirmed"}\n")
        } catch (e: Exception) { }
        try {
            val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            sb.append("Wi-Fi switch: ${if (wm.isWifiEnabled) "on" else "off"}\n")
        } catch (e: Exception) { }
        try {
            val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val m = am.getStreamVolume(AudioManager.STREAM_MUSIC) * 100 / am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
            val r = am.getStreamVolume(AudioManager.STREAM_RING) * 100 / am.getStreamMaxVolume(AudioManager.STREAM_RING).coerceAtLeast(1)
            sb.append("Volume: media $m%, ring $r%\n")
        } catch (e: Exception) { }
        try {
            val b = Settings.System.getInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128) * 100 / 255
            sb.append("Brightness: $b%\n")
        } catch (e: Exception) { }
        try {
            val s = StatFs(Environment.getDataDirectory().path)
            sb.append("Storage free: ${s.availableBytes / 1_000_000_000} GB of ${s.totalBytes / 1_000_000_000} GB\n")
        } catch (e: Exception) { }
        try {
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            sb.append("Do Not Disturb: ${if (nm.currentInterruptionFilter == NotificationManager.INTERRUPTION_FILTER_ALL) "off" else "on"}\n")
        } catch (e: Exception) { }
        return sb.toString().ifBlank { "No status available." }
    }

    fun openSettings(page: String): String {
        val action = when (page.lowercase().trim()) {
            "wifi", "internet" -> if (Build.VERSION.SDK_INT >= 29) Settings.Panel.ACTION_INTERNET_CONNECTIVITY else Settings.ACTION_WIFI_SETTINGS
            "wifi_settings" -> Settings.ACTION_WIFI_SETTINGS
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "display", "brightness" -> Settings.ACTION_DISPLAY_SETTINGS
            "sound" -> Settings.ACTION_SOUND_SETTINGS
            "volume" -> if (Build.VERSION.SDK_INT >= 29) Settings.Panel.ACTION_VOLUME else Settings.ACTION_SOUND_SETTINGS
            "battery" -> Settings.ACTION_BATTERY_SAVER_SETTINGS
            "apps" -> Settings.ACTION_APPLICATION_SETTINGS
            "accessibility" -> Settings.ACTION_ACCESSIBILITY_SETTINGS
            "location" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
            "date" -> Settings.ACTION_DATE_SETTINGS
            "language" -> Settings.ACTION_LOCALE_SETTINGS
            "storage" -> Settings.ACTION_INTERNAL_STORAGE_SETTINGS
            "security" -> Settings.ACTION_SECURITY_SETTINGS
            "airplane" -> Settings.ACTION_AIRPLANE_MODE_SETTINGS
            "nfc" -> Settings.ACTION_NFC_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }
        return if (launch(Intent(action))) "Opened the \"$page\" settings screen." else "ERROR: could not open settings."
    }

    suspend fun closeApp(name: String): String {
        val pm = ctx.packageManager
        val n = name.trim().lowercase()
        if (n.isEmpty()) return "ERROR: app name missing"
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val m = apps.firstOrNull { it.activityInfo.packageName.equals(n, true) || it.loadLabel(pm).toString().lowercase() == n }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(n) }
            ?: return "ERROR: no installed app matches \"$name\""
        val pkg = m.activityInfo.packageName
        if (pkg == ctx.packageName) return "I will not close myself."
        val label = m.loadLabel(pm).toString()
        val svc = AgentAccessibilityService.instance
        if (svc != null && svc.currentPackage() == pkg) {
            svc.press("home")
            kotlinx.coroutines.delay(700)
        }
        (ctx.getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager).killBackgroundProcesses(pkg)
        return "Asked Android to stop $label in the background (the app is sent home first). Protected apps may keep running."
    }

    // ------------------------------------------------------------ alarm / timer / calendar

    fun setAlarm(hour: Int, minute: Int, label: String): String {
        if (hour !in 0..23 || minute !in 0..59) return "ERROR: hour must be 0-23 and minute 0-59."
        val i = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, hour).putExtra(AlarmClock.EXTRA_MINUTES, minute)
            .putExtra(AlarmClock.EXTRA_MESSAGE, label).putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        return if (launch(i)) "Alarm set for %02d:%02d.".format(hour, minute) else "ERROR: no clock app could set the alarm."
    }

    fun setTimer(seconds: Int, label: String): String {
        if (seconds <= 0) return "ERROR: seconds must be greater than 0."
        val i = Intent(AlarmClock.ACTION_SET_TIMER)
            .putExtra(AlarmClock.EXTRA_LENGTH, seconds).putExtra(AlarmClock.EXTRA_MESSAGE, label)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        return if (launch(i)) "Timer started for $seconds seconds." else "ERROR: no clock app could start the timer."
    }

    fun addEvent(a: JSONObject): String {
        val begin = parseTime(a.optString("start")) ?: return "ERROR: 'start' must look like 2026-12-31 18:30 (24h)."
        val end = parseTime(a.optString("end")) ?: (begin + 3600_000L)
        val i = Intent(Intent.ACTION_INSERT).setData(CalendarContract.Events.CONTENT_URI)
            .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, begin)
            .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, end)
            .putExtra(CalendarContract.Events.TITLE, a.optString("title"))
            .putExtra(CalendarContract.Events.EVENT_LOCATION, a.optString("location"))
            .putExtra(CalendarContract.Events.DESCRIPTION, a.optString("description"))
        return if (launch(i)) "Calendar form opened with the event filled in. Tap Save to add it."
        else "ERROR: no calendar app found."
    }

    fun listEvents(days: Int): String {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CALENDAR) != PackageManager.PERMISSION_GRANTED) {
            return "ERROR: calendar permission is not granted."
        }
        return try {
            val b = System.currentTimeMillis()
            val e = b + days.coerceIn(1, 60) * 86_400_000L
            val cur = CalendarContract.Instances.query(
                ctx.contentResolver,
                arrayOf(CalendarContract.Instances.TITLE, CalendarContract.Instances.BEGIN, CalendarContract.Instances.EVENT_LOCATION),
                b, e
            )
            val rows = mutableListOf<Pair<Long, String>>()
            cur?.use { c ->
                while (c.moveToNext()) {
                    val begin = c.getLong(1)
                    val f = SimpleDateFormat("EEE d MMM HH:mm", Locale.ENGLISH).format(Date(begin))
                    val loc = c.getString(2).orEmpty()
                    rows.add(begin to "$f  ${c.getString(0).orEmpty()}${if (loc.isNotBlank()) " @ $loc" else ""}")
                }
            }
            if (rows.isEmpty()) "No events in the next $days days." else rows.sortedBy { it.first }.take(25).joinToString("\n") { it.second }
        } catch (ex: Exception) {
            "ERROR: calendar failed: ${ex.message}"
        }
    }

    // ------------------------------------------------------------ messaging helpers

    fun whatsapp(to: String, text: String): String {
        val raw = Actions.resolveNumber(to) ?: return "ERROR: could not find a number for \"$to\" (Contacts permission may be off)."
        var digits = raw.filter { it.isDigit() }
        if (digits.startsWith("01") && digits.length == 11) digits = "880" + digits.drop(1)
        val uri = Uri.parse("https://wa.me/$digits?text=" + Uri.encode(text))
        val pm = ctx.packageManager
        val pkg = listOf("com.whatsapp", "com.whatsapp.w4b").firstOrNull { pm.getLaunchIntentForPackage(it) != null }
        val i = Intent(Intent.ACTION_VIEW, uri)
        if (pkg != null) i.setPackage(pkg)
        return if (launch(i)) "WhatsApp chat opened with the message typed. To send it, tap the Send button (the user will be asked to confirm)."
        else "ERROR: WhatsApp is not installed."
    }

    fun composeEmail(to: String, subject: String, body: String): String {
        val i = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:"))
            .putExtra(Intent.EXTRA_EMAIL, arrayOf(to)).putExtra(Intent.EXTRA_SUBJECT, subject).putExtra(Intent.EXTRA_TEXT, body)
        return if (launch(i)) "Email draft opened. To send it, tap Send (the user will be asked to confirm)."
        else "ERROR: no email app found."
    }
}

/** One-off reminders shown as a notification at the chosen time. */
object Reminders {
    const val CHANNEL = "sarp_reminders"

    fun set(text: String, at: String): String {
        val ctx = S.app
        if (text.isBlank()) return "ERROR: reminder text missing."
        val whenMs = Device.parseTime(at) ?: return "ERROR: 'at' must look like 2026-12-31 18:30 (24h, local time)."
        if (whenMs <= System.currentTimeMillis()) return "ERROR: that time is in the past."
        val id = (System.currentTimeMillis() % Int.MAX_VALUE).toInt()
        val intent = Intent(ctx, ReminderReceiver::class.java).putExtra("text", text).putExtra("id", id)
        val pi = PendingIntent.getBroadcast(ctx, id, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val exact = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()
        return try {
            if (exact) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, whenMs, pi)
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, whenMs, pi)
            "Reminder set for $at: $text"
        } catch (e: Exception) {
            "ERROR: reminder failed: ${e.message}"
        }
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val text = i.getStringExtra("text") ?: "Reminder"
        val id = i.getIntExtra("id", 1)
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(Reminders.CHANNEL, "Reminders", NotificationManager.IMPORTANCE_HIGH))
        val open = PendingIntent.getActivity(c, id, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = NotificationCompat.Builder(c, Reminders.CHANNEL)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("SARP AI ⏰")
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setAutoCancel(true)
            .setContentIntent(open)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()
        try {
            NotificationManagerCompat.from(c).notify(id, n)
        } catch (e: SecurityException) { }
    }
}
