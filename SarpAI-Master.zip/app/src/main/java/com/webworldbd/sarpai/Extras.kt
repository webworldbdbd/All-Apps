package com.webworldbd.sarpai

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.PowerManager
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.math.BigDecimal
import java.math.MathContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

/** Hides one-time codes and passwords from what is sent to the AI. */
object Privacy {
    private val secret = Regex("(?i)(otp|one[- ]?time|verification|passcode|password|pin|code|ওটিপি|কোড|পিন|পাসওয়ার্ড)([^0-9\\n]{0,24})(\\d{4,8})")

    fun redact(text: String): String {
        if (!S.hideSecrets) return text
        return secret.replace(text) { m -> m.groupValues[1] + m.groupValues[2] + "[hidden]" }
    }
}

/** Exact calculator, so the AI does not have to guess arithmetic. */
object Calc {
    fun eval(expr: String): String {
        return try {
            val p = Parser(expr.lowercase().replace("×", "*").replace("÷", "/").replace("−", "-").replace(" ", "").replace(",", ""))
            val v = p.parse()
            if (v.isNaN() || v.isInfinite()) "ERROR: result is not a number"
            else BigDecimal(v).round(MathContext(12)).stripTrailingZeros().toPlainString()
        } catch (e: Exception) {
            "ERROR: cannot calculate \"$expr\" (${e.message})"
        }
    }

    private class Parser(val s: String) {
        var i = 0

        fun parse(): Double {
            val v = expr()
            if (i != s.length) throw IllegalArgumentException("unexpected '${s[i]}'")
            return v
        }

        private fun peek(): Char = if (i < s.length) s[i] else '\u0000'

        private fun expr(): Double {
            var v = term()
            while (peek() == '+' || peek() == '-') {
                val op = s[i++]
                val r = term()
                v = if (op == '+') v + r else v - r
            }
            return v
        }

        private fun term(): Double {
            var v = power()
            while (peek() == '*' || peek() == '/' || peek() == '%') {
                val op = s[i++]
                val r = power()
                v = when (op) {
                    '*' -> v * r
                    '/' -> v / r
                    else -> v % r
                }
            }
            return v
        }

        private fun power(): Double {
            val b = unary()
            if (peek() == '^') {
                i++
                return Math.pow(b, power())
            }
            return b
        }

        private fun unary(): Double {
            if (peek() == '-') { i++; return -unary() }
            if (peek() == '+') { i++; return unary() }
            return atom()
        }

        private fun atom(): Double {
            val c = peek()
            if (c == '(') {
                i++
                val v = expr()
                if (peek() != ')') throw IllegalArgumentException("missing )")
                i++
                return v
            }
            if (c.isDigit() || c == '.') {
                val st = i
                while (peek().isDigit() || peek() == '.') i++
                return s.substring(st, i).toDouble()
            }
            if (c.isLetter()) {
                val st = i
                while (peek().isLetter()) i++
                val name = s.substring(st, i)
                if (name == "pi") return Math.PI
                if (name == "e") return Math.E
                if (peek() != '(') throw IllegalArgumentException("unknown '$name'")
                i++
                val a = expr()
                if (peek() != ')') throw IllegalArgumentException("missing )")
                i++
                return when (name) {
                    "sqrt" -> Math.sqrt(a)
                    "sin" -> Math.sin(Math.toRadians(a))
                    "cos" -> Math.cos(Math.toRadians(a))
                    "tan" -> Math.tan(Math.toRadians(a))
                    "log" -> Math.log10(a)
                    "ln" -> Math.log(a)
                    "abs" -> abs(a)
                    "round" -> Math.round(a).toDouble()
                    else -> throw IllegalArgumentException("unknown function '$name'")
                }
            }
            throw IllegalArgumentException("unexpected end")
        }
    }
}

data class Sched(val id: Int, val goal: String, val at: Long, val repeat: String)

/** Runs an agent task at a chosen time, once or repeating (daily / weekly). Survives reboot. */
object Scheduler {
    val items = MutableStateFlow<List<Sched>>(emptyList())

    fun load() {
        try {
            val arr = JSONArray(S.getSecure("schedules").ifBlank { "[]" })
            val l = mutableListOf<Sched>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                l.add(Sched(o.getInt("id"), o.getString("goal"), o.getLong("at"), o.optString("repeat", "none")))
            }
            items.value = l
        } catch (e: Exception) { }
    }

    private fun persist() {
        val arr = JSONArray()
        items.value.forEach { arr.put(JSONObject().put("id", it.id).put("goal", it.goal).put("at", it.at).put("repeat", it.repeat)) }
        S.putSecure("schedules", arr.toString())
    }

    private fun pending(id: Int): PendingIntent {
        val c = S.app
        return PendingIntent.getBroadcast(
            c, 50000 + id, Intent(c, ScheduledReceiver::class.java).putExtra("id", id),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
    }

    private fun arm(s: Sched, at: Long = s.at) {
        val am = S.app.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = pending(s.id)
        val exact = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()
        try {
            if (exact) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        } catch (e: Exception) { }
    }

    fun add(goal: String, at: String, repeat: String): String {
        if (goal.isBlank()) return "ERROR: goal missing"
        val whenMs = Device.parseTime(at) ?: return "ERROR: 'at' must look like 2026-12-31 18:30 (24h, local time)."
        if (whenMs <= System.currentTimeMillis()) return "ERROR: that time is in the past."
        val r = if (repeat == "daily" || repeat == "weekly") repeat else "none"
        val s = Sched((System.currentTimeMillis() % 1_000_000).toInt(), goal.trim(), whenMs, r)
        items.value = items.value + s
        persist()
        arm(s)
        return "Scheduled: \"${s.goal}\" at $at (${if (r == "none") "once" else r}). The screen must be unlocked when it runs for app control."
    }

    fun cancel(query: String): Int {
        val q = query.trim().lowercase()
        val (gone, keep) = items.value.partition { q.isEmpty() || it.goal.lowercase().contains(q) }
        val am = S.app.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        gone.forEach { am.cancel(pending(it.id)) }
        items.value = keep
        persist()
        return gone.size
    }

    fun remove(id: Int) {
        val am = S.app.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(pending(id))
        items.value = items.value.filter { it.id != id }
        persist()
    }

    fun describe(): String {
        if (items.value.isEmpty()) return "No scheduled tasks."
        val f = SimpleDateFormat("EEE d MMM HH:mm", Locale.ENGLISH)
        return items.value.joinToString("\n") { "- ${f.format(Date(it.at))} (${it.repeat}): ${it.goal}" }
    }

    @Suppress("DEPRECATION")
    fun fire(id: Int) {
        val s = items.value.firstOrNull { it.id == id } ?: return
        try {
            val pm = S.app.getSystemService(Context.POWER_SERVICE) as PowerManager
            pm.newWakeLock(PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP, "sarp:schedule").acquire(90_000)
        } catch (e: Exception) { }
        if (Agent.busy.value) {
            arm(s, System.currentTimeMillis() + 60_000)
            return
        }
        // next occurrence (or remove a one-off)
        val next = when (s.repeat) {
            "daily" -> s.at + 86_400_000L
            "weekly" -> s.at + 7 * 86_400_000L
            else -> 0L
        }
        if (next > 0) {
            var n = next
            while (n <= System.currentTimeMillis()) n += if (s.repeat == "daily") 86_400_000L else 7 * 86_400_000L
            val ns = s.copy(at = n)
            items.value = items.value.map { if (it.id == id) ns else it }
            arm(ns)
        } else {
            items.value = items.value.filter { it.id != id }
        }
        persist()
        Agent.addLog("agent", tr("Running scheduled task: ", "নির্ধারিত কাজ চলছে: ") + s.goal)
        Agent.submit(s.goal)
    }

    fun rescheduleAll() {
        val now = System.currentTimeMillis()
        items.value.forEach { arm(it, if (it.at < now) now + 5_000 else it.at) }
    }
}

class ScheduledReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Scheduler.fire(i.getIntExtra("id", -1))
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action == Intent.ACTION_BOOT_COMPLETED) Scheduler.rescheduleAll()
    }
}
