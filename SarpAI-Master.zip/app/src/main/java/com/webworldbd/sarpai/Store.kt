package com.webworldbd.sarpai

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONArray
import org.json.JSONObject

/** Inline translation helper: tr("English", "বাংলা") */
fun tr(en: String, bn: String): String = if (S.language == "bn") bn else en

data class ApiKey(
    val id: String,
    val title: String,
    val provider: String,
    val key: String,
    val model: String,
    val baseUrl: String,
    val enabled: Boolean = true
)

/** All user settings. API keys / biodata / tokens live in EncryptedSharedPreferences. */
object S {
    const val MAX_KEYS = 5

    lateinit var app: Context
    private lateinit var sp: SharedPreferences
    private lateinit var secure: SharedPreferences

    var language by mutableStateOf("bn")          // bn | en
    var theme by mutableStateOf("system")         // system | light | dark
    var voiceEngine by mutableStateOf("phone")    // phone | ai
    var voiceGender by mutableStateOf("female")   // female | male
    var speakReplies by mutableStateOf(true)
    var inputLang by mutableStateOf("bn-BD")      // bn-BD | en-US
    var wakeWordOn by mutableStateOf(false)
    var wakeWords by mutableStateOf("sarp, সার্প, শার্প")
    var confirmSensitive by mutableStateOf(true)
    var rules by mutableStateOf("")
    var blocked by mutableStateOf("")
    var biodata by mutableStateOf("")
    var githubToken by mutableStateOf("")
    var githubUser by mutableStateOf("")
    var emailAddress by mutableStateOf("")
    var emailHost by mutableStateOf("imap.gmail.com")
    var emailPassword by mutableStateOf("")
    var routing by mutableStateOf("auto")         // auto | <key id>
    var soulName by mutableStateOf("SARP")
    var hideSecrets by mutableStateOf(true)
    var voiceMode by mutableStateOf("classic")     // classic | live
    var liveModel by mutableStateOf("gemini-3.8-live")
    var liveBargeIn by mutableStateOf(false)
    var soul by mutableStateOf("")

    val keys = mutableStateListOf<ApiKey>()
    val caps = mutableStateMapOf<String, Boolean>()

    fun init(ctx: Context) {
        app = ctx.applicationContext
        sp = app.getSharedPreferences("sarp_settings", Context.MODE_PRIVATE)
        secure = try {
            val mk = MasterKey.Builder(app).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
            EncryptedSharedPreferences.create(
                app, "sarp_secure", mk,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        } catch (e: Exception) {
            app.getSharedPreferences("sarp_secure_fallback", Context.MODE_PRIVATE)
        }
        load()
    }

    private fun load() {
        language = sp.getString("language", "bn") ?: "bn"
        theme = sp.getString("theme", "system") ?: "system"
        voiceEngine = sp.getString("voiceEngine", "phone") ?: "phone"
        voiceGender = sp.getString("voiceGender", "female") ?: "female"
        speakReplies = sp.getBoolean("speakReplies", true)
        inputLang = sp.getString("inputLang", "bn-BD") ?: "bn-BD"
        wakeWordOn = sp.getBoolean("wakeWordOn", false)
        wakeWords = sp.getString("wakeWords", wakeWords) ?: wakeWords
        confirmSensitive = sp.getBoolean("confirmSensitive", true)
        rules = sp.getString("rules", "") ?: ""
        blocked = sp.getString("blocked", "") ?: ""
        routing = sp.getString("routing", "auto") ?: "auto"
        soulName = sp.getString("soulName", "SARP") ?: "SARP"
        hideSecrets = sp.getBoolean("hideSecrets", true)
        voiceMode = sp.getString("voiceMode", "classic") ?: "classic"
        liveModel = sp.getString("liveModel", "gemini-3.8-live") ?: "gemini-3.8-live"
        liveBargeIn = sp.getBoolean("liveBargeIn", false)
        soul = sp.getString("soul", "") ?: ""
        githubUser = sp.getString("githubUser", "") ?: ""
        emailAddress = sp.getString("emailAddress", "") ?: ""
        emailHost = sp.getString("emailHost", "imap.gmail.com") ?: "imap.gmail.com"
        emailPassword = secure.getString("emailPassword", "") ?: ""
        biodata = secure.getString("biodata", "") ?: ""
        githubToken = secure.getString("githubToken", "") ?: ""

        keys.clear()
        try {
            val arr = JSONArray(secure.getString("keys", "[]") ?: "[]")
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                keys.add(
                    ApiKey(
                        o.getString("id"), o.optString("title"), o.optString("provider", "openai"),
                        o.optString("key"), o.optString("model"), o.optString("baseUrl"),
                        o.optBoolean("enabled", true)
                    )
                )
            }
        } catch (e: Exception) { }

        caps.clear()
        try {
            val o = JSONObject(sp.getString("caps", "{}") ?: "{}")
            val it = o.keys()
            while (it.hasNext()) {
                val k = it.next()
                caps[k] = o.getBoolean(k)
            }
        } catch (e: Exception) { }
    }

    fun save() {
        sp.edit()
            .putString("language", language)
            .putString("theme", theme)
            .putString("voiceEngine", voiceEngine)
            .putString("voiceGender", voiceGender)
            .putBoolean("speakReplies", speakReplies)
            .putString("inputLang", inputLang)
            .putBoolean("wakeWordOn", wakeWordOn)
            .putString("wakeWords", wakeWords)
            .putBoolean("confirmSensitive", confirmSensitive)
            .putString("rules", rules)
            .putString("blocked", blocked)
            .putString("routing", routing)
            .putString("soulName", soulName)
            .putBoolean("hideSecrets", hideSecrets)
            .putString("voiceMode", voiceMode)
            .putString("liveModel", liveModel)
            .putBoolean("liveBargeIn", liveBargeIn)
            .putString("soul", soul)
            .putString("githubUser", githubUser)
            .putString("emailAddress", emailAddress)
            .putString("emailHost", emailHost)
            .putString("caps", JSONObject(caps.toMap()).toString())
            .apply()
        secure.edit()
            .putString("biodata", biodata)
            .putString("githubToken", githubToken)
            .putString("emailPassword", emailPassword)
            .apply()
    }

    fun getSecure(k: String): String = secure.getString(k, "") ?: ""

    fun putSecure(k: String, v: String) {
        secure.edit().putString(k, v).apply()
    }

    fun saveKeys() {
        val arr = JSONArray()
        keys.forEach {
            arr.put(
                JSONObject().put("id", it.id).put("title", it.title).put("provider", it.provider)
                    .put("key", it.key).put("model", it.model).put("baseUrl", it.baseUrl)
                    .put("enabled", it.enabled)
            )
        }
        secure.edit().putString("keys", arr.toString()).apply()
        if (routing != "auto" && keys.none { it.id == routing }) {
            routing = "auto"
            save()
        }
    }
}
