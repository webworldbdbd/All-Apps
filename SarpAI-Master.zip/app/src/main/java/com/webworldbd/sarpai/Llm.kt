package com.webworldbd.sarpai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

enum class Provider(val id: String, val label: String, val defModel: String, val defBase: String) {
    GEMINI("gemini", "Google Gemini", "gemini-3.8-flash", "https://generativelanguage.googleapis.com"),
    OPENAI("openai", "OpenAI (ChatGPT)", "gpt-4o-mini", "https://api.openai.com/v1"),
    ANTHROPIC("anthropic", "Anthropic (Claude)", "claude-sonnet-5-5", "https://api.anthropic.com"),
    DEEPSEEK("deepseek", "DeepSeek", "deepseek-chat", "https://api.deepseek.com"),
    GROQ("groq", "Groq (Meta Llama)", "llama-3.3-70b-versatile", "https://api.groq.com/openai/v1"),
    OPENROUTER("openrouter", "OpenRouter (Meta Llama etc.)", "meta-llama/llama-3.3-70b-instruct", "https://openrouter.ai/api/v1"),
    CUSTOM("custom", "Custom (OpenAI-compatible)", "", "");

    companion object {
        fun of(id: String): Provider = values().firstOrNull { it.id == id } ?: CUSTOM
    }
}

data class Msg(val role: String, val text: String)

class LlmException(message: String, val code: Int = 0) : IOException(message)

object Llm {
    val http: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private val JSON_MT = "application/json; charset=utf-8".toMediaType()

    /** Merge same-role neighbours and make sure the list starts with a user message. */
    fun normalize(msgs: List<Msg>): List<Msg> {
        val out = mutableListOf<Msg>()
        for (m in msgs) {
            if (m.text.isBlank()) continue
            if (out.isNotEmpty() && out.last().role == m.role) {
                out[out.lastIndex] = Msg(m.role, out.last().text + "\n\n" + m.text)
            } else out.add(m)
        }
        while (out.isNotEmpty() && out.first().role != "user") out.removeAt(0)
        return out
    }

    suspend fun chat(k: ApiKey, system: String, msgs: List<Msg>, search: Boolean = false): String =
        withContext(Dispatchers.IO) {
            val m = normalize(msgs)
            if (m.isEmpty()) throw LlmException("Empty conversation")
            val p = Provider.of(k.provider)
            val base = k.baseUrl.ifBlank { p.defBase }.trimEnd('/')
            val model = k.model.ifBlank { p.defModel }
            // Busy / rate-limited servers (429, 5xx): retry automatically before giving up.
            var last: LlmException? = null
            for (wait in longArrayOf(0L, 2500L, 6000L)) {
                if (wait > 0) delay(wait)
                try {
                    return@withContext when (p) {
                        Provider.GEMINI -> gemini(base, model, k.key, system, m, search)
                        Provider.ANTHROPIC -> anthropic(base, model, k.key, system, m)
                        else -> openai(base, model, k.key, system, m)
                    }
                } catch (e: LlmException) {
                    if (e.code == 429 || e.code >= 500) last = e else throw e
                }
            }
            // Still busy: for Gemini, try the previous Flash models too.
            if (p == Provider.GEMINI) {
                for (alt in listOf("gemini-3.6-flash", "gemini-3.5-flash-lite")) {
                    if (alt == model) continue
                    try {
                        return@withContext gemini(base, alt, k.key, system, m, search)
                    } catch (e: LlmException) {
                    }
                }
            }
            throw last ?: LlmException("Request failed")
        }

    suspend fun test(k: ApiKey): String {
        val r = chat(k, "", listOf(Msg("user", "Reply with the single word: OK")))
        return r.take(40)
    }

    fun postJson(url: String, headers: Map<String, String>, body: JSONObject): String {
        val rb = Request.Builder().url(url).post(body.toString().toRequestBody(JSON_MT))
        headers.forEach { (a, b) -> rb.header(a, b) }
        return http.newCall(rb.build()).execute().use { r ->
            val s = r.body?.string().orEmpty()
            if (!r.isSuccessful) throw LlmException("HTTP ${r.code}: ${apiError(s)}", r.code)
            s
        }
    }

    /** Pull the human-readable message out of a provider error body. */
    private fun apiError(body: String): String {
        return try {
            val e = JSONObject(body).opt("error")
            val m = if (e is JSONObject) e.optString("message") else e?.toString().orEmpty()
            m.ifBlank { body }.take(300)
        } catch (x: Exception) {
            body.take(300)
        }
    }

    private fun gemini(base: String, model: String, key: String, system: String, m: List<Msg>, search: Boolean): String {
        fun build(withSearch: Boolean): JSONObject {
            val b = JSONObject()
            if (system.isNotBlank()) {
                b.put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            }
            val contents = JSONArray()
            m.forEach {
                contents.put(
                    JSONObject().put("role", if (it.role == "user") "user" else "model")
                        .put("parts", JSONArray().put(JSONObject().put("text", it.text)))
                )
            }
            b.put("contents", contents)
            if (withSearch) b.put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))
            return b
        }

        val url = "$base/v1beta/models/$model:generateContent"
        val h = mapOf("x-goog-api-key" to key)
        val resp = try {
            postJson(url, h, build(search))
        } catch (e: LlmException) {
            if (search) postJson(url, h, build(false)) else throw e
        }
        val parts = JSONObject(resp).optJSONArray("candidates")?.optJSONObject(0)
            ?.optJSONObject("content")?.optJSONArray("parts") ?: throw LlmException("Empty response")
        val sb = StringBuilder()
        for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
        val t = sb.toString()
        if (t.isBlank()) throw LlmException("Empty response")
        return t
    }

    private fun anthropic(base: String, model: String, key: String, system: String, m: List<Msg>): String {
        val arr = JSONArray()
        m.forEach { arr.put(JSONObject().put("role", it.role).put("content", it.text)) }
        val b = JSONObject().put("model", model).put("max_tokens", 4096).put("messages", arr)
        if (system.isNotBlank()) b.put("system", system)
        val resp = postJson(
            "$base/v1/messages",
            mapOf("x-api-key" to key, "anthropic-version" to "2023-06-01"),
            b
        )
        val content = JSONObject(resp).optJSONArray("content") ?: throw LlmException("Empty response")
        val sb = StringBuilder()
        for (i in 0 until content.length()) {
            val o = content.getJSONObject(i)
            if (o.optString("type") == "text") sb.append(o.optString("text"))
        }
        val t = sb.toString()
        if (t.isBlank()) throw LlmException("Empty response")
        return t
    }

    private fun openai(base: String, model: String, key: String, system: String, m: List<Msg>): String {
        val arr = JSONArray()
        if (system.isNotBlank()) arr.put(JSONObject().put("role", "system").put("content", system))
        m.forEach { arr.put(JSONObject().put("role", it.role).put("content", it.text)) }
        val b = JSONObject().put("model", model).put("messages", arr)
        val resp = postJson("$base/chat/completions", mapOf("Authorization" to "Bearer $key"), b)
        val t = JSONObject(resp).optJSONArray("choices")?.optJSONObject(0)
            ?.optJSONObject("message")?.optString("content").orEmpty()
        if (t.isBlank() || t == "null") throw LlmException("Empty response")
        return t
    }
}
