package com.webworldbd.sarpai

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import android.util.Base64
import android.util.Size
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

/**
 * Real-time voice conversation with the Gemini Live API (WebSocket).
 * Microphone audio goes up, the model's voice comes down. Phone actions are done through
 * the function `do_on_phone`, which runs the normal agent engine. Camera and screen frames can be streamed too.
 */
object Live {
    val active = MutableStateFlow(false)
    val cameraOn = MutableStateFlow(false)
    val screenOn = MutableStateFlow(false)
    @Volatile var ready = false
        private set
    @Volatile var muted = false
    var onStopped: (() -> Unit)? = null

    private val client: OkHttpClient by lazy {
        Llm.http.newBuilder().readTimeout(0, TimeUnit.MILLISECONDS).pingInterval(20, TimeUnit.SECONDS).build()
    }
    private var ws: WebSocket? = null
    private var scope: CoroutineScope? = null
    private var rec: AudioRecord? = null
    private var track: AudioTrack? = null
    private var micThread: Thread? = null
    private var playThread: Thread? = null
    private val queue = LinkedBlockingQueue<ByteArray>()
    @Volatile private var playEndAt = 0L
    @Volatile private var wantActive = false
    @Volatile private var wasReady = false
    @Volatile private var toolsRunning = 0
    private var attempts = 0
    private val inBuf = StringBuilder()
    private val outBuf = StringBuilder()
    private var savedMode = AudioManager.MODE_NORMAL
    private var savedSpeaker = false

    fun key(): ApiKey? = S.keys.firstOrNull { it.enabled && it.key.isNotBlank() && it.provider == "gemini" }

    /** Returns an error text, or null when the session is starting. */
    @Suppress("DEPRECATION")
    fun start(ctx: Context): String? {
        if (wantActive) return null
        val k = key() ?: return tr("Live voice needs a Gemini API key.", "লাইভ ভয়েসের জন্য Gemini API key লাগবে।")
        if (!Caps.osGranted(ctx, Cap.MIC)) return tr("Microphone permission is missing.", "মাইক্রোফোনের পারমিশন নেই।")
        wantActive = true
        wasReady = false
        attempts = 0
        muted = false
        inBuf.setLength(0)
        outBuf.setLength(0)
        scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
        try {
            val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            savedMode = am.mode
            savedSpeaker = am.isSpeakerphoneOn
            am.mode = AudioManager.MODE_IN_COMMUNICATION
            am.isSpeakerphoneOn = true
        } catch (e: Exception) { }
        startPlayback()
        connect(k)
        active.value = true
        scope?.launch {
            while (isActive) {
                delay(150)
                if (!ready) continue
                val speaking = System.currentTimeMillis() < playEndAt
                Agent.state.value = when {
                    toolsRunning > 0 || Agent.busy.value -> AState.THINKING
                    speaking -> AState.SPEAKING
                    muted -> AState.PAUSED
                    else -> AState.LISTENING
                }
            }
        }
        return null
    }

    @Suppress("DEPRECATION")
    fun stop() {
        wantActive = false
        ready = false
        try { ws?.close(1000, "bye") } catch (e: Exception) { }
        ws = null
        stopMic()
        try { track?.stop() } catch (e: Exception) { }
        try { track?.release() } catch (e: Exception) { }
        track = null
        queue.clear()
        try {
            val am = S.app.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am.isSpeakerphoneOn = savedSpeaker
            am.mode = savedMode
        } catch (e: Exception) { }
        scope?.cancel()
        scope = null
        active.value = false
        cameraOn.value = false
        screenOn.value = false
        LiveCamera.stop()
    }

    // ------------------------------------------------------------ connection

    private fun connect(k: ApiKey) {
        val base = k.baseUrl.ifBlank { Provider.GEMINI.defBase }
        val host = base.removePrefix("https://").removePrefix("http://").trimEnd('/')
        val url = "wss://$host/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent?key=${k.key}"
        ready = false
        ws = client.newWebSocket(Request.Builder().url(url).build(), listener)
    }

    private val listener = object : WebSocketListener() {
        override fun onOpen(webSocket: WebSocket, response: Response) {
            if (webSocket !== ws) return
            webSocket.send(setupJson().toString())
        }

        override fun onMessage(webSocket: WebSocket, text: String) {
            if (webSocket === ws) handle(text)
        }

        override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
            if (webSocket === ws) handle(bytes.utf8())
        }

        override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
            webSocket.close(1000, null)
        }

        override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
            ended(webSocket, "closed $code $reason")
        }

        override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
            ended(webSocket, "${response?.code ?: ""} ${t.message ?: "connection failed"}".trim())
        }
    }

    private fun ended(sock: WebSocket, reason: String) {
        if (sock !== ws) return
        ready = false
        stopMic()
        if (wantActive && wasReady && attempts < 3) {
            attempts++
            Agent.addLog("agent", tr("Live connection dropped, reconnecting…", "লাইভ সংযোগ কেটেছে, আবার যুক্ত হচ্ছি…"))
            scope?.launch {
                delay(800)
                key()?.let { connect(it) }
            }
            return
        }
        Agent.addLog("error", "Live: $reason")
        stop()
        onStopped?.invoke()
    }

    private fun setupJson(): JSONObject {
        val m = S.liveModel.ifBlank { "gemini-3.8-live" }
        val model = if (m.startsWith("models/")) m else "models/$m"
        val voice = if (S.voiceGender == "female") "Kore" else "Charon"
        val gen = JSONObject()
            .put("responseModalities", JSONArray().put("AUDIO"))
            .put(
                "speechConfig", JSONObject().put(
                    "voiceConfig", JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", voice))
                )
            )
        val setup = JSONObject()
            .put("model", model)
            .put("generationConfig", gen)
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", Prompts.liveSystem()))))
            .put("tools", JSONArray().put(JSONObject().put("functionDeclarations", declarations())))
            .put("inputAudioTranscription", JSONObject())
            .put("outputAudioTranscription", JSONObject())
        return JSONObject().put("setup", setup)
    }

    private fun declarations(): JSONArray {
        val doOnPhone = JSONObject()
            .put("name", "do_on_phone")
            .put(
                "description",
                "Do something on the user's phone or fetch information: open or control apps (tap, type, scroll), send SMS or WhatsApp, calls, " +
                    "alarms, timers, reminders, calendar, to-do tasks, flashlight, volume, brightness, settings, files, web search, news, weather, " +
                    "email, notifications, images, GitHub websites. Describe the whole task in one clear English sentence with all details. Returns the result."
            )
            .put(
                "parameters", JSONObject().put("type", "OBJECT").put(
                    "properties", JSONObject().put(
                        "task", JSONObject().put("type", "STRING").put("description", "The complete task in plain English, with names, numbers, text and times.")
                    )
                ).put("required", JSONArray().put("task"))
            )
        val remember = JSONObject()
            .put("name", "remember")
            .put("description", "Save an important fact about the user to long-term memory.")
            .put(
                "parameters", JSONObject().put("type", "OBJECT").put(
                    "properties", JSONObject().put("text", JSONObject().put("type", "STRING"))
                ).put("required", JSONArray().put("text"))
            )
        val getTime = JSONObject().put("name", "get_time").put("description", "Get the current local date and time.")
        return JSONArray().put(doOnPhone).put(remember).put(getTime)
    }

    // ------------------------------------------------------------ incoming messages

    private fun handle(text: String) {
        val j = try { JSONObject(text) } catch (e: Exception) { return }
        if (j.has("setupComplete")) {
            ready = true
            wasReady = true
            attempts = 0
            startMic()
            Agent.addLog("agent", tr("Live voice is ready. Talk to me.", "লাইভ ভয়েস প্রস্তুত। কথা বলুন।"))
            return
        }
        val sc = j.optJSONObject("serverContent")
        if (sc != null) {
            val parts = sc.optJSONObject("modelTurn")?.optJSONArray("parts")
            if (parts != null) {
                for (i in 0 until parts.length()) {
                    val inl = parts.optJSONObject(i)?.optJSONObject("inlineData") ?: continue
                    if (inl.optString("mimeType").startsWith("audio/")) {
                        val pcm = Base64.decode(inl.optString("data"), Base64.DEFAULT)
                        enqueue(pcm)
                    }
                }
            }
            sc.optJSONObject("inputTranscription")?.optString("text")?.let { inBuf.append(it) }
            sc.optJSONObject("outputTranscription")?.optString("text")?.let { outBuf.append(it) }
            if (sc.optBoolean("interrupted")) {
                clearPlayback()
                flushTranscripts()
            }
            if (sc.optBoolean("turnComplete")) flushTranscripts()
        }
        j.optJSONObject("toolCall")?.let { handleToolCall(it) }
        if (j.has("goAway")) Agent.addLog("agent", tr("Live session will refresh soon.", "লাইভ সেশন শিগগিরই নতুন হবে।"))
    }

    private fun flushTranscripts() {
        val u = inBuf.toString().trim()
        val a = outBuf.toString().trim()
        inBuf.setLength(0)
        outBuf.setLength(0)
        if (u.isNotEmpty()) Agent.addLog("user", u)
        if (a.isNotEmpty()) Agent.addLog("agent", a)
    }

    private fun handleToolCall(tc: JSONObject) {
        val calls = tc.optJSONArray("functionCalls") ?: return
        for (i in 0 until calls.length()) {
            val c = calls.getJSONObject(i)
            val id = c.optString("id")
            val name = c.optString("name")
            val args = c.optJSONObject("args") ?: JSONObject()
            scope?.launch {
                toolsRunning++
                val result = try {
                    runTool(name, args)
                } catch (e: Exception) {
                    "ERROR: ${e.message}"
                } finally {
                    toolsRunning--
                }
                val resp = JSONObject().put(
                    "toolResponse", JSONObject().put(
                        "functionResponses", JSONArray().put(
                            JSONObject().put("id", id).put("name", name).put("response", JSONObject().put("result", result))
                        )
                    )
                )
                ws?.send(resp.toString())
            }
        }
    }

    private suspend fun runTool(name: String, args: JSONObject): String = when (name) {
        "do_on_phone" -> {
            val task = args.optString("task")
            if (task.isBlank()) "ERROR: task is empty" else withTimeoutOrNull(120_000) { withContext(Dispatchers.Main) { Agent.runForLive(task) } }
                ?: "The task is still running; check the Agent tab for the result."
        }
        "remember" -> {
            val t = args.optString("text")
            if (t.isBlank()) "ERROR: text is empty" else { MemoryStore.add("memory", "", t); "Saved to memory." }
        }
        "get_time" -> SimpleDateFormat("EEEE, d MMMM yyyy, HH:mm", Locale.ENGLISH).format(Date())
        else -> "ERROR: unknown function $name"
    }

    // ------------------------------------------------------------ audio

    private fun startPlayback() {
        val minBuf = AudioTrack.getMinBufferSize(24000, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
            )
            .setAudioFormat(
                AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(24000).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
            )
            .setBufferSizeInBytes(maxOf(minBuf, 48000))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        track = t
        t.play()
        queue.clear()
        playThread = Thread {
            while (wantActive) {
                val b = queue.poll(200, TimeUnit.MILLISECONDS) ?: continue
                try { t.write(b, 0, b.size) } catch (e: Exception) { }
            }
        }.also { it.isDaemon = true; it.start() }
    }

    private fun enqueue(pcm: ByteArray) {
        queue.offer(pcm)
        val durMs = pcm.size / 48L
        playEndAt = maxOf(System.currentTimeMillis(), playEndAt) + durMs
    }

    private fun clearPlayback() {
        queue.clear()
        playEndAt = 0L
        try {
            track?.pause()
            track?.flush()
            track?.play()
        } catch (e: Exception) { }
    }

    /** Stop the assistant talking right now (used by the on-screen button). */
    fun interrupt() = clearPlayback()

    private fun startMic() {
        stopMic()
        val minBuf = AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val r = try {
            AudioRecord(
                MediaRecorder.AudioSource.VOICE_COMMUNICATION, 16000,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuf, 6400)
            )
        } catch (e: Exception) {
            Agent.addLog("error", "Microphone error: ${e.message}")
            return
        }
        if (r.state != AudioRecord.STATE_INITIALIZED) {
            Agent.addLog("error", tr("Microphone could not start.", "মাইক্রোফোন চালু হয়নি।"))
            r.release()
            return
        }
        try { if (AcousticEchoCanceler.isAvailable()) AcousticEchoCanceler.create(r.audioSessionId)?.setEnabled(true) } catch (e: Exception) { }
        try { if (NoiseSuppressor.isAvailable()) NoiseSuppressor.create(r.audioSessionId)?.setEnabled(true) } catch (e: Exception) { }
        rec = r
        r.startRecording()
        micThread = Thread {
            val buf = ByteArray(3200)
            while (wantActive && rec === r) {
                val n = r.read(buf, 0, buf.size)
                if (n < 0) break
                if (n == 0 || muted || !ready) continue
                if (!S.liveBargeIn && System.currentTimeMillis() < playEndAt + 350) continue
                val b64 = Base64.encodeToString(buf, 0, n, Base64.NO_WRAP)
                ws?.send("{\"realtimeInput\":{\"audio\":{\"data\":\"$b64\",\"mimeType\":\"audio/pcm;rate=16000\"}}}")
            }
        }.also { it.isDaemon = true; it.start() }
    }

    private fun stopMic() {
        val r = rec
        rec = null
        if (r != null) {
            try { r.stop() } catch (e: Exception) { }
            try { r.release() } catch (e: Exception) { }
        }
    }

    // ------------------------------------------------------------ camera / screen frames

    fun sendFrame(jpeg: ByteArray) {
        if (!ready) return
        val b64 = Base64.encodeToString(jpeg, Base64.NO_WRAP)
        ws?.send("{\"realtimeInput\":{\"video\":{\"data\":\"$b64\",\"mimeType\":\"image/jpeg\"}}}")
    }

    fun setScreenShare(on: Boolean) {
        screenOn.value = on
        if (!on) return
        scope?.launch {
            while (isActive && screenOn.value) {
                if (ready) {
                    val svc = AgentAccessibilityService.instance
                    if (svc == null || !Caps.allowed(S.app, Cap.SCREEN)) {
                        Agent.addLog("error", tr("Screen sharing needs Screen control permission.", "স্ক্রিন শেয়ারের জন্য স্ক্রিন কন্ট্রোল পারমিশন লাগবে।"))
                        screenOn.value = false
                        break
                    }
                    val blocked = Guard.hit(svc.currentLabel() + " " + (svc.currentPackage() ?: ""))
                    if (blocked == null) {
                        val jpeg = svc.screenshotJpeg(800)
                        if (jpeg != null) sendFrame(jpeg)
                    }
                }
                delay(2500)
            }
        }
    }

    // ------------------------------------------------------------ connection test

    suspend fun test(): String = withContext(Dispatchers.IO) {
        val k = key() ?: return@withContext "✗ ${tr("Gemini key missing", "Gemini key নেই")}"
        val d = CompletableDeferred<String>()
        val base = k.baseUrl.ifBlank { Provider.GEMINI.defBase }
        val host = base.removePrefix("https://").removePrefix("http://").trimEnd('/')
        val url = "wss://$host/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent?key=${k.key}"
        val sock = client.newWebSocket(Request.Builder().url(url).build(), object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                webSocket.send(setupJson().toString())
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                d.complete(if (text.contains("setupComplete")) "✓ OK" else "✗ ${text.take(200)}")
            }

            override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
                val t = bytes.utf8()
                d.complete(if (t.contains("setupComplete")) "✓ OK" else "✗ ${t.take(200)}")
            }

            override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                d.complete("✗ $code $reason")
                webSocket.close(1000, null)
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                d.complete("✗ ${response?.code ?: ""} ${t.message ?: "failed"}".replace("  ", " "))
            }
        })
        val r = withTimeoutOrNull(12_000) { d.await() } ?: "✗ timeout"
        try { sock.close(1000, null) } catch (e: Exception) { }
        r
    }
}

/** Streams camera frames (about one per second) to the live session. Works while the app is on screen. */
object LiveCamera {
    private var provider: ProcessCameraProvider? = null
    private val executor = Executors.newSingleThreadExecutor()
    @Volatile private var lastSent = 0L

    fun start(ctx: Context, owner: LifecycleOwner, front: Boolean, onError: (String) -> Unit) {
        val future = ProcessCameraProvider.getInstance(ctx)
        future.addListener({
            try {
                val p = future.get()
                provider = p
                val analysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .setTargetResolution(Size(640, 480))
                    .build()
                analysis.setAnalyzer(executor) { img ->
                    val now = System.currentTimeMillis()
                    if (now - lastSent >= 1000 && Live.ready) {
                        lastSent = now
                        try {
                            val bmp = img.toBitmap()
                            val m = Matrix()
                            m.postRotate(img.imageInfo.rotationDegrees.toFloat())
                            val rot = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
                            val bos = ByteArrayOutputStream()
                            rot.compress(Bitmap.CompressFormat.JPEG, 65, bos)
                            Live.sendFrame(bos.toByteArray())
                        } catch (e: Exception) { }
                    }
                    img.close()
                }
                p.unbindAll()
                p.bindToLifecycle(
                    owner,
                    if (front) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA,
                    analysis
                )
                Live.cameraOn.value = true
            } catch (e: Exception) {
                Live.cameraOn.value = false
                onError(e.message ?: "camera error")
            }
        }, ContextCompat.getMainExecutor(ctx))
    }

    fun stop() {
        try { provider?.unbindAll() } catch (e: Exception) { }
        Live.cameraOn.value = false
    }
}
