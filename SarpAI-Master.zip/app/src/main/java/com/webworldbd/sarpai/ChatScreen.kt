@file:OptIn(ExperimentalMaterial3Api::class)

package com.webworldbd.sarpai

import android.app.Activity
import android.content.Intent
import android.provider.OpenableColumns
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private fun skillChips(): List<Pair<String, String>> = listOf(
    tr("Facebook post", "Facebook পোস্ট") to tr("Write an engaging Facebook post about: ", "একটি আকর্ষণীয় Facebook পোস্ট লিখুন, বিষয়: "),
    tr("YouTube script", "YouTube স্ক্রিপ্ট") to tr("Write a YouTube video script, title, description and hashtags about: ", "YouTube ভিডিওর স্ক্রিপ্ট, Title, Description ও Hashtag লিখুন, বিষয়: "),
    tr("Translate", "অনুবাদ") to tr("Translate this (Bangla <-> English): ", "এটি অনুবাদ করুন (বাংলা <-> ইংরেজি): "),
    tr("Summarize", "সারাংশ") to tr("Summarize this briefly: ", "সংক্ষেপে সারাংশ লিখুন: "),
    tr("Solve maths", "অঙ্ক সমাধান") to tr("Solve step by step: ", "ধাপে ধাপে সমাধান করুন: "),
    tr("MCQ", "MCQ") to tr("Make 10 MCQs with answers on: ", "এই বিষয়ে উত্তরসহ ১০টি MCQ বানান: "),
    tr("Exam plan", "পরীক্ষার প্ল্যান") to tr("Make an exam preparation plan. Subjects and dates: ", "পরীক্ষার প্রস্তুতির পরিকল্পনা বানান। বিষয় ও তারিখ: "),
    tr("Email", "ইমেইল") to tr("Write a professional email: ", "একটি পেশাদার ইমেইল লিখুন: "),
    tr("Travel plan", "ভ্রমণ প্ল্যান") to tr("Plan a trip. Destination, days and budget: ", "ভ্রমণ পরিকল্পনা করুন। গন্তব্য, দিন ও বাজেট: "),
    tr("Quiz me", "কুইজ") to tr("Give me a fun quiz.", "আমাকে একটি মজার কুইজ দিন।")
)

@Composable
fun ChatScreen() {
    val ctx = LocalContext.current
    val msgs by ChatStore.messages.collectAsState()
    val sending by ChatStore.sending.collectAsState()
    var input by remember { mutableStateOf("") }
    var plus by remember { mutableStateOf(false) }
    val ls = rememberLazyListState()
    val scope = rememberCoroutineScope()

    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val t = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (r.resultCode == Activity.RESULT_OK && !t.isNullOrBlank()) ChatStore.send(t, true)
    }

    val pickPhoto = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            scope.launch {
                val jpeg = withContext(Dispatchers.IO) {
                    try {
                        ctx.contentResolver.openInputStream(uri)?.use { Media.toJpeg(it.readBytes()) }
                    } catch (e: Exception) { null }
                }
                if (jpeg != null) {
                    ChatStore.sendImage(input, jpeg, false)
                    input = ""
                }
            }
        }
    }

    val pickFile = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                val pair = withContext(Dispatchers.IO) {
                    try {
                        var name = "file"
                        ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
                            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                            if (i >= 0 && c.moveToFirst()) name = c.getString(i) ?: "file"
                        }
                        val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                        if (bytes == null || bytes.size > 30_000_000) null else name to FileTools.extract(name, bytes)
                    } catch (e: Exception) { null }
                }
                if (pair == null) {
                    Toast.makeText(ctx, tr("Could not read the file", "ফাইল পড়া যায়নি"), Toast.LENGTH_SHORT).show()
                } else {
                    ChatStore.sendFile(pair.first, pair.second, input)
                    input = ""
                }
            }
        }
    }

    LaunchedEffect(msgs.size) {
        if (msgs.isNotEmpty()) ls.animateScrollToItem(msgs.lastIndex)
    }

    Column(Modifier.fillMaxSize()) {
        ChatHeader()
        if (msgs.isEmpty()) {
            Column(
                Modifier.weight(1f).fillMaxWidth().padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
            ) {
                Image(painterResource(R.drawable.logo), null, Modifier.size(84.dp))
                Text(
                    tr("Ask me anything", "যা খুশি জিজ্ঞেস করুন"),
                    style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 10.dp)
                )
                Text(
                    tr("Tap a skill, or attach a photo / PDF / Word / Excel file with the + button.", "একটি স্কিল চাপুন, অথবা + বাটন দিয়ে ছবি / PDF / Word / Excel ফাইল যোগ করুন।"),
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 4.dp, bottom = 14.dp)
                )
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    skillChips().forEach { (label, template) ->
                        OutlinedButton(onClick = { input = template }) { Text(label) }
                    }
                }
            }
        } else {
            LazyColumn(
                state = ls, modifier = Modifier.weight(1f).fillMaxWidth(),
                contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(msgs) { m -> Bubble(m) }
            }
        }
        if (sending) LinearProgressIndicator(Modifier.fillMaxWidth())
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Box {
                IconButton(onClick = { plus = true }) {
                    Icon(Icons.Filled.Add, tr("Attach", "যোগ করুন"), tint = MaterialTheme.colorScheme.primary)
                }
                DropdownMenu(expanded = plus, onDismissRequest = { plus = false }) {
                    DropdownMenuItem(
                        text = { Text(tr("Photo from gallery", "গ্যালারির ছবি")) },
                        leadingIcon = { Icon(Icons.Filled.PhotoLibrary, null) },
                        onClick = { plus = false; pickPhoto.launch("image/*") }
                    )
                    DropdownMenuItem(
                        text = { Text(tr("Take a photo", "ছবি তুলুন")) },
                        leadingIcon = { Icon(Icons.Filled.CameraAlt, null) },
                        onClick = {
                            plus = false
                            if (!Caps.osGranted(ctx, Cap.CAMERA)) {
                                Toast.makeText(ctx, tr("Grant Camera in Settings > Permissions", "সেটিংস > পারমিশনে ক্যামেরা দিন"), Toast.LENGTH_LONG).show()
                            } else {
                                scope.launch {
                                    val jpeg = CameraCaptureActivity.capture(ctx)
                                    if (jpeg != null) { ChatStore.sendImage(input, jpeg, false); input = "" }
                                }
                            }
                        }
                    )
                    DropdownMenuItem(
                        text = { Text(tr("File (PDF, Word, Excel, text)", "ফাইল (PDF, Word, Excel, টেক্সট)")) },
                        leadingIcon = { Icon(Icons.Filled.AttachFile, null) },
                        onClick = {
                            plus = false
                            pickFile.launch(
                                arrayOf(
                                    "application/pdf",
                                    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                                    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                                    "text/*", "image/*", "application/json"
                                )
                            )
                        }
                    )
                }
            }
            OutlinedTextField(
                value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f),
                placeholder = { Text(tr("Message…", "মেসেজ লিখুন…")) }, maxLines = 5,
                shape = RoundedCornerShape(24.dp)
            )
            IconButton(onClick = {
                val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE, S.inputLang)
                try { micLauncher.launch(i) } catch (e: Exception) {
                    Toast.makeText(ctx, tr("Voice input not available", "ভয়েস ইনপুট পাওয়া যাচ্ছে না"), Toast.LENGTH_SHORT).show()
                }
            }) { Icon(Icons.Filled.Mic, tr("Voice", "ভয়েস"), tint = MaterialTheme.colorScheme.primary) }
            IconButton(onClick = {
                if (input.isNotBlank()) {
                    ChatStore.send(input, false)
                    input = ""
                }
            }, enabled = !sending) { Icon(Icons.AutoMirrored.Filled.Send, tr("Send", "পাঠান"), tint = MaterialTheme.colorScheme.primary) }
        }
    }
}

@Composable
private fun ChatHeader() {
    var open by remember { mutableStateOf(false) }
    val cur = S.keys.firstOrNull { it.id == S.routing }?.title ?: tr("Auto", "অটো")
    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Image(painterResource(R.drawable.logo), null, Modifier.size(30.dp))
        Text("  ${S.soulName.ifBlank { "SARP" }}", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
        Box {
            TextButton(onClick = { open = true }) { Text("AI: $cur") }
            DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                DropdownMenuItem(
                    text = { Text(tr("Auto (best AI for the task)", "অটো (কাজ অনুযায়ী সেরা AI)")) },
                    onClick = { S.routing = "auto"; S.save(); open = false }
                )
                S.keys.forEach { k ->
                    DropdownMenuItem(
                        text = { Text("${k.title} · ${Provider.of(k.provider).label}") },
                        onClick = { S.routing = k.id; S.save(); open = false }
                    )
                }
            }
        }
        IconButton(onClick = { ChatStore.clear() }) { Icon(Icons.Filled.Delete, tr("Clear", "মুছুন")) }
    }
}

@Composable
private fun Bubble(m: ChatMsg) {
    val isUser = m.role == "user"
    val err = m.role == "error"
    val cs = MaterialTheme.colorScheme
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start) {
        Column(
            horizontalAlignment = if (isUser) Alignment.End else Alignment.Start,
            modifier = Modifier.widthIn(max = 330.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = when {
                    err -> cs.errorContainer
                    isUser -> cs.primaryContainer
                    else -> cs.surfaceVariant
                }
            ) {
                SelectionContainer {
                    Text(
                        m.text, modifier = Modifier.padding(12.dp),
                        color = when {
                            err -> cs.onErrorContainer
                            isUser -> cs.onPrimaryContainer
                            else -> cs.onSurface
                        }
                    )
                }
            }
            if (m.via.isNotBlank()) {
                Text(
                    m.via, style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
            }
        }
    }
}
