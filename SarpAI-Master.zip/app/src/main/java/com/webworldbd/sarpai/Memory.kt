package com.webworldbd.sarpai

import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class MemoryItem(val id: String, val kind: String, val title: String, val text: String, val time: Long)
data class TaskItem(val id: String, val text: String, val done: Boolean, val time: Long)

/** Things the assistant remembers about the user (encrypted on this phone). */
object MemoryStore {
    val items = MutableStateFlow<List<MemoryItem>>(emptyList())

    fun load() {
        try {
            val arr = JSONArray(S.getSecure("memory_items").ifBlank { "[]" })
            val l = mutableListOf<MemoryItem>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                l.add(MemoryItem(o.getString("id"), o.optString("kind", "memory"), o.optString("title"), o.optString("text"), o.optLong("time")))
            }
            items.value = l
        } catch (e: Exception) { }
    }

    private fun persist() {
        val arr = JSONArray()
        items.value.forEach {
            arr.put(JSONObject().put("id", it.id).put("kind", it.kind).put("title", it.title).put("text", it.text).put("time", it.time))
        }
        S.putSecure("memory_items", arr.toString())
    }

    fun add(kind: String, title: String, text: String): MemoryItem {
        val m = MemoryItem(UUID.randomUUID().toString().take(8), kind, title.trim(), text.trim(), System.currentTimeMillis())
        items.value = (items.value + m).takeLast(300)
        persist()
        return m
    }

    fun remove(id: String) {
        items.value = items.value.filter { it.id != id }
        persist()
    }

    fun forget(query: String): Int {
        val q = query.trim().lowercase()
        if (q.isEmpty()) return 0
        val keep = items.value.filter { !(it.text.lowercase().contains(q) || it.title.lowercase().contains(q)) }
        val n = items.value.size - keep.size
        items.value = keep
        persist()
        return n
    }

    fun clear() {
        items.value = emptyList()
        persist()
    }

    fun promptBlock(): String {
        val l = items.value.takeLast(40)
        if (l.isEmpty()) return "(nothing yet)"
        return l.joinToString("\n") { m ->
            "- [" + m.kind + "] " + (if (m.title.isNotBlank()) m.title + ": " else "") + m.text.take(300)
        }
    }
}

/** The to-do list shown on the home screen. */
object TaskStore {
    val items = MutableStateFlow<List<TaskItem>>(emptyList())

    fun load() {
        try {
            val arr = JSONArray(S.getSecure("task_items").ifBlank { "[]" })
            val l = mutableListOf<TaskItem>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                l.add(TaskItem(o.getString("id"), o.optString("text"), o.optBoolean("done"), o.optLong("time")))
            }
            items.value = l
        } catch (e: Exception) { }
    }

    private fun persist() {
        val arr = JSONArray()
        items.value.forEach {
            arr.put(JSONObject().put("id", it.id).put("text", it.text).put("done", it.done).put("time", it.time))
        }
        S.putSecure("task_items", arr.toString())
    }

    fun add(text: String) {
        val t = text.trim()
        if (t.isEmpty()) return
        items.value = (items.value + TaskItem(UUID.randomUUID().toString().take(8), t, false, System.currentTimeMillis())).takeLast(200)
        persist()
    }

    fun toggle(id: String) {
        items.value = items.value.map { if (it.id == id) it.copy(done = !it.done) else it }
        persist()
    }

    fun complete(query: String): Boolean {
        val q = query.trim().lowercase()
        if (q.isEmpty()) return false
        var hit = false
        items.value = items.value.map {
            if (!hit && !it.done && it.text.lowercase().contains(q)) { hit = true; it.copy(done = true) } else it
        }
        if (hit) persist()
        return hit
    }

    fun remove(id: String) {
        items.value = items.value.filter { it.id != id }
        persist()
    }

    fun clear() {
        items.value = emptyList()
        persist()
    }

    fun promptBlock(): String {
        val l = items.value.takeLast(30)
        if (l.isEmpty()) return "(empty)"
        return l.joinToString("\n") { (if (it.done) "[x] " else "[ ] ") + it.text }
    }
}
