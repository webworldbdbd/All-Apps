@file:OptIn(ExperimentalMaterial3Api::class)

package com.webworldbd.sarpai

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.Request
import org.json.JSONObject
import java.util.UUID

@Composable
fun SettingsScreen(page: String, setPage: (String) -> Unit) {
    BackHandler(enabled = page != "") { setPage("") }
    if (page == "") {
        SettingsMenu(setPage)
        return
    }
    val title = when (page) {
        "keys" -> tr("API Keys", "API Keys")
        "routing" -> tr("AI selection", "AI নির্বাচন")
        "voice" -> tr("Voice", "ভয়েস")
        "look" -> tr("Language & Theme", "ভাষা ও থিম")
        "safety" -> tr("Safety & Rules", "নিরাপত্তা ও নিষেধাজ্ঞা")
        "bio" -> tr("Biodata", "বায়োডাটা")
        "perms" -> tr("Permissions", "পারমিশন সেন্টার")
        "integ" -> tr("Integrations", "ইন্টিগ্রেশন")
        "soul" -> tr("Soul (personality)", "Soul (ব্যক্তিত্ব)")
        "memory" -> tr("Memory, Notes & Tasks", "মেমরি, নোট ও কাজ")
        else -> tr("About", "অ্যাপ সম্পর্কে")
    }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { setPage("") }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) }
            Text(title, style = MaterialTheme.typography.titleLarge)
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 4.dp)) {
            when (page) {
                "keys" -> KeysPage()
                "routing" -> RoutingPage()
                "voice" -> VoicePage()
                "look" -> LookPage()
                "safety" -> SafetyPage()
                "bio" -> BioPage()
                "perms" -> PermsPage()
                "integ" -> IntegPage()
                "soul" -> SoulPage()
                "memory" -> MemoryPage()
                else -> AboutPage()
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun SettingsMenu(setPage: (String) -> Unit) {
    data class Item(val page: String, val icon: ImageVector, val title: String, val sub: String)
    val items = listOf(
        Item("keys", Icons.Filled.Key, tr("API Keys", "API Keys"), tr("Add up to 5 keys (Gemini, OpenAI, Claude…)", "সর্বোচ্চ ৫টি key (Gemini, OpenAI, Claude…)")),
        Item("routing", Icons.Filled.Tune, tr("AI selection", "AI নির্বাচন"), tr("Auto-pick the best AI or choose one", "অটো সেরা AI অথবা নিজে বাছুন")),
        Item("voice", Icons.Filled.RecordVoiceOver, tr("Voice", "ভয়েস"), tr("Male / female, phone or AI voice, wake word", "মেল/ফিমেল, ফোন বা AI ভয়েস, ওয়েক ওয়ার্ড")),
        Item("look", Icons.Filled.DarkMode, tr("Language & Theme", "ভাষা ও থিম"), tr("Bangla / English, Light / Dark / System", "বাংলা / English, লাইট / ডার্ক / সিস্টেম")),
        Item("safety", Icons.Filled.Shield, tr("Safety & Rules", "নিরাপত্তা ও নিষেধাজ্ঞা"), tr("What the agent must never do", "এজেন্ট যা কখনো করবে না")),
        Item("soul", Icons.Filled.Face, tr("Soul (personality)", "Soul (ব্যক্তিত্ব)"), tr("Name and speaking style of your assistant", "এজেন্টের নাম ও কথা বলার ধরন")),
        Item("memory", Icons.Filled.Memory, tr("Memory, Notes & Tasks", "মেমরি, নোট ও কাজ"), tr("What the assistant remembers; delete anytime", "এজেন্ট কী মনে রেখেছে; যেকোনো সময় মুছুন")),
        Item("bio", Icons.Filled.Person, tr("Biodata", "বায়োডাটা"), tr("Tell the agent about yourself", "এজেন্টকে আপনার সম্পর্কে জানান")),
        Item("perms", Icons.Filled.Lock, tr("Permissions", "পারমিশন সেন্টার"), tr("Grant each access separately", "প্রতিটি অ্যাক্সেস আলাদাভাবে দিন")),
        Item("integ", Icons.Filled.Code, tr("Integrations", "ইন্টিগ্রেশন"), tr("GitHub token for building & hosting sites", "ওয়েবসাইট বানাতে ও হোস্ট করতে GitHub token")),
        Item("about", Icons.Filled.Info, tr("About", "অ্যাপ সম্পর্কে"), "SARP AI 1.0.0")
    )
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp)) {
        Text(tr("Settings", "সেটিংস"), style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(bottom = 8.dp))
        items.forEach { it ->
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable { setPage(it.page) }
            ) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(it.icon, null, tint = MaterialTheme.colorScheme.primary)
                    Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
                        Text(it.title, style = MaterialTheme.typography.titleMedium)
                        Text(it.sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Icon(Icons.Filled.KeyboardArrowRight, null)
                }
            }
        }
    }
}

// ------------------------------------------------------------------ API keys

@Composable
private fun KeysPage() {
    var editing by remember { mutableStateOf<ApiKey?>(null) }
    var adding by remember { mutableStateOf(false) }
    val results = remember { mutableStateMapOf<String, String>() }
    val scope = rememberCoroutineScope()

    Text(
        tr(
            "Keys are stored encrypted on this phone only. Add 1 to 5 keys. With one key it does everything; with several, the app picks the best one for each job automatically.",
            "key গুলো শুধু এই ফোনে এনক্রিপ্ট করে রাখা হয়। ১ থেকে ৫টি key দিন। একটি থাকলে সে-ই সব করবে; একাধিক থাকলে অ্যাপ নিজে কাজ অনুযায়ী সেরাটি বেছে নেবে।"
        ),
        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
    )
    Spacer(Modifier.height(8.dp))
    S.keys.toList().forEach { k ->
        SCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(k.title, style = MaterialTheme.typography.titleMedium)
                    Text(
                        "${Provider.of(k.provider).label} · ${k.model.ifBlank { Provider.of(k.provider).defModel }}",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        if (k.key.length > 8) k.key.take(4) + "••••" + k.key.takeLast(4) else "••••",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                Switch(checked = k.enabled, onCheckedChange = { on ->
                    val i = S.keys.indexOfFirst { it.id == k.id }
                    if (i >= 0) { S.keys[i] = k.copy(enabled = on); S.saveKeys() }
                })
            }
            Row {
                TextButton(onClick = {
                    scope.launch {
                        results[k.id] = "…"
                        results[k.id] = try { "✓ " + Llm.test(k) } catch (e: Exception) { "✗ " + (e.message ?: "error") }
                    }
                }) { Text(tr("Test", "টেস্ট")) }
                TextButton(onClick = { editing = k }) { Text(tr("Edit", "এডিট")) }
                TextButton(onClick = { S.keys.removeAll { it.id == k.id }; S.saveKeys() }) { Text(tr("Delete", "মুছুন")) }
            }
            results[k.id]?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
        }
    }
    Button(onClick = { adding = true }, enabled = S.keys.size < S.MAX_KEYS, modifier = Modifier.padding(top = 8.dp)) {
        Text(tr("Add API key", "API key যোগ করুন") + " (${S.keys.size}/${S.MAX_KEYS})")
    }
    if (adding || editing != null) {
        KeyDialog(
            existing = editing,
            onDismiss = { adding = false; editing = null },
            onSave = { nk ->
                val i = S.keys.indexOfFirst { it.id == nk.id }
                if (i >= 0) S.keys[i] = nk else S.keys.add(nk)
                S.saveKeys()
                adding = false; editing = null
            }
        )
    }
}

@Composable
private fun KeyDialog(existing: ApiKey?, onDismiss: () -> Unit, onSave: (ApiKey) -> Unit) {
    var title by remember { mutableStateOf(existing?.title ?: "") }
    var provider by remember { mutableStateOf(existing?.provider ?: Provider.GEMINI.id) }
    var key by remember { mutableStateOf(existing?.key ?: "") }
    var model by remember { mutableStateOf(existing?.model ?: Provider.GEMINI.defModel) }
    var base by remember { mutableStateOf(existing?.baseUrl ?: "") }
    var show by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    val p = Provider.of(provider)

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) tr("Add API key", "API key যোগ করুন") else tr("Edit API key", "API key এডিট")) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(title, { title = it }, label = { Text(tr("Title (e.g. My Gemini)", "টাইটেল (যেমন: আমার Gemini)")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Box {
                    OutlinedButton(onClick = { menu = true }, modifier = Modifier.fillMaxWidth()) { Text(p.label) }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        Provider.values().forEach { np ->
                            DropdownMenuItem(text = { Text(np.label) }, onClick = {
                                if (model.isBlank() || model == Provider.of(provider).defModel) model = np.defModel
                                provider = np.id
                                menu = false
                            })
                        }
                    }
                }
                OutlinedTextField(
                    key, { key = it }, label = { Text("API key") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                    visualTransformation = if (show) VisualTransformation.None else PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    trailingIcon = {
                        IconButton(onClick = { show = !show }) {
                            Icon(if (show) Icons.Filled.VisibilityOff else Icons.Filled.Visibility, null)
                        }
                    }
                )
                OutlinedTextField(model, { model = it }, label = { Text(tr("Model name", "মডেলের নাম")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                if (p == Provider.CUSTOM || base.isNotBlank()) {
                    OutlinedTextField(base, { base = it }, label = { Text("Base URL (OpenAI-compatible, ends with /v1)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                }
                Text(
                    tr("Model names change over time. If a test fails, check the model name on the provider's site.", "মডেলের নাম সময়ের সাথে বদলায়। টেস্ট ব্যর্থ হলে প্রোভাইডারের সাইটে মডেলের নাম দেখে নিন।"),
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        confirmButton = {
            TextButton(
                enabled = key.isNotBlank() && (p != Provider.CUSTOM || base.isNotBlank()),
                onClick = {
                    onSave(
                        ApiKey(
                            existing?.id ?: UUID.randomUUID().toString().take(8),
                            title.ifBlank { p.label }, provider, key.trim(), model.trim(), base.trim(),
                            existing?.enabled ?: true
                        )
                    )
                }
            ) { Text(tr("Save", "সেভ")) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("Cancel", "বাতিল")) } }
    )
}

// ------------------------------------------------------------------ routing

@Composable
private fun RoutingPage() {
    Text(
        tr(
            "Auto picks the best AI for every job and switches to another key if one fails or runs out of limit.",
            "Auto প্রতিটি কাজের জন্য সেরা AI বেছে নেয়, আর কোনো key ব্যর্থ হলে বা লিমিট শেষ হলে অন্য key-তে চলে যায়।"
        ),
        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
    )
    Spacer(Modifier.height(8.dp))
    @Composable
    fun Opt(id: String, label: String) {
        Row(
            Modifier.fillMaxWidth().clickable { S.routing = id; S.save() }.padding(vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            RadioButton(selected = S.routing == id, onClick = { S.routing = id; S.save() })
            Text(label)
        }
    }
    Opt("auto", tr("Auto (recommended)", "Auto (প্রস্তাবিত)"))
    S.keys.forEach { Opt(it.id, "${it.title} · ${Provider.of(it.provider).label}") }
    SectionTitle(tr("How Auto decides", "Auto কীভাবে বাছে"))
    SCard {
        Text(
            tr(
                "• Coding, websites → Claude\n• Search, news, weather → Gemini\n• Facebook / social content → Llama-type key (Groq / OpenRouter) if added\n• Everything else → ChatGPT, then the rest\n• Only one key added → that key does everything",
                "• কোডিং, ওয়েবসাইট → Claude\n• সার্চ, খবর, আবহাওয়া → Gemini\n• ফেসবুক / সোশ্যাল কনটেন্ট → Llama-ধরনের key (Groq / OpenRouter) থাকলে সেটি\n• বাকি সব → ChatGPT, তারপর অন্যগুলো\n• একটি মাত্র key থাকলে → সেটিই সব করে"
            ),
            style = MaterialTheme.typography.bodyMedium
        )
    }
}

// ------------------------------------------------------------------ voice

@Composable
private fun VoicePage() {
    val scope = rememberCoroutineScope()
    var liveTest by remember { mutableStateOf("") }
    SectionTitle(tr("Voice mode", "ভয়েস মোড"))
    ChipRow(
        listOf(
            "classic" to tr("Classic (listen, think, speak)", "ক্লাসিক (শুনে, ভেবে, বলে)"),
            "live" to tr("Live conversation (Gemini Live)", "লাইভ কথোপকথন (Gemini Live)")
        ),
        S.voiceMode
    ) { S.voiceMode = it; S.save() }
    Text(
        tr(
            "Live talks like a phone call: fast replies, you can talk naturally, and it can see your camera or screen. It needs a Gemini key and uses more of your quota. Classic works with any key.",
            "লাইভ মোডে ফোন কলের মতো দ্রুত কথা বলা যায় এবং এজেন্ট আপনার ক্যামেরা বা স্ক্রিন দেখতে পারে। এর জন্য Gemini key লাগে ও কোটা বেশি খরচ হয়। ক্লাসিক মোড যেকোনো key-তে চলে।"
        ),
        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(top = 6.dp)
    )
    if (S.voiceMode == "live") {
        OutlinedTextField(
            S.liveModel, { S.liveModel = it.trim(); S.save() }, label = { Text(tr("Live model name", "লাইভ মডেলের নাম")) },
            singleLine = true, modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
        )
        SwitchRow(
            tr("Let me interrupt by voice", "কথার মাঝে থামাতে দিন"),
            tr("Turn on only with headphones, otherwise the assistant can hear itself.", "শুধু হেডফোন থাকলে চালু করুন, না হলে এজেন্ট নিজের কথাই শুনে ফেলতে পারে।"),
            S.liveBargeIn
        ) { S.liveBargeIn = it; S.save() }
        OutlinedButton(onClick = { scope.launch { liveTest = "…"; liveTest = Live.test() } }) {
            Text(tr("Test Live connection", "লাইভ সংযোগ টেস্ট"))
        }
        if (liveTest.isNotEmpty()) Text(liveTest, modifier = Modifier.padding(top = 4.dp))
    }
    SectionTitle(tr("Voice of the agent", "এজেন্টের কণ্ঠ"))
    ChipRow(listOf("female" to tr("Female", "মহিলা"), "male" to tr("Male", "পুরুষ")), S.voiceGender) { S.voiceGender = it; S.save() }
    Spacer(Modifier.height(8.dp))
    Text(tr("Voice engine", "ভয়েস ইঞ্জিন"), style = MaterialTheme.typography.labelMedium)
    ChipRow(
        listOf("phone" to tr("Phone voice (free)", "ফোনের ভয়েস (ফ্রি)"), "ai" to tr("AI voice (Gemini / OpenAI key)", "AI ভয়েস (Gemini / OpenAI key)")),
        S.voiceEngine
    ) { S.voiceEngine = it; S.save() }
    Text(
        tr(
            "Phone voice depends on the voices installed on your phone; if no male voice exists the pitch is lowered. AI voice sounds more natural and uses your Gemini or OpenAI key.",
            "ফোনের ভয়েস ফোনে ইনস্টল থাকা কণ্ঠের ওপর নির্ভর করে; পুরুষ কণ্ঠ না থাকলে পিচ কমিয়ে নেওয়া হয়। AI ভয়েস বেশি স্বাভাবিক এবং আপনার Gemini বা OpenAI key ব্যবহার করে।"
        ),
        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(top = 6.dp)
    )
    SwitchRow(tr("Speak replies aloud", "উত্তর জোরে বলবে"), null, S.speakReplies) { S.speakReplies = it; S.save() }
    OutlinedButton(onClick = {
        scope.launch { Speaker.speak(tr("Hello, I am SARP AI.", "হ্যালো, আমি সার্প এআই।")) }
    }) { Text(tr("Test voice", "ভয়েস টেস্ট")) }

    SectionTitle(tr("Listening", "শোনা"))
    Text(tr("Language I listen in", "আমি যে ভাষায় শুনব"), style = MaterialTheme.typography.labelMedium)
    ChipRow(listOf("bn-BD" to "বাংলা", "en-US" to "English"), S.inputLang) { S.inputLang = it; S.save() }
    SwitchRow(
        tr("Wake word", "ওয়েক ওয়ার্ড"),
        tr("Only act when a sentence contains the word (safer: ignores TV and other people).", "বাক্যে শব্দটি থাকলেই কাজ করবে (নিরাপদ: টিভি বা অন্যদের কথা এড়ায়)।"),
        S.wakeWordOn
    ) { S.wakeWordOn = it; S.save() }
    if (S.wakeWordOn) {
        OutlinedTextField(
            S.wakeWords, { S.wakeWords = it; S.save() }, label = { Text(tr("Wake words (comma separated)", "ওয়েক ওয়ার্ড (কমা দিয়ে)")) },
            modifier = Modifier.fillMaxWidth()
        )
    }
}

// ------------------------------------------------------------------ look

@Composable
private fun LookPage() {
    SectionTitle(tr("App language", "অ্যাপের ভাষা"))
    ChipRow(listOf("bn" to "বাংলা", "en" to "English"), S.language) { S.language = it; S.save() }
    SectionTitle(tr("Theme", "থিম"))
    ChipRow(
        listOf("system" to tr("System", "সিস্টেম"), "light" to tr("Light", "লাইট"), "dark" to tr("Dark", "ডার্ক")), S.theme
    ) { S.theme = it; S.save() }
}

// ------------------------------------------------------------------ safety

@Composable
private fun SafetyPage() {
    SwitchRow(
        tr("Ask before sensitive actions", "সংবেদনশীল কাজের আগে জিজ্ঞেস করবে"),
        tr("Send SMS, call, post, delete, pay, upload to GitHub… The agent asks you (voice or button) first.", "এসএমএস, কল, পোস্ট, ডিলিট, পেমেন্ট, GitHub আপলোড… আগে আপনাকে জিজ্ঞেস করবে (ভয়েস বা বাটন)।"),
        S.confirmSensitive
    ) { S.confirmSensitive = it; S.save() }

    SwitchRow(
        tr("Hide OTP codes and passwords from the AI", "OTP কোড ও পাসওয়ার্ড AI-কে দেখাবে না"),
        tr("Codes in notifications, emails and on screen are replaced with [hidden] before they are sent to the AI. Password fields are never read.", "নোটিফিকেশন, ইমেইল ও স্ক্রিনের কোড AI-এর কাছে যাওয়ার আগে [hidden] হয়ে যায়। পাসওয়ার্ড ঘর কখনো পড়া হয় না।"),
        S.hideSecrets
    ) { S.hideSecrets = it; S.save() }

    SectionTitle(tr("Blocked apps & words (hard block)", "নিষিদ্ধ অ্যাপ ও শব্দ (কঠোর ব্লক)"))
    Text(
        tr(
            "One per line. If a command, an action or the app on screen contains any of these, the app itself stops the action — even if you ask for it. Example: bKash.",
            "প্রতি লাইনে একটি। কমান্ড, অ্যাকশন বা স্ক্রিনের অ্যাপে এর কোনোটি থাকলে অ্যাপ নিজেই কাজ থামিয়ে দেয় — আপনি বললেও। যেমন: bKash।"
        ),
        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
    )
    OutlinedTextField(
        S.blocked, { S.blocked = it; S.save() }, modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
        minLines = 3, placeholder = { Text("bkash\nnagad\nbank") }
    )

    SectionTitle(tr("My rules (written instructions)", "আমার নিয়ম (লিখিত নির্দেশ)"))
    Text(
        tr(
            "Free text. The AI must follow these. (For anything critical, also add it to the hard-block list above.)",
            "যেকোনো লেখা। AI এগুলো মানতে বাধ্য। (গুরুত্বপূর্ণ কিছুর জন্য ওপরের কঠোর ব্লক তালিকাতেও দিন।)"
        ),
        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
    )
    OutlinedTextField(
        S.rules, { S.rules = it; S.save() }, modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
        minLines = 4, placeholder = { Text(tr("e.g. Never post on Facebook. Never delete files.", "যেমন: ফেসবুকে কখনো পোস্ট করবে না। কোনো ফাইল ডিলিট করবে না।")) }
    )
}

// ------------------------------------------------------------------ biodata

@Composable
private fun BioPage() {
    Text(
        tr(
            "Write about yourself: name, work, goals, preferences, how you like replies. The agent reads this every time so it does not keep asking you questions.",
            "নিজের সম্পর্কে লিখুন: নাম, কাজ, লক্ষ্য, পছন্দ, কেমন উত্তর চান। এজেন্ট প্রতিবার এটা পড়ে, তাই বারবার প্রশ্ন করবে না।"
        ),
        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
    )
    OutlinedTextField(
        S.biodata, { S.biodata = it; S.save() }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
        minLines = 10
    )
    Text(
        tr(
            "Privacy: this text is sent to the AI company whose key is used. Do not write passwords, ID numbers or bank details.",
            "গোপনীয়তা: এই লেখা আপনার ব্যবহৃত AI কোম্পানির কাছে যায়। পাসওয়ার্ড, আইডি নম্বর বা ব্যাংকের তথ্য লিখবেন না।"
        ),
        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error,
        modifier = Modifier.padding(top = 6.dp)
    )
}

// ------------------------------------------------------------------ permissions

@Composable
private fun PermsPage() {
    val ctx = LocalContext.current
    val tick = rememberResumeTick()
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    fun go(i: Intent) {
        try { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { }
    }

    fun grant(c: Cap) {
        when (c.special) {
            "accessibility" -> go(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            "listener" -> go(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            "overlay" -> go(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}")))
            "battery" -> go(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${ctx.packageName}")))
            "write_settings" -> go(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${ctx.packageName}")))
            "dnd" -> go(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
            "all_files" -> go(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:${ctx.packageName}")))
            "none" -> {}
            else -> c.perm?.let { launcher.launch(it) }
        }
    }

    Text(
        tr(
            "Every access is separate. The agent can use a feature only if Android permission is granted AND the switch here is ON.",
            "প্রতিটি অ্যাক্সেস আলাদা। Android পারমিশন দেওয়া থাকলে এবং এখানকার সুইচ ON থাকলেই এজেন্ট সেটি ব্যবহার করতে পারে।"
        ),
        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
    )
    SCard {
        Text(tr("Screen control is greyed out?", "Screen control বাটন ধূসর (বন্ধ) দেখাচ্ছে?"), style = MaterialTheme.typography.titleSmall)
        Text(
            tr(
                "Android 13+ blocks Accessibility for apps installed from an APK file. Open App info, tap the ⋮ menu (top right) and choose \"Allow restricted settings\". Then enable SARP AI in Accessibility.",
                "Android 13+ এ APK থেকে ইনস্টল করা অ্যাপের Accessibility বন্ধ থাকে। App info খুলুন, ওপরে ডানের ⋮ মেনুতে \"Allow restricted settings\" চাপুন। তারপর Accessibility-তে SARP AI চালু করুন।"
            ),
            style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(vertical = 6.dp)
        )
        OutlinedButton(onClick = {
            go(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}")))
        }) { Text(tr("Open App info", "App info খুলুন")) }
    }
    Cap.values().forEach { c ->
        val granted = remember(tick, c) { Caps.osGranted(ctx, c) }
        var on by remember(c) { mutableStateOf(Caps.enabled(c)) }
        SCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(c.label, style = MaterialTheme.typography.titleSmall)
                    Text(
                        if (granted) tr("Allowed by Android", "Android অনুমতি দিয়েছে") else tr("Not granted", "অনুমতি দেওয়া হয়নি"),
                        style = MaterialTheme.typography.bodySmall,
                        color = if (granted) Color(0xFF22C55E) else MaterialTheme.colorScheme.error
                    )
                }
                if (!granted) {
                    Button(onClick = { grant(c) }) { Text(tr("Grant", "দিন")) }
                } else if (c.toggle) {
                    Switch(checked = on, onCheckedChange = { on = it; S.caps[c.key] = it; S.save() })
                }
            }
        }
    }
}

// ------------------------------------------------------------------ integrations

@Composable
private fun IntegPage() {
    val scope = rememberCoroutineScope()
    var res by remember { mutableStateOf("") }
    var show by remember { mutableStateOf(false) }
    Text(
        tr(
            "To let the agent create repositories, upload code and publish websites on GitHub Pages, add a GitHub personal access token (classic, scope: repo).",
            "এজেন্ট যেন GitHub-এ রিপোজিটরি বানাতে, কোড আপলোড করতে ও GitHub Pages-এ সাইট প্রকাশ করতে পারে, তার জন্য GitHub personal access token (classic, scope: repo) দিন।"
        ),
        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
    )
    OutlinedTextField(
        S.githubToken, { S.githubToken = it.trim(); S.save() }, label = { Text("GitHub token") }, singleLine = true,
        modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
        visualTransformation = if (show) VisualTransformation.None else PasswordVisualTransformation(),
        trailingIcon = {
            IconButton(onClick = { show = !show }) { Icon(if (show) Icons.Filled.VisibilityOff else Icons.Filled.Visibility, null) }
        }
    )
    OutlinedTextField(
        S.githubUser, { S.githubUser = it.trim(); S.save() }, label = { Text(tr("GitHub username (auto-filled on test)", "GitHub username (টেস্টে নিজে ভরে যাবে)")) },
        singleLine = true, modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
    )
    Button(onClick = {
        scope.launch {
            res = "…"
            res = withContext(Dispatchers.IO) {
                try {
                    val req = Request.Builder().url("https://api.github.com/user")
                        .header("Authorization", "Bearer ${S.githubToken}").build()
                    Llm.http.newCall(req).execute().use { r ->
                        if (r.isSuccessful) {
                            val l = JSONObject(r.body?.string().orEmpty()).optString("login")
                            S.githubUser = l
                            S.save()
                            "✓ $l"
                        } else "✗ HTTP ${r.code}"
                    }
                } catch (e: Exception) {
                    "✗ " + (e.message ?: "error")
                }
            }
        }
    }, modifier = Modifier.padding(top = 8.dp)) { Text(tr("Test token", "token টেস্ট")) }
    if (res.isNotEmpty()) Text(res, modifier = Modifier.padding(top = 6.dp))

    SectionTitle(tr("Email (read-only)", "ইমেইল (শুধু পড়া)"))
    Text(
        tr(
            "Gmail: turn on 2-step verification, create an App Password, and use it here (not your normal password). The agent can only read, never send.",
            "Gmail: 2-step verification চালু করে একটি App Password বানান এবং সেটা এখানে দিন (আসল পাসওয়ার্ড নয়)। এজেন্ট শুধু পড়তে পারবে, পাঠাতে পারবে না।"
        ),
        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
    )
    OutlinedTextField(
        S.emailAddress, { S.emailAddress = it.trim(); S.save() }, label = { Text("Email") }, singleLine = true,
        modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
    )
    OutlinedTextField(
        S.emailPassword, { S.emailPassword = it.trim(); S.save() }, label = { Text("App Password") }, singleLine = true,
        visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
    )
    OutlinedTextField(
        S.emailHost, { S.emailHost = it.trim(); S.save() }, label = { Text("IMAP server") }, singleLine = true,
        modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
    )
    var mailRes by remember { mutableStateOf("") }
    Button(onClick = {
        scope.launch {
            mailRes = "…"
            val r = Mail.read(1, false, "")
            mailRes = if (r.startsWith("ERROR")) "✗ $r" else "✓ OK"
        }
    }, modifier = Modifier.padding(top = 8.dp)) { Text(tr("Test email", "ইমেইল টেস্ট")) }
    if (mailRes.isNotEmpty()) Text(mailRes, modifier = Modifier.padding(top = 6.dp))
}

// ------------------------------------------------------------------ about

@Composable
private fun AboutPage() {
    Column(Modifier.fillMaxWidth().padding(top = 24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Image(painterResource(R.drawable.logo), null, Modifier.size(110.dp))
        Text("SARP AI", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(top = 12.dp))
        Text("Version 1.0.0", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text("Powered By WebWorldBD", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 8.dp))
        Text(
            tr(
                "A personal AI agent that works only on your commands. You bring your own API keys.",
                "একটি ব্যক্তিগত AI এজেন্ট যা শুধু আপনার কমান্ডে কাজ করে। API key আপনার নিজের।"
            ),
            style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(top = 16.dp)
        )
    }
}


// ------------------------------------------------------------------ soul

@Composable
private fun SoulPage() {
    Text(
        tr(
            "Give your assistant a name and a personality. It is used in chat, in the agent and in live voice.",
            "আপনার এজেন্টকে একটি নাম ও ব্যক্তিত্ব দিন। এটি চ্যাট, এজেন্ট ও লাইভ ভয়েস, সবখানে ব্যবহার হয়।"
        ),
        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
    )
    OutlinedTextField(
        S.soulName, { S.soulName = it; S.save() }, label = { Text(tr("Assistant name", "এজেন্টের নাম")) },
        singleLine = true, modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
    )
    SectionTitle(tr("Style presets", "স্টাইল প্রিসেট"))
    val keyNow = Prompts.PRESETS.firstOrNull { it.second == S.soul || (S.soul.isBlank() && it.first == "jarvis") }?.first ?: ""
    ChipRow(
        listOf(
            "jarvis" to "Jarvis", "friend" to tr("Friend", "বন্ধু"), "teacher" to tr("Teacher", "শিক্ষক"),
            "pro" to tr("Professional", "প্রফেশনাল"), "funny" to tr("Funny", "মজার")
        ),
        keyNow
    ) { k -> S.soul = Prompts.PRESETS.first { it.first == k }.second; S.save() }
    OutlinedTextField(
        S.soul, { S.soul = it; S.save() }, modifier = Modifier.fillMaxWidth().padding(top = 10.dp), minLines = 5,
        label = { Text(tr("Personality (you can edit)", "ব্যক্তিত্ব (নিজে বদলাতে পারেন)")) },
        placeholder = { Text(Prompts.DEFAULT_SOUL) }
    )
}

// ------------------------------------------------------------------ memory / notes / tasks

@Composable
private fun MemoryPage() {
    val mem by MemoryStore.items.collectAsState()
    val tasks by TaskStore.items.collectAsState()
    var newMem by remember { mutableStateOf("") }
    var newTask by remember { mutableStateOf("") }
    var confirmAll by remember { mutableStateOf(false) }

    Text(
        tr(
            "Everything here is stored encrypted on this phone. It is also sent to your AI provider as context, so do not store secrets. Say \"remember that…\" and the assistant saves it here.",
            "এখানকার সব তথ্য এই ফোনে এনক্রিপ্ট করে রাখা হয়। এগুলো আপনার AI প্রোভাইডারের কাছেও প্রসঙ্গ হিসেবে যায়, তাই গোপন তথ্য রাখবেন না। \"মনে রাখো…\" বললে এজেন্ট এখানে সেভ করে।"
        ),
        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
    )
    SectionTitle(tr("Memory & notes", "মেমরি ও নোট"))
    Row(verticalAlignment = Alignment.CenterVertically) {
        OutlinedTextField(newMem, { newMem = it }, modifier = Modifier.weight(1f), label = { Text(tr("Add to memory", "মেমরিতে যোগ করুন")) })
        Button(onClick = { if (newMem.isNotBlank()) { MemoryStore.add("memory", "", newMem); newMem = "" } }, modifier = Modifier.padding(start = 8.dp)) {
            Text("+")
        }
    }
    if (mem.isEmpty()) Text(tr("Nothing saved yet.", "এখনও কিছু সেভ নেই।"), modifier = Modifier.padding(top = 6.dp))
    mem.reversed().forEach { m ->
        SCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(
                        (if (m.kind == "note") tr("NOTE", "নোট") else tr("MEMORY", "মেমরি")) + (if (m.title.isNotBlank()) " · ${m.title}" else ""),
                        style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary
                    )
                    Text(m.text)
                }
                IconButton(onClick = { MemoryStore.remove(m.id) }) { Icon(Icons.Filled.Delete, tr("Delete", "মুছুন")) }
            }
        }
    }
    SectionTitle(tr("Tasks", "কাজের তালিকা"))
    Row(verticalAlignment = Alignment.CenterVertically) {
        OutlinedTextField(newTask, { newTask = it }, modifier = Modifier.weight(1f), label = { Text(tr("Add a task", "কাজ যোগ করুন")) })
        Button(onClick = { TaskStore.add(newTask); newTask = "" }, modifier = Modifier.padding(start = 8.dp)) { Text("+") }
    }
    tasks.reversed().forEach { t ->
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = t.done, onCheckedChange = { TaskStore.toggle(t.id) })
            Text(t.text, modifier = Modifier.weight(1f))
            IconButton(onClick = { TaskStore.remove(t.id) }) { Icon(Icons.Filled.Delete, tr("Delete", "মুছুন")) }
        }
    }
    val sched by Scheduler.items.collectAsState()
    SectionTitle(tr("Scheduled tasks", "নির্ধারিত কাজ"))
    if (sched.isEmpty()) {
        Text(tr("None. Say: \"every morning at 7 read me the news\".", "কিছু নেই। বলুন: \"প্রতিদিন সকাল ৭টায় আমাকে খবর পড়ে শোনাও\"।"))
    }
    sched.forEach { s ->
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(s.goal)
                Text(
                    java.text.SimpleDateFormat("EEE d MMM HH:mm", java.util.Locale.ENGLISH).format(java.util.Date(s.at)) + " · " + s.repeat,
                    style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            IconButton(onClick = { Scheduler.remove(s.id) }) { Icon(Icons.Filled.Delete, tr("Delete", "মুছুন")) }
        }
    }
    SectionTitle(tr("Privacy", "গোপনীয়তা"))
    OutlinedButton(onClick = { confirmAll = true }) { Text(tr("Delete all my saved data", "আমার সব সেভ করা তথ্য মুছুন")) }
    if (confirmAll) {
        AlertDialog(
            onDismissRequest = { confirmAll = false },
            title = { Text(tr("Delete everything?", "সব মুছে ফেলবেন?")) },
            text = { Text(tr("Memory, notes, tasks and chat history will be erased. API keys and settings stay.", "মেমরি, নোট, কাজ ও চ্যাট ইতিহাস মুছে যাবে। API key ও সেটিংস থাকবে।")) },
            confirmButton = {
                TextButton(onClick = {
                    MemoryStore.clear(); TaskStore.clear(); ChatStore.clear(); Scheduler.cancel(""); confirmAll = false
                }) { Text(tr("Delete", "মুছুন")) }
            },
            dismissButton = { TextButton(onClick = { confirmAll = false }) { Text(tr("Cancel", "বাতিল")) } }
        )
    }
}
