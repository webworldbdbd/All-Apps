package com.webworldbd.sarpai

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.Build
import android.os.Environment
import android.os.ParcelFileDescriptor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipInputStream

/** Reads PDF / Word / Excel / text / image files and finds files on the phone. Never deletes anything. */
object FileTools {
    data class Extracted(val text: String, val images: List<ByteArray>)

    private fun xmlDecode(s: String) = s.replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
        .replace("&quot;", "\"").replace("&apos;", "'")

    fun extract(name: String, bytes: ByteArray): Extracted {
        return when (name.substringAfterLast('.', "").lowercase()) {
            "txt", "md", "csv", "json", "log", "xml", "html", "htm", "kt", "java", "js", "py", "css", "ts", "sql" ->
                Extracted(String(bytes, Charsets.UTF_8).take(60000), emptyList())
            "docx" -> Extracted(docx(bytes), emptyList())
            "xlsx" -> Extracted(xlsx(bytes), emptyList())
            "pdf" -> pdf(bytes)
            "jpg", "jpeg", "png", "webp" -> Extracted("", listOf(Media.toJpeg(bytes)))
            else -> Extracted("", emptyList())
        }
    }

    private fun docx(bytes: ByteArray): String {
        val z = ZipInputStream(ByteArrayInputStream(bytes))
        try {
            var e = z.nextEntry
            while (e != null) {
                if (e.name == "word/document.xml") {
                    val xml = String(z.readBytes(), Charsets.UTF_8)
                    return xmlDecode(
                        xml.replace("</w:p>", "\n").replace("<w:tab/>", "\t").replace(Regex("<[^>]+>"), "")
                    ).trim().take(60000)
                }
                e = z.nextEntry
            }
        } finally {
            z.close()
        }
        return "(could not read this Word file)"
    }

    private fun xlsx(bytes: ByteArray): String {
        var shared = listOf<String>()
        var sheet = ""
        val z = ZipInputStream(ByteArrayInputStream(bytes))
        try {
            var e = z.nextEntry
            while (e != null) {
                if (e.name == "xl/sharedStrings.xml") {
                    val xml = String(z.readBytes(), Charsets.UTF_8)
                    shared = Regex("(?s)<si>(.*?)</si>").findAll(xml).map { m ->
                        xmlDecode(Regex("(?s)<t[^>]*>(.*?)</t>").findAll(m.groupValues[1]).joinToString("") { it.groupValues[1] })
                    }.toList()
                } else if (e.name == "xl/worksheets/sheet1.xml") {
                    sheet = String(z.readBytes(), Charsets.UTF_8)
                }
                e = z.nextEntry
            }
        } finally {
            z.close()
        }
        if (sheet.isBlank()) return "(could not read this Excel file)"
        val out = StringBuilder()
        var rows = 0
        for (r in Regex("(?s)<row[^>]*>(.*?)</row>").findAll(sheet)) {
            val cells = mutableListOf<String>()
            for (c in Regex("(?s)<c\\s([^>]*?)>(.*?)</c>").findAll(r.groupValues[1])) {
                val attrs = c.groupValues[1]
                val inner = c.groupValues[2]
                val t = Regex("t=\"(\\w+)\"").find(attrs)?.groupValues?.get(1)
                val v = Regex("(?s)<v>(.*?)</v>").find(inner)?.groupValues?.get(1).orEmpty()
                cells.add(
                    when (t) {
                        "s" -> shared.getOrNull(v.toIntOrNull() ?: -1).orEmpty()
                        "inlineStr" -> xmlDecode(Regex("(?s)<t[^>]*>(.*?)</t>").find(inner)?.groupValues?.get(1).orEmpty())
                        else -> v
                    }
                )
            }
            out.append(cells.joinToString("\t")).append('\n')
            if (++rows >= 300) break
        }
        return out.toString().take(60000)
    }

    private fun pdf(bytes: ByteArray): Extracted {
        val f = File(S.app.cacheDir, "doc.pdf")
        f.writeBytes(bytes)
        val pfd = ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY)
        val r = PdfRenderer(pfd)
        try {
            val n = minOf(r.pageCount, 6)
            val imgs = mutableListOf<ByteArray>()
            for (i in 0 until n) {
                val p = r.openPage(i)
                try {
                    val w = 1000
                    val h = (w.toFloat() / p.width * p.height).toInt().coerceAtLeast(1)
                    val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                    bmp.eraseColor(Color.WHITE)
                    p.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    val bos = ByteArrayOutputStream()
                    bmp.compress(Bitmap.CompressFormat.JPEG, 80, bos)
                    imgs.add(bos.toByteArray())
                } finally {
                    p.close()
                }
            }
            return Extracted("(PDF with ${r.pageCount} pages; the first $n pages are attached as images)", imgs)
        } finally {
            r.close()
            pfd.close()
        }
    }

    /** Saves a text document (txt, md, csv, html, json) to Documents/SARP AI. */
    fun create(name: String, content: String): String {
        if (content.isEmpty()) return "ERROR: content is empty"
        var safe = name.trim().replace(Regex("[^A-Za-z0-9._ -]"), "_").ifBlank { "note" }
        if (!safe.contains('.')) safe += ".txt"
        val mime = when (safe.substringAfterLast('.').lowercase()) {
            "html", "htm" -> "text/html"
            "csv" -> "text/csv"
            "json" -> "application/json"
            "md" -> "text/markdown"
            else -> "text/plain"
        }
        val ctx = S.app
        return try {
            if (Build.VERSION.SDK_INT >= 29) {
                val cv = android.content.ContentValues().apply {
                    put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, safe)
                    put(android.provider.MediaStore.MediaColumns.MIME_TYPE, mime)
                    put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, "Documents/SARP AI")
                }
                val uri = ctx.contentResolver.insert(android.provider.MediaStore.Files.getContentUri("external"), cv)
                    ?: return "ERROR: cannot create the file"
                ctx.contentResolver.openOutputStream(uri)?.use { it.write(content.toByteArray(Charsets.UTF_8)) }
                "Saved to Documents/SARP AI/$safe"
            } else {
                val dir = ctx.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS) ?: ctx.filesDir
                File(dir, safe).writeText(content)
                "Saved to ${dir.absolutePath}/$safe"
            }
        } catch (e: Exception) {
            "ERROR: could not save the file: ${e.message}"
        }
    }

    // ------------------------------------------------------------ finding / reading on the phone

    private fun allFiles(): Boolean = if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager() else true

    suspend fun find(query: String): String = withContext(Dispatchers.IO) {
        if (!allFiles()) return@withContext "ERROR: 'All files access' is not granted (Settings > Permissions)."
        val q = query.trim().lowercase()
        if (q.isEmpty()) return@withContext "ERROR: query missing"
        val root = Environment.getExternalStorageDirectory()
        val found = mutableListOf<File>()
        try {
            root.walkTopDown().maxDepth(6)
                .onEnter { d -> !d.name.startsWith(".") && d.name != "Android" }
                .forEach { f ->
                    if (found.size < 20 && f.isFile && f.name.lowercase().contains(q)) found.add(f)
                }
        } catch (e: Exception) { }
        if (found.isEmpty()) "No file found matching \"$query\"."
        else found.joinToString("\n") {
            "${it.absolutePath}  (${it.length() / 1024} KB, ${SimpleDateFormat("d MMM yyyy", Locale.ENGLISH).format(Date(it.lastModified()))})"
        }
    }

    suspend fun readForAgent(path: String, question: String): String = withContext(Dispatchers.IO) {
        if (!allFiles()) return@withContext "ERROR: 'All files access' is not granted (Settings > Permissions)."
        val f = File(path)
        if (!f.exists() || !f.isFile) return@withContext "ERROR: file not found: $path"
        if (f.length() > 30_000_000L) return@withContext "ERROR: file is too large (over 30 MB)."
        try {
            val ex = extract(f.name, f.readBytes())
            val q = question.ifBlank { "Summarize this file." }
            if (ex.images.isNotEmpty()) {
                Media.visionMulti("File: ${f.name}\n${ex.text}\nTask: $q", ex.images).second
            } else if (ex.text.isNotBlank()) {
                "FILE CONTENT (${f.name}):\n" + ex.text.take(20000)
            } else {
                "ERROR: this file type cannot be read (supported: pdf, docx, xlsx, txt/csv/code, images)."
            }
        } catch (e: Exception) {
            "ERROR: could not read the file: ${e.message}"
        }
    }
}
