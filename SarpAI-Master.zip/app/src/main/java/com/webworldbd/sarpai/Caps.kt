package com.webworldbd.sarpai

import android.Manifest
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import android.os.PowerManager
import android.provider.Settings
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat

/** Every capability the agent can use. Each needs the OS permission AND the in-app switch. */
enum class Cap(
    val key: String,
    val en: String,
    val bn: String,
    val perm: String?,
    val special: String?,
    val toggle: Boolean = true
) {
    MIC("mic", "Microphone", "মাইক্রোফোন", Manifest.permission.RECORD_AUDIO, null),
    CAMERA("camera", "Camera (take photos for analysis)", "ক্যামেরা (ছবি তুলে বিশ্লেষণ)", Manifest.permission.CAMERA, null),
    POST_NOTIF("post_notif", "Show notifications", "নোটিফিকেশন দেখানো", "android.permission.POST_NOTIFICATIONS", null, false),
    CONTACTS("contacts", "Contacts", "কন্টাক্টস", Manifest.permission.READ_CONTACTS, null),
    CALL("call", "Phone calls", "ফোন কল", Manifest.permission.CALL_PHONE, null),
    SMS("sms", "Send SMS", "এসএমএস পাঠানো", Manifest.permission.SEND_SMS, null),
    LOCATION("location", "Location", "লোকেশন", Manifest.permission.ACCESS_FINE_LOCATION, null),
    SCREEN("screen", "Screen control (Accessibility)", "স্ক্রিন কন্ট্রোল (Accessibility)", null, "accessibility"),
    NOTIF_ACCESS("notif_access", "Read notifications", "নোটিফিকেশন পড়া", null, "listener"),
    OVERLAY("overlay", "Floating button (display over apps)", "ভাসমান বাটন (অন্য অ্যাপের ওপরে)", null, "overlay", false),
    BATTERY("battery", "Keep running in background", "ব্যাকগ্রাউন্ডে চালু রাখা", null, "battery", false),
    CALENDAR("calendar", "Calendar (read events)", "ক্যালেন্ডার (ইভেন্ট পড়া)", Manifest.permission.READ_CALENDAR, null),
    WRITE_SETTINGS("write_settings", "Change brightness (system settings)", "ব্রাইটনেস পরিবর্তন (সিস্টেম সেটিংস)", null, "write_settings"),
    DND("dnd", "Do Not Disturb control", "ডু নট ডিস্টার্ব নিয়ন্ত্রণ", null, "dnd"),
    FILES("files", "All files access (find & read files)", "সব ফাইলের অ্যাক্সেস (ফাইল খোঁজা ও পড়া)", null, "all_files"),
    WEB("web", "Internet / web pages", "ইন্টারনেট / ওয়েব পেজ", null, "none"),
    EMAIL("email", "Email (read-only)", "ইমেইল (শুধু পড়া)", null, "none"),
    GITHUB("github", "GitHub & website hosting", "GitHub ও ওয়েবসাইট হোস্টিং", null, "none");

    val label: String get() = tr(en, bn)
}

object Caps {
    fun osGranted(ctx: Context, c: Cap): Boolean = when (c.special) {
        "accessibility" -> AgentAccessibilityService.instance != null
        "listener" -> NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)
        "overlay" -> Settings.canDrawOverlays(ctx)
        "battery" -> (ctx.getSystemService(Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(ctx.packageName)
        "write_settings" -> Settings.System.canWrite(ctx)
        "dnd" -> (ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).isNotificationPolicyAccessGranted
        "all_files" -> if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager() else true
        "none" -> true
        else -> {
            val p = c.perm
            p == null || ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED
        }
    }

    fun enabled(c: Cap): Boolean = S.caps[c.key] ?: true

    fun allowed(ctx: Context, c: Cap): Boolean = osGranted(ctx, c) && enabled(c)
}
