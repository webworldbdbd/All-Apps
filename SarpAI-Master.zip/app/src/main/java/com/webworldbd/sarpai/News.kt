package com.webworldbd.sarpai

import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.withContext
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLDecoder
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Locale

/** Headlines (Google News RSS), no API key needed. */
object News {
    data class Headline(val title: String, val source: String, val link: String)

    val headlines = MutableStateFlow<List<Headline>>(emptyList())
    val loading = MutableStateFlow(false)
    private var last = 0L

    private fun params() = if (S.language == "bn") "hl=bn&gl=BD&ceid=BD:bn" else "hl=en-US&gl=US&ceid=US:en"

    fun decode(s: String): String = s.replace("<![CDATA[", "").replace("]]>", "")
        .replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
        .replace("&quot;", "\"").replace("&#39;", "'").replace("&apos;", "'").trim()

    suspend fun fetch(topic: String?, count: Int): List<Headline> = withContext(Dispatchers.IO) {
        val url = if (topic.isNullOrBlank()) "https://news.google.com/rss?${params()}"
        else "https://news.google.com/rss/search?q=${URLEncoder.encode(topic, "UTF-8")}&${params()}"
        val req = Request.Builder().url(url).header("User-Agent", "Mozilla/5.0 (Linux; Android) SARP-AI").build()
        val xml = Llm.http.newCall(req).execute().use { it.body?.string().orEmpty() }
        val out = mutableListOf<Headline>()
        for (m in Regex("(?s)<item>(.*?)</item>").findAll(xml)) {
            val b = m.groupValues[1]
            val title = decode(Regex("(?s)<title>(.*?)</title>").find(b)?.groupValues?.get(1).orEmpty())
            val link = decode(Regex("(?s)<link>(.*?)</link>").find(b)?.groupValues?.get(1).orEmpty())
            val src = decode(Regex("(?s)<source[^>]*>(.*?)</source>").find(b)?.groupValues?.get(1).orEmpty())
            if (title.isNotBlank()) out.add(Headline(title.removeSuffix(" - $src"), src, link))
            if (out.size >= count) break
        }
        out
    }

    suspend fun refresh(force: Boolean = false) {
        if (loading.value) return
        if (!force && System.currentTimeMillis() - last < 15 * 60 * 1000 && headlines.value.isNotEmpty()) return
        loading.value = true
        try {
            val l = fetch(null, 6)
            if (l.isNotEmpty()) {
                headlines.value = l
                last = System.currentTimeMillis()
            }
        } catch (e: Exception) {
        } finally {
            loading.value = false
        }
    }

    suspend fun summary(topic: String): String {
        return try {
            val l = fetch(topic, 8)
            if (l.isEmpty()) "No news found." else l.joinToString("\n") { "- ${it.title} (${it.source})" }
        } catch (e: Exception) {
            "ERROR: news failed: ${e.message}"
        }
    }
}

/** Weather from open-meteo (no API key). */
object Weather {
    private fun describe(code: Int): String = when (code) {
        0 -> "clear sky"
        1, 2 -> "mostly clear / partly cloudy"
        3 -> "overcast"
        45, 48 -> "fog"
        in 51..57 -> "drizzle"
        in 61..67 -> "rain"
        in 71..77 -> "snow"
        in 80..82 -> "rain showers"
        in 95..99 -> "thunderstorm"
        else -> "unknown"
    }

    suspend fun get(city: String): String = withContext(Dispatchers.IO) {
        try {
            var lat: Double
            var lon: Double
            var place: String
            if (city.isBlank()) {
                val loc = Device.lastLocation() ?: return@withContext "ERROR: tell me the city name (location is not available)."
                lat = loc.first
                lon = loc.second
                place = "your location"
            } else {
                val g = Llm.http.newCall(
                    Request.Builder().url("https://geocoding-api.open-meteo.com/v1/search?name=${URLEncoder.encode(city, "UTF-8")}&count=1&format=json").build()
                ).execute().use { it.body?.string().orEmpty() }
                val r = JSONObject(g).optJSONArray("results")?.optJSONObject(0)
                    ?: return@withContext "ERROR: city \"$city\" not found."
                lat = r.getDouble("latitude")
                lon = r.getDouble("longitude")
                place = r.optString("name") + ", " + r.optString("country")
            }
            val url = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
                "&current=temperature_2m,relative_humidity_2m,weather_code,wind_speed_10m" +
                "&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max,weather_code" +
                "&timezone=auto&forecast_days=3"
            val body = Llm.http.newCall(Request.Builder().url(url).build()).execute().use { it.body?.string().orEmpty() }
            val j = JSONObject(body)
            val cur = j.getJSONObject("current")
            val d = j.getJSONObject("daily")
            val sb = StringBuilder("Weather for $place:\n")
            sb.append("Now: ${cur.getDouble("temperature_2m")}°C, ${describe(cur.getInt("weather_code"))}, humidity ${cur.getInt("relative_humidity_2m")}%, wind ${cur.getDouble("wind_speed_10m")} km/h\n")
            val days = d.getJSONArray("time")
            for (i in 0 until days.length()) {
                sb.append("${days.getString(i)}: ${d.getJSONArray("temperature_2m_min").getDouble(i)}–${d.getJSONArray("temperature_2m_max").getDouble(i)}°C, ")
                sb.append("${describe(d.getJSONArray("weather_code").getInt(i))}, rain chance ${d.getJSONArray("precipitation_probability_max").optInt(i)}%\n")
            }
            sb.toString()
        } catch (e: Exception) {
            "ERROR: weather failed: ${e.message}"
        }
    }
}

/** Web search: Gemini + Google Search grounding (with sources), DuckDuckGo as fallback. */
object Search {
    suspend fun run(query: String): String = withContext(Dispatchers.IO) {
        if (query.isBlank()) return@withContext "ERROR: query missing"
        val g = S.keys.firstOrNull { it.enabled && it.key.isNotBlank() && it.provider == "gemini" }
        if (g != null) {
            try {
                return@withContext grounded(g, query)
            } catch (e: Exception) { }
        }
        try {
            ddg(query)
        } catch (e: Exception) {
            "ERROR: search failed: ${e.message}"
        }
    }

    private fun grounded(k: ApiKey, q: String): String {
        val base = k.baseUrl.ifBlank { Provider.GEMINI.defBase }.trimEnd('/')
        val model = k.model.ifBlank { Provider.GEMINI.defModel }
        val sys = "Answer using Google Search results. Be concise and factual. Reply in the language of the question."
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", sys))))
            .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", q)))))
            .put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))
        val resp = Llm.postJson("$base/v1beta/models/$model:generateContent", mapOf("x-goog-api-key" to k.key), body)
        val cand = JSONObject(resp).optJSONArray("candidates")?.optJSONObject(0) ?: throw LlmException("Empty response")
        val parts = cand.optJSONObject("content")?.optJSONArray("parts") ?: throw LlmException("Empty response")
        val sb = StringBuilder()
        for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
        if (sb.isBlank()) throw LlmException("Empty response")
        val chunks = cand.optJSONObject("groundingMetadata")?.optJSONArray("groundingChunks")
        if (chunks != null && chunks.length() > 0) {
            sb.append("\nSources:\n")
            for (i in 0 until minOf(chunks.length(), 5)) {
                val w = chunks.getJSONObject(i).optJSONObject("web") ?: continue
                sb.append("- ${w.optString("title")} (${w.optString("uri")})\n")
            }
        }
        return sb.toString()
    }

    private fun ddg(q: String): String {
        val req = Request.Builder().url("https://html.duckduckgo.com/html/?q=" + URLEncoder.encode(q, "UTF-8"))
            .header("User-Agent", "Mozilla/5.0 (Linux; Android 14) SARP-AI").build()
        val html = Llm.http.newCall(req).execute().use { it.body?.string().orEmpty() }
        val links = Regex("(?s)class=\"result__a\"[^>]*href=\"([^\"]+)\"[^>]*>(.*?)</a>").findAll(html).take(6).toList()
        if (links.isEmpty()) return "ERROR: no search results (search service unavailable)."
        val sb = StringBuilder("Search results for \"$q\":\n")
        for (m in links) {
            var href = News.decode(m.groupValues[1])
            val u = Uri.parse(if (href.startsWith("//")) "https:$href" else href).getQueryParameter("uddg")
            if (u != null) href = URLDecoder.decode(u, "UTF-8")
            val title = News.decode(m.groupValues[2].replace(Regex("<[^>]+>"), ""))
            sb.append("- $title ($href)\n")
        }
        return sb.toString()
    }
}
