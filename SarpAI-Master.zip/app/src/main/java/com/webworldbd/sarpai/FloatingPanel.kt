package com.webworldbd.sarpai

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** Small chat window that floats over any app: type a command, see the answer, use quick actions. */
class FloatingPanel(
    private val ctx: Context,
    private val wm: WindowManager,
    private val onToggleListening: () -> Unit
) {
    private var root: LinearLayout? = null
    private var answer: TextView? = null
    private var micBtn: Button? = null
    private var shown = false
    private var large = false
    private var torch = false
    var waitingAnswer = false

    private val green = Color.parseColor("#00FF9C")
    private val gray = Color.parseColor("#7A8C85")

    private fun dp(v: Int) = (v * ctx.resources.displayMetrics.density).toInt()

    private fun lastAnswer(): String =
        Agent.log.value.lastOrNull { it.kind == "agent" || it.kind == "error" }?.text
            ?: tr("Type a command or tap a quick action.", "কমান্ড লিখুন বা একটি কুইক অ্যাকশন চাপুন।")

    private fun textBtn(label: String, onClick: () -> Unit): Button = Button(ctx).apply {
        text = label
        isAllCaps = false
        textSize = 15f
        setTextColor(green)
        setBackgroundColor(Color.TRANSPARENT)
        minWidth = 0
        minimumWidth = 0
        setPadding(dp(8), 0, dp(8), 0)
        setOnClickListener { onClick() }
    }

    private fun chip(label: String, onClick: () -> Unit): Button = Button(ctx).apply {
        text = label
        isAllCaps = false
        textSize = 11f
        setTextColor(green)
        background = GradientDrawable().apply {
            setColor(Color.parseColor("#0B1B14"))
            cornerRadius = dp(8).toFloat()
            setStroke(dp(1), green)
        }
        minHeight = 0
        minimumHeight = 0
        minWidth = 0
        minimumWidth = 0
        setPadding(dp(10), dp(4), dp(10), dp(4))
        setOnClickListener { onClick() }
    }

    private fun ask(prompt: String) {
        hide()
        waitingAnswer = true
        Agent.submit(prompt)
    }

    private fun submit(et: EditText) {
        val t = et.text.toString().trim()
        if (t.isEmpty()) return
        et.setText("")
        answer?.text = "…"
        Agent.submit(t)
    }

    private fun build(): LinearLayout {
        val r = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(12))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#F2061410"))
                cornerRadius = dp(16).toFloat()
                setStroke(dp(1), green)
            }
        }
        val header = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(
            TextView(ctx).apply {
                text = "◉ ${S.soulName.ifBlank { "SARP" }.uppercase()}"
                setTextColor(green)
                typeface = Typeface.MONOSPACE
                textSize = 13f
            },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        )
        header.addView(textBtn("⤢") { toggleSize() })
        header.addView(textBtn("✕") { hide() })
        r.addView(header)

        val ans = TextView(ctx).apply {
            setTextColor(Color.WHITE)
            textSize = 14f
            text = lastAnswer()
            setPadding(0, dp(6), 0, dp(6))
        }
        answer = ans
        val scroll = ScrollView(ctx).apply { addView(ans) }
        r.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(if (large) 260 else 110)))

        val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val et = EditText(ctx).apply {
            hint = tr("Type a command…", "কমান্ড লিখুন…")
            setHintTextColor(gray)
            setTextColor(Color.WHITE)
            textSize = 14f
            setSingleLine(true)
            imeOptions = EditorInfo.IME_ACTION_SEND
        }
        et.setOnEditorActionListener { _, id, _ ->
            if (id == EditorInfo.IME_ACTION_SEND) { submit(et); true } else false
        }
        row.addView(et, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(textBtn("➤") { submit(et) })
        r.addView(row)

        val hs = HorizontalScrollView(ctx).apply { isHorizontalScrollBarEnabled = false }
        val q = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        fun add(b: Button) {
            q.addView(b, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(34)).apply { setMargins(0, dp(6), dp(6), 0) })
        }
        val mic = chip(micLabel()) { onToggleListening(); refreshMic() }
        micBtn = mic
        add(mic)
        add(chip("🖥 " + tr("Screen", "স্ক্রিন")) { ask("Use read_screen and explain briefly what is on my screen.") })
        add(chip("📸 " + tr("Screenshot", "স্ক্রিনশট")) { ask("Wait 1 second, then use analyze_screen to explain what is on my screen.") })
        add(chip("🌐 " + tr("Translate", "অনুবাদ")) { ask("Read my screen and translate the visible text into Bangla (or into English if it is already Bangla).") })
        add(chip("📝 " + tr("Summarize", "সারাংশ")) { ask("Read my screen and summarize the page in 5 short points.") })
        add(chip("🔦") { torch = !torch; Device.flashlight(torch) })
        add(chip("🔋 " + tr("Status", "স্ট্যাটাস")) { ask("Tell me my battery, network and volume status with device_status.") })
        add(chip("📰 " + tr("News", "খবর")) { ask("Tell me the top 3 news headlines in a short spoken style.") })
        add(chip("⚙ " + tr("Open app", "অ্যাপ")) {
            hide()
            ctx.startActivity(Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP))
        })
        hs.addView(q)
        r.addView(hs)
        return r
    }

    private fun micLabel() = if (Agent.muted) "🎤 " + tr("off", "বন্ধ") else "🎤 " + tr("on", "চালু")

    private fun refreshMic() {
        micBtn?.text = micLabel()
    }

    fun show() {
        if (shown) return
        val r = build()
        root = r
        val lp = WindowManager.LayoutParams(
            dp(if (large) 360 else 320), WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = dp(70)
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN
        }
        try {
            wm.addView(r, lp)
            shown = true
        } catch (e: Exception) {
            Agent.addLog("error", "Floating window failed: ${e.message}")
        }
    }

    fun hide() {
        if (!shown) return
        try { root?.let { wm.removeView(it) } } catch (e: Exception) { }
        root = null
        answer = null
        micBtn = null
        shown = false
    }

    fun toggle() { if (shown) hide() else show() }

    fun toggleSize() {
        large = !large
        hide()
        show()
    }

    fun update(text: String) {
        answer?.text = text
    }
}
