# Play Console "Data safety" — suggested answers (this build: no ads, no analytics)
(Review against the final build and Google's current form before submitting.)

**Does your app collect or share any of the required user data types?** No.

| Data type | Collected | Shared | Notes |
|---|---|---|---|
| Photos, files, camera images | No | No | Processed on-device only; never leave the phone. |
| Personal info (name, email, etc.) | No | No | No accounts. |
| Device or other IDs | No | No | No ads/analytics SDK in this build. |
| Purchases | Handled by Google Play | — | Purchases are not active yet; the app never stores payment info. |

- **Is all of the user data encrypted in transit?** Not applicable (no data is sent).
- **Can users request data deletion?** No account data is held. Local history can be cleared in Settings → Clear history.
- **Ads declaration:** App contains ads = **No**.
- **Target audience:** 13+ / general. Not designed for children.
- **If you add ads later:** switch Ads to Yes, declare the advertising ID, and follow docs/ads-enable/README.md.
