# Google Play listing text

## App name
FileFit: Image, PDF & QR Tools

## Short description (max 80 characters)
Compress images, make PDFs and scan QR codes — offline and private.

## Full description (English)
FileFit puts 140 everyday tools in one fast app: image, PDF, QR, text, calculators, converters, date and time, and security tools. Everything is processed on your phone, so your files stay private and most tools work without internet.

IMAGES
• Compress photos by quality or to an exact size like 50 KB, 100 KB or 1 MB
• Resize by pixels or percent, crop, rotate and flip
• Convert between JPG, PNG and WebP
• Process up to 20 images at once, and compare before and after

PDF
• Turn photos into a PDF
• Merge, split and extract pages
• Reorder, rotate and delete pages
• Compress PDFs and read them inside the app

QR CODES
• Create QR codes for websites, Wi-Fi, contacts, email, phone numbers and text
• Scan with the camera or from an image
• Warnings for suspicious links — nothing opens without your tap

MADE FOR PRIVACY AND SPEED
• No account needed and no file uploads
• Light and Dark mode, English and Bangla
• Clean, simple design for everyone

FileFit is free. Premium (coming soon) raises the batch limit.

Developed by SHAFAET HOSSEN SARIP, WebWorldBD. Support: saripofficialsupport@gmail.com

## পূর্ণ বিবরণ (বাংলা)
FileFit ছবি, PDF ও QR কোডের প্রতিদিনের কাজ একটি দ্রুত অ্যাপে এনেছে। সব কাজ আপনার ফোনেই হয়, তাই ফাইল থাকে গোপন এবং বেশিরভাগ টুল ইন্টারনেট ছাড়াই চলে।

ছবি: মান বা ৫০ KB / ১০০ KB / ১ MB-এর মতো নির্দিষ্ট সাইজে ছোট করুন, মাপ বদলান, কাটুন, ঘোরান, JPG/PNG/WebP-তে রূপান্তর করুন, একসঙ্গে ২০টি ছবি করুন, আগে-পরে তুলনা দেখুন।
PDF: ছবি থেকে PDF, একত্র করা, ভাগ করা, পৃষ্ঠা বের করা, ক্রম বদল, ঘোরানো, ছোট করা ও দেখা।
QR: ওয়েবসাইট, Wi-Fi, যোগাযোগ, ইমেইল, ফোন ও লেখার QR তৈরি এবং ক্যামেরা বা ছবি থেকে স্ক্যান; সন্দেহজনক লিংকে সতর্কতা।
অ্যাকাউন্ট লাগে না, ফাইল আপলোড হয় না। বিনামূল্যে ব্যবহার করুন; Premium (শীঘ্রই আসছে) এ আরও বেশি ফাইল একসঙ্গে করা যাবে।
ডেভেলপার: SHAFAET HOSSEN SARIP, WebWorldBD। সহায়তা: saripofficialsupport@gmail.com

## Category / tags
Tools • image, pdf, qr, calculators, converters, text tools
