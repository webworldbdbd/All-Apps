import { h } from '../core/util.js';
import { icon } from '../core/icons.js';
import { t, LANGS, lang, initLang } from '../core/i18n.js';
import { settings, history, scanLog } from '../core/store.js';
import { toast, sheet, confirmDialog, navRow, toggleRow, selectBox, slider, segmented } from '../core/ui.js';
import { go } from '../core/router.js';
import { clearTemp, shareText, isNative } from '../core/files.js';
import { applyTheme } from '../core/theme.js';
import { LEGAL } from '../core/legal.js';
import * as billing from '../core/billing.js';
import cfg from '../config.js';
import { createScreen } from './toolkit.js';
import logo from '../assets/logo.png';

const PLAY_URL = 'https://play.google.com/store/apps/details?id=' + cfg.appId;
const group = (title, ...rows) => h('div', { class: 'group' }, h('div', { class: 'group-title' }, title), h('div', { class: 'card list-card flush' }, rows));

export function settingsPage(rerender) {
  const root = h('div', { class: 'screen' });
  const body = h('div', { class: 'body' });
  const themeLabel = { system: t('theme.system'), light: t('theme.light'), dark: t('theme.dark') };

  const premiumRow = settings.get('premium') ? null
    : h('button', { class: 'premium-banner', onClick: () => go('/premium') }, icon('crown', 26), h('span', { class: 'row-text' }, h('b', {}, t('premium.title')), h('span', {}, t('premium.sub'))), icon('right', 18));

  const pickLanguage = () => {
    const s = sheet({ title: t('settings.language'), body: h('div', { class: 'stack tight' },
      navRow({ iconName: 'globe', title: t('lang.auto'), value: settings.get('lang') === 'auto' ? '✓' : '', onClick: () => choose('auto') }),
      Object.entries(LANGS).map(([k, v]) => navRow({ iconName: 'globe', title: v.name, value: settings.get('lang') === k ? '✓' : '', onClick: () => choose(k) })),
      h('p', { class: 'hint' }, t('lang.more'))) });
    const choose = (k) => { settings.set('lang', k); initLang(); s.close(); rerender(); };
  };
  const pickTheme = () => {
    const s = sheet({ title: t('settings.theme'), body: h('div', { class: 'stack tight' }, ['system', 'light', 'dark'].map((k) => navRow({ iconName: 'moon', title: themeLabel[k], value: settings.get('theme') === k ? '✓' : '', onClick: () => { settings.set('theme', k); applyTheme(); s.close(); rerender(); } }))) });
  };
  const pickFormat = () => {
    const opts = [['original', t('fmt.original')], ['jpg', 'JPG'], ['png', 'PNG'], ['webp', 'WebP']];
    const s = sheet({ title: t('settings.imgFormat'), body: h('div', { class: 'stack tight' }, opts.map(([k, l]) => navRow({ iconName: 'image', title: l, value: settings.get('imageFormat') === k ? '✓' : '', onClick: () => { settings.set('imageFormat', k); s.close(); rerender(); } }))) });
  };
  const q = slider({ min: 10, max: 100, value: settings.get('quality'), format: (v) => v + '%', onInput: (v) => settings.set('quality', v) });

  body.append(h('h1', { class: 'page-title' }, t('nav.settings')), premiumRow,
    group(t('settings.general'),
      navRow({ iconName: 'globe', title: t('settings.language'), value: settings.get('lang') === 'auto' ? t('lang.auto') : LANGS[lang()].name, onClick: pickLanguage }),
      navRow({ iconName: 'moon', title: t('settings.theme'), value: themeLabel[settings.get('theme')], onClick: pickTheme })),
    group(t('settings.images'),
      h('div', { class: 'row-item static' }, h('span', { class: 'row-ico' }, icon('image', 20)), h('span', { class: 'row-text' }, h('span', { class: 'row-title' }, t('settings.defaultQuality')), q.el)),
      navRow({ iconName: 'convert', title: t('settings.imgFormat'), value: settings.get('imageFormat') === 'original' ? t('fmt.original') : settings.get('imageFormat').toUpperCase(), onClick: pickFormat })),
    group(t('settings.files'),
      isNative ? navRow({ iconName: 'folder', title: t('settings.imgFolder'), value: settings.get('imageFolder') === 'pictures' ? 'Pictures/FileFit' : 'Documents/FileFit', onClick: () => {
        const s = sheet({ title: t('settings.imgFolder'), body: h('div', { class: 'stack tight' }, [['pictures', 'Pictures/FileFit'], ['documents', 'Documents/FileFit']].map(([k, l]) => navRow({ iconName: 'folder', title: l, value: settings.get('imageFolder') === k ? '✓' : '', onClick: () => { settings.set('imageFolder', k); s.close(); rerender(); } }))) });
      } }) : null,
      toggleRow({ iconName: 'save', title: t('settings.autoSave'), sub: t('settings.autoSaveSub'), value: settings.get('autoSave'), onChange: (v) => settings.set('autoSave', v) }),
      h('div', { class: 'row-item static' }, h('span', { class: 'row-ico' }, icon('settings', 20)), h('span', { class: 'row-text' }, h('span', { class: 'row-title' }, t('settings.maxMP')), h('span', { class: 'row-sub' }, t('settings.maxMPSub')),
        h('div', { class: 'mt' }, segmented([{ value: '12', label: t('opt.low') }, { value: '25', label: t('opt.medium') }, { value: '50', label: t('opt.high') }], String(settings.get('maxMP')), (v) => settings.set('maxMP', Number(v))))))),
    group(t('settings.privacy'),
      toggleRow({ iconName: 'trash', title: t('settings.autoClean'), sub: t('settings.autoCleanSub'), value: settings.get('autoClean'), onChange: (v) => settings.set('autoClean', v) }),
      navRow({ iconName: 'trash', title: t('settings.clearTemp'), onClick: async () => { await clearTemp(); toast(t('settings.tempCleared')); } }),
      navRow({ iconName: 'history', title: t('settings.clearHistory'), onClick: async () => {
        if (await confirmDialog({ title: t('settings.clearHistory'), message: t('settings.clearHistoryQ'), confirmText: t('common.delete'), danger: true })) { history.clear(); scanLog.clear(); toast(t('settings.historyCleared')); }
      } }),
      navRow({ iconName: 'shield', title: t('settings.privacyPolicy'), onClick: () => go('/legal/privacy') }),
      navRow({ iconName: 'file', title: t('settings.terms'), onClick: () => go('/legal/terms') })),
    group(t('settings.about'),
      navRow({ iconName: 'info', title: t('settings.aboutApp'), value: 'v' + cfg.versionName, onClick: () => go('/about') }),
      navRow({ iconName: 'mail', title: t('settings.contact'), onClick: () => { const a = h('a', { href: 'mailto:' + cfg.supportEmail + '?subject=FileFit%20' + cfg.versionName }); document.body.append(a); a.click(); a.remove(); } }),
      navRow({ iconName: 'rating', title: t('settings.rate'), onClick: () => { const a = h('a', { href: 'market://details?id=' + cfg.appId }); document.body.append(a); a.click(); a.remove(); } }),
      navRow({ iconName: 'share', title: t('settings.shareApp'), onClick: () => shareText(t('settings.shareText') + ' ' + PLAY_URL).catch(() => {}) }),
      navRow({ iconName: 'history', title: t('settings.reset'), onClick: async () => { if (await confirmDialog({ title: t('settings.reset'), message: t('settings.resetQ'), danger: true, confirmText: t('common.ok') })) { settings.reset(); initLang(); applyTheme(); rerender(); } } })));
  root.append(body);
  void selectBox;
  return root;
}

export function aboutPage() {
  const s = createScreen(t('settings.aboutApp'));
  s.body.append(h('div', { class: 'center stack about' },
    h('img', { class: 'about-logo', src: logo, alt: 'FileFit' }),
    h('h2', {}, 'File', h('span', { class: 'accent' }, 'Fit')),
    h('div', { class: 'muted' }, t('app.tagline')),
    h('div', { class: 'pill' }, 'v' + cfg.versionName + ' (' + cfg.versionCode + ')'),
    h('p', { class: 'muted' }, t('about.text'))),
    h('div', { class: 'card list-card' },
      [['lock', t('about.p1')], ['image', t('about.p2')], ['pdf', t('about.p3')], ['qr', t('about.p4')]].map(([ic, tx]) => h('div', { class: 'recent-row' }, h('span', { class: 'row-ico' }, icon(ic, 20)), h('span', { class: 'row-text' }, h('span', { class: 'row-title wrap' }, tx))))),
    h('p', { class: 'hint center' }, t('about.dev', { name: cfg.developer, company: cfg.company })),
    h('p', { class: 'hint center' }, cfg.supportEmail),
    h('p', { class: 'hint center' }, t('about.libs')));
  return { el: s.root, destroy: s.destroy };
}

export function legalPage(kind) {
  const s = createScreen(t(kind === 'privacy' ? 'settings.privacyPolicy' : 'settings.terms'));
  const doc = (LEGAL[lang()] || LEGAL.en)[kind];
  s.body.append(h('div', { class: 'stack legal' }, doc.map(([hd, tx]) => h('section', {}, h('h3', {}, hd), h('p', {}, tx))),
    kind === 'privacy' ? h('p', { class: 'hint' }, cfg.privacyUrl) : null));
  return { el: s.root, destroy: s.destroy };
}

export function premiumPage() {
  const s = createScreen(t('premium.title'));
  const plans = [['yearly', t('premium.yearly'), t('premium.best')], ['monthly', t('premium.monthly'), ''], ['lifetime', t('premium.lifetime'), '']];
  let chosen = 'yearly';
  const cards = h('div', { class: 'stack tight' });
  const paint = () => {
    cards.replaceChildren(...plans.map(([id, name, badge]) => h('button', { class: 'plan' + (chosen === id ? ' on' : ''), onClick: () => { chosen = id; paint(); } },
      h('span', { class: 'row-text' }, h('span', { class: 'row-title' }, name), badge ? h('span', { class: 'badge' }, badge) : null),
      h('span', { class: 'plan-price' }, billing.priceOf(id) || '—'))));
  };
  paint();
  const buy = h('button', { class: 'btn primary block', onClick: async () => {
    if (settings.get('premium')) { toast(t('premium.already')); return; }
    const r = await billing.purchase(chosen);
    if (!r.ok) toast(r.reason === 'not_configured' ? t('premium.notConfigured') : t('premium.failed'), 4500);
  } }, icon('crown', 20), t('premium.cta'));
  s.body.append(h('div', { class: 'card premium-hero center stack' }, icon('crown', 40, 'gold'), h('h2', {}, t('premium.headline')), h('p', { class: 'muted' }, t('premium.sub'))),
    h('div', { class: 'card list-card' }, ['premium.f2', 'premium.f3', 'premium.f4'].map((k) => h('div', { class: 'recent-row' }, h('span', { class: 'row-ico ok' }, icon('check', 18)), h('span', { class: 'row-text' }, h('span', { class: 'row-title wrap' }, t(k)))))),
    cards, buy,
    h('button', { class: 'btn ghost block', onClick: async () => { const ok = await billing.restore(); toast(ok ? t('premium.restoring') : t('premium.notConfigured'), 3500); } }, t('premium.restore')),
    h('p', { class: 'hint center' }, t('premium.terms')));
  return { el: s.root, destroy: s.destroy };
}
