// Plain-language policies shown inside the app. Keep in sync with store/privacy-policy.html.
// Ads are off in this build, so there is no advertising section. See docs/ads-enable/README.md for the text to add back.
export const LEGAL = {
  "en": {
    "privacy": [
      [
        "Summary",
        "FileFit processes your images, PDFs and QR codes on your device. Your files are never uploaded to our servers, and we do not require an account."
      ],
      [
        "Files you choose",
        "The app only reads files you explicitly pick. Results are saved in the FileFit folder on your phone (Pictures/FileFit or Documents/FileFit) only when you tap Save, or when you turn on Auto-save. Temporary files are stored in the app cache and can be deleted from Settings."
      ],
      [
        "Camera",
        "The camera is used only on the QR scanner screen to read QR codes. Images from the camera are analysed on the device and are not stored or sent anywhere."
      ],
      [
        "Local data",
        "History, favorites, scan history and settings are stored only on your device. You can clear them any time from Settings."
      ],
      [
        "Purchases",
        "Premium purchases are handled by Google Play. We do not see or store your payment details."
      ],
      [
        "Children",
        "FileFit is a general-audience utility app and is not directed to children under 13."
      ],
      [
        "Developer",
        "FileFit is developed by SHAFAET HOSSEN SARIP, WebWorldBD."
      ],
      [
        "Contact",
        "Questions about privacy: saripofficialsupport@gmail.com"
      ]
    ],
    "terms": [
      [
        "Use of the app",
        "FileFit is provided “as is”. Please keep a copy of important original files before editing them."
      ],
      [
        "Your content",
        "You keep all rights to your files. You are responsible for having the right to process the files you select."
      ],
      [
        "Results",
        "Compression and conversion can reduce quality. A requested file size may not always be reachable; the app tells you when that happens."
      ],
      [
        "Premium",
        "Premium subscriptions renew until cancelled in Google Play. Refunds follow Google Play policy."
      ],
      [
        "Changes",
        "We may update these terms; continued use means you accept the updated terms."
      ],
      [
        "Developer and contact",
        "FileFit is developed by SHAFAET HOSSEN SARIP, WebWorldBD. Support: saripofficialsupport@gmail.com"
      ]
    ]
  },
  "bn": {
    "privacy": [
      [
        "সংক্ষিপ্ত",
        "FileFit আপনার ছবি, PDF ও QR কোড ফোনের ভেতরেই প্রক্রিয়া করে। আপনার ফাইল কখনো আমাদের সার্ভারে আপলোড হয় না এবং অ্যাকাউন্ট লাগে না।"
      ],
      [
        "আপনি যে ফাইল বেছে নেন",
        "অ্যাপ শুধু আপনি যে ফাইল বেছে দেন সেগুলোই পড়ে। আপনি Save চাপলে (অথবা Auto-save চালু করলে) ফলাফল FileFit ফোল্ডারে (Pictures/FileFit অথবা Documents/FileFit) সংরক্ষিত হয়। অস্থায়ী ফাইল সেটিংস থেকে মুছতে পারবেন।"
      ],
      [
        "ক্যামেরা",
        "ক্যামেরা শুধু QR স্ক্যানার পর্দায় QR কোড পড়ার জন্য ব্যবহার হয়। ছবি ফোনেই বিশ্লেষণ হয়, কোথাও সংরক্ষণ বা পাঠানো হয় না।"
      ],
      [
        "লোকাল তথ্য",
        "ইতিহাস, পছন্দের তালিকা, স্ক্যানের ইতিহাস ও সেটিংস শুধু আপনার ফোনে থাকে। সেটিংস থেকে যে কোনো সময় মুছতে পারবেন।"
      ],
      [
        "কেনাকাটা",
        "Premium কেনাকাটা Google Play পরিচালনা করে। আমরা আপনার পেমেন্ট তথ্য দেখি না ও সংরক্ষণ করি না।"
      ],
      [
        "শিশু",
        "FileFit সাধারণ ব্যবহারকারীদের জন্য; ১৩ বছরের কম বয়সী শিশুদের উদ্দেশ্যে নয়।"
      ],
      [
        "ডেভেলপার",
        "FileFit-এর ডেভেলপার SHAFAET HOSSEN SARIP, WebWorldBD।"
      ],
      [
        "যোগাযোগ",
        "গোপনীয়তা সম্পর্কে প্রশ্ন থাকলে: saripofficialsupport@gmail.com"
      ]
    ],
    "terms": [
      [
        "অ্যাপ ব্যবহার",
        "FileFit “যেমন আছে” ভিত্তিতে দেওয়া হয়। গুরুত্বপূর্ণ মূল ফাইল সম্পাদনার আগে একটি কপি রাখুন।"
      ],
      [
        "আপনার কনটেন্ট",
        "আপনার ফাইলের সব অধিকার আপনারই। যে ফাইল প্রক্রিয়া করছেন তা ব্যবহারের অধিকার আপনার আছে তা নিশ্চিত করতে হবে।"
      ],
      [
        "ফলাফল",
        "কম্প্রেস ও রূপান্তরে মান কমতে পারে। চাইতে নির্দিষ্ট সাইজে নাও পৌঁছানো যেতে পারে; তখন অ্যাপ তা জানিয়ে দেয়।"
      ],
      [
        "Premium",
        "Premium সাবস্ক্রিপশন Google Play থেকে বাতিল না করা পর্যন্ত নবায়ন হয়। রিফান্ড Google Play নীতি অনুযায়ী।"
      ],
      [
        "পরিবর্তন",
        "আমরা শর্তাবলি হালনাগাদ করতে পারি; ব্যবহার অব্যাহত রাখলে নতুন শর্ত মেনে নেওয়া হবে।"
      ],
      [
        "ডেভেলপার ও যোগাযোগ",
        "FileFit-এর ডেভেলপার SHAFAET HOSSEN SARIP, WebWorldBD। সহায়তা: saripofficialsupport@gmail.com"
      ]
    ]
  }
};
