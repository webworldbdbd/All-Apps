// Ads are switched off in this build (no AdMob SDK is included).
// To enable them later, see docs/ads-enable/README.md - it contains the full AdMob version of this file.
export async function initAds() {}
export async function showBanner() {}
export async function hideBanner() {}
export async function afterAction() {}
