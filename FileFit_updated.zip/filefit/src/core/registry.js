// Single list of every tool. Home, Tools tab and search all read from here.
export const TOOLS = [
  { id: 'compress', cat: 'image', route: '/image/compress', icon: 'compress' },
  { id: 'resize', cat: 'image', route: '/image/resize', icon: 'resize' },
  { id: 'crop', cat: 'image', route: '/image/crop', icon: 'crop' },
  { id: 'convert', cat: 'image', route: '/image/convert', icon: 'convert' },
  { id: 'rotate', cat: 'image', route: '/image/rotate', icon: 'rotate' },
  { id: 'imginfo', cat: 'image', route: '/image/info', icon: 'info' },
  { id: 'img2pdf', cat: 'pdf', route: '/pdf/img2pdf', icon: 'image' },
  { id: 'merge', cat: 'pdf', route: '/pdf/merge', icon: 'merge' },
  { id: 'split', cat: 'pdf', route: '/pdf/split', icon: 'split' },
  { id: 'extract', cat: 'pdf', route: '/pdf/extract', icon: 'extract' },
  { id: 'organize', cat: 'pdf', route: '/pdf/organize', icon: 'reorder' },
  { id: 'pdfrotate', cat: 'pdf', route: '/pdf/pdfrotate', icon: 'rotate' },
  { id: 'pdfcompress', cat: 'pdf', route: '/pdf/pdfcompress', icon: 'compress' },
  { id: 'view', cat: 'pdf', route: '/pdf/view', icon: 'eye' },
  { id: 'pdfinfo', cat: 'pdf', route: '/pdf/pdfinfo', icon: 'info' },
  { id: 'qrgen', cat: 'qr', route: '/qr/generate', icon: 'qr' },
  { id: 'qrscan', cat: 'qr', route: '/qr/scan', icon: 'camera' },
];
export const CATS = [
  { id: 'image', route: '/images', icon: 'image' },
  { id: 'pdf', route: '/pdf', icon: 'pdf' },
  { id: 'qr', route: '/qr', icon: 'qr' },
];
export const toolsOf = (cat) => TOOLS.filter((x) => x.cat === cat);
export const QUICK = ['compress', 'img2pdf', 'merge', 'qrscan', 'qrgen', 'resize'];
