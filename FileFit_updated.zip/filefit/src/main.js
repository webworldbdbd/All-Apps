import './styles.css';
import { Capacitor } from '@capacitor/core';
import { h } from './core/util.js';
import { icon } from './core/icons.js';
import { initLang, t } from './core/i18n.js';
import { settings, onChange } from './core/store.js';
import { applyTheme, watchSystemTheme } from './core/theme.js';
import { route, startRouter, go, refresh } from './core/router.js';
import { closeTopLayer } from './core/ui.js';
import { clearTemp } from './core/files.js';
import { initAds, showBanner, hideBanner } from './core/ads.js';
import { initBilling } from './core/billing.js';
import { homePage, toolsPage, categoryPage } from './pages/home.js';
import { filesPage } from './pages/files.js';
import { settingsPage, aboutPage, legalPage, premiumPage } from './pages/settings.js';
import { comparePage } from './pages/compare.js';
import { imageToolPage } from './pages/imageTools.js';
import { pdfToolPage } from './pages/pdfTools.js';
import { qrGeneratePage, qrScanPage } from './pages/qr.js';
import { splashScreen, onboarding } from './pages/onboarding.js';

const IMAGE_IDS = ['compress', 'resize', 'crop', 'convert', 'rotate', 'info'];
const PDF_IDS = ['img2pdf', 'merge', 'split', 'extract', 'organize', 'pdfrotate', 'pdfcompress', 'view', 'pdfinfo'];
const TABS = [
  { id: 'home', path: '/home', icon: 'home', key: 'nav.home' },
  { id: 'tools', path: '/tools', icon: 'grid', key: 'nav.tools' },
  { id: 'files', path: '/files', icon: 'folder', key: 'nav.files' },
  { id: 'settings', path: '/settings', icon: 'settings', key: 'nav.settings' },
];

function bootApp(root) {
  root.replaceChildren();
  const view = h('main', { class: 'view', id: 'view' });
  const tabbar = h('nav', { class: 'tabbar', 'aria-label': 'Main' });
  root.append(view, tabbar);

  const paintTabs = (active) => {
    tabbar.replaceChildren(...TABS.map((x) => h('button', { class: 'tab' + (x.id === active ? ' on' : ''), onClick: () => go(x.path), 'aria-label': t(x.key) },
      h('span', { class: 'tab-pill' }, icon(x.icon, 22)), h('span', { class: 'tab-label' }, t(x.key)))));
  };

  route('/home', () => homePage(), { tab: 'home' });
  route('/tools', () => toolsPage(), { tab: 'tools' });
  route('/files', () => filesPage(), { tab: 'files' });
  route('/settings', () => settingsPage(refresh), { tab: 'settings' });
  route('/images', () => categoryPage('image'));
  route('/pdf', () => categoryPage('pdf'));
  route('/qr', () => categoryPage('qr'));
  route('/image/:id', ({ id }) => (IMAGE_IDS.includes(id) ? imageToolPage(id) : (location.replace('#/images'), h('div'))));
  route('/pdf/:id', ({ id }) => (PDF_IDS.includes(id) ? pdfToolPage(id) : (location.replace('#/pdf'), h('div'))));
  route('/qr/generate', () => qrGeneratePage());
  route('/qr/scan', () => qrScanPage());
  route('/compare', () => comparePage());
  route('/premium', () => premiumPage());
  route('/about', () => aboutPage());
  route('/legal/:kind', ({ kind }) => legalPage(kind === 'terms' ? 'terms' : 'privacy'));

  startRouter(view, (path, meta) => {
    const tab = meta && meta.tab;
    tabbar.classList.toggle('hidden', !tab);
    document.documentElement.classList.toggle('has-tabs', !!tab);
    if (tab) { paintTabs(tab); showBanner(); } else hideBanner();
  });
  onChange((w) => { if (w === 'settings:premium') hideBanner(); });
}

function wireBackButton() {
  if (!Capacitor.isNativePlatform()) return;
  import('@capacitor/app').then(({ App }) => {
    App.addListener('backButton', () => {
      if (closeTopLayer()) return;
      const path = location.hash.replace(/^#/, '') || '/home';
      if (['/home', ''].includes(path)) App.exitApp();
      else if (['/tools', '/files', '/settings'].includes(path)) go('/home');
      else history.back();
    });
  }).catch(() => {});
}

async function main() {
  const root = document.getElementById('app');
  initLang();
  await applyTheme();
  watchSystemTheme();
  root.append(splashScreen());
  wireBackButton();
  if (settings.get('autoClean')) clearTemp();

  const start = () => {
    if (!location.hash || location.hash === '#') history.replaceState(null, '', '#/home');
    bootApp(root);
    initAds().then(() => { if (!document.querySelector('.tabbar.hidden')) showBanner(); });
    initBilling().catch(() => {});
  };
  setTimeout(() => {
    if (settings.get('onboarded')) start();
    else { root.replaceChildren(onboarding(start)); }
  }, 900);
}

main();
