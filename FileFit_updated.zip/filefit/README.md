# FileFit — ছবি, PDF, QR ও টেক্সট টুলস (Android)

HTML + CSS + JavaScript + Capacitor দিয়ে তৈরি। সব কাজ ফোনের ভেতরেই হয়, ইন্টারনেট ছাড়া চলে।

## অ্যাপে কী কী আছে

| বিভাগ | সুবিধা |
|---|---|
| ছবি | সাইজ কমানো (মান দিয়ে বা নির্দিষ্ট KB/MB দিয়ে), মাপ বদলানো (px / %), ছবি কাটা, JPG/PNG/WebP রূপান্তর, ঘোরানো ও উল্টানো, ছবির তথ্য, একসঙ্গে ২০টি (Premium-এ ৫০টি), আগে-পরে তুলনা |
| PDF | ছবি থেকে PDF, মার্জ, স্প্লিট (পৃষ্ঠা/রেঞ্জ, ZIP), পৃষ্ঠা বের করা, পৃষ্ঠার ক্রম বদল/মোছা, পৃষ্ঠা ঘোরানো, PDF কমপ্রেস (৩ স্তর), PDF দেখা, PDF তথ্য |
| QR | তৈরি (ওয়েবসাইট, লেখা, Wi-Fi, যোগাযোগ, ইমেইল, ফোন, SMS), রং ও ত্রুটি-সংশোধন, ক্যামেরা বা ছবি থেকে স্ক্যান, সন্দেহজনক লিংকের সতর্কতা (ব্যবহারকারী ট্যাপ না করলে কিছু খোলে না), স্ক্যান ইতিহাস |
| টেক্সট | শব্দ গণনা, ডুপ্লিকেট লাইন/শব্দ মোছা, লাইন সাজানো, খুঁজুন ও বদলান (regex সহ), বড়-ছোট হাতের অক্ষর, লেখা পরিষ্কার, লেখা উল্টানো, স্লাগ, Lorem Ipsum — সবই ফোনে, নেটওয়ার্ক ছাড়া |
| ফাইল | সাম্প্রতিক / পছন্দের / সংরক্ষিত, খোঁজা, প্রিভিউ, শেয়ার, মোছা, অস্থায়ী ফাইল পরিষ্কার |
| অন্যান্য | Light/Dark, English + বাংলা (সহজে ভাষা যোগ করা যায়), অনবোর্ডিং, সেটিংস, গোপনীয়তা নীতি, Premium স্ক্রিন (কেনাকাটা এখনো বন্ধ), বিজ্ঞাপন বন্ধ (পরে AdMob যোগ করা যাবে — docs/ads-enable) |

## যা লাগবে (আপনার কম্পিউটারে)

- **Node.js 22 বা নতুন** — https://nodejs.org
- **JDK 21** (Android Studio-র সঙ্গেই আসে)
- **Android Studio** (Android SDK-র জন্য) — শুধু পদ্ধতি A-তে লাগবে

## পদ্ধতি A: নিজের কম্পিউটার থেকে AAB বানানো

```bash
unzip filefit.zip && cd filefit
npm install
npm run android:init     # android প্রজেক্ট, আইকন, স্প্ল্যাশ ও সব প্যাচ নিজে করে দেয়
npm run android:open     # Android Studio-তে খুলতে চাইলে (ঐচ্ছিক)
npm run android:aab      # সরাসরি AAB বানায়
```

AAB পাবেন: `android/app/build/outputs/bundle/release/app-release.aab`

ফোনে ট্রায়াল করতে ফোন USB দিয়ে লাগিয়ে Android Studio থেকে **Run** চাপুন।

## পদ্ধতি B: কম্পিউটারে কিছু ইনস্টল না করে — GitHub Actions

1. GitHub-এ নতুন প্রাইভেট রিপো বানিয়ে এই প্রজেক্টের সব ফাইল আপলোড করুন (`.github` ফোল্ডারসহ)।
2. Settings → Secrets and variables → Actions → নিচের ৪টি Secret দিন (সাইনিং কী বানানোর নিয়ম নিচে):
   `KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`
3. Actions ট্যাব → **Build Android AAB** → **Run workflow**।
4. কাজ শেষে নিচে **Artifacts** থেকে `filefit-release-aab` নামিয়ে নিন।

## সাইনিং কী (একবারই বানাতে হয়)

```bash
keytool -genkey -v -keystore upload-keystore.jks -keyalg RSA -keysize 2048 -validity 10000 -alias upload
```

- **এই ফাইল ও পাসওয়ার্ড কোথাও হারাবেন না, কাউকে দেবেন না, GitHub-এর কোডে আপলোড করবেন না।** ব্যাকআপ রাখুন।
- পদ্ধতি A: ফাইলটি `android/` ফোল্ডারে রাখুন এবং `android/keystore.properties` ফাইল বানান:
  ```
  storeFile=../upload-keystore.jks
  storePassword=আপনার-পাসওয়ার্ড
  keyAlias=upload
  keyPassword=আপনার-পাসওয়ার্ড
  ```
- পদ্ধতি B: `base64 -w0 upload-keystore.jks` (Mac: `base64 -i upload-keystore.jks`) চালিয়ে যা পাবেন সেটাই `KEYSTORE_BASE64` Secret।
- Play Console-এ **Play App Signing** চালু রাখুন (নতুন অ্যাপে ডিফল্ট)। এই কী হলো আপনার *upload key*।

## প্রকাশের আগে অবশ্যই বদলাতে হবে — `app.config.json`

| ফিল্ড | কী করবেন |
|---|---|
| `appId` | আপনার নিজের ইউনিক প্যাকেজ নাম (যেমন `com.webworldbd.filefit`)। Play Store-এ আপলোডের পর **আর বদলানো যায় না** |
| `supportEmail`, `privacyUrl` | আসল ইমেইল ও গোপনীয়তা নীতির ওয়েব লিংক (`store/privacy-policy.html` হোস্ট করুন, GitHub Pages-এ করা যায়) |
| `ads.testMode` | প্রকাশের আগে `false` করুন |
| `ads.androidAppId`, `bannerId`, `interstitialId` | AdMob অ্যাকাউন্ট থেকে আসল আইডি। এখন যেগুলো আছে সেগুলো Google-এর **টেস্ট** আইডি |
| `versionCode` | প্রতিটি নতুন আপলোডে ১ করে বাড়ান |
| `versionName` | দেখানোর সংস্করণ (যেমন `1.0.1`) |

বদলানোর পর আবার `npm run android:init` চালান।

## Premium কেনাকাটা চালু করা (শেষ ধাপ)

অ্যাপে Premium স্ক্রিন, বিজ্ঞাপন লুকানো ও ৫০ ফাইলের সীমা তৈরি আছে। আসল কেনাকাটার জন্য:

1. Play Console → Monetize → Products থেকে তিনটি প্রোডাক্ট বানান: `filefit_premium_monthly`, `filefit_premium_yearly` (Subscription) এবং `filefit_premium_lifetime` (One-time)। আইডি বদলালে `app.config.json`-এও বদলান।
2. `npm i cordova-plugin-purchase` তারপর `npm run android:init`।
3. Internal testing ট্র্যাকে আপলোড করে একটি টেস্ট অ্যাকাউন্টে কিনে দেখুন।

প্লাগিন না থাকলে "কেনাকাটা এখনো সেট করা হয়নি" বার্তা দেখায়; কোনো ভুয়া আনলক হয় না।

## Google Play-তে আপলোডের চেকলিস্ট

- [ ] নতুন অ্যাপ বানান, Default language English (বা বাংলা), App/Free নির্বাচন
- [ ] `store/play-store-icon-512.png` (আইকন), `store/feature-graphic-1024x500.png` (ফিচার গ্রাফিক – চাইলে নিজের ডিজাইনে বদলান) ও কমপক্ষে ২টি ফোন স্ক্রিনশট
- [ ] `store/listing.md` থেকে সংক্ষিপ্ত ও পূর্ণ বিবরণ
- [ ] Privacy policy URL (`store/privacy-policy.html` হোস্ট করে)
- [ ] App content → **Ads: না**, **Data safety** (`store/data-safety.md` দেখুন), Content rating প্রশ্নমালা, Target audience (১৩+/সবাই)
- [ ] Testing → Internal testing-এ AAB আপলোড, নিজের ফোনে ইনস্টল করে পুরো অ্যাপ পরীক্ষা
- [ ] নতুন ব্যক্তিগত ডেভেলপার অ্যাকাউন্টে Production-এ যাওয়ার আগে Google-এর ক্লোজড টেস্টিং শর্ত পূরণ করতে হতে পারে (Play Console-এ বর্তমান নিয়ম দেখুন)

## ফোনে পরীক্ষার তালিকা (প্রকাশের আগে)

- [ ] ছবি কমানো: মান দিয়ে ও ১০০ KB দিয়ে; ফলাফল Pictures/FileFit-এ এসেছে ও গ্যালারিতে দেখা যাচ্ছে
- [ ] একসঙ্গে ২০টি ছবি; মাঝপথে বাতিল চেপে দেখুন
- [ ] ছবি → PDF → PDF মার্জ → স্প্লিট; Documents/FileFit-এ ফাইল এসেছে কি না
- [ ] শেয়ার (WhatsApp/Drive) — ফাইল ঠিকমতো যাচ্ছে কি না
- [ ] QR স্ক্যান: ক্যামেরার অনুমতি, টর্চ, ছবি থেকে স্ক্যান; Wi-Fi/URL/ফোন QR
- [ ] ইন্টারনেট বন্ধ (Airplane mode) রেখে সব টুল
- [ ] Dark mode, বাংলা, বড় ফন্ট সাইজ
- [ ] পুরোনো (Android 8–10) ও নতুন (Android 14+) ফোন; কম RAM-এর ফোনে ৫০ MP ছবি
- [ ] ব্যাক বাটন, অ্যাপ বন্ধ করে আবার চালু

## কোড কোথায় কী

```
src/main.js            অ্যাপ শুরু, রাউটার, ট্যাব বার
src/core/              util, icons, store(সেটিংস/ইতিহাস), i18n, files(সংরক্ষণ/শেয়ার), ads, billing, ui
src/tools/image.js     ছবির ইঞ্জিন (compress/resize/crop/rotate/convert)
src/tools/pdf.js       PDF ইঞ্জিন (pdf-lib + PDF.js)
src/tools/qr.js        QR তৈরি/স্ক্যান
src/tools/specs/      ক্যালকুলেটর, কনভার্টার, সময়, সিকিউরিটি, টেক্সট টুলের তালিকা (একটি ফাইলে একটি ধরনের টুল)
src/pages/toolEngine.js  সব সাধারণ টুলের পেজ এক ইঞ্জিনে তৈরি হয় (নতুন টুল যোগ করতে শুধু specs-এ একটি এন্ট্রি লিখুন)
src/pages/             প্রতিটি স্ক্রিন
src/locales/en.js bn.js  সব লেখা (নতুন ভাষা: ফাইল কপি করে src/core/i18n.js-এ যোগ করুন)
src/core/registry.js   টুলের তালিকা (নতুন টুল যোগ করার জায়গা)
scripts/               Android সেটআপ ও AAB বিল্ড
store/                 Play Store-এর আইকন, বিবরণ, গোপনীয়তা নীতি
assets/                আইকন ও স্ল্যাশের উৎস ছবি
```

## জেনে রাখুন

- **ছবি/PDF কমপ্রেস:** নির্দিষ্ট KB-তে পৌঁছানো না গেলে অ্যাপ তা স্পষ্ট জানায়; আরও ছোট না হলে আসল ফাইলই রাখে। PDF "মাঝারি/জোরালো" কমপ্রেসে পৃষ্ঠা ছবি হয়ে যায় (লেখা সিলেক্ট করা যায় না) — অ্যাপে এটা লেখা আছে।
- **ফাইল সংরক্ষণ:** ছবি `Pictures/FileFit`, বাকি সব `Documents/FileFit`-এ। অন্য জায়গায় রাখতে **Share** চেপে "Files/Drive-এ সেভ" বেছে নিন।
- **পাসওয়ার্ড-সুরক্ষিত PDF** প্রক্রিয়া করা যায় না (অ্যাপ জানিয়ে দেয়)।
- **HEIC ছবি** কিছু ফোনে WebView খুলতে পারে না; তখন "ছবিটি খোলা যায়নি" দেখায়।
