# Play Console "Data safety" — suggested answers (this build: Google AdMob ads, no analytics)
(Review against the final build and Google's current form before submitting. AdMob's own list of what it collects is at
https://developers.google.com/admob/android/privacy/play-data-disclosure — follow it if it differs from the table below.)

**Does your app collect or share any of the required user data types?** Yes (only through the Google Mobile Ads SDK).

| Data type | Collected | Shared | Purpose | Notes |
|---|---|---|---|---|
| Photos, files, camera images | No | No | — | Processed on-device only; never leave the phone. |
| Personal info (name, email, etc.) | No | No | — | No accounts. |
| Device or other IDs (advertising ID) | Yes | Yes (Google AdMob) | Advertising or marketing | Collected by the AdMob SDK. |
| Approximate location (from IP) | Yes | Yes (Google AdMob) | Advertising or marketing | Collected by the AdMob SDK. |
| App interactions / diagnostics (ad views, crashes) | Yes | Yes (Google AdMob) | Advertising, analytics | Collected by the AdMob SDK. |
| Purchases | Handled by Google Play | — | — | Purchases are not active yet; the app never stores payment info. |

- **Is all of the user data encrypted in transit?** Yes (AdMob SDK traffic uses HTTPS).
- **Can users request data deletion?** The app holds no account data. Local history can be cleared in Settings → Clear history. Ad data: users can reset/delete the advertising ID in Android settings.
- **Ads declaration:** App contains ads = **Yes**.
- **Advertising ID declaration (App content → Advertising ID):** Yes, used for Advertising or marketing. The manifest already carries `com.google.android.gms.permission.AD_ID` (added by `scripts/setup-android.mjs`).
- **Target audience:** 13+ / general. Not designed for children (do not select any child age group, so AdMob policies for children's apps do not apply).
- **Privacy policy:** re-host `store/privacy-policy.html` at the privacy URL — it now has an Advertising section.
