# Play Console "Data safety" — suggested answers
(Review against the final build and Google's current form before submitting.)

**Does your app collect or share user data?** Yes — only through the ads SDK (Google AdMob).

| Data type | Collected | Shared | Purpose | Notes |
|---|---|---|---|---|
| Device or other IDs (advertising ID) | Yes | Yes (Google AdMob) | Advertising | Collected by the AdMob SDK. Removed in the Premium version. |
| Approximate location / IP-derived | Yes (by AdMob) | Yes (Google AdMob) | Advertising | Declare if the AdMob data-safety guidance for your SDK version lists it. |
| App interactions / Diagnostics | Optional | Yes (Google AdMob) | Advertising/analytics | Follow Google's AdMob data disclosure guide. |
| Photos, files, camera images | **No** | No | — | Processed on-device only; never leave the phone. |
| Personal info (name, email, etc.) | No | No | — | No accounts. |
| Purchases | Handled by Google Play | — | — | App does not store payment info. |

- **Data encrypted in transit:** Yes (HTTPS used by ads/billing SDKs).
- **Can users request data deletion?** No account data is held. Local history can be cleared in Settings → Clear history.
- **Ads declaration:** App contains ads = Yes.
- **Target audience:** 13+ / general. Not designed for children.
