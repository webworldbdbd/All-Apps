import { Capacitor } from '@capacitor/core';
import cfg from '../config.js';
import { settings } from './store.js';

let admob = null;
let ready = false;
let bannerOn = false;
let lastInterstitial = 0;
let actions = 0;

const enabled = () => Capacitor.isNativePlatform() && cfg.ads.enabled && !settings.get('premium');

export async function initAds() {
  if (!enabled() || ready) return;
  try {
    const mod = await import('@capacitor-community/admob');
    admob = mod;
    const { AdMob } = mod;
    await AdMob.initialize();
    try {
      const info = await AdMob.requestConsentInfo();
      if (info && info.status === 'REQUIRED' && info.isConsentFormAvailable) await AdMob.showConsentForm();
    } catch { /* consent is only required in some regions */ }
    ready = true;
  } catch (e) {
    console.warn('Ads unavailable', e);
  }
}

export async function showBanner(bottomMarginDp = 64) {
  if (!ready || !enabled() || bannerOn) return;
  try {
    const { AdMob, BannerAdSize, BannerAdPosition } = admob;
    await AdMob.showBanner({
      adId: cfg.ads.bannerId,
      adSize: BannerAdSize.ADAPTIVE_BANNER,
      position: BannerAdPosition.BOTTOM_CENTER,
      margin: bottomMarginDp,
      isTesting: !!cfg.ads.testMode,
    });
    bannerOn = true;
    document.documentElement.classList.add('ads-on');
  } catch (e) { console.warn('Banner failed', e); }
}

export async function hideBanner() {
  if (!ready || !bannerOn) return;
  try { await admob.AdMob.removeBanner(); } catch { /* ignore */ }
  bannerOn = false;
  document.documentElement.classList.remove('ads-on');
}

/** Called after a completed save/share. Shows an interstitial at most every 5th action and every 4 minutes. */
export async function afterAction() {
  actions++;
  if (!ready || !enabled()) return;
  if (actions % 5 !== 0 || Date.now() - lastInterstitial < 4 * 60 * 1000) return;
  try {
    const { AdMob } = admob;
    await AdMob.prepareInterstitial({ adId: cfg.ads.interstitialId, isTesting: !!cfg.ads.testMode });
    await AdMob.showInterstitial();
    lastInterstitial = Date.now();
  } catch (e) { console.warn('Interstitial failed', e); }
}
