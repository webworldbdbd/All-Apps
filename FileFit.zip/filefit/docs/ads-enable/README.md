# Enabling AdMob later

> DONE: AdMob is now enabled in this project (see `src/core/ads.js` and `app.config.json`). This file is kept only as history.


1. `npm install @capacitor-community/admob@^8`
2. Copy `docs/ads-enable/ads.js` over `src/core/ads.js`
3. In `app.config.json` set `"ads": { "enabled": true, "testMode": false, ... }` with your REAL AdMob app id, banner id and interstitial id
4. Run `npm run android:init` again (it adds the AdMob app id and AD_ID permission to the Android project)
5. Update the privacy policy and Play Console "Data safety" / "Ads" answers to say the app shows ads (see store/data-safety.md)
6. Add the advertising section back to `src/core/legal.js` (privacy) and `store/privacy-policy.html`: the free version shows Google AdMob ads; AdMob may use the advertising ID and device information; Premium removes ads.
7. Add the `premium.f1` line ('No ads') back to the list in `premiumPage()` in `src/pages/settings.js`, and restore the premium headline text in `src/locales/en.js` / `bn.js`.
8. In `store/listing.md` change the last line to mention ads, and in Play Console set Ads = Yes.
