import { defineConfig } from 'vite';

// The pdf.js worker is a module file (.mjs). Some Android WebViews serve .mjs
// with a wrong MIME type, so we rename it to .js in the build output.
export default defineConfig({
  base: './',
  build: {
    outDir: 'dist',
    target: 'es2020',
    chunkSizeWarningLimit: 2500,
    assetsInlineLimit: 0,
    rollupOptions: {
      output: {
        assetFileNames: (info) => {
          const n = (info.names && info.names[0]) || info.name || '';
          return n.endsWith('.mjs') ? 'assets/[name]-[hash].js' : 'assets/[name]-[hash][extname]';
        },
      },
    },
  },
  server: { host: true },
});
