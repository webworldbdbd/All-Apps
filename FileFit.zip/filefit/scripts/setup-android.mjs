#!/usr/bin/env node
/**
 * One-command Android setup for FileFit.
 *   npm install
 *   npm run android:init
 * Creates the native android/ project (Capacitor), generates icons + splash from /assets,
 * and patches the manifest, AdMob id, version numbers and release signing.
 * Safe to run again at any time.
 */
import { execSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
process.chdir(root);
const cfg = JSON.parse(fs.readFileSync('app.config.json', 'utf8'));
const run = (cmd) => { console.log('\n> ' + cmd); execSync(cmd, { stdio: 'inherit' }); };
const read = (f) => fs.readFileSync(f, 'utf8');
const write = (f, s) => fs.writeFileSync(f, s);

const major = Number(process.versions.node.split('.')[0]);
if (major < 22) { console.error('Node.js 22 or newer is required (you have ' + process.versions.node + ').'); process.exit(1); }

// 1. keep capacitor.config.json in sync with app.config.json
const capCfg = JSON.parse(read('capacitor.config.json'));
capCfg.appId = cfg.appId; capCfg.appName = cfg.appName;
write('capacitor.config.json', JSON.stringify(capCfg, null, 2) + '\n');

// 2. dependencies + web build
if (!fs.existsSync('node_modules')) run('npm install');
run('npx vite build');

// 3. native project
if (!fs.existsSync('android')) run('npx cap add android');

// 4. icons + splash from /assets
try { run('npx capacitor-assets generate --android --splashBackgroundColor "#0a58f5" --splashBackgroundColorDark "#0a58f5"'); }
catch { console.warn('! Icon generation failed. Run: npx capacitor-assets generate --android'); }

// 5. AndroidManifest
const manifestPath = 'android/app/src/main/AndroidManifest.xml';
let manifest = read(manifestPath);
const needs = [
  ['android.permission.INTERNET', '<uses-permission android:name="android.permission.INTERNET" />'],
  ['android.permission.CAMERA', '<uses-permission android:name="android.permission.CAMERA" />'],
  ['android.permission.WRITE_EXTERNAL_STORAGE', '<uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" android:maxSdkVersion="28" />'],
  ['com.google.android.gms.permission.AD_ID', '<uses-permission android:name="com.google.android.gms.permission.AD_ID" />'],
  ['android.hardware.camera"', '<uses-feature android:name="android.hardware.camera" android:required="false" />'],
  ['android.hardware.camera.autofocus', '<uses-feature android:name="android.hardware.camera.autofocus" android:required="false" />'],
];
const block = needs.filter(([key]) => !manifest.includes(key)).map(([, line]) => '    ' + line).join('\n');
if (block) manifest = manifest.replace('<application', block + '\n\n    <application');
if (cfg.ads.enabled && !manifest.includes('com.google.android.gms.ads.APPLICATION_ID')) {
  manifest = manifest.replace(/<application[^>]*>/, (m) => m + '\n        <meta-data android:name="com.google.android.gms.ads.APPLICATION_ID" android:value="@string/admob_app_id" />');
}
write(manifestPath, manifest);

// 6. AdMob app id as a string resource
const stringsPath = 'android/app/src/main/res/values/strings.xml';
let strings = read(stringsPath);
strings = strings.replace(/\s*<string name="admob_app_id">[^<]*<\/string>/, '');
strings = strings.replace('</resources>', '    <string name="admob_app_id">' + cfg.ads.androidAppId + '</string>\n</resources>');
write(stringsPath, strings);

// 7. version + release signing
const gradlePath = 'android/app/build.gradle';
if (fs.existsSync(gradlePath)) {
  let g = read(gradlePath);
  g = g.replace(/versionCode\s+\d+/, 'versionCode ' + cfg.versionCode).replace(/versionName\s+"[^"]*"/, 'versionName "' + cfg.versionName + '"');
  if (!g.includes('keystore.properties')) {
    g = g.replace(/android\s*\{/, `android {
    def keystorePropertiesFile = rootProject.file("keystore.properties")
    def keystoreProperties = new Properties()
    if (keystorePropertiesFile.exists()) { keystoreProperties.load(new FileInputStream(keystorePropertiesFile)) }
    signingConfigs {
        release {
            if (keystorePropertiesFile.exists()) {
                storeFile file(keystoreProperties['storeFile'])
                storePassword keystoreProperties['storePassword']
                keyAlias keystoreProperties['keyAlias']
                keyPassword keystoreProperties['keyPassword']
            }
        }
    }`);
    g = g.replace(/buildTypes\s*\{\s*release\s*\{/, (m) => m + '\n            signingConfig keystorePropertiesFile.exists() ? signingConfigs.release : null');
  }
  write(gradlePath, g);
} else console.warn('! android/app/build.gradle not found - add signing manually (see README).');

const vars = 'android/variables.gradle';
if (fs.existsSync(vars)) {
  const m = /targetSdkVersion\s*=\s*(\d+)/.exec(read(vars));
  if (m) console.log('\nTarget SDK: ' + m[1] + (Number(m[1]) < 35 ? '  (WARNING: Google Play needs 35 or higher)' : '  (ok for Google Play)'));
}

// 8. copy web build into the native project
run('npx cap sync android');

console.log('\nDone. Next: open Android Studio with "npm run android:open", or build the bundle with "npm run android:aab".');
if (cfg.ads.testMode) console.log('Reminder: ads are in TEST mode. Set ads.testMode=false and your real AdMob ids in app.config.json before publishing, then run this script again.');
if (/YOUR-USERNAME|example\.com/.test(JSON.stringify(cfg))) console.log('Reminder: replace the placeholder email/privacy URL in app.config.json.');
