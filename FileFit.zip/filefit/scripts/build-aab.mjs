#!/usr/bin/env node
// Builds the release Android App Bundle (.aab) for Google Play.
import { execSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
process.chdir(root);
const run = (cmd, cwd) => { console.log('\n> ' + cmd); execSync(cmd, { stdio: 'inherit', cwd }); };
const cfg = JSON.parse(fs.readFileSync('app.config.json', 'utf8'));

if (!fs.existsSync('android')) { console.error('Run "npm run android:init" first.'); process.exit(1); }
if (!fs.existsSync('android/keystore.properties')) {
  console.warn('\n! android/keystore.properties not found: the bundle will be UNSIGNED and Google Play will reject it.\n  See README step "Signing key".\n');
}
if (cfg.ads.enabled && cfg.ads.testMode) console.warn('! Ads are in TEST mode (app.config.json). Fine for testing, not for release.\n');

run('npx vite build');
run('npx cap sync android');
const win = process.platform === 'win32';
run(win ? 'gradlew.bat bundleRelease' : './gradlew bundleRelease', 'android');
const aab = 'android/app/build/outputs/bundle/release/app-release.aab';
console.log(fs.existsSync(aab) ? '\nAAB ready: ' + path.resolve(aab) : '\nBuild finished but the AAB was not found at ' + aab);
