import { h } from '../core/util.js';
import { icon } from '../core/icons.js';
import { t } from '../core/i18n.js';
import { chips, toast } from '../core/ui.js';
import { createScreen } from './toolkit.js';
import { tname } from '../core/registry.js';
import { evalExpr } from '../tools/mathlib.js';
import { B, tr, fmtSig, pad2, toAscii } from '../tools/lite.js';
import { ZONES, clockIn, offsetLabel } from '../tools/specs/time.js';

function beep(times = 3) {
  try {
    const C = window.AudioContext || window.webkitAudioContext;
    const c = new C();
    for (let i = 0; i < times; i++) {
      const o = c.createOscillator(); const g = c.createGain();
      o.connect(g); g.connect(c.destination); o.frequency.value = 880; g.gain.value = 0.15;
      o.start(c.currentTime + i * 0.4); o.stop(c.currentTime + i * 0.4 + 0.25);
    }
    setTimeout(() => { try { c.close(); } catch { /* ignore */ } }, times * 400 + 400);
  } catch { /* no audio */ }
  try { if (navigator.vibrate) navigator.vibrate([300, 150, 300]); } catch { /* ignore */ }
}
const mmss = (ms) => { const s = Math.max(0, Math.ceil(ms / 1000)); const hh = Math.floor(s / 3600); const mm = Math.floor((s % 3600) / 60); return (hh ? hh + ':' : '') + pad2(mm) + ':' + pad2(s % 60); };
const num = (x) => { const n = Number(toAscii(x || '').trim()); return Number.isFinite(n) && n >= 0 ? n : 0; };

/* ------------------------------------------------------------- calculator */
const BASIC = [['C', '%', '⌫', '÷'], ['7', '8', '9', '×'], ['4', '5', '6', '−'], ['1', '2', '3', '+'], ['0', '.', '(', ')']];
const SCI = [['sin', 'cos', 'tan', '^'], ['asin', 'acos', 'atan', '!'], ['ln', 'log', '√', 'π'], ['e', 'ans', 'x²', 'DEG']];

function calculatorPage(id) {
  const sci = id === 'scientific';
  const s = createScreen(tname(id));
  let expr = ''; let ans = 0; let deg = true; let fresh = false;
  const exprEl = h('div', { class: 'calc-expr' });
  const resEl = h('div', { class: 'calc-res' });
  const degBtnRef = {};
  const show = () => {
    exprEl.textContent = expr || '0';
    exprEl.scrollLeft = exprEl.scrollWidth;
    if (!expr) { resEl.textContent = ''; return; }
    try { resEl.textContent = '= ' + fmtSig(evalExpr(expr, { deg, ans })); } catch { resEl.textContent = ''; }
  };
  const FUNCS = ['sin', 'cos', 'tan', 'asin', 'acos', 'atan', 'ln', 'log'];
  const put = (txt, isValue) => { if (fresh && isValue) expr = ''; fresh = false; expr += txt; show(); };
  function press(k) {
    if (k === 'C') { expr = ''; fresh = false; return show(); }
    if (k === '⌫') { expr = fresh ? '' : expr.replace(/[a-z]+\($|.$/i, ''); fresh = false; return show(); }
    if (k === '=') {
      try {
        const val = evalExpr(expr, { deg, ans });
        ans = val; expr = /e/i.test(String(val)) ? 'ans' : String(val); fresh = true; show();
        resEl.textContent = '';
      } catch { resEl.textContent = tr(B('Error', 'ভুল')); }
      return undefined;
    }
    if (k === 'DEG') { deg = !deg; degBtnRef.el.textContent = deg ? 'DEG' : 'RAD'; return show(); }
    if (FUNCS.includes(k)) return put(k + '(', true);
    if (k === '√') return put('sqrt(', true);
    if (k === 'x²') return put('^2', false);
    if (['π', 'e', 'ans'].includes(k)) return put(k, true);
    if (/^[0-9.(]$/.test(k)) return put(k, true);
    return put(k, false);
  }
  const key = (k, cls = '') => {
    const b = h('button', { class: 'key ' + cls, onClick: () => press(k) }, k);
    if (k === 'DEG') degBtnRef.el = b;
    return b;
  };
  const isOp = (k) => ['÷', '×', '−', '+', '%', '^', '!'].includes(k);
  const keys = [];
  if (sci) SCI.forEach((r) => r.forEach((k) => keys.push(key(k, 'fn'))));
  BASIC.forEach((r) => r.forEach((k) => keys.push(key(k, isOp(k) ? 'op' : k === 'C' || k === '⌫' ? 'fn' : ''))));
  keys.push(key('=', 'eq'));
  s.body.append(h('div', { class: 'calc' }, h('div', { class: 'calc-screen' }, exprEl, resEl), h('div', { class: 'keypad' }, keys)));
  show();
  return { el: s.root, destroy: s.destroy };
}

/* -------------------------------------------------------------- countdown */
function countdownPage(id) {
  const s = createScreen(tname(id));
  let endAt = 0; let left = 0; let running = false; let timer = null;
  const disp = h('div', { class: 'big-time' }, '00:00');
  const hh = h('input', { class: 'input', type: 'text', inputmode: 'numeric', placeholder: tr(B('Hours', 'ঘণ্টা')) });
  const mi = h('input', { class: 'input', type: 'text', inputmode: 'numeric', placeholder: tr(B('Minutes', 'মিনিট')) });
  const se = h('input', { class: 'input', type: 'text', inputmode: 'numeric', placeholder: tr(B('Seconds', 'সেকেন্ড')) });
  const startBtn = h('button', { class: 'btn primary grow' });
  const resetBtn = h('button', { class: 'btn ghost grow' }, icon('rotate', 18), tr(B('Reset', 'রিসেট')));
  const setStart = () => { startBtn.replaceChildren(icon(running ? 'x' : 'right', 18), tr(running ? B('Pause', 'থামান') : B('Start', 'শুরু'))); };
  const total = () => (num(hh.value) * 3600 + num(mi.value) * 60 + num(se.value)) * 1000;
  const tick = () => {
    left = endAt - Date.now();
    if (left <= 0) { stop(); left = 0; disp.textContent = tr(B('Time up!', 'সময় শেষ!')); disp.classList.add('done'); beep(); toast(tr(B('Time is up', 'সময় শেষ'))); return; }
    disp.textContent = mmss(left);
  };
  function stop() { running = false; clearInterval(timer); timer = null; setStart(); }
  startBtn.addEventListener('click', () => {
    if (running) { left = endAt - Date.now(); stop(); return; }
    if (!left) left = total();
    if (!left) { toast(tr(B('Set a time first', 'আগে সময় দিন'))); return; }
    disp.classList.remove('done');
    endAt = Date.now() + left; running = true; setStart(); tick(); timer = setInterval(tick, 200);
  });
  resetBtn.addEventListener('click', () => { stop(); left = 0; disp.classList.remove('done'); disp.textContent = mmss(total()); });
  const preset = (m) => { stop(); left = 0; hh.value = Math.floor(m / 60) || ''; mi.value = m % 60 || ''; se.value = ''; disp.classList.remove('done'); disp.textContent = mmss(m * 60000); };
  [hh, mi, se].forEach((el) => el.addEventListener('input', () => { if (!running) { left = 0; disp.textContent = mmss(total()); } }));
  setStart();
  s.body.append(h('div', { class: 'stack' }, disp,
    h('div', { class: 'row gap' }, [hh, mi, se].map((e) => h('div', { class: 'grow' }, e))),
    chips([1, 5, 10, 15, 30, 60].map((m) => ({ value: m, label: m + ' ' + tr(B('min', 'মিনিট')) })), '', preset),
    h('div', { class: 'row gap' }, startBtn, resetBtn),
    h('div', { class: 'hint' }, tr(B('Keep the app open. The sound plays when time is up.', 'অ্যাপ খোলা রাখুন। সময় শেষ হলে শব্দ হবে।')))));
  return { el: s.root, destroy() { clearInterval(timer); s.destroy(); } };
}

/* -------------------------------------------------------------- stopwatch */
function stopwatchPage(id) {
  const s = createScreen(tname(id));
  let running = false; let startAt = 0; let acc = 0; let timer = null; const laps = [];
  const fmtT = (ms) => { const c = Math.floor(ms / 10) % 100; const sec = Math.floor(ms / 1000) % 60; const m = Math.floor(ms / 60000); return pad2(m) + ':' + pad2(sec) + '.' + pad2(c); };
  const elapsed = () => acc + (running ? performance.now() - startAt : 0);
  const disp = h('div', { class: 'big-time' }, '00:00.00');
  const list = h('div', { class: 'stack tight' });
  const startBtn = h('button', { class: 'btn primary grow' });
  const lapBtn = h('button', { class: 'btn ghost grow' }, icon('plus', 18), tr(B('Lap', 'ল্যাপ')));
  const resetBtn = h('button', { class: 'btn ghost grow' }, icon('rotate', 18), tr(B('Reset', 'রিসেট')));
  const setStart = () => { startBtn.replaceChildren(icon(running ? 'x' : 'right', 18), tr(running ? B('Stop', 'থামান') : B('Start', 'শুরু'))); };
  const paintLaps = () => {
    list.replaceChildren(...laps.map((l, i) => h('div', { class: 'row-item static' }, h('span', { class: 'row-text' }, h('span', { class: 'row-title' }, tr(B('Lap ', 'ল্যাপ ')) + (i + 1))), h('span', { class: 'mono' }, fmtT(l.split) + '  /  ' + fmtT(l.total)))).reverse());
  };
  const loop = () => { disp.textContent = fmtT(elapsed()); };
  startBtn.addEventListener('click', () => {
    if (running) { acc = elapsed(); running = false; clearInterval(timer); } else { startAt = performance.now(); running = true; timer = setInterval(loop, 40); }
    setStart(); loop();
  });
  lapBtn.addEventListener('click', () => { if (!running) return; const tot = elapsed(); const prev = laps.length ? laps[laps.length - 1].total : 0; laps.push({ total: tot, split: tot - prev }); paintLaps(); });
  resetBtn.addEventListener('click', () => { running = false; clearInterval(timer); acc = 0; laps.length = 0; paintLaps(); setStart(); loop(); });
  setStart();
  s.body.append(h('div', { class: 'stack' }, disp, h('div', { class: 'row gap' }, startBtn, lapBtn, resetBtn), list));
  return { el: s.root, destroy() { clearInterval(timer); s.destroy(); } };
}

/* --------------------------------------------------------------- pomodoro */
function pomodoroPage(id) {
  const s = createScreen(tname(id));
  const mins = { focus: 25, short: 5, long: 15 };
  let mode = 'focus'; let endAt = 0; let left = mins.focus * 60000; let running = false; let timer = null; let done = 0;
  const disp = h('div', { class: 'big-time' }, mmss(left));
  const bar = h('div', { class: 'bar-fill' });
  const counter = h('div', { class: 'hint center' });
  const startBtn = h('button', { class: 'btn primary grow' });
  const resetBtn = h('button', { class: 'btn ghost grow' }, icon('rotate', 18), tr(B('Reset', 'রিসেট')));
  const setStart = () => { startBtn.replaceChildren(icon(running ? 'x' : 'right', 18), tr(running ? B('Pause', 'থামান') : B('Start', 'শুরু'))); };
  const paintCount = () => { counter.textContent = tr(B('Focus sessions done: ', 'সম্পন্ন ফোকাস সেশন: ')) + done; };
  const full = () => mins[mode] * 60000;
  const paint = () => { disp.textContent = mmss(left); bar.style.width = Math.max(0, Math.min(100, (1 - left / full()) * 100)) + '%'; };
  function stop() { running = false; clearInterval(timer); timer = null; setStart(); }
  function pick(m) { mode = m; stop(); left = full(); paint(); modeChips.setValue(m); }
  const tick = () => {
    left = endAt - Date.now();
    if (left <= 0) {
      stop(); beep();
      if (mode === 'focus') { done++; paintCount(); toast(tr(B('Focus done. Take a break!', 'ফোকাস শেষ। একটু বিরতি নিন!'))); pick(done % 4 === 0 ? 'long' : 'short'); } else { toast(tr(B('Break over. Back to focus!', 'বিরতি শেষ। আবার পড়ায় ফিরুন!'))); pick('focus'); }
      return;
    }
    paint();
  };
  startBtn.addEventListener('click', () => { if (running) { left = endAt - Date.now(); stop(); return; } endAt = Date.now() + left; running = true; setStart(); tick(); timer = setInterval(tick, 250); });
  resetBtn.addEventListener('click', () => pick(mode));
  const modeChips = chips([['focus', B('Focus', 'ফোকাস')], ['short', B('Short break', 'ছোট বিরতি')], ['long', B('Long break', 'লম্বা বিরতি')]].map(([value, l]) => ({ value, label: tr(l) })), mode, pick);
  const lens = ['focus', 'short', 'long'].map((m) => {
    const inp = h('input', { class: 'input', type: 'text', inputmode: 'numeric' }); inp.value = mins[m];
    inp.addEventListener('input', () => { const n = Math.min(180, Math.max(1, Math.floor(num(inp.value)))); mins[m] = n; if (!running && mode === m) { left = full(); paint(); } });
    return h('div', { class: 'grow' }, h('span', { class: 'field-label' }, tr({ focus: B('Focus (min)', 'ফোকাস (মিনিট)'), short: B('Short (min)', 'ছোট (মিনিট)'), long: B('Long (min)', 'লম্বা (মিনিট)') }[m])), inp);
  });
  setStart(); paintCount(); paint();
  s.body.append(h('div', { class: 'stack' }, modeChips, disp, h('div', { class: 'bar' }, bar), h('div', { class: 'row gap' }, startBtn, resetBtn), counter, h('div', { class: 'row gap' }, lens)));
  return { el: s.root, destroy() { clearInterval(timer); s.destroy(); } };
}

/* ------------------------------------------------------------- world clock */
function worldClockPage(id) {
  const s = createScreen(tname(id));
  const local = Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC';
  const zones = [[local, B('This device', 'এই ডিভাইস')], ...ZONES.filter(([z]) => z !== local)];
  const rows = zones.map(([tz, name]) => {
    const time = h('span', { class: 'clock-time' }); const sub = h('span', { class: 'row-sub' });
    return { tz, time, sub, el: h('div', { class: 'row-item static' }, h('span', { class: 'row-text' }, h('span', { class: 'row-title' }, tr(name)), sub), time) };
  });
  const paint = () => {
    const now = Date.now();
    rows.forEach((r) => {
      try { const c = clockIn(r.tz, now); r.time.textContent = pad2(c.h) + ':' + pad2(c.mi) + ':' + pad2(c.s); r.sub.textContent = c.d + '/' + c.m + '/' + c.y + ' · ' + offsetLabel(r.tz, now); } catch { r.time.textContent = '—'; }
    });
  };
  paint();
  const timer = setInterval(paint, 1000);
  s.body.append(h('div', { class: 'card list-card' }, rows.map((r) => r.el)));
  return { el: s.root, destroy() { clearInterval(timer); s.destroy(); } };
}

export const SPECIAL_PAGES = {
  calculator: calculatorPage, scientific: calculatorPage, countdown: countdownPage, stopwatch: stopwatchPage, pomodoro: pomodoroPage, worldclock: worldClockPage,
};
