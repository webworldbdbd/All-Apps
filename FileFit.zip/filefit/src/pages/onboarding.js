import { h } from '../core/util.js';
import { icon } from '../core/icons.js';
import { t } from '../core/i18n.js';
import { settings } from '../core/store.js';
import logo from '../assets/logo.png';
import cfg from '../config.js';

export function splashScreen() {
  return h('div', { class: 'splash' }, h('img', { src: logo, alt: 'FileFit' }), h('div', { class: 'splash-by' }, 'Powered by ' + cfg.company));
}

export function onboarding(done) {
  const slides = [
    { ic: 'compress', title: t('ob.1.t'), text: t('ob.1.d'), cls: 'c-image' },
    { ic: 'lock', title: t('ob.2.t'), text: t('ob.2.d'), cls: 'c-qr' },
    { ic: 'crown', title: t('ob.3.t'), text: t('ob.3.d'), cls: 'c-pdf' },
  ];
  let i = 0;
  const el = h('div', { class: 'onboard' });
  const paint = () => {
    const s = slides[i];
    el.replaceChildren(
      h('button', { class: 'link skip', onClick: finish }, i < slides.length - 1 ? t('ob.skip') : ''),
      h('div', { class: 'ob-art ' + s.cls }, icon(s.ic, 64)),
      h('h1', {}, s.title), h('p', { class: 'muted' }, s.text),
      h('div', { class: 'dots' }, slides.map((_, k) => h('i', { class: k === i ? 'on' : '' }))),
      h('button', { class: 'btn primary block', onClick: () => { if (i < slides.length - 1) { i++; paint(); } else finish(); } }, i < slides.length - 1 ? t('common.next') : t('ob.start')));
  };
  function finish() { settings.set('onboarded', true); done(); }
  paint();
  return el;
}
