import { h, fmtSize, fmtDate, nextFrame } from '../core/util.js';
import { icon } from '../core/icons.js';
import { t, lang } from '../core/i18n.js';
import { settings } from '../core/store.js';
import { pickFiles, saveBlob, shareBlobs } from '../core/files.js';
import { toast, appBar, emptyState, progressOverlay, errMsg } from '../core/ui.js';
import { go } from '../core/router.js';
import { session } from '../core/session.js';
import { afterAction } from '../core/ads.js';

export const batchLimit = () => (settings.get('premium') ? 50 : 20);

/** A standard tool screen: app bar + scrolling body. */
export function createScreen(title, { actions = [], back = true } = {}) {
  const root = h('div', { class: 'screen' });
  const body = h('div', { class: 'body' });
  root.append(appBar(title, { back, actions }), body);
  const cleanups = [];
  return { root, body, onDestroy: (f) => cleanups.push(f), destroy() { cleanups.forEach((f) => { try { f(); } catch { /* ignore */ } }); } };
}

export function stickyAction(label, onClick, { iconName } = {}) {
  const btn = h('button', { class: 'btn primary block', onClick }, iconName ? icon(iconName, 20) : null, label);
  return { el: h('div', { class: 'sticky-action' }, btn), btn };
}

/** File list with add/remove (and optional reordering). */
export function filePicker({ accept, multiple = true, maxFiles, kind = 'image', sortable = false, title, hint, iconName, onChange }) {
  let files = [];
  const urls = new Map();
  const el = h('div', { class: 'picker' });

  const urlFor = (f) => { if (!urls.has(f)) urls.set(f, URL.createObjectURL(f)); return urls.get(f); };
  const emit = () => onChange && onChange(files);

  async function add() {
    const picked = await pickFiles({ accept, multiple });
    if (!picked.length) return;
    let next = multiple ? files.concat(picked) : picked.slice(0, 1);
    if (maxFiles && next.length > maxFiles) {
      next = next.slice(0, maxFiles);
      toast(t('limit.files', { n: maxFiles }) + (settings.get('premium') ? '' : ' ' + t('limit.premium')));
    }
    files = next;
    render(); emit();
  }
  function remove(i) {
    const [gone] = files.splice(i, 1);
    if (urls.has(gone)) { URL.revokeObjectURL(urls.get(gone)); urls.delete(gone); }
    render(); emit();
  }
  function move(i, d) {
    const j = i + d;
    if (j < 0 || j >= files.length) return;
    [files[i], files[j]] = [files[j], files[i]];
    render(); emit();
  }
  function render() {
    el.replaceChildren();
    if (!files.length) {
      el.append(h('button', { class: 'drop', onClick: add },
        h('span', { class: 'drop-ico' }, icon(iconName || (kind === 'image' ? 'image' : 'pdf'), 34)),
        h('span', { class: 'drop-title' }, title || t('pick.files')),
        h('span', { class: 'muted small' }, hint || '')));
      return;
    }
    const list = h('div', { class: 'file-list' });
    files.forEach((f, i) => {
      list.append(h('div', { class: 'file-row' },
        h('div', { class: 'thumb' }, kind === 'image' ? h('img', { src: urlFor(f), alt: '' }) : icon('pdf', 24)),
        h('div', { class: 'meta' }, h('div', { class: 'name' }, f.name), h('div', { class: 'sub' }, fmtSize(f.size))),
        sortable ? h('div', { class: 'col' },
          h('button', { class: 'icon-btn sm', 'aria-label': 'up', disabled: i === 0 || null, onClick: () => move(i, -1) }, icon('up', 16)),
          h('button', { class: 'icon-btn sm', 'aria-label': 'down', disabled: i === files.length - 1 || null, onClick: () => move(i, 1) }, icon('down', 16))) : null,
        h('button', { class: 'icon-btn sm', 'aria-label': t('common.remove'), onClick: () => remove(i) }, icon('x', 18))));
    });
    el.append(list);
    if (multiple) el.append(h('button', { class: 'btn ghost block', onClick: add }, icon('plus', 18), t('pick.more')));
  }
  render();
  return {
    el,
    get files() { return files; },
    set(f) { files = f; render(); emit(); },
    clear() { files = []; render(); emit(); },
    destroy() { urls.forEach((u) => URL.revokeObjectURL(u)); urls.clear(); },
  };
}

/** Runs async work behind a cancellable progress overlay. Returns null on cancel/error. */
export async function runJob(titleKey, work) {
  const ac = new AbortController();
  const ov = progressOverlay(t(titleKey), () => ac.abort());
  await nextFrame();
  try {
    return await work({ signal: ac.signal, progress: (p, label) => ov.set(p, label) });
  } catch (e) {
    if (e && e.name === 'AbortError') { toast(t('job.cancelled')); return null; }
    console.error(e);
    toast(errMsg(e), 4000);
    return null;
  } finally {
    ov.close();
    settings.set('jobsDone', (settings.get('jobsDone') || 0) + 1);
  }
}

const KIND_ICON = { image: 'image', doc: 'pdf', zip: 'zip' };

/** Results list. items: [{name, blob, kind, origSize, srcBlob, note}] */
export function resultsView(items, { tool, onAgain, compare = false, summary = false }) {
  const urls = [];
  const root = h('div', { class: 'stack' });
  const totalOrig = items.reduce((s, x) => s + (x.origSize || 0), 0);
  const totalNew = items.reduce((s, x) => s + x.blob.size, 0);

  if (summary && totalOrig) {
    const pct = Math.round((1 - totalNew / totalOrig) * 100);
    root.append(h('div', { class: 'card hero-result' },
      h('div', { class: 'big' }, pct > 0 ? '−' + pct + '%' : '0%'),
      h('div', { class: 'muted' }, fmtSize(totalOrig) + ' → ' + fmtSize(totalNew))));
  }

  const rows = h('div', { class: 'file-list' });
  items.forEach((it, idx) => {
    const status = h('span', { class: 'saved-tag' });
    const saveBtn = h('button', { class: 'icon-btn', 'aria-label': t('common.save') }, icon('save', 20));
    const paint = () => {
      status.replaceChildren();
      if (it.saved) { status.append(icon('check', 14), ' ' + it.saved.label); saveBtn.classList.add('done'); }
    };
    const doSave = async () => {
      if (it.saved) return;
      try {
        it.saved = await saveBlob(it.blob, it.name, { kind: it.kind === 'image' ? 'image' : 'doc', tool, orig: it.origSize || 0 });
        paint();
        toast(t('saved.to', { where: it.saved.label }));
        afterAction();
      } catch (e) { toast(errMsg(e), 4000); }
    };
    it._save = doSave;
    saveBtn.addEventListener('click', doSave);
    let thumb;
    if (it.kind === 'image') { const u = URL.createObjectURL(it.blob); urls.push(u); thumb = h('img', { src: u, alt: '' }); }
    else thumb = icon(KIND_ICON[it.kind] || 'file', 24);
    const sizeLine = it.origSize && it.origSize !== it.blob.size
      ? fmtSize(it.origSize) + ' → ' + fmtSize(it.blob.size) + '  ' + (it.blob.size < it.origSize ? '−' + Math.round((1 - it.blob.size / it.origSize) * 100) + '%' : '')
      : fmtSize(it.blob.size);
    rows.append(h('div', { class: 'file-row result' },
      h('div', { class: 'thumb' }, thumb),
      h('div', { class: 'meta' },
        h('div', { class: 'name' }, it.name),
        h('div', { class: 'sub' }, sizeLine, it.dims ? ' • ' + it.dims : ''),
        it.note ? h('div', { class: 'note ' + (it.noteWarn ? 'warn' : '') }, t('note.' + it.note)) : null,
        status),
      h('div', { class: 'col' },
        compare && it.srcBlob ? h('button', { class: 'icon-btn', 'aria-label': t('common.compare'), onClick: () => { session.compare = { items: items.filter((x) => x.srcBlob), index: items.filter((x) => x.srcBlob).indexOf(it) }; go('/compare'); } }, icon('eye', 20)) : null,
        it.kind === 'doc' && it.blob.type === 'application/pdf' ? h('button', { class: 'icon-btn', 'aria-label': t('tool.view'), onClick: () => { session.viewPdf = it.blob; go('/pdf/view'); } }, icon('eye', 20)) : null,
        saveBtn,
        h('button', { class: 'icon-btn', 'aria-label': t('common.share'), onClick: async () => { try { await shareBlobs([{ blob: it.blob, name: it.name }]); afterAction(); } catch { /* user closed the share sheet */ } } }, icon('share', 20)))));
    paint();
    void idx;
  });
  root.append(rows);

  const saveAll = async () => { for (const it of items) await it._save(); };
  const shareAll = async () => { try { await shareBlobs(items.map((x) => ({ blob: x.blob, name: x.name }))); afterAction(); } catch { /* closed */ } };
  root.append(h('div', { class: 'row gap' },
    items.length > 1 ? h('button', { class: 'btn primary grow', onClick: saveAll }, icon('save', 18), t('common.saveAll')) : null,
    items.length > 1 ? h('button', { class: 'btn ghost grow', onClick: shareAll }, icon('share', 18), t('common.shareAll')) : null));
  root.append(h('button', { class: 'btn ghost block', onClick: onAgain }, icon('plus', 18), t('common.startOver')));

  if (settings.get('autoSave')) setTimeout(saveAll, 50);
  return { el: root, destroy() { urls.forEach((u) => URL.revokeObjectURL(u)); } };
}

export const dateLabel = (ts) => fmtDate(ts, lang());
export { emptyState };
