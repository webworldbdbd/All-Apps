import { h, fmtSize, fmtDate, stripExt, nextFrame } from '../core/util.js';
import { icon } from '../core/icons.js';
import { t, lang } from '../core/i18n.js';
import { settings } from '../core/store.js';
import { segmented, chips, field, textInput, toast, emptyState } from '../core/ui.js';
import { session } from '../core/session.js';
import { AppError } from '../core/util.js';
import { shareBlobs } from '../core/files.js';
import * as pdf from '../tools/pdf.js';
import { createScreen, filePicker, stickyAction, runJob, resultsView, batchLimit } from './toolkit.js';

const maxPixels = () => settings.get('maxMP') * 1e6;
const PDF_ACCEPT = 'application/pdf,.pdf';

/** Common frame for PDF tools. */
function frame({ titleKey, actionKey, multiple = false, sortable = false, minFiles = 1, onFiles, pickTitle, pickHint, kind = 'pdf' }) {
  const s = createScreen(t(titleKey));
  const setup = h('div', { class: 'stack' });
  const out = h('div', { class: 'stack hidden' });
  const optionsHost = h('div', { class: 'stack' });
  const picker = filePicker({
    accept: kind === 'image' ? 'image/*' : PDF_ACCEPT, multiple, kind: kind === 'image' ? 'image' : 'pdf', sortable,
    maxFiles: multiple ? (kind === 'image' ? batchLimit() : Math.min(30, batchLimit())) : 1,
    title: pickTitle || (multiple ? t('pick.pdfs') : t('pick.pdf')), hint: pickHint || '',
    onChange: (f) => { act.btn.disabled = f.length < minFiles; optionsHost.classList.toggle('hidden', !f.length); if (onFiles) onFiles(f); },
  });
  const act = stickyAction(t(actionKey), () => {});
  act.btn.disabled = true;
  optionsHost.classList.add('hidden');
  setup.append(picker.el, optionsHost);
  s.body.append(setup, out);
  s.root.append(act.el);
  s.onDestroy(() => picker.destroy());
  let rv = null;
  s.onDestroy(() => rv && rv.destroy());

  function show(items, tool, opts = {}) {
    act.el.classList.add('hidden'); setup.classList.add('hidden'); out.classList.remove('hidden');
    out.replaceChildren();
    rv = resultsView(items, { tool, compare: false, summary: !!opts.summary, onAgain: () => { rv.destroy(); out.classList.add('hidden'); setup.classList.remove('hidden'); act.el.classList.remove('hidden'); picker.clear(); } });
    out.append(rv.el);
    s.body.scrollTop = 0;
  }
  return { s, picker, optionsHost, act, show };
}

const pagesOf = async (file) => (await pdf.loadDoc(await pdf.readBytes(file))).getPageCount();

/* ----------------------------------------------------------------- img2pdf */
function img2pdfPage() {
  const f = frame({ titleKey: 'tool.img2pdf', actionKey: 'act.createPdf', multiple: true, sortable: true, kind: 'image', pickTitle: t('pick.images'), pickHint: t('pick.reorderHint') });
  const st = { size: 'a4', margin: 0, quality: 'medium' };
  f.optionsHost.append(
    field(t('opt.pageSize'), chips([{ value: 'a4', label: 'A4' }, { value: 'letter', label: 'Letter' }, { value: 'fit', label: t('opt.fitImage') }], 'a4', (v) => { st.size = v; })),
    field(t('opt.margin'), chips([{ value: 0, label: t('opt.none') }, { value: 18, label: t('opt.small') }, { value: 36, label: t('opt.medium') }], 0, (v) => { st.margin = Number(v); })),
    field(t('opt.quality'), chips([{ value: 'high', label: t('opt.high') }, { value: 'medium', label: t('opt.medium') }, { value: 'low', label: t('opt.low') }], 'medium', (v) => { st.quality = v; })));
  f.act.btn.addEventListener('click', async () => {
    const files = f.picker.files.slice();
    const blob = await runJob('job.creating', ({ signal, progress }) => pdf.imagesToPdf(files, { ...st, maxPixels: maxPixels() }, { signal, progress }));
    if (!blob) return;
    f.show([{ name: 'FileFit_' + Date.now().toString(36) + '.pdf', blob, kind: 'doc', origSize: files.reduce((s, x) => s + x.size, 0) }], 'img2pdf');
  });
  return f.s;
}

/* ------------------------------------------------------------------- merge */
function mergePage() {
  const f = frame({ titleKey: 'tool.merge', actionKey: 'act.merge', multiple: true, sortable: true, minFiles: 2, pickHint: t('pick.reorderHint') });
  f.optionsHost.append(h('p', { class: 'hint' }, t('hint.mergeOrder')));
  f.act.btn.addEventListener('click', async () => {
    const files = f.picker.files.slice();
    const blob = await runJob('job.merging', ({ signal, progress }) => pdf.mergePdfs(files, { signal, progress }));
    if (!blob) return;
    f.show([{ name: 'merged_' + Date.now().toString(36) + '.pdf', blob, kind: 'doc' }], 'merge');
  });
  return f.s;
}

/* ------------------------------------------------------------------- split */
function splitPage() {
  const st = { mode: 'each', ranges: '', zip: false, total: 0 };
  const count = h('div', { class: 'hint' }, '');
  const f = frame({ titleKey: 'tool.split', actionKey: 'act.split', onFiles: async (files) => {
    count.textContent = '';
    if (!files.length) return;
    try { st.total = await pagesOf(files[0]); count.textContent = t('info.pages') + ': ' + st.total; } catch (e) { toast(t('err.' + (e.code || 'generic'))); f.picker.clear(); }
  } });
  const rangeInput = textInput({ placeholder: '1-3, 4-6, 7-', onInput: (v) => { st.ranges = v; } });
  const rangeField = field(t('opt.ranges'), rangeInput, t('hint.splitRanges'));
  rangeField.classList.add('hidden');
  f.optionsHost.append(count,
    segmented([{ value: 'each', label: t('opt.eachPage') }, { value: 'ranges', label: t('opt.byRanges') }], 'each', (v) => { st.mode = v; rangeField.classList.toggle('hidden', v !== 'ranges'); }),
    rangeField,
    field(t('opt.output'), chips([{ value: 'files', label: t('opt.separatePdfs') }, { value: 'zip', label: t('opt.oneZip') }], 'files', (v) => { st.zip = v === 'zip'; })));
  f.act.btn.addEventListener('click', async () => {
    const file = f.picker.files[0];
    const items = await runJob('job.splitting', async ({ signal, progress }) => {
      const parts = await pdf.splitPdf(file, { mode: st.mode, ranges: st.ranges }, { signal, progress });
      if (st.zip) return [{ name: stripExt(file.name) + '_split.zip', blob: await pdf.zipFiles(parts), kind: 'zip' }];
      return parts.map((p) => ({ name: p.name, blob: p.blob, kind: 'doc' }));
    });
    if (items) f.show(items, 'split');
  });
  return f.s;
}

/* ----------------------------------------------------------------- extract */
function extractPage() {
  const st = { ranges: '' };
  const count = h('div', { class: 'hint' }, '');
  const f = frame({ titleKey: 'tool.extract', actionKey: 'act.extract', onFiles: async (files) => {
    count.textContent = '';
    if (!files.length) return;
    try { count.textContent = t('info.pages') + ': ' + (await pagesOf(files[0])); } catch (e) { toast(t('err.' + (e.code || 'generic'))); f.picker.clear(); }
  } });
  f.optionsHost.append(count, field(t('opt.pages'), textInput({ placeholder: '1, 3, 5-8', onInput: (v) => { st.ranges = v; } }), t('hint.extractPages')));
  f.act.btn.addEventListener('click', async () => {
    const file = f.picker.files[0];
    const blob = await runJob('job.extracting', () => pdf.extractPages(file, st.ranges));
    if (blob) f.show([{ name: stripExt(file.name) + '_pages.pdf', blob, kind: 'doc' }], 'extract');
  });
  return f.s;
}

/* ------------------------------------------------- organize / rotate pages */
function organizePage(mode) {
  const titleKey = mode === 'rotate' ? 'tool.pdfrotate' : 'tool.organize';
  let pages = [];
  let viewer = null;
  let alive = true;
  const grid = h('div', { class: 'page-grid' });
  const info = h('div', { class: 'hint' }, mode === 'rotate' ? t('hint.rotatePages') : t('hint.organizePages'));
  const f = frame({ titleKey, actionKey: 'act.savePdf', onFiles: async (files) => {
    grid.replaceChildren(); pages = [];
    if (viewer) { try { await viewer.dispose(); } catch { /* ignore */ } viewer = null; }
    if (!files.length) return;
    try {
      viewer = await pdf.openViewer(await pdf.readBytes(files[0]));
      if (viewer.numPages > 150) { toast(t('err.too-many-pages')); f.picker.clear(); return; }
      pages = Array.from({ length: viewer.numPages }, (_, i) => ({ index: i, rotate: 0 }));
      draw();
    } catch (e) { toast(t('err.' + (e.code || 'generic'))); f.picker.clear(); }
  } });

  function draw() {
    grid.replaceChildren();
    pages.forEach((p, i) => {
      const holder = h('div', { class: 'pg-thumb' });
      const cv = p.canvas || (p.canvas = document.createElement('canvas'));
      holder.append(cv);
      cv.style.transform = 'rotate(' + p.rotate + 'deg)';
      grid.append(h('div', { class: 'pg' },
        holder,
        h('div', { class: 'pg-bar' },
          h('span', { class: 'pg-n' }, String(p.index + 1)),
          mode === 'rotate' ? null : h('button', { class: 'icon-btn xs', 'aria-label': 'left', disabled: i === 0 || null, onClick: () => { [pages[i - 1], pages[i]] = [pages[i], pages[i - 1]]; draw(); } }, icon('left', 14)),
          mode === 'rotate' ? null : h('button', { class: 'icon-btn xs', 'aria-label': 'right', disabled: i === pages.length - 1 || null, onClick: () => { [pages[i + 1], pages[i]] = [pages[i], pages[i + 1]]; draw(); } }, icon('right', 14)),
          h('button', { class: 'icon-btn xs', 'aria-label': t('opt.right'), onClick: () => { p.rotate = (p.rotate + 90) % 360; draw(); } }, icon('rotate', 14)),
          mode === 'rotate' ? null : h('button', { class: 'icon-btn xs danger-ico', 'aria-label': t('common.remove'), onClick: () => { pages.splice(i, 1); draw(); } }, icon('trash', 14)))));
    });
    renderQueue();
  }
  let busy = false;
  async function renderQueue() {
    if (busy) return;
    busy = true;
    for (const p of pages.slice()) {
      if (!alive || !viewer) break;
      if (p.done) continue;
      try { await pdf.renderPage(viewer, p.index + 1, { width: 180, canvas: p.canvas }); p.done = true; } catch { p.done = true; }
      await nextFrame();
    }
    busy = false;
  }
  f.s.onDestroy(() => { alive = false; if (viewer) viewer.dispose(); });

  const rotAll = h('button', { class: 'btn ghost', onClick: () => { pages.forEach((p) => { p.rotate = (p.rotate + 90) % 360; }); draw(); } }, icon('rotate', 18), t('opt.rotateAll'));
  f.optionsHost.append(info, mode === 'rotate' ? rotAll : null, grid);
  f.act.btn.addEventListener('click', async () => {
    if (!pages.length) { toast(t('err.no-pages')); return; }
    const file = f.picker.files[0];
    const blob = await runJob('job.saving', () => pdf.organizePdf(file, pages.map((p) => ({ index: p.index, rotate: p.rotate }))));
    if (blob) f.show([{ name: stripExt(file.name) + (mode === 'rotate' ? '_rotated' : '_organized') + '.pdf', blob, kind: 'doc' }], mode === 'rotate' ? 'pdfrotate' : 'organize');
  });
  return f.s;
}

/* ---------------------------------------------------------------- compress */
function pdfCompressPage() {
  const st = { level: 'medium' };
  const f = frame({ titleKey: 'tool.pdfcompress', actionKey: 'act.compress' });
  const desc = h('p', { class: 'hint' }, t('pdfc.medium'));
  f.optionsHost.append(
    field(t('opt.level'), chips([{ value: 'light', label: t('opt.light') }, { value: 'medium', label: t('opt.medium') }, { value: 'strong', label: t('opt.strong') }], 'medium', (v) => { st.level = v; desc.textContent = t('pdfc.' + v); })), desc);
  f.act.btn.addEventListener('click', async () => {
    const file = f.picker.files[0];
    const r = await runJob('job.compressing', ({ signal, progress }) => pdf.compressPdf(file, st.level, { signal, progress }));
    if (!r) return;
    const keep = !r.smaller;
    f.show([{ name: keep ? file.name : stripExt(file.name) + '_compressed.pdf', blob: keep ? file : r.blob, kind: 'doc', origSize: file.size, note: keep ? 'keptOriginal' : null }], 'pdfcompress', { summary: true });
  });
  return f.s;
}

/* -------------------------------------------------------------------- view */
function viewPage() {
  const s = createScreen(t('tool.view'));
  let viewer = null;
  let current = null;
  let alive = true;
  const host = h('div', { class: 'pdf-view' });
  const meta = h('div', { class: 'hint center' }, '');
  const picker = filePicker({ accept: PDF_ACCEPT, multiple: false, kind: 'pdf', title: t('pick.pdf'), hint: '', onChange: (files) => { if (files.length) open(files[0]); else reset(); } });

  function reset() { host.replaceChildren(); meta.textContent = ''; if (viewer) { viewer.dispose(); viewer = null; } }
  async function open(blob) {
    reset(); current = blob;
    try {
      viewer = await pdf.openViewer(await pdf.readBytes(blob));
    } catch (e) { toast(t('err.' + (e.code || 'generic'))); return; }
    meta.textContent = t('info.pages') + ': ' + viewer.numPages + ' • ' + fmtSize(blob.size);
    const first = await viewer.getPage(1);
    const vp = first.getViewport({ scale: 1 });
    const width = Math.min(host.clientWidth || window.innerWidth - 24, 900);
    const ratio = vp.height / vp.width;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const io = new IntersectionObserver((entries) => {
      entries.forEach(async (en) => {
        if (!en.isIntersecting) return;
        const el = en.target;
        io.unobserve(el);
        if (!alive || !viewer) return;
        const cv = document.createElement('canvas');
        try { await pdf.renderPage(viewer, Number(el.dataset.n), { width: width * dpr, canvas: cv }); } catch { return; }
        cv.style.width = '100%'; cv.style.height = 'auto';
        el.replaceChildren(cv);
      });
    }, { rootMargin: '600px 0px' });
    for (let n = 1; n <= viewer.numPages; n++) {
      const ph = h('div', { class: 'pdf-page', 'data-n': n, style: { aspectRatio: String(vp.width / vp.height), minHeight: Math.round(width * ratio * 0.2) + 'px' } }, h('span', { class: 'muted small' }, String(n)));
      host.append(ph); io.observe(ph);
    }
    s.onDestroy(() => io.disconnect());
  }

  const shareBtn = h('button', { class: 'icon-btn', 'aria-label': t('common.share'), onClick: () => { if (current) shareBlobs([{ blob: current, name: (current.name || 'document.pdf') }]).catch(() => {}); } }, icon('share', 20));
  s.root.querySelector('.appbar-actions').append(shareBtn);
  s.body.append(picker.el, meta, host);
  s.onDestroy(() => { alive = false; picker.destroy(); if (viewer) viewer.dispose(); });
  if (session.viewPdf) { const b = session.viewPdf; session.viewPdf = null; picker.el.classList.add('hidden'); open(b); }
  return s;
}

/* -------------------------------------------------------------------- info */
function pdfInfoPage() {
  const s = createScreen(t('tool.pdfinfo'));
  const out = h('div', { class: 'stack' });
  const picker = filePicker({
    accept: PDF_ACCEPT, multiple: false, kind: 'pdf', title: t('pick.pdf'), hint: '',
    onChange: async (files) => {
      out.replaceChildren();
      if (!files.length) return;
      try {
        const i = await pdf.pdfInfo(files[0]);
        const rows = [[t('info.name'), files[0].name], [t('info.size'), fmtSize(i.size)], [t('info.pages'), String(i.pages)], [t('info.pageSize'), i.width + ' × ' + i.height + ' pt'],
          [t('info.title'), i.title || '—'], [t('info.author'), i.author || '—'], [t('info.producer'), i.producer || '—'],
          [t('info.created'), i.created ? fmtDate(i.created, lang()) : '—'], [t('info.modified'), i.modified ? fmtDate(i.modified, lang()) : '—']];
        out.append(h('div', { class: 'card list-card' }, rows.map(([k, v]) => h('div', { class: 'kv' }, h('span', { class: 'muted' }, k), h('span', { class: 'v' }, v)))));
      } catch (e) { toast(t('err.' + (e.code || 'generic'))); picker.clear(); }
    },
  });
  s.body.append(picker.el, out);
  s.onDestroy(() => picker.destroy());
  return s;
}

const PAGES = {
  img2pdf: img2pdfPage, merge: mergePage, split: splitPage, extract: extractPage,
  organize: () => organizePage('organize'), pdfrotate: () => organizePage('rotate'),
  pdfcompress: pdfCompressPage, view: viewPage, pdfinfo: pdfInfoPage,
};
export function pdfToolPage(id) {
  const s = PAGES[id]();
  return { el: s.root, destroy: s.destroy };
}
void emptyState; void AppError;
