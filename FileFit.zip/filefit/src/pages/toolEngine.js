import { h, debounce, copyText } from '../core/util.js';
import { icon } from '../core/icons.js';
import { t } from '../core/i18n.js';
import { chips, selectBox, toggleRow, toast } from '../core/ui.js';
import { createScreen } from './toolkit.js';
import { outputBox, inputBar } from './textTools.js';
import { SPECS_BY_ID } from '../tools/index.js';
import { tr, toAscii, todayISO } from '../tools/lite.js';
import { SPECIAL_PAGES } from './specialTools.js';

const fieldDiv = (label, control, hint) => h('div', { class: 'field' }, h('span', { class: 'field-label' }, label), control, hint ? h('span', { class: 'hint' }, hint) : null);

function parseNum(x) {
  const s = toAscii(x).replace(/[,\s]/g, '').replace(/[−–]/g, '-');
  if (s === '' || s === '-' || s === '.' || s === '-.') return null;
  const n = Number(s);
  return Number.isFinite(n) ? n : null;
}
const optList = (opts, v) => (typeof opts === 'function' ? opts(v) : opts).map(([value, label]) => ({ value, label: tr(label) }));
const sv = (x) => (x !== null && typeof x === 'object' ? tr(x) : String(x));

/* Editable list of rows (courses, semesters ...). */
function rowsControl(d, getVals, onChange) {
  const cols = d.cols;
  const rows = Array.from({ length: d.rows || 3 }, () => ({}));
  const list = h('div', { class: 'stack tight' });
  const head = h('div', { class: 'rowline head' }, cols.map((c) => h('span', {}, tr(c.label))), h('span', { class: 'rm' }));
  function build() {
    list.replaceChildren();
    rows.forEach((r, i) => {
      const line = h('div', { class: 'rowline' });
      cols.forEach((c) => {
        let el;
        if (c.t === 'select') {
          const opts = optList(c.opts, getVals());
          if (!opts.some((o) => o.value === r[c.k])) r[c.k] = opts[0].value;
          el = selectBox(opts, r[c.k], (val) => { r[c.k] = val; onChange(); });
        } else {
          el = h('input', { class: 'input', type: 'text', inputmode: 'decimal', placeholder: tr(c.label), autocomplete: 'off' });
          el.value = r[c.k] == null ? '' : String(r[c.k]);
          el.addEventListener('input', () => { r[c.k] = parseNum(el.value); onChange(); });
        }
        line.append(el);
      });
      line.append(h('button', { class: 'icon-btn rm', 'aria-label': t('common.remove'), onClick: () => { if (rows.length > 1) { rows.splice(i, 1); build(); onChange(); } } }, icon('x', 16)));
      list.append(line);
    });
  }
  build();
  const el = h('div', { class: 'stack tight' }, head, list,
    h('button', { class: 'btn ghost block', onClick: () => { rows.push({}); build(); } }, icon('plus', 18), tr(d.add) || t('common.add')));
  return { el, get: () => rows.map((r) => ({ ...r })), refresh: build, hasDynamic: cols.some((c) => typeof c.opts === 'function') };
}

export function genericToolPage(spec) {
  const s = createScreen(tr(spec.name));
  const v = {};
  const rowCtl = {};
  const wraps = [];
  let token = 0;

  for (const d of spec.inputs) {
    const def = typeof d.def === 'function' ? d.def() : d.def;
    if (d.t === 'number') v[d.k] = def ?? null;
    else if (d.t === 'toggle') v[d.k] = !!def;
    else if (d.t === 'date') v[d.k] = def === 'today' ? todayISO() : (def || '');
    else if (d.t === 'select' || d.t === 'chips') v[d.k] = def ?? optList(d.opts, v)[0]?.value;
    else if (d.t !== 'rows') v[d.k] = def ?? '';
  }
  const snapshot = () => { const o = { ...v }; for (const k in rowCtl) o[k] = rowCtl[k].get(); return o; };

  /* ---- result area ---- */
  const errEl = h('div', { class: 'card warn-card' });
  const swatch = h('div', { class: 'swatch' });
  const rowsHost = h('div', { class: 'stack tight' });
  const noteEl = h('div', { class: 'hint text-note' });
  const { out, bar } = outputBox(spec.id);
  const textWrap = h('div', { class: 'stack' }, fieldDiv(t('text.result'), out), bar);
  const resultWrap = h('div', { class: 'stack' }, errEl, swatch, rowsHost, textWrap, noteEl);
  const hide = (el, on) => { el.style.display = on ? 'none' : ''; };

  function paint(r) {
    rowsHost.replaceChildren();
    hide(errEl, true); hide(swatch, true); hide(textWrap, true); noteEl.textContent = '';
    if (!r) return;
    if (r.error) { errEl.textContent = tr(r.error); hide(errEl, false); return; }
    if (r.color) { swatch.style.background = r.color; hide(swatch, false); }
    if (r.rows && r.rows.length) {
      rowsHost.append(h('div', { class: 'card list-card flush' }, r.rows.map(([label, val]) => h('button', {
        class: 'row-item res-row',
        onClick: async () => { try { await copyText(sv(val)); toast(t('common.copied')); } catch { /* ignore */ } },
      }, h('span', { class: 'row-text' }, h('span', { class: 'row-sub' }, tr(label)), h('span', { class: 'res-val' }, sv(val))), icon('copy', 16)))));
      if (r.rows.length > 1) {
        rowsHost.append(h('button', { class: 'btn ghost block', onClick: async () => {
          try { await copyText(r.rows.map(([l, x]) => tr(l) + ': ' + sv(x)).join('\n')); toast(t('common.copied')); } catch { /* ignore */ }
        } }, icon('copy', 18), t('text.copyAll')));
      }
    }
    if (r.text != null && r.text !== '') { out.value = r.text; hide(textWrap, false); }
    if (r.note) noteEl.textContent = tr(r.note);
  }

  async function compute() {
    const my = ++token;
    wraps.forEach(({ d, el }) => hide(el, !!(d.when && !d.when(v))));
    let r;
    try { r = await spec.run(snapshot()); } catch (e) { r = { error: { en: 'Something went wrong. Please check the values.', bn: 'কিছু সমস্যা হয়েছে। মানগুলো দেখে নিন।' } }; }
    if (my === token) paint(r);
  }
  const computeSoon = debounce(compute, 120);
  const changed = (k) => {
    for (const rk in rowCtl) if (rk !== k && rowCtl[rk].hasDynamic) rowCtl[rk].refresh();
    computeSoon();
  };

  /* ---- inputs ---- */
  const nodes = [];
  let toggleGroup = null;
  for (const d of spec.inputs) {
    const label = tr(d.label);
    const hint = d.hint ? tr(d.hint) : '';
    let el;
    if (d.t === 'toggle') {
      const row = toggleRow({ title: label, value: v[d.k], onChange: (x) => { v[d.k] = x; changed(d.k); } });
      if (!toggleGroup) { toggleGroup = h('div', { class: 'card list-card flush' }); nodes.push(toggleGroup); wraps.push({ d: {}, el: toggleGroup }); }
      toggleGroup.append(row);
      if (d.when) wraps.push({ d, el: row });
      continue;
    }
    toggleGroup = null;
    if (d.t === 'number') {
      const inp = h('input', { class: 'input', type: 'text', inputmode: d.neg ? 'text' : 'decimal', placeholder: d.ph || '', autocomplete: 'off' });
      inp.value = v[d.k] == null ? '' : String(v[d.k]);
      inp.addEventListener('input', () => { v[d.k] = parseNum(inp.value); changed(d.k); });
      el = fieldDiv(label, inp, hint);
    } else if (d.t === 'text') {
      const inp = h('input', { class: 'input', type: 'text', placeholder: d.ph || '', autocomplete: 'off', autocapitalize: 'off', spellcheck: 'false' });
      inp.value = v[d.k];
      inp.addEventListener('input', () => { v[d.k] = inp.value; changed(d.k); });
      el = fieldDiv(label, inp, hint);
    } else if (d.t === 'area') {
      const area = h('textarea', { class: 'input text-area', rows: d.rows || 6, placeholder: d.ph || t('text.inputHere'), spellcheck: 'false', autocapitalize: 'off' });
      area.value = v[d.k];
      area.addEventListener('input', () => { v[d.k] = area.value; changed(d.k); });
      el = h('div', { class: 'stack tight' }, fieldDiv(label, area, hint), d.paste ? inputBar(area, () => { v[d.k] = area.value; changed(d.k); }) : null);
    } else if (d.t === 'select') {
      el = fieldDiv(label, selectBox(optList(d.opts, v), v[d.k], (x) => { v[d.k] = x; changed(d.k); }), hint);
    } else if (d.t === 'chips') {
      el = fieldDiv(label, chips(optList(d.opts, v), v[d.k], (x) => { v[d.k] = x; changed(d.k); }), hint);
    } else if (d.t === 'date' || d.t === 'time') {
      const inp = h('input', { class: 'input', type: d.t });
      inp.value = v[d.k];
      const on = () => { v[d.k] = inp.value; changed(d.k); };
      inp.addEventListener('input', on); inp.addEventListener('change', on);
      el = fieldDiv(label, inp, hint);
    } else if (d.t === 'rows') {
      const ctl = rowsControl(d, snapshot, () => changed(d.k));
      rowCtl[d.k] = ctl;
      el = fieldDiv(label, ctl.el, hint);
    }
    nodes.push(el);
    wraps.push({ d, el });
  }

  const action = spec.action ? h('button', { class: 'btn primary block', onClick: compute }, icon('rotate', 18), tr(spec.action)) : null;
  s.body.append(h('div', { class: 'stack' }, ...nodes, action, resultWrap));
  compute();
  return { el: s.root, destroy: s.destroy };
}

export function toolPage(id) {
  if (SPECIAL_PAGES[id]) return SPECIAL_PAGES[id](id);
  const spec = SPECS_BY_ID[id];
  if (!spec) { location.replace('#/tools'); return h('div'); }
  return genericToolPage(spec);
}
