import { h, fmtSize } from '../core/util.js';
import { icon } from '../core/icons.js';
import { t } from '../core/i18n.js';
import { session } from '../core/session.js';
import { go } from '../core/router.js';
import { createScreen } from './toolkit.js';

export function comparePage() {
  const data = session.compare;
  const s = createScreen(t('compare.title'));
  if (!data || !data.items.length) { setTimeout(() => go('/home'), 0); return { el: s.root, destroy: s.destroy }; }
  let idx = Math.max(0, data.index);
  const urls = [];
  const stage = h('div', { class: 'cmp' });
  const info = h('div', { class: 'cmp-info' });
  const nav = h('div', { class: 'row gap center-row' });

  function paint() {
    urls.splice(0).forEach((u) => URL.revokeObjectURL(u));
    const it = data.items[idx];
    const before = URL.createObjectURL(it.srcBlob), after = URL.createObjectURL(it.blob);
    urls.push(before, after);
    const imgB = h('img', { src: before, alt: '' }), imgA = h('img', { src: after, alt: '', class: 'cmp-after' });
    const range = h('input', { type: 'range', min: 0, max: 100, value: 50, class: 'cmp-range', 'aria-label': t('compare.slider') });
    const line = h('div', { class: 'cmp-line' }, h('span', {}, icon('left', 14), icon('right', 14)));
    const set = (v) => { imgA.style.clipPath = 'inset(0 0 0 ' + v + '%)'; line.style.left = v + '%'; };
    range.addEventListener('input', () => set(range.value));
    set(50);
    stage.replaceChildren(imgB, imgA, line, range, h('span', { class: 'cmp-tag l' }, t('compare.before')), h('span', { class: 'cmp-tag r' }, t('compare.after')));
    const pct = it.srcBlob.size ? Math.round((1 - it.blob.size / it.srcBlob.size) * 100) : 0;
    info.replaceChildren(
      h('div', { class: 'cmp-name ellipsis' }, it.name),
      h('div', { class: 'cmp-stats' },
        h('div', {}, h('span', { class: 'muted small' }, t('compare.before')), h('b', {}, fmtSize(it.srcBlob.size))),
        h('div', {}, h('span', { class: 'muted small' }, t('compare.after')), h('b', {}, fmtSize(it.blob.size))),
        h('div', {}, h('span', { class: 'muted small' }, t('compare.saved')), h('b', { class: pct > 0 ? 'good' : '' }, pct > 0 ? '−' + pct + '%' : '0%'))),
      it.dims ? h('div', { class: 'muted small center' }, it.dims + ' px') : null);
    nav.replaceChildren(
      data.items.length > 1 ? h('button', { class: 'btn ghost', disabled: idx === 0 || null, onClick: () => { idx--; paint(); } }, icon('left', 18), t('common.prev')) : null,
      data.items.length > 1 ? h('span', { class: 'muted' }, (idx + 1) + ' / ' + data.items.length) : null,
      data.items.length > 1 ? h('button', { class: 'btn ghost', disabled: idx === data.items.length - 1 || null, onClick: () => { idx++; paint(); } }, t('common.next'), icon('right', 18)) : null);
  }
  paint();
  s.body.append(stage, info, nav);
  s.onDestroy(() => urls.forEach((u) => URL.revokeObjectURL(u)));
  return { el: s.root, destroy: s.destroy };
}
