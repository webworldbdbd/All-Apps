import { h, fmtSize, fmtDate } from '../core/util.js';
import { icon } from '../core/icons.js';
import { t, lang } from '../core/i18n.js';
import { settings, history, onChange } from '../core/store.js';
import { go } from '../core/router.js';
import { goBack } from '../core/ui.js';
import { TOOLS, CATS, QUICK, toolsOf } from '../core/registry.js';
import logo from '../assets/logo.png';

const CAT_CLASS = { image: 'c-image', pdf: 'c-pdf', qr: 'c-qr' };
const toolOf = (id) => TOOLS.find((x) => x.id === id);

export function toolTile(tool) {
  return h('button', { class: 'tile ' + CAT_CLASS[tool.cat], onClick: () => go(tool.route) },
    h('span', { class: 'tile-ico' }, icon(tool.icon, 26)),
    h('span', { class: 'tile-name' }, t('tool.' + tool.id)));
}

export function fileIcon(mime, name = '') {
  if ((mime || '').startsWith('image/')) return 'image';
  if ((mime || '').includes('pdf') || /\.pdf$/i.test(name)) return 'pdf';
  if (/zip/.test(mime || '') || /\.zip$/i.test(name)) return 'zip';
  return 'file';
}

export function homePage() {
  const root = h('div', { class: 'screen home' });
  const body = h('div', { class: 'body' });
  const saved = history.bytesSaved();
  const premium = settings.get('premium');

  const top = h('div', { class: 'home-top' },
    h('img', { class: 'brand-logo', src: logo, alt: 'FileFit' }),
    h('div', { class: 'brand-text' }, h('div', { class: 'brand-name' }, 'File', h('span', {}, 'Fit')), h('div', { class: 'muted small' }, t('app.tagline'))),
    premium ? null : h('button', { class: 'icon-btn crown', 'aria-label': t('premium.title'), onClick: () => go('/premium') }, icon('crown', 22)));

  const hero = h('div', { class: 'hero' },
    h('div', { class: 'hero-num' }, saved > 0 ? fmtSize(saved) : '0 MB'),
    h('div', { class: 'hero-label' }, t('home.saved')),
    h('div', { class: 'hero-pill' }, icon('lock', 14), t('home.onDevice')));

  const cats = h('div', { class: 'cat-grid' }, CATS.map((c) => h('button', { class: 'cat-card ' + CAT_CLASS[c.id], onClick: () => go(c.route) },
    h('span', { class: 'cat-ico' }, icon(c.icon, 28)),
    h('span', { class: 'cat-name' }, t('cat.' + c.id)),
    h('span', { class: 'cat-count' }, t('home.tools', { n: toolsOf(c.id).length })))));

  const quick = h('div', { class: 'tile-grid' }, QUICK.map((id) => toolTile(toolOf(id))));

  const recentHost = h('div', { class: 'stack' });
  const paintRecent = () => {
    recentHost.replaceChildren();
    const list = history.list().slice(0, 3);
    if (!list.length) return;
    recentHost.append(h('div', { class: 'section-head' }, h('h2', {}, t('home.recent')), h('button', { class: 'link', onClick: () => go('/files') }, t('common.viewAll'))),
      h('div', { class: 'card list-card' }, list.map((e) => h('div', { class: 'recent-row' },
        h('span', { class: 'row-ico' }, icon(fileIcon(e.mime, e.name), 20)),
        h('span', { class: 'row-text' }, h('span', { class: 'row-title ellipsis' }, e.name), h('span', { class: 'row-sub' }, fmtSize(e.size) + ' • ' + fmtDate(e.time, lang())))))));
  };
  paintRecent();
  const off = onChange((w) => { if (w === 'history') paintRecent(); });

  body.append(top, hero, h('div', { class: 'section-head' }, h('h2', {}, t('home.categories'))), cats,
    h('div', { class: 'section-head' }, h('h2', {}, t('home.quick'))), quick, recentHost);
  root.append(body);
  return { el: root, destroy: off };
}

export function toolsPage() {
  const root = h('div', { class: 'screen' });
  const body = h('div', { class: 'body' });
  const list = h('div', { class: 'stack' });
  const input = h('input', { class: 'input search', type: 'search', placeholder: t('tools.search') });
  const paint = () => {
    const q = input.value.trim().toLowerCase();
    list.replaceChildren();
    for (const c of CATS) {
      const catHit = q && t('cat.' + c.id).toLowerCase().includes(q);
      const items = toolsOf(c.id).filter((x) => !q || catHit || t('tool.' + x.id).toLowerCase().includes(q) || t('tool.' + x.id + '.d').toLowerCase().includes(q));
      if (!items.length) continue;
      list.append(h('div', { class: 'section-head' }, h('h2', {}, t('cat.' + c.id)), h('span', { class: 'muted small' }, t('home.tools', { n: items.length }))),
        h('div', { class: 'tile-grid' }, items.map(toolTile)));
    }
    if (!list.children.length) list.append(h('p', { class: 'muted center' }, t('tools.none')));
  };
  input.addEventListener('input', paint);
  paint();
  body.append(h('h1', { class: 'page-title' }, t('nav.tools')), h('div', { class: 'search-wrap' }, icon('search', 18), input), list);
  root.append(body);
  return root;
}

export function categoryPage(catId) {
  const root = h('div', { class: 'screen' });
  const bar = h('header', { class: 'appbar' }, h('button', { class: 'icon-btn', onClick: goBack }, icon('back')), h('h1', {}, t('cat.' + catId)), h('div', { class: 'appbar-actions' }));
  const body = h('div', { class: 'body' });
  body.append(h('div', { class: 'stack' }, toolsOf(catId).map((x) => h('button', { class: 'row-item big ' + CAT_CLASS[x.cat], onClick: () => go(x.route) },
    h('span', { class: 'row-ico tinted' }, icon(x.icon, 22)),
    h('span', { class: 'row-text' }, h('span', { class: 'row-title' }, t('tool.' + x.id)), h('span', { class: 'row-sub' }, t('tool.' + x.id + '.d'))),
    icon('right', 18, 'faint')))));
  root.append(bar, body);
  return root;
}
