import { h, copyText, debounce, safeName } from '../core/util.js';
import { icon } from '../core/icons.js';
import { t } from '../core/i18n.js';
import { chips, field, toggleRow, toast, errMsg, numberInput } from '../core/ui.js';
import { saveBlob, shareText } from '../core/files.js';
import { tname } from '../core/registry.js';
import { afterAction } from '../core/ads.js';
import { createScreen } from './toolkit.js';
import * as tx from '../tools/text.js';

/* ------------------------------------------------------------- shared bits */
export function inputBox(placeholder, onInput, rows = 7) {
  const el = h('textarea', { class: 'input text-area', rows, placeholder, spellcheck: 'false', autocapitalize: 'off' });
  el.addEventListener('input', () => onInput(el.value));
  return el;
}

export function inputBar(area, onChange) {
  return h('div', { class: 'row gap' },
    h('button', { class: 'btn ghost grow', onClick: async () => {
      try {
        const txt = await navigator.clipboard.readText();
        if (txt) { area.value = txt; onChange(); } else toast(t('text.clipEmpty'));
      } catch { toast(t('text.pasteHint')); }
    } }, icon('copy', 18), t('text.paste')),
    h('button', { class: 'btn ghost grow', onClick: () => { area.value = ''; onChange(); area.focus(); } }, icon('x', 18), t('text.clear')));
}

export function outputBox(toolId) {
  const out = h('textarea', { class: 'input text-area', rows: 7, readonly: true, placeholder: t('text.resultHere') });
  const getText = () => out.value;
  const need = () => { if (!getText()) { toast(t('text.nothing')); return false; } return true; };
  const bar = h('div', { class: 'row gap' },
    h('button', { class: 'btn primary grow', onClick: async () => {
      if (!need()) return;
      try { await copyText(getText()); toast(t('common.copied')); } catch { toast(t('err.generic')); }
    } }, icon('copy', 18), t('common.copy')),
    h('button', { class: 'btn ghost grow', onClick: async () => {
      if (!need()) return;
      try {
        const blob = new Blob([getText()], { type: 'text/plain' });
        const r = await saveBlob(blob, safeName(tname(toolId)) + '.txt', { kind: 'doc', tool: toolId });
        toast(t('saved.to', { where: r.label })); afterAction();
      } catch (e) { toast(errMsg(e), 4000); }
    } }, icon('save', 18), t('common.save')),
    h('button', { class: 'btn ghost icon-only', 'aria-label': t('common.share'), onClick: async () => {
      if (!need()) return;
      try { await shareText(getText(), tname(toolId)); afterAction(); } catch { /* closed */ }
    } }, icon('share', 18)));
  return { out, bar };
}

export const optionBlock = (defs, state, run) => {
  const nodes = [];
  const toggles = [];
  for (const d of defs) {
    if (d.type === 'chips') {
      nodes.push(field(d.label, chips(d.choices.map((c) => ({ value: c, label: t(d.prefix + c) })), state[d.key], (v) => { state[d.key] = v; run(); })));
    } else if (d.type === 'text') {
      const el = h('input', { class: 'input', type: 'text', placeholder: d.placeholder || '', autocomplete: 'off', autocapitalize: 'off', spellcheck: 'false' });
      el.value = state[d.key] || '';
      el.addEventListener('input', () => { state[d.key] = el.value; run(); });
      nodes.push(field(d.label, el));
    } else {
      toggles.push(toggleRow({ title: d.label, value: state[d.key], onChange: (v) => { state[d.key] = v; run(); } }));
    }
  }
  if (toggles.length) nodes.push(h('div', { class: 'card list-card flush' }, toggles));
  return nodes;
};

/* ------------------------------------------------------- generic transform */
const SPECS = {
  dedupe: {
    opts: [
      { key: 'ignoreCase', type: 'toggle', def: true, label: 'text.o.ignoreCase' },
      { key: 'trim', type: 'toggle', def: true, label: 'text.o.trim' },
      { key: 'removeEmpty', type: 'toggle', def: true, label: 'text.o.removeEmpty' },
    ],
    run: (s, o) => { const r = tx.dedupeLines(s, o); return { text: r.text, note: t('text.n.dedupe', { removed: r.removed, left: r.left }) }; },
  },
  sortlines: {
    opts: [
      { key: 'mode', type: 'chips', def: 'az', choices: ['az', 'za', 'short', 'long', 'num', 'random', 'flip'], prefix: 'text.sort.', label: 'text.o.order' },
      { key: 'ignoreCase', type: 'toggle', def: true, label: 'text.o.ignoreCase' },
      { key: 'removeEmpty', type: 'toggle', def: true, label: 'text.o.removeEmpty' },
    ],
    run: (s, o) => ({ text: tx.sortLines(s, o) }),
  },
  casechange: {
    opts: [{ key: 'mode', type: 'chips', def: 'upper', choices: ['upper', 'lower', 'title', 'sentence', 'swap'], prefix: 'text.case.', label: 'text.o.style' }],
    run: (s, o) => ({ text: tx.changeCase(s, o.mode) }),
  },
  cleantext: {
    opts: [
      { key: 'trimLines', type: 'toggle', def: true, label: 'text.o.trimLines' },
      { key: 'collapse', type: 'toggle', def: true, label: 'text.o.collapse' },
      { key: 'emptyLines', type: 'toggle', def: false, label: 'text.o.removeEmpty' },
      { key: 'joinLines', type: 'toggle', def: false, label: 'text.o.joinLines' },
    ],
    run: (s, o) => ({ text: tx.cleanText(s, o) }),
  },
  reversetext: {
    opts: [{ key: 'mode', type: 'chips', def: 'chars', choices: ['chars', 'words', 'lines'], prefix: 'text.rev.', label: 'text.o.reverseBy' }],
    run: (s, o) => ({ text: tx.reverseText(s, o.mode) }),
  },
  slug: {
    opts: [
      { key: 'sep', type: 'chips', def: '-', choices: ['-', '_'], prefix: 'text.sep.', label: 'text.o.separator' },
      { key: 'lower', type: 'toggle', def: true, label: 'text.o.lowercase' },
    ],
    run: (s, o) => ({ text: tx.slugify(s, o) }),
  },
  dedupewords: {
    opts: [{ key: 'ignoreCase', type: 'toggle', def: true, label: 'text.o.ignoreCase' }],
    run: (s, o) => { const r = tx.dedupeWords(s, o); return { text: r.text, note: t('text.n.dedupeWords', { removed: r.removed }) }; },
  },
  findreplace: {
    opts: [
      { key: 'find', type: 'text', def: '', label: 'text.o.find' },
      { key: 'rep', type: 'text', def: '', label: 'text.o.replace' },
      { key: 'caseSensitive', type: 'toggle', def: false, label: 'text.o.caseSensitive' },
      { key: 'whole', type: 'toggle', def: false, label: 'text.o.wholeWord' },
      { key: 'regex', type: 'toggle', def: false, label: 'text.o.regex' },
    ],
    run: (s, o) => {
      if (!o.find) return { text: s };
      try { const r = tx.findReplace(s, o.find, o.rep, o); return { text: r.text, note: t('text.n.replaced', { n: r.count }) }; }
      catch { return { text: '', note: t('text.n.badRegex'), bad: true }; }
    },
  },
};

function transformPage(id) {
  const spec = SPECS[id];
  const s = createScreen(tname(id));
  const state = Object.fromEntries(spec.opts.map((d) => [d.key, d.def]));
  const note = h('div', { class: 'hint text-note' });
  const { out, bar } = outputBox(id);
  let area;
  const run = () => {
    const r = spec.run(area.value, state);
    out.value = r.text;
    note.textContent = r.note || '';
    note.classList.toggle('warn', !!r.bad);
  };
  const runSoon = debounce(run, 120);
  area = inputBox(t('text.inputHere'), runSoon);
  const defs = spec.opts.map((d) => ({ ...d, label: t(d.label) }));
  s.body.append(h('div', { class: 'stack' },
    field(t('text.input'), area), inputBar(area, run),
    ...optionBlock(defs, state, run),
    field(t('text.result'), out), note, bar));
  return { el: s.root, destroy: s.destroy };
}

/* ------------------------------------------------------------ word counter */
function fmtMin(m) {
  if (m < 1 / 60) return '0 ' + t('text.sec');
  if (m < 1) return Math.max(1, Math.round(m * 60)) + ' ' + t('text.sec');
  return Math.round(m) + ' ' + t('text.min');
}

function wordCountPage() {
  const s = createScreen(t('tool.wordcount'));
  const cells = {};
  const keys = ['words', 'chars', 'noSpace', 'sentences', 'paragraphs', 'lines'];
  const grid = h('div', { class: 'stat-grid' }, keys.map((k) => {
    const v = h('b', {}, '0');
    cells[k] = v;
    return h('div', { class: 'card stat' }, v, h('span', {}, t('text.stat.' + k)));
  }));
  const read = h('b', {}, '0');
  const speak = h('b', {}, '0');
  const times = h('div', { class: 'card list-card' },
    h('div', { class: 'row-item static flat' }, h('span', { class: 'row-ico' }, icon('eye', 20)), h('span', { class: 'row-text' }, h('span', { class: 'row-title' }, t('text.stat.read'))), read),
    h('div', { class: 'row-item static flat' }, h('span', { class: 'row-ico' }, icon('sms', 20)), h('span', { class: 'row-text' }, h('span', { class: 'row-title' }, t('text.stat.speak'))), speak));
  let area;
  const run = () => {
    const r = tx.stats(area.value);
    keys.forEach((k) => { cells[k].textContent = r[k].toLocaleString(); });
    read.textContent = fmtMin(r.readMin);
    speak.textContent = fmtMin(r.speakMin);
  };
  area = inputBox(t('text.inputHere'), run, 9);
  s.body.append(h('div', { class: 'stack' }, field(t('text.input'), area), inputBar(area, run), grid, times));
  return { el: s.root, destroy: s.destroy };
}

/* ------------------------------------------------------------------- lorem */
function loremPage() {
  const s = createScreen(t('tool.lorem'));
  const st = { unit: 'paragraphs', count: 3, classic: true };
  const { out, bar } = outputBox('lorem');
  out.rows = 12;
  const gen = () => { out.value = tx.lorem(st.unit, st.count, st.classic); };
  const num = numberInput({ value: st.count, min: 1, max: 1000, onInput: (v) => { st.count = v || 1; gen(); } });
  s.body.append(h('div', { class: 'stack' },
    field(t('text.o.unit'), chips(['paragraphs', 'sentences', 'words'].map((u) => ({ value: u, label: t('text.lorem.' + u) })), st.unit, (v) => { st.unit = v; gen(); })),
    field(t('text.o.count'), num),
    h('div', { class: 'card list-card flush' }, toggleRow({ title: t('text.o.classic'), value: st.classic, onChange: (v) => { st.classic = v; gen(); } })),
    h('button', { class: 'btn primary block', onClick: gen }, icon('rotate', 18), t('text.generate')),
    field(t('text.result'), out), bar));
  gen();
  return { el: s.root, destroy: s.destroy };
}

export function textToolPage(id) {
  if (id === 'wordcount') return wordCountPage();
  if (id === 'lorem') return loremPage();
  return transformPage(id);
}
export const TEXT_IDS = ['wordcount', 'dedupe', 'sortlines', 'findreplace', 'casechange', 'cleantext', 'reversetext', 'slug', 'lorem', 'dedupewords'];
