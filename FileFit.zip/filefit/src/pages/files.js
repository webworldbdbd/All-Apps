import { h, fmtSize, fmtDate } from '../core/util.js';
import { icon } from '../core/icons.js';
import { tname } from '../core/registry.js';
import { t, lang } from '../core/i18n.js';
import { history, onChange } from '../core/store.js';
import { segmented, toast, sheet, confirmDialog, emptyState, navRow, errMsg } from '../core/ui.js';
import { listSaved, readSaved, deleteSaved, shareBlobs, clearTemp, isNative, pickFiles } from '../core/files.js';
import { go } from '../core/router.js';
import { session } from '../core/session.js';
import { fileIcon } from './home.js';

const TOOL_NAME = (id) => (id && tname(id) !== 'tool.' + id ? tname(id) : '');

export function filesPage() {
  const root = h('div', { class: 'screen' });
  const body = h('div', { class: 'body' });
  const state = { tab: 'recent', q: '' };
  const list = h('div', { class: 'stack' });
  let savedCache = null;

  const search = h('input', { class: 'input search', type: 'search', placeholder: t('files.search') });
  search.addEventListener('input', () => { state.q = search.value.trim().toLowerCase(); paint(); });
  const seg = segmented([{ value: 'recent', label: t('files.recent') }, { value: 'fav', label: t('files.favorites') }, { value: 'saved', label: t('files.saved') }], 'recent', (v) => { state.tab = v; paint(); });

  async function items() {
    if (state.tab === 'recent') return history.list();
    if (state.tab === 'fav') return history.favorites();
    if (!savedCache) savedCache = await listSaved();
    return savedCache.map((x) => ({ ...x, mime: undefined, ...(history.find(x.path, x.dir) || {}), saved: true }));
  }

  async function paint() {
    let rows = await items();
    if (state.q) rows = rows.filter((e) => e.name.toLowerCase().includes(state.q));
    list.replaceChildren();
    if (!rows.length) {
      list.append(emptyState(state.tab === 'fav' ? 'star' : 'folder', t('files.empty.' + state.tab), t('files.emptyHint')));
      return;
    }
    const kindOf = (e) => (/\.(jpe?g|png|webp|gif|heic)$/i.test(e.name) || (e.mime || '').startsWith('image/') ? 'images'
      : /\.pdf$/i.test(e.name) || (e.mime || '').includes('pdf') ? 'pdfs' : 'other');
    const rowEl = (e) => h('button', { class: 'row-item', onClick: () => openSheet(e) },
      h('span', { class: 'row-ico' }, icon(fileIcon(e.mime, e.name), 20)),
      h('span', { class: 'row-text' }, h('span', { class: 'row-title ellipsis' }, e.name),
        h('span', { class: 'row-sub' }, [fmtSize(e.size), e.time ? fmtDate(e.time, lang()) : '', TOOL_NAME(e.tool)].filter(Boolean).join(' • '))),
      e.fav ? h('span', { class: 'fav-on' }, icon('star', 16)) : null);
    for (const g of ['images', 'pdfs', 'other']) {
      const part = rows.filter((e) => kindOf(e) === g);
      if (!part.length) continue;
      list.append(h('div', { class: 'section-head' }, h('h2', {}, t('files.g.' + g)), h('span', { class: 'muted small' }, String(part.length))), ...part.map(rowEl));
    }
  }


  async function openPhoneFile(accept) {
    const [file] = await pickFiles({ accept, multiple: false });
    if (!file) return;
    if (/\.pdf$/i.test(file.name) || file.type === 'application/pdf') { session.viewPdf = file; go('/pdf/view'); return; }
    if ((file.type || '').startsWith('image/')) {
      const u = URL.createObjectURL(file);
      sheet({ title: file.name, body: h('img', { class: 'preview-img', src: u, alt: '' }), onClose: () => URL.revokeObjectURL(u) });
      return;
    }
    shareBlobs([{ blob: file, name: file.name }]).catch(() => {});
  }
  const browseCard = h('div', { class: 'card stack tight' },
    h('div', { class: 'muted small' }, t('files.browseHint')),
    h('div', { class: 'row gap' },
      h('button', { class: 'btn ghost grow', onClick: () => openPhoneFile('image/*') }, icon('image', 18), t('files.g.images')),
      h('button', { class: 'btn ghost grow', onClick: () => openPhoneFile('application/pdf,.pdf') }, icon('pdf', 18), t('files.g.pdfs')),
      h('button', { class: 'btn ghost grow', onClick: () => openPhoneFile('*/*') }, icon('file', 18), t('files.g.other'))));

  async function openBlob(e) {
    try { return await readSaved(e.path, e.dir); } catch (err) { toast(errMsg(err)); return null; }
  }

  function openSheet(e) {
    const s = sheet({ title: e.name, body: null });
    const isImg = /\.(jpe?g|png|webp)$/i.test(e.name);
    const isPdf = /\.pdf$/i.test(e.name);
    const entry = history.find(e.path, e.dir);
    const box = s.el.querySelector('.sheet-body');
    box.append(h('div', { class: 'stack tight' },
      isImg || isPdf ? navRow({ iconName: 'eye', title: t('files.open'), onClick: async () => {
        s.close(); const b = await openBlob(e); if (!b) return;
        if (isPdf) { session.viewPdf = b; go('/pdf/view'); }
        else { const u = URL.createObjectURL(b); const ps = sheet({ title: e.name, body: h('img', { class: 'preview-img', src: u, alt: '' }), onClose: () => URL.revokeObjectURL(u) }); void ps; }
      } }) : null,
      navRow({ iconName: 'share', title: t('common.share'), onClick: async () => { s.close(); const b = await openBlob(e); if (b) shareBlobs([{ blob: b, name: e.name }]).catch(() => {}); } }),
      entry ? navRow({ iconName: 'star', title: entry.fav ? t('files.unfav') : t('files.fav'), onClick: () => { history.toggleFav(entry.id); s.close(); paint(); } }) : null,
      navRow({ iconName: 'info', title: t('files.details'), onClick: () => {
        s.close();
        sheet({ title: t('files.details'), body: h('div', { class: 'card list-card' }, [
          [t('info.name'), e.name], [t('info.size'), fmtSize(e.size)], [t('files.location'), (e.dir === 'pictures' ? 'Pictures/FileFit' : e.dir === 'documents' ? 'Documents/FileFit' : '—')], [t('info.modified'), e.time ? fmtDate(e.time, lang()) : '—'],
        ].map(([k, v]) => h('div', { class: 'kv' }, h('span', { class: 'muted' }, k), h('span', { class: 'v' }, v)))) });
      } }),
      navRow({ iconName: 'trash', title: t('common.delete'), onClick: async () => {
        s.close();
        if (!(await confirmDialog({ title: t('files.deleteQ'), message: e.name, confirmText: t('common.delete'), danger: true }))) return;
        if (e.dir && e.dir !== 'web') await deleteSaved(e.path, e.dir); else history.remove(e.id);
        savedCache = null; paint();
      } })));
  }

  const footer = h('div', { class: 'card stack tight' },
    h('div', { class: 'muted small' }, isNative ? t('files.folderInfo') : t('files.webInfo')),
    h('button', { class: 'btn ghost block', onClick: async () => { await clearTemp(); toast(t('settings.tempCleared')); } }, icon('trash', 18), t('settings.clearTemp')));

  const off = onChange((w) => { if (w === 'history') { savedCache = null; paint(); } });
  body.append(h('h1', { class: 'page-title' }, t('nav.files')), h('div', { class: 'search-wrap' }, icon('search', 18), search), browseCard, seg, list, footer);
  root.append(body);
  paint();
  return { el: root, destroy: off };
}
