import { h, fmtSize, fmtDate, debounce, stripExt } from '../core/util.js';
import { icon } from '../core/icons.js';
import { t, lang } from '../core/i18n.js';
import { settings } from '../core/store.js';
import { segmented, chips, field, slider, selectBox, numberInput, toast, toggleRow } from '../core/ui.js';
import { processImage, imageInfo, createCropper, fmtOfFile } from '../tools/image.js';
import { createScreen, filePicker, stickyAction, runJob, resultsView, batchLimit } from './toolkit.js';

const maxPixels = () => settings.get('maxMP') * 1e6;
const fmtOptions = (withOriginal = true) => [
  ...(withOriginal ? [{ value: 'original', label: t('fmt.original') }] : []),
  { value: 'jpg', label: 'JPG' }, { value: 'png', label: 'PNG' }, { value: 'webp', label: 'WebP' },
];

function peekDims(file) {
  return new Promise((res) => {
    const u = URL.createObjectURL(file);
    const i = new Image();
    i.onload = () => { res({ w: i.naturalWidth, h: i.naturalHeight }); URL.revokeObjectURL(u); };
    i.onerror = () => { res(null); URL.revokeObjectURL(u); };
    i.src = u;
  });
}

/** Shared frame: picker + options + sticky action, swapping to results after a run. */
function frame({ titleKey, multiple = true, pickTitle, pickHint, actionKey, onFiles }) {
  const s = createScreen(t(titleKey));
  const setup = h('div', { class: 'stack' });
  const out = h('div', { class: 'stack hidden' });
  const optionsHost = h('div', { class: 'stack' });
  const picker = filePicker({
    accept: 'image/*', multiple, maxFiles: multiple ? batchLimit() : 1, kind: 'image',
    title: pickTitle || t('pick.images'), hint: pickHint || t('pick.imagesHint', { n: batchLimit() }),
    onChange: (f) => { act.btn.disabled = !f.length; optionsHost.classList.toggle('hidden', !f.length); if (onFiles) onFiles(f); },
  });
  const act = stickyAction(t(actionKey), () => {});
  act.btn.disabled = true;
  optionsHost.classList.add('hidden');
  setup.append(picker.el, optionsHost);
  s.body.append(setup, out);
  s.root.append(act.el);
  s.onDestroy(() => picker.destroy());
  let resView = null;
  s.onDestroy(() => resView && resView.destroy());

  async function execute(tool, optsFor, { compareView = true, summary = true, keepIfBigger = false, afterEach } = {}) {
    const files = picker.files.slice();
    const items = await runJob('job.processing', async ({ signal, progress }) => {
      const list = [];
      for (let i = 0; i < files.length; i++) {
        progress(i / files.length, (i + 1) + '/' + files.length + ' · ' + files[i].name);
        const f = files[i];
        const o = optsFor(f);
        if (o.skipIfSmallerThan && f.size <= o.skipIfSmallerThan) {
          list.push({ name: f.name, blob: f, kind: 'image', origSize: f.size, srcBlob: f, note: 'alreadySmall' });
          continue;
        }
        const r = await processImage(f, o, { signal, maxPixels: maxPixels() });
        let blob = r.blob, name = r.name, note = null, warn = false;
        if (keepIfBigger && blob.size >= f.size && (o.fmt === 'original' || o.fmt === fmtOfFile(f))) { blob = f; name = f.name; note = 'keptOriginal'; }
        else if (r.reached === false) { note = 'notReached'; warn = true; }
        else if (r.downscaled) { note = 'downscaled'; warn = true; }
        list.push({ name, blob, kind: 'image', origSize: f.size, srcBlob: f, note, noteWarn: warn, dims: r.w + '×' + r.h });
        if (afterEach) afterEach(r);
      }
      progress(1);
      return list;
    });
    if (!items) return;
    act.el.classList.add('hidden');
    setup.classList.add('hidden');
    out.classList.remove('hidden');
    out.replaceChildren();
    resView = resultsView(items, {
      tool, compare: compareView, summary,
      onAgain: () => { resView.destroy(); out.classList.add('hidden'); setup.classList.remove('hidden'); act.el.classList.remove('hidden'); picker.clear(); },
    });
    out.append(resView.el);
    s.body.scrollTop = 0;
  }
  return { s, picker, optionsHost, act, execute };
}

/* ---------------------------------------------------------------- compress */
function compressPage() {
  const f = frame({ titleKey: 'tool.compress', actionKey: 'act.compress', onFiles: () => { updatePngHint(); estimate(); } });
  const st = { mode: 'quality', quality: settings.get('quality'), fmt: settings.get('imageFormat'), maxSide: '', kb: 200 };
  const hintPng = h('p', { class: 'hint hidden' }, t('hint.pngQuality'));
  const est = h('div', { class: 'estimate' }, '');

  const qualityPanel = h('div', { class: 'stack tight' });
  const q = slider({ min: 10, max: 100, value: st.quality, format: (v) => v + '%', onInput: (v) => { st.quality = v; estimate(); } });
  qualityPanel.append(field(t('opt.quality'), q.el), est);

  const targetPanel = h('div', { class: 'stack tight' });
  const kbInput = numberInput({ value: st.kb, min: 1, max: 100000, onInput: (v) => { st.kb = v; presets.setValue(null); } });
  const unit = selectBox([{ value: 'KB', label: 'KB' }, { value: 'MB', label: 'MB' }], 'KB', (v) => { st.unit = v; });
  st.unit = 'KB';
  const presetVals = [50, 100, 200, 500, 1024];
  const presets = chips(presetVals.map((v) => ({ value: v, label: v >= 1024 ? '1 MB' : v + ' KB' })), 200, (v) => { st.kb = v; kbInput.value = v; unit.value = 'KB'; st.unit = 'KB'; });
  targetPanel.append(field(t('opt.targetSize'), presets), h('div', { class: 'row gap' }, h('div', { class: 'grow' }, kbInput), h('div', { class: 'unit' }, unit)), h('p', { class: 'hint' }, t('hint.target')));

  const modeSeg = segmented([{ value: 'quality', label: t('opt.byQuality') }, { value: 'target', label: t('opt.byTarget') }], st.mode, (v) => {
    st.mode = v; qualityPanel.classList.toggle('hidden', v !== 'quality'); targetPanel.classList.toggle('hidden', v !== 'target'); updatePngHint(); estimate();
  });
  targetPanel.classList.add('hidden');

  const fmtSel = selectBox(fmtOptions(), st.fmt, (v) => { st.fmt = v; updatePngHint(); estimate(); });
  const sideSel = selectBox([{ value: '', label: t('opt.keepSize') }, { value: 4096, label: '4096 px' }, { value: 2560, label: '2560 px' }, { value: 1920, label: '1920 px' }, { value: 1280, label: '1280 px' }, { value: 1024, label: '1024 px' }, { value: 640, label: '640 px' }], '', (v) => { st.maxSide = v ? Number(v) : ''; estimate(); });

  function updatePngHint() {
    const hasPng = f.picker.files.some((x) => fmtOfFile(x) === 'png');
    hintPng.classList.toggle('hidden', !(st.mode === 'quality' && st.fmt === 'original' && hasPng));
  }
  const estimate = debounce(async () => {
    est.textContent = '';
    if (st.mode !== 'quality' || !f.picker.files.length) return;
    const file = f.picker.files[0];
    try {
      const r = await processImage(file, { ...optsFor(file), suffix: '' }, { maxPixels: maxPixels() });
      const pct = Math.round((1 - r.blob.size / file.size) * 100);
      est.textContent = t('opt.estimate') + ' ' + fmtSize(file.size) + ' → ' + fmtSize(r.blob.size) + (pct > 0 ? '  (−' + pct + '%)' : '');
    } catch { /* estimate is optional */ }
  }, 450);

  const optsFor = (file) => {
    const o = { fmt: st.fmt, mode: st.mode, maxSide: st.maxSide || 0, suffix: '_compressed' };
    if (st.mode === 'quality') o.quality = st.quality / 100;
    else {
      const kb = (st.unit === 'MB' ? (st.kb || 0) * 1024 : st.kb) || 0;
      o.targetBytes = Math.max(1, Math.round(kb * 1024));
      if (st.fmt === 'original' && !o.maxSide) o.skipIfSmallerThan = o.targetBytes;
    }
    return o;
  };

  f.optionsHost.append(modeSeg, qualityPanel, targetPanel, field(t('opt.format'), fmtSel), hintPng, field(t('opt.maxSide'), sideSel));
  f.act.btn.addEventListener('click', () => {
    if (st.mode === 'target' && (!st.kb || st.kb <= 0)) { toast(t('err.target-invalid')); return; }
    f.execute('compress', optsFor, { keepIfBigger: true });
  });
  return f.s;
}

/* ------------------------------------------------------------------ resize */
function resizePage() {
  let ratio = null;
  const f = frame({ titleKey: 'tool.resize', actionKey: 'act.resize', onFiles: async (files) => {
    if (!files.length) { ratio = null; return; }
    const d = await peekDims(files[0]);
    if (d) { ratio = d.w / d.h; wIn.value = d.w; hIn.value = d.h; st.w = d.w; st.h = d.h; pxHint.textContent = t('opt.original') + ': ' + d.w + ' × ' + d.h + ' px'; }
  } });
  const st = { mode: 'px', w: null, h: null, lock: true, percent: 50, fmt: settings.get('imageFormat'), kb: null };
  const pxHint = h('div', { class: 'hint' }, '');
  const wIn = numberInput({ min: 1, max: 20000, onInput: (v) => { st.w = v; if (st.lock && ratio && v) { st.h = Math.round(v / ratio); hIn.value = st.h; } } });
  const hIn = numberInput({ min: 1, max: 20000, onInput: (v) => { st.h = v; if (st.lock && ratio && v) { st.w = Math.round(v * ratio); wIn.value = st.w; } } });
  const px = h('div', { class: 'stack tight' },
    h('div', { class: 'row gap' }, field(t('opt.width'), wIn), field(t('opt.height'), hIn)),
    toggleRow({ title: t('opt.lock'), value: true, onChange: (v) => { st.lock = v; } }), pxHint);
  const pct = slider({ min: 5, max: 200, value: 50, format: (v) => v + '%', onInput: (v) => { st.percent = v; } });
  const pctChips = chips([25, 50, 75].map((v) => ({ value: v, label: v + '%' })), 50, (v) => { st.percent = v; pct.set(v); });
  const pctPanel = h('div', { class: 'stack tight hidden' }, pctChips, pct.el);
  const mode = segmented([{ value: 'px', label: t('opt.pixels') }, { value: 'pct', label: t('opt.percent') }], 'px', (v) => { st.mode = v; px.classList.toggle('hidden', v !== 'px'); pctPanel.classList.toggle('hidden', v !== 'pct'); });
  const kb = numberInput({ min: 1, max: 100000, placeholder: t('opt.optional'), onInput: (v) => { st.kb = v; } });
  const fmtSel = selectBox(fmtOptions(), st.fmt, (v) => { st.fmt = v; });
  f.optionsHost.append(mode, px, pctPanel, field(t('opt.limitKB'), kb, t('hint.limitKB')), field(t('opt.format'), fmtSel));
  f.act.btn.addEventListener('click', () => {
    if (st.mode === 'px' && !st.w && !st.h) { toast(t('err.size-invalid')); return; }
    f.execute('resize', () => {
      const o = { fmt: st.fmt, mode: st.kb ? 'target' : 'quality', quality: settings.get('quality') / 100, suffix: '_resized' };
      if (st.mode === 'pct') o.percent = st.percent;
      else { o.w = st.w; o.h = st.h; o.fit = st.lock; }
      if (st.kb) { o.targetBytes = Math.round(st.kb * 1024); o.allowScale = false; }
      return o;
    });
  });
  return f.s;
}

/* ----------------------------------------------------------------- convert */
function convertPage() {
  const f = frame({ titleKey: 'tool.convert', actionKey: 'act.convert' });
  const st = { fmt: 'jpg', quality: Math.max(85, settings.get('quality')) };
  const q = slider({ min: 40, max: 100, value: st.quality, format: (v) => v + '%', onInput: (v) => { st.quality = v; } });
  const qField = field(t('opt.quality'), q.el);
  const pick = chips([{ value: 'jpg', label: 'JPG' }, { value: 'png', label: 'PNG' }, { value: 'webp', label: 'WebP' }], 'jpg', (v) => { st.fmt = v; qField.classList.toggle('hidden', v === 'png'); });
  f.optionsHost.append(field(t('opt.convertTo'), pick), qField, h('p', { class: 'hint' }, t('hint.convertAlpha')));
  f.act.btn.addEventListener('click', () => f.execute('convert', () => ({ fmt: st.fmt, mode: 'quality', quality: st.quality / 100, suffix: '' }), { summary: false }));
  return f.s;
}

/* -------------------------------------------------------------------- crop */
function cropPage() {
  let cropper = null;
  const host = h('div', { class: 'stack' });
  const f = frame({ titleKey: 'tool.crop', multiple: false, actionKey: 'act.crop', onFiles: (files) => {
    host.replaceChildren();
    if (cropper) { cropper.destroy(); cropper = null; }
    if (!files.length) return;
    cropper = createCropper(files[0]);
    const aspects = [{ value: 'free', label: t('opt.free') }, { value: '1', label: '1:1' }, { value: String(4 / 3), label: '4:3' }, { value: String(3 / 4), label: '3:4' }, { value: String(16 / 9), label: '16:9' }, { value: String(9 / 16), label: '9:16' }];
    host.append(cropper.el, chips(aspects, 'free', (v) => cropper.setAspect(v === 'free' ? null : Number(v))), h('p', { class: 'hint' }, t('hint.crop')));
  } });
  f.optionsHost.append(host);
  f.s.onDestroy(() => cropper && cropper.destroy());
  f.act.btn.addEventListener('click', () => {
    if (!cropper) return;
    const r = cropper.getRect();
    f.execute('crop', (file) => ({ fmt: 'original', mode: 'quality', quality: 0.95, crop: r, suffix: '_cropped' }), { summary: false });
  });
  return f.s;
}

/* ------------------------------------------------------------------ rotate */
function rotatePage() {
  const st = { rot: 0, fh: false, fv: false };
  const prev = h('img', { class: 'rot-prev', alt: '' });
  let url = null;
  // flips are applied after rotation in the output, so mirror that order in the preview
  const applyPreview = () => {
    prev.style.transform = 'scale(' + (st.fh ? -1 : 1) + ',' + (st.fv ? -1 : 1) + ') rotate(' + st.rot + 'deg)';
  };
  const f = frame({ titleKey: 'tool.rotate', actionKey: 'act.apply', onFiles: (files) => {
    if (url) { URL.revokeObjectURL(url); url = null; }
    if (files.length) { url = URL.createObjectURL(files[0]); prev.src = url; }
    st.rot = 0; st.fh = false; st.fv = false; applyPreview();
  } });
  const btn = (ic, label, fn) => h('button', { class: 'tile-btn', onClick: fn }, icon(ic, 22), h('span', {}, label));
  f.optionsHost.append(
    h('div', { class: 'rot-stage' }, prev),
    h('div', { class: 'tile-row' },
      btn('rotateL', t('opt.left'), () => { st.rot = (st.rot + 270) % 360; applyPreview(); }),
      btn('rotate', t('opt.right'), () => { st.rot = (st.rot + 90) % 360; applyPreview(); }),
      btn('flipH', t('opt.flipH'), () => { st.fh = !st.fh; applyPreview(); }),
      btn('flipV', t('opt.flipV'), () => { st.fv = !st.fv; applyPreview(); })));
  f.s.onDestroy(() => url && URL.revokeObjectURL(url));
  f.act.btn.addEventListener('click', () => {
    if (!st.rot && !st.fh && !st.fv) { toast(t('err.nothing-to-do')); return; }
    f.execute('rotate', () => ({ fmt: 'original', mode: 'quality', quality: 0.95, rotate: st.rot, flipH: st.fh, flipV: st.fv, suffix: '_rotated' }), { summary: false });
  });
  return f.s;
}

/* -------------------------------------------------------------------- info */
function infoPage() {
  const s = createScreen(t('tool.imginfo'));
  const out = h('div', { class: 'stack' });
  const picker = filePicker({
    accept: 'image/*', multiple: false, kind: 'image', title: t('pick.image'), hint: '',
    onChange: async (files) => {
      out.replaceChildren();
      if (!files.length) return;
      try {
        const i = await imageInfo(files[0]);
        const gcd = (a, b) => (b ? gcd(b, a % b) : a);
        const g = gcd(i.w, i.h);
        const rows = [
          [t('info.name'), i.name], [t('info.format'), (i.fmt || i.type || '—').toUpperCase()], [t('info.size'), fmtSize(i.size) + ' (' + i.size.toLocaleString() + ' B)'],
          [t('info.dims'), i.w + ' × ' + i.h + ' px'], [t('info.mp'), i.mp.toFixed(2) + ' MP'], [t('info.ratio'), (i.w / g) + ':' + (i.h / g)],
          [t('info.modified'), i.modified ? fmtDate(i.modified, lang()) : '—'], [t('info.exif'), i.exif ? t('info.exifYes') : t('info.exifNo')],
        ];
        out.append(h('div', { class: 'card list-card' }, rows.map(([k, v]) => h('div', { class: 'kv' }, h('span', { class: 'muted' }, k), h('span', { class: 'v' }, v)))));
        if (i.exif) out.append(h('p', { class: 'hint' }, t('info.exifHint')));
      } catch { toast(t('err.bad-image')); }
    },
  });
  s.body.append(picker.el, out);
  s.onDestroy(() => picker.destroy());
  return s;
}

const PAGES = { compress: compressPage, resize: resizePage, convert: convertPage, crop: cropPage, rotate: rotatePage, info: infoPage };
export function imageToolPage(id) {
  const s = PAGES[id]();
  return { el: s.root, destroy: s.destroy };
}
void stripExt;
