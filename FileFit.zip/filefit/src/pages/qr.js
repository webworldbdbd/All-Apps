import { Capacitor } from '@capacitor/core';
import { h, debounce, copyText, fmtDate } from '../core/util.js';
import { icon } from '../core/icons.js';
import { t, lang } from '../core/i18n.js';
import { scanLog } from '../core/store.js';
import { chips, field, textInput, selectBox, toast, sheet, confirmDialog, errMsg, emptyState } from '../core/ui.js';
import { saveBlob, shareBlobs, pickFiles } from '../core/files.js';
import { afterAction } from '../core/ads.js';
import * as qr from '../tools/qr.js';
import { createScreen } from './toolkit.js';

/* ---------------------------------------------------------------- generate */
const TYPES = [
  { id: 'url', icon: 'link' }, { id: 'text', icon: 'text' }, { id: 'wifi', icon: 'wifi' }, { id: 'contact', icon: 'contact' },
  { id: 'email', icon: 'mail' }, { id: 'phone', icon: 'phone' }, { id: 'sms', icon: 'sms' },
];
const COLORS = ['#000000', '#1668e3', '#0b8a6f', '#c2410c', '#7c3aed', '#be123c'];

export function qrGeneratePage() {
  const s = createScreen(t('tool.qrgen'));
  const st = { type: 'url', f: { security: 'WPA' }, fg: '#000000', ec: 'M' };
  const form = h('div', { class: 'stack' });
  const preview = h('div', { class: 'qr-preview' }, h('span', { class: 'muted small' }, t('qr.previewEmpty')));
  let current = null;

  const inp = (key, label, opts = {}) => field(label, textInput({ value: st.f[key] || '', type: opts.type || 'text', placeholder: opts.ph || '', multiline: opts.multi, onInput: (v) => { st.f[key] = v; refresh(); } }));
  const forms = {
    url: () => [inp('url', t('qr.url'), { ph: 'example.com', type: 'url' })],
    text: () => [inp('text', t('qr.text'), { multi: true })],
    wifi: () => [inp('ssid', t('qr.ssid')), field(t('qr.security'), chips([{ value: 'WPA', label: 'WPA/WPA2' }, { value: 'WEP', label: 'WEP' }, { value: 'nopass', label: t('qr.open') }], st.f.security, (v) => { st.f.security = v; refresh(); })), inp('password', t('qr.password'))],
    contact: () => [inp('name', t('qr.name')), inp('phone', t('qr.phone'), { type: 'tel' }), inp('email', t('qr.email'), { type: 'email' }), inp('org', t('qr.org')), inp('website', t('qr.website'))],
    email: () => [inp('to', t('qr.emailTo'), { type: 'email' }), inp('subject', t('qr.subject')), inp('body', t('qr.body'), { multi: true })],
    phone: () => [inp('phone', t('qr.phone'), { type: 'tel', ph: '+8801XXXXXXXXX' })],
    sms: () => [inp('phone', t('qr.phone'), { type: 'tel' }), inp('message', t('qr.message'), { multi: true })],
  };
  const paintForm = () => { form.replaceChildren(...forms[st.type]()); };

  const refresh = debounce(async () => {
    const text = qr.builders[st.type](st.f);
    if (!text) { current = null; preview.replaceChildren(h('span', { class: 'muted small' }, t('qr.previewEmpty'))); return; }
    try {
      const c = await qr.qrCanvas(text, { size: 560, fg: st.fg, ec: st.ec });
      c.className = 'qr-canvas';
      current = text;
      preview.replaceChildren(c);
    } catch { current = null; preview.replaceChildren(h('span', { class: 'warn small' }, t('err.qr-too-long'))); }
  }, 220);

  const typeChips = chips(TYPES.map((x) => ({ value: x.id, label: t('qr.t.' + x.id) })), 'url', (v) => { st.type = v; st.f = { security: 'WPA' }; paintForm(); refresh(); });
  const colorRow = h('div', { class: 'swatches' }, COLORS.map((c) => h('button', { class: 'swatch' + (c === st.fg ? ' on' : ''), style: { background: c }, 'aria-label': c, onClick: (e) => { st.fg = c; [...e.currentTarget.parentNode.children].forEach((x) => x.classList.toggle('on', x === e.currentTarget)); refresh(); } })));
  const ecChips = chips([{ value: 'L', label: 'L' }, { value: 'M', label: 'M' }, { value: 'Q', label: 'Q' }, { value: 'H', label: 'H' }], 'M', (v) => { st.ec = v; refresh(); });

  const getBlob = () => qr.qrBlob(current, { fg: st.fg, ec: st.ec });
  const act = h('div', { class: 'row gap' },
    h('button', { class: 'btn primary grow', onClick: async () => {
      if (!current) { toast(t('qr.fillFirst')); return; }
      try { const r = await saveBlob(await getBlob(), 'QR_' + Date.now().toString(36) + '.png', { kind: 'image', tool: 'qrgen' }); toast(t('saved.to', { where: r.label })); afterAction(); } catch (e) { toast(errMsg(e), 4000); }
    } }, icon('save', 18), t('common.save')),
    h('button', { class: 'btn ghost grow', onClick: async () => {
      if (!current) { toast(t('qr.fillFirst')); return; }
      try { await shareBlobs([{ blob: await getBlob(), name: 'QR.png' }]); afterAction(); } catch { /* closed */ }
    } }, icon('share', 18), t('common.share')));

  paintForm();
  s.body.append(typeChips, form, h('div', { class: 'card center stack' }, preview), field(t('qr.color'), colorRow), field(t('qr.errorLevel'), ecChips, t('qr.errorHint')), act);
  return { el: s.root, destroy: s.destroy };
}

/* -------------------------------------------------------------------- scan */
async function openExternal(url) {
  if (Capacitor.isNativePlatform()) {
    const { Browser } = await import('@capacitor/browser');
    await Browser.open({ url });
  } else window.open(url, '_blank', 'noopener');
}
function openScheme(href) {
  const a = h('a', { href }); document.body.append(a); a.click(); a.remove();
}

function resultSheet(text, onClose) {
  const p = qr.parsePayload(text);
  const body = h('div', { class: 'stack' });
  const rowsEl = (rows) => h('div', { class: 'card list-card' }, rows.filter(Boolean).map(([k, v]) => h('div', { class: 'kv' }, h('span', { class: 'muted' }, k), h('span', { class: 'v' }, v))));
  const btns = [];
  const copyBtn = (label, val) => h('button', { class: 'btn ghost grow', onClick: () => copyText(val).then(() => toast(t('common.copied'))) }, icon('copy', 18), label);
  const shareBtn = h('button', { class: 'btn ghost grow', onClick: async () => { const { shareText } = await import('../core/files.js'); shareText(text).catch(() => {}); } }, icon('share', 18), t('common.share'));
  let title = t('qr.t.' + p.type);

  if (p.type === 'url') {
    body.append(h('div', { class: 'url-box' }, p.url));
    if (p.risks && p.risks.length) body.append(h('div', { class: 'alert' }, icon('info', 18), h('div', {}, h('b', {}, t('qr.risk.title')), p.risks.map((r) => h('div', { class: 'small' }, '• ' + t('qr.risk.' + r))))));
    btns.push(h('button', { class: 'btn primary grow', onClick: async () => {
      if (p.risks && p.risks.length && !(await confirmDialog({ title: t('qr.openAnyway'), message: p.url, confirmText: t('qr.open.btn'), danger: true }))) return;
      openExternal(p.url).catch(() => toast(t('err.generic')));
    } }, icon('external', 18), t('qr.open.btn')), copyBtn(t('common.copy'), p.url));
  } else if (p.type === 'wifi') {
    const pw = h('span', { class: 'v' }, p.password ? '••••••••' : '—');
    let shown = false;
    body.append(rowsEl([[t('qr.ssid'), p.ssid], [t('qr.security'), p.security === 'nopass' ? t('qr.open') : p.security], [t('qr.password'), pw]]));
    if (p.password) body.append(h('button', { class: 'btn ghost block', onClick: () => { shown = !shown; pw.textContent = shown ? p.password : '••••••••'; } }, icon('eye', 18), t('qr.showPassword')));
    btns.push(copyBtn(t('qr.copyPassword'), p.password || ''), copyBtn(t('qr.copyName'), p.ssid));
    body.append(h('p', { class: 'hint' }, t('qr.wifiHint')));
  } else if (p.type === 'phone') {
    body.append(rowsEl([[t('qr.phone'), p.phone]]));
    btns.push(h('button', { class: 'btn primary grow', onClick: () => openScheme('tel:' + p.phone) }, icon('phone', 18), t('qr.call')), copyBtn(t('common.copy'), p.phone));
  } else if (p.type === 'email') {
    body.append(rowsEl([[t('qr.emailTo'), p.to]]));
    btns.push(h('button', { class: 'btn primary grow', onClick: () => openScheme(p.raw) }, icon('mail', 18), t('qr.sendEmail')), copyBtn(t('common.copy'), p.to));
  } else if (p.type === 'sms') {
    body.append(rowsEl([[t('qr.phone'), p.phone], [t('qr.message'), p.message]]));
    btns.push(h('button', { class: 'btn primary grow', onClick: () => openScheme('sms:' + p.phone + (p.message ? '?body=' + encodeURIComponent(p.message) : '')) }, icon('sms', 18), t('qr.sendSms')), copyBtn(t('common.copy'), p.message || p.phone));
  } else if (p.type === 'contact') {
    body.append(rowsEl([[t('qr.name'), p.name], [t('qr.phone'), p.phone], [t('qr.email'), p.email], [t('qr.org'), p.org], [t('qr.website'), p.website]]));
    btns.push(copyBtn(t('common.copy'), text));
  } else {
    body.append(h('div', { class: 'url-box' }, text));
    btns.push(copyBtn(t('common.copy'), text));
  }
  body.append(h('div', { class: 'row gap' }, btns, shareBtn));
  return sheet({ title, body, onClose });
}

export function qrScanPage() {
  const s = createScreen(t('tool.qrscan'));
  const video = h('video', { class: 'scan-video', muted: true, playsinline: true, autoplay: true });
  const msg = h('div', { class: 'scan-msg' }, t('qr.starting'));
  const frameEl = h('div', { class: 'scan-frame' }, h('i'), h('i'), h('i'), h('i'));
  const stage = h('div', { class: 'scan-stage' }, video, frameEl, msg);
  let scanner = null, torchOn = false, sheetOpen = false, alive = true;

  const torchBtn = h('button', { class: 'round-btn hidden', 'aria-label': t('qr.torch'), onClick: async () => { torchOn = !torchOn; if (!(await scanner.torch(torchOn))) torchOn = false; torchBtn.classList.toggle('on', torchOn); } }, icon('flash', 22));
  const galleryBtn = h('button', { class: 'round-btn', 'aria-label': t('qr.fromImage'), onClick: async () => {
    const [file] = await pickFiles({ accept: 'image/*' });
    if (!file) return;
    try { const r = await qr.decodeFromFile(file); if (r) handle(r); else toast(t('qr.notFound')); } catch (e) { toast(errMsg(e)); }
  } }, icon('gallery', 22));
  const histBtn = h('button', { class: 'round-btn', 'aria-label': t('qr.history'), onClick: showHistory }, icon('history', 22));
  const controls = h('div', { class: 'scan-controls' }, galleryBtn, torchBtn, histBtn);

  function handle(text) {
    if (sheetOpen) return;
    sheetOpen = true;
    if (navigator.vibrate) navigator.vibrate(40);
    scanLog.add({ text, type: qr.parsePayload(text).type });
    resultSheet(text, () => { sheetOpen = false; if (scanner) scanner.resetLast(); });
  }
  function showHistory() {
    const list = scanLog.list();
    const body = list.length ? h('div', { class: 'stack' }, list.map((e) => h('button', { class: 'row-item', onClick: () => { hs.close(); handle(e.text); } },
      h('span', { class: 'row-ico' }, icon({ url: 'link', wifi: 'wifi', phone: 'phone', email: 'mail', sms: 'sms', contact: 'contact' }[e.type] || 'text', 20)),
      h('span', { class: 'row-text' }, h('span', { class: 'row-title ellipsis' }, e.text.replace(/\s+/g, ' ')), h('span', { class: 'row-sub' }, fmtDate(e.time, lang()))))),
      h('button', { class: 'btn ghost block', onClick: () => { scanLog.clear(); hs.close(); } }, icon('trash', 18), t('qr.clearHistory')))
      : emptyState('history', t('qr.noHistory'), '');
    const hs = sheet({ title: t('qr.history'), body });
  }

  async function start() {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) { msg.textContent = t('qr.noCamera'); return; }
    try {
      scanner = await qr.startScanner(video, handle);
      if (!alive) { scanner.stop(); return; }
      msg.textContent = t('qr.pointCamera');
      torchBtn.classList.toggle('hidden', !scanner.torchSupported);
    } catch (e) {
      msg.replaceChildren(h('div', {}, t('qr.permission')), h('button', { class: 'btn primary', onClick: () => { msg.textContent = t('qr.starting'); start(); } }, t('qr.retry')));
    }
  }
  s.body.append(stage, controls, h('p', { class: 'hint center' }, t('qr.privacyNote')));
  s.onDestroy(() => { alive = false; if (scanner) scanner.stop(); });
  setTimeout(start, 120);
  return { el: s.root, destroy: s.destroy };
}
