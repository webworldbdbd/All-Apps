import cfg from '../app.config.json';
export default cfg;
