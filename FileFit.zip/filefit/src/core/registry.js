import { t } from './i18n.js';
import { ALL_META, META_BY_ID } from '../tools/index.js';
import { tr } from '../tools/lite.js';

// Single list of every tool. Home, Tools tab and search all read from here.
export const TOOLS = [
  { id: 'compress', cat: 'image', route: '/image/compress', icon: 'compress' },
  { id: 'resize', cat: 'image', route: '/image/resize', icon: 'resize' },
  { id: 'crop', cat: 'image', route: '/image/crop', icon: 'crop' },
  { id: 'convert', cat: 'image', route: '/image/convert', icon: 'convert' },
  { id: 'rotate', cat: 'image', route: '/image/rotate', icon: 'rotate' },
  { id: 'imginfo', cat: 'image', route: '/image/info', icon: 'info' },
  { id: 'img2pdf', cat: 'pdf', route: '/pdf/img2pdf', icon: 'image' },
  { id: 'merge', cat: 'pdf', route: '/pdf/merge', icon: 'merge' },
  { id: 'split', cat: 'pdf', route: '/pdf/split', icon: 'split' },
  { id: 'extract', cat: 'pdf', route: '/pdf/extract', icon: 'extract' },
  { id: 'organize', cat: 'pdf', route: '/pdf/organize', icon: 'reorder' },
  { id: 'pdfrotate', cat: 'pdf', route: '/pdf/pdfrotate', icon: 'rotate' },
  { id: 'pdfcompress', cat: 'pdf', route: '/pdf/pdfcompress', icon: 'compress' },
  { id: 'view', cat: 'pdf', route: '/pdf/view', icon: 'eye' },
  { id: 'pdfinfo', cat: 'pdf', route: '/pdf/pdfinfo', icon: 'info' },
  { id: 'qrgen', cat: 'qr', route: '/qr/generate', icon: 'qr' },
  { id: 'qrscan', cat: 'qr', route: '/qr/scan', icon: 'camera' },
  { id: 'wordcount', cat: 'text', route: '/text/wordcount', icon: 'text' },
  { id: 'dedupe', cat: 'text', route: '/text/dedupe', icon: 'list' },
  { id: 'sortlines', cat: 'text', route: '/text/sortlines', icon: 'sort' },
  { id: 'findreplace', cat: 'text', route: '/text/findreplace', icon: 'search' },
  { id: 'casechange', cat: 'text', route: '/text/casechange', icon: 'case' },
  { id: 'cleantext', cat: 'text', route: '/text/cleantext', icon: 'sparkle' },
  { id: 'reversetext', cat: 'text', route: '/text/reversetext', icon: 'convert' },
  { id: 'slug', cat: 'text', route: '/text/slug', icon: 'link' },
  { id: 'dedupewords', cat: 'text', route: '/text/dedupewords', icon: 'copy' },
  { id: 'lorem', cat: 'text', route: '/text/lorem', icon: 'file' },
  ...ALL_META.map((m) => ({ id: m.id, cat: m.cat, route: '/tool/' + m.id, icon: m.icon })),
];
export const tname = (id) => (META_BY_ID[id] ? tr(META_BY_ID[id].name) : t('tool.' + id));
export const tdesc = (id) => (META_BY_ID[id] ? tr(META_BY_ID[id].desc) : t('tool.' + id + '.d'));
export const CATS = [
  { id: 'image', route: '/images', icon: 'image' },
  { id: 'pdf', route: '/pdf', icon: 'pdf' },
  { id: 'qr', route: '/qr', icon: 'qr' },
  { id: 'text', route: '/text', icon: 'text' },
  { id: 'calc', route: '/calc', icon: 'calc' },
  { id: 'life', route: '/life', icon: 'money' },
  { id: 'time', route: '/time', icon: 'clock' },
  { id: 'convert', route: '/convert', icon: 'convert' },
  { id: 'dev', route: '/dev', icon: 'code' },
];
export const toolsOf = (cat) => TOOLS.filter((x) => x.cat === cat);
export const QUICK = ['compress', 'img2pdf', 'merge', 'qrscan', 'calculator', 'age'];
