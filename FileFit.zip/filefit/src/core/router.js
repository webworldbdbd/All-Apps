import { closeTopLayer } from './ui.js';

const routes = [];
let current = null;
let host = null;
let onRoute = null;

export function route(pattern, handler, meta = {}) {
  const keys = [];
  const rx = new RegExp('^' + pattern.replace(/:(\w+)/g, (_, k) => { keys.push(k); return '([^/]+)'; }) + '$');
  routes.push({ rx, keys, handler, meta });
}

export function startRouter(container, cb) {
  host = container;
  onRoute = cb;
  window.addEventListener('hashchange', render);
  render();
}

export function go(path) { location.hash = '#' + path; }
export function refresh() { render(); }

function render() {
  closeTopLayer();
  const path = (location.hash.replace(/^#/, '') || '/home').split('?')[0];
  let match = null;
  for (const r of routes) {
    const m = r.rx.exec(path);
    if (m) { match = { r, params: Object.fromEntries(r.keys.map((k, i) => [k, decodeURIComponent(m[i + 1])])) }; break; }
  }
  if (!match) { location.replace('#/home'); return; }
  if (current && current.destroy) { try { current.destroy(); } catch { /* ignore */ } }
  const out = match.r.handler(match.params);
  const el = out && out.el ? out.el : out;
  current = out && out.el ? out : { el };
  host.replaceChildren(el);
  el.classList.add('route-in');
  host.scrollTop = 0;
  if (onRoute) onRoute(path, match.r.meta);
}
