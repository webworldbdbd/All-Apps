import en from '../locales/en.js';
import bn from '../locales/bn.js';
import { settings } from './store.js';

// To add a language: create src/locales/xx.js (copy en.js) and register it here.
export const LANGS = {
  en: { name: 'English', dict: en },
  bn: { name: 'বাংলা', dict: bn },
};

let cur = 'en';
export function initLang() {
  const s = settings.get('lang');
  const dev = ((navigator.language || 'en') + '').slice(0, 2).toLowerCase();
  cur = s === 'auto' ? dev : s;
  if (!LANGS[cur]) cur = 'en';
  document.documentElement.lang = cur;
}
export const lang = () => cur;

export function t(key, vars) {
  let s = LANGS[cur].dict[key];
  if (s == null) s = en[key];
  if (s == null) return key;
  if (vars) for (const k of Object.keys(vars)) s = s.split('{' + k + '}').join(String(vars[k]));
  return s;
}
