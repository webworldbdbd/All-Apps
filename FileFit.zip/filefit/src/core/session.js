// In-memory hand-off between screens (compare view, PDF viewer, etc.). Never persisted.
export const session = { compare: null, viewPdf: null };
