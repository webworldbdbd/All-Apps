import { h } from './util.js';
import { icon } from './icons.js';
import { t } from './i18n.js';

const layers = [];
export function closeTopLayer() {
  const l = layers[layers.length - 1];
  if (!l) return false;
  l.close();
  return true;
}

export function toast(msg, ms = 2600) {
  document.querySelectorAll('.toast').forEach((x) => x.remove());
  const el = h('div', { class: 'toast', role: 'status' }, msg);
  document.body.append(el);
  requestAnimationFrame(() => el.classList.add('show'));
  setTimeout(() => { el.classList.remove('show'); setTimeout(() => el.remove(), 250); }, ms);
}

export function sheet({ title, body, onClose } = {}) {
  const back = h('div', { class: 'backdrop' });
  const box = h('div', { class: 'sheet', role: 'dialog', 'aria-modal': 'true' },
    h('div', { class: 'grab' }),
    title ? h('h2', { class: 'sheet-title' }, title) : null,
    h('div', { class: 'sheet-body' }, body));
  const wrap = h('div', { class: 'layer' }, back, box);
  document.body.append(wrap);
  requestAnimationFrame(() => wrap.classList.add('open'));
  const api = {
    el: box,
    close() {
      const i = layers.indexOf(api);
      if (i >= 0) layers.splice(i, 1);
      wrap.classList.remove('open');
      setTimeout(() => wrap.remove(), 220);
      if (onClose) onClose();
    },
  };
  back.addEventListener('click', () => api.close());
  layers.push(api);
  return api;
}

export function confirmDialog({ title, message, confirmText, danger = false }) {
  return new Promise((resolve) => {
    let done = false;
    const finish = (v) => { if (done) return; done = true; s.close(); resolve(v); };
    const s = sheet({
      title,
      onClose: () => { if (!done) { done = true; resolve(false); } },
      body: h('div', { class: 'stack' },
        message ? h('p', { class: 'muted' }, message) : null,
        h('div', { class: 'row gap' },
          h('button', { class: 'btn ghost grow', onClick: () => finish(false) }, t('common.cancel')),
          h('button', { class: 'btn grow ' + (danger ? 'danger' : 'primary'), onClick: () => finish(true) }, confirmText || t('common.ok')))),
    });
  });
}

export function progressOverlay(title, onCancel) {
  const bar = h('div', { class: 'bar-fill' });
  const label = h('div', { class: 'muted small' }, '');
  const el = h('div', { class: 'layer open overlay' },
    h('div', { class: 'backdrop dark' }),
    h('div', { class: 'progress-card' },
      h('div', { class: 'spinner' }),
      h('h3', {}, title),
      h('div', { class: 'bar' }, bar),
      label,
      h('button', { class: 'btn ghost', onClick: () => onCancel && onCancel() }, t('common.cancel'))));
  document.body.append(el);
  const entry = { close: () => onCancel && onCancel() };
  layers.push(entry);
  return {
    set(p, text) {
      bar.style.width = Math.round(Math.max(0, Math.min(1, p)) * 100) + '%';
      if (text != null) label.textContent = text;
    },
    close() {
      const i = layers.indexOf(entry);
      if (i >= 0) layers.splice(i, 1);
      el.remove();
    },
  };
}

export function appBar(title, { back = true, actions = [] } = {}) {
  return h('header', { class: 'appbar' },
    back ? h('button', { class: 'icon-btn', 'aria-label': t('common.back'), onClick: goBack }, icon('back')) : h('span', { class: 'appbar-gap' }),
    h('h1', {}, title),
    h('div', { class: 'appbar-actions' }, actions));
}

export function goBack() {
  if (closeTopLayer()) return;
  if (history.length > 1) history.back();
  else location.hash = '#/home';
}

export function segmented(options, value, onChange) {
  const el = h('div', { class: 'seg', role: 'tablist' });
  const paint = (v) => [...el.children].forEach((b) => b.classList.toggle('on', b.dataset.v === v));
  options.forEach((o) => {
    el.append(h('button', { class: 'seg-btn', role: 'tab', 'data-v': o.value, onClick: () => { paint(o.value); onChange(o.value); } }, o.label));
  });
  paint(value);
  el.setValue = paint;
  return el;
}

export function chips(options, value, onChange) {
  const el = h('div', { class: 'chips' });
  const paint = (v) => [...el.children].forEach((b) => b.classList.toggle('on', String(b.dataset.v) === String(v)));
  options.forEach((o) => el.append(h('button', { class: 'chip', 'data-v': o.value, onClick: () => { paint(o.value); onChange(o.value); } }, o.label)));
  paint(value);
  el.setValue = paint;
  return el;
}

export function field(label, input, hint) {
  return h('label', { class: 'field' }, h('span', { class: 'field-label' }, label), input, hint ? h('span', { class: 'hint' }, hint) : null);
}

export function emptyState(iconName, title, text, action) {
  return h('div', { class: 'empty' },
    h('div', { class: 'empty-ico' }, icon(iconName, 34)),
    h('h3', {}, title),
    text ? h('p', { class: 'muted' }, text) : null,
    action || null);
}

export function toggleRow({ iconName, title, sub, value, onChange }) {
  const input = h('input', { type: 'checkbox', class: 'switch-input' });
  input.checked = !!value;
  input.addEventListener('change', () => onChange(input.checked));
  return h('label', { class: 'row-item' },
    iconName ? h('span', { class: 'row-ico' }, icon(iconName, 20)) : null,
    h('span', { class: 'row-text' }, h('span', { class: 'row-title' }, title), sub ? h('span', { class: 'row-sub' }, sub) : null),
    h('span', { class: 'switch' }, input, h('span', { class: 'knob' })));
}

export function navRow({ iconName, title, sub, value, onClick }) {
  return h('button', { class: 'row-item', onClick },
    iconName ? h('span', { class: 'row-ico' }, icon(iconName, 20)) : null,
    h('span', { class: 'row-text' }, h('span', { class: 'row-title' }, title), sub ? h('span', { class: 'row-sub' }, sub) : null),
    value ? h('span', { class: 'row-value' }, value) : null,
    icon('right', 18, 'faint'));
}

export function errMsg(e) {
  if (e && e.code) {
    const m = t('err.' + e.code);
    return m === 'err.' + e.code ? t('err.generic') : m;
  }
  return t('err.generic');
}

export function slider({ min = 0, max = 100, step = 1, value, format = (v) => v, onInput }) {
  const out = h('span', { class: 'range-val' }, format(value));
  const input = h('input', { type: 'range', class: 'range', min, max, step, value });
  const paint = () => {
    const p = ((input.value - min) / (max - min)) * 100;
    input.style.setProperty('--p', p + '%');
    out.textContent = format(Number(input.value));
  };
  input.addEventListener('input', () => { paint(); if (onInput) onInput(Number(input.value)); });
  paint();
  return { el: h('div', { class: 'range-row' }, input, out), get: () => Number(input.value), set(v) { input.value = v; paint(); } };
}

export function selectBox(options, value, onChange) {
  const el = h('select', { class: 'select' }, options.map((o) => h('option', { value: o.value }, o.label)));
  el.value = String(value);
  el.addEventListener('change', () => onChange && onChange(el.value));
  return el;
}

export function numberInput({ value = '', min = 1, max = 99999, placeholder = '', onInput } = {}) {
  const el = h('input', { type: 'number', inputmode: 'numeric', class: 'input', min, max, placeholder });
  el.value = value;
  el.addEventListener('input', () => onInput && onInput(el.value === '' ? null : Number(el.value)));
  return el;
}

export function textInput({ value = '', placeholder = '', type = 'text', onInput, multiline = false, autocapitalize = 'off' } = {}) {
  const el = multiline ? h('textarea', { class: 'input', rows: 3, placeholder }) : h('input', { type, class: 'input', placeholder, autocapitalize, autocomplete: 'off', spellcheck: 'false' });
  el.value = value;
  el.addEventListener('input', () => onInput && onInput(el.value));
  return el;
}
