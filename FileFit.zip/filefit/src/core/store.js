import { uid } from './util.js';

const K = 'filefit:v1:';
const load = (k, d) => { try { const v = localStorage.getItem(K + k); return v ? JSON.parse(v) : d; } catch { return d; } };
const save = (k, v) => { try { localStorage.setItem(K + k, JSON.stringify(v)); } catch { /* storage full or blocked */ } };

const DEFAULTS = {
  lang: 'auto',
  theme: 'system',
  quality: 80,
  imageFormat: 'original',
  imageFolder: 'pictures',
  autoSave: false,
  autoClean: true,
  maxMP: 25,
  onboarded: false,
  premium: false,
  jobsDone: 0,
};

const listeners = new Set();
export const onChange = (fn) => { listeners.add(fn); return () => listeners.delete(fn); };
const emit = (what) => listeners.forEach((f) => { try { f(what); } catch { /* ignore */ } });

let cache = { ...DEFAULTS, ...load('settings', {}) };
export const settings = {
  get: (k) => cache[k],
  set(k, v) { cache[k] = v; save('settings', cache); emit('settings:' + k); },
  reset() { cache = { ...DEFAULTS, onboarded: true, premium: cache.premium }; save('settings', cache); emit('settings'); },
};

let hist = load('history', []);
let scans = load('scans', []);

export const history = {
  list: () => hist.slice().sort((a, b) => b.time - a.time),
  favorites: () => history.list().filter((e) => e.fav),
  add(entry) {
    const e = { id: uid(), time: Date.now(), fav: false, ...entry };
    hist.push(e);
    if (hist.length > 500) hist = hist.slice(-500);
    save('history', hist);
    emit('history');
    return e;
  },
  find: (path, dir) => hist.find((e) => e.path === path && e.dir === dir),
  remove(id) { hist = hist.filter((e) => e.id !== id); save('history', hist); emit('history'); },
  removeByPath(path, dir) { hist = hist.filter((e) => !(e.path === path && e.dir === dir)); save('history', hist); emit('history'); },
  toggleFav(id) { const e = hist.find((x) => x.id === id); if (e) { e.fav = !e.fav; save('history', hist); emit('history'); } return e && e.fav; },
  clear() { hist = []; save('history', hist); emit('history'); },
  bytesSaved: () => hist.reduce((s, e) => s + Math.max(0, (e.orig || 0) - (e.size || 0)), 0),
};

export const scanLog = {
  list: () => scans.slice().sort((a, b) => b.time - a.time),
  add(entry) {
    if (scans[scans.length - 1] && scans[scans.length - 1].text === entry.text) return;
    scans.push({ id: uid(), time: Date.now(), ...entry });
    if (scans.length > 200) scans = scans.slice(-200);
    save('scans', scans);
  },
  remove(id) { scans = scans.filter((s) => s.id !== id); save('scans', scans); },
  clear() { scans = []; save('scans', scans); },
};
