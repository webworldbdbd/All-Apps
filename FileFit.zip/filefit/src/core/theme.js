import { settings } from './store.js';

let mq = null;
export function isDark() {
  const th = settings.get('theme');
  return th === 'dark' || (th === 'system' && window.matchMedia('(prefers-color-scheme: dark)').matches);
}

export async function applyTheme() {
  const dark = isDark();
  document.documentElement.dataset.theme = dark ? 'dark' : 'light';
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.setAttribute('content', dark ? '#0b1220' : '#f3f6fb');
  try {
    // Capacitor 8 SystemBars: light icons on dark background and vice versa
    const core = await import('@capacitor/core');
    if (core.SystemBars && core.SystemBarsStyle) await core.SystemBars.setStyle({ style: dark ? core.SystemBarsStyle.Dark : core.SystemBarsStyle.Light });
  } catch { /* running in a browser */ }
}

export function watchSystemTheme() {
  if (mq) return;
  mq = window.matchMedia('(prefers-color-scheme: dark)');
  mq.addEventListener('change', () => { if (settings.get('theme') === 'system') applyTheme(); });
}
