// Google Play Billing adapter.
// Purchases need (1) products created in Play Console and (2) the plugin below:
//   npm i cordova-plugin-purchase && npx cap sync android
// Without it, isAvailable() is false and the Premium screen says so honestly (nothing is faked).
import cfg from '../config.js';
import { settings } from './store.js';

const ids = cfg.billing;
let inited = false;

function lib() { return window.CdvPurchase || null; }
export const isAvailable = () => !!lib();

export async function initBilling() {
  const L = lib();
  if (!L || inited) return;
  inited = true;
  const { store, ProductType, Platform } = L;
  store.register([
    { id: ids.monthly, type: ProductType.PAID_SUBSCRIPTION, platform: Platform.GOOGLE_PLAY },
    { id: ids.yearly, type: ProductType.PAID_SUBSCRIPTION, platform: Platform.GOOGLE_PLAY },
    { id: ids.lifetime, type: ProductType.NON_CONSUMABLE, platform: Platform.GOOGLE_PLAY },
  ]);
  const sync = () => {
    const owned = [ids.monthly, ids.yearly, ids.lifetime].some((id) => store.owned(id));
    if (owned !== settings.get('premium')) settings.set('premium', owned);
  };
  store.when().approved((tx) => tx.finish()).finished(sync).productUpdated(sync).receiptUpdated(sync);
  await store.initialize([Platform.GOOGLE_PLAY]);
  sync();
}

export function priceOf(plan) {
  const L = lib();
  if (!L) return null;
  const p = L.store.get(ids[plan]);
  const offer = p && p.getOffer && p.getOffer();
  const ph = offer && offer.pricingPhases && offer.pricingPhases[0];
  return ph ? ph.price : (offer && offer.price) || null;
}

export async function purchase(plan) {
  const L = lib();
  if (!L) return { ok: false, reason: 'not_configured' };
  const p = L.store.get(ids[plan]);
  const offer = p && p.getOffer && p.getOffer();
  if (!offer) return { ok: false, reason: 'not_found' };
  const err = await offer.order();
  return err ? { ok: false, reason: 'failed', message: err.message } : { ok: true };
}

export async function restore() {
  const L = lib();
  if (!L) return false;
  await L.store.restorePurchases();
  return true;
}
