// Google AdMob ads: banner, interstitial and rewarded.
// IDs and the test/live switch live in app.config.json (ads.*). Ads never run on the web build, for Premium users,
// or while the "ad-free for 1 hour" reward is active.
import { Capacitor } from '@capacitor/core';
import cfg from '../config.js';
import { settings } from './store.js';

const AD_FREE_MS = 60 * 60 * 1000;

let admob = null;
let ready = false;
let bannerOn = false;
let lastInterstitial = 0;
let actions = 0;
let privacyRequired = false;

const adFree = () => Date.now() < (Number(settings.get('adFreeUntil')) || 0);
const baseEnabled = () => Capacitor.isNativePlatform() && !!cfg.ads.enabled && !settings.get('premium');
const enabled = () => baseEnabled() && !adFree();
const testing = () => !!cfg.ads.testMode;

export async function initAds() {
  if (!baseEnabled() || ready) return;
  try {
    const mod = await import('@capacitor-community/admob');
    admob = mod;
    const { AdMob } = mod;
    // Consent (Google UMP) comes first: the form only appears where the law requires it (EEA, UK ...).
    try {
      let info = await AdMob.requestConsentInfo();
      if (info && info.isConsentFormAvailable && info.status === 'REQUIRED') info = await AdMob.showConsentForm();
      privacyRequired = !!info && info.privacyOptionsRequirementStatus === 'REQUIRED';
      if (info && info.canRequestAds === false) return; // the user has not allowed ads
    } catch { /* consent is only required in some regions */ }
    await AdMob.initialize();
    ready = true;
  } catch (e) {
    console.warn('Ads unavailable', e);
  }
}

export const adsAvailable = () => ready && enabled();
export const adsPrivacyRequired = () => ready && privacyRequired;

export async function showAdPrivacyOptions() {
  if (!admob) return;
  try { await admob.AdMob.showPrivacyOptionsForm(); } catch (e) { console.warn('Privacy options failed', e); }
}

export async function showBanner(bottomMarginDp = 64) {
  if (!ready || !enabled() || bannerOn) return;
  try {
    const { AdMob, BannerAdSize, BannerAdPosition } = admob;
    await AdMob.showBanner({
      adId: cfg.ads.bannerId,
      adSize: BannerAdSize.ADAPTIVE_BANNER,
      position: BannerAdPosition.BOTTOM_CENTER,
      margin: bottomMarginDp,
      isTesting: testing(),
    });
    bannerOn = true;
    document.documentElement.classList.add('ads-on');
  } catch (e) { console.warn('Banner failed', e); }
}

export async function hideBanner() {
  if (!ready || !bannerOn) return;
  try { await admob.AdMob.removeBanner(); } catch { /* ignore */ }
  bannerOn = false;
  document.documentElement.classList.remove('ads-on');
}

/** Called after a completed save/share. Shows an interstitial at most every 5th action and every 4 minutes. */
export async function afterAction() {
  actions++;
  if (!ready || !enabled()) return;
  if (actions % 5 !== 0 || Date.now() - lastInterstitial < 4 * 60 * 1000) return;
  try {
    const { AdMob } = admob;
    await AdMob.prepareInterstitial({ adId: cfg.ads.interstitialId, isTesting: testing() });
    await AdMob.showInterstitial();
    lastInterstitial = Date.now();
  } catch (e) { console.warn('Interstitial failed', e); }
}

/** Opt-in rewarded video: the user taps a button, watches the video and gets 1 hour without ads. Resolves true if rewarded. */
export async function watchRewarded() {
  if (!ready || !enabled()) return false;
  const { AdMob, RewardAdPluginEvents } = admob;
  const handles = [];
  let rewarded = false;
  let finish;
  const finished = new Promise((resolve) => { finish = resolve; });
  try {
    handles.push(await AdMob.addListener(RewardAdPluginEvents.Rewarded, () => { rewarded = true; }));
    handles.push(await AdMob.addListener(RewardAdPluginEvents.Dismissed, () => finish()));
    handles.push(await AdMob.addListener(RewardAdPluginEvents.FailedToShow, () => finish()));
    handles.push(await AdMob.addListener(RewardAdPluginEvents.FailedToLoad, () => finish()));
    await AdMob.prepareRewardVideoAd({ adId: cfg.ads.rewardedId, isTesting: testing() });
    AdMob.showRewardVideoAd().catch(() => finish());
    await finished;
  } catch (e) {
    console.warn('Rewarded failed', e);
    return false;
  } finally {
    handles.forEach((x) => { try { x && x.remove && x.remove(); } catch { /* ignore */ } });
  }
  if (rewarded) {
    settings.set('adFreeUntil', Date.now() + AD_FREE_MS);
    hideBanner();
  }
  return rewarded;
}
