import { Capacitor } from '@capacitor/core';
import { Filesystem, Directory } from '@capacitor/filesystem';
import { Share } from '@capacitor/share';
import { settings, history } from './store.js';
import { blobToBase64, base64ToBlob, safeName, AppError, getExt } from './util.js';

export const isNative = Capacitor.isNativePlatform();
const APP_DIR = 'FileFit';
const TMP_DIR = 'filefit-share';

export function pickFiles({ accept, multiple = false }) {
  return new Promise((resolve) => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = accept;
    input.multiple = multiple;
    input.style.display = 'none';
    document.body.append(input);
    input.addEventListener('change', () => { const f = [...input.files]; input.remove(); resolve(f); });
    input.addEventListener('cancel', () => { input.remove(); resolve([]); });
    input.click();
  });
}

export function mimeOf(name, fallback = 'application/octet-stream') {
  const e = getExt(name);
  return ({ jpg: 'image/jpeg', jpeg: 'image/jpeg', png: 'image/png', webp: 'image/webp', pdf: 'application/pdf', zip: 'application/zip' })[e] || fallback;
}

function targetFor(kind) {
  if (kind === 'image' && settings.get('imageFolder') === 'pictures') {
    return { directory: Directory.ExternalStorage, base: 'Pictures/' + APP_DIR, label: 'Pictures/' + APP_DIR, key: 'pictures' };
  }
  return { directory: Directory.Documents, base: APP_DIR, label: 'Documents/' + APP_DIR, key: 'documents' };
}

async function ensurePermission() {
  try {
    const p = await Filesystem.checkPermissions();
    if (p.publicStorage !== 'granted') await Filesystem.requestPermissions();
  } catch { /* newer Android versions do not need it */ }
}

async function uniquePath(directory, base, name) {
  const dot = name.lastIndexOf('.');
  const stem = dot > 0 ? name.slice(0, dot) : name;
  const ext = dot > 0 ? name.slice(dot) : '';
  let n = 0;
  for (;;) {
    const candidate = base + '/' + stem + (n ? ' (' + n + ')' : '') + ext;
    try { await Filesystem.stat({ path: candidate, directory }); n++; if (n > 200) return candidate; }
    catch { return candidate; }
  }
}

export function downloadBlob(blob, name) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = name;
  document.body.append(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
}

/** Save into the FileFit folder. kind: 'image' | 'doc'. Returns {path, dir, label}. */
export async function saveBlob(blob, name, { kind = 'doc', tool = '', orig = 0 } = {}) {
  name = safeName(name);
  if (!isNative) {
    downloadBlob(blob, name);
    return { path: name, dir: 'web', label: 'Downloads' };
  }
  await ensurePermission();
  const tg = targetFor(kind);
  const data = await blobToBase64(blob);
  let path;
  try {
    path = await uniquePath(tg.directory, tg.base, name);
    await Filesystem.writeFile({ path, data, directory: tg.directory, recursive: true });
  } catch (e) {
    throw new AppError('save-failed', e && e.message);
  }
  history.add({ name: path.split('/').pop(), path, dir: tg.key, size: blob.size, mime: blob.type || mimeOf(name), tool, orig });
  return { path, dir: tg.key, label: tg.label };
}

async function writeTemp(blob, name) {
  const path = TMP_DIR + '/' + safeName(name);
  await Filesystem.writeFile({ path, data: await blobToBase64(blob), directory: Directory.Cache, recursive: true });
  const { uri } = await Filesystem.getUri({ path, directory: Directory.Cache });
  return uri;
}

export async function shareBlobs(list, title = 'FileFit') {
  if (!isNative) {
    const files = list.map((x) => new File([x.blob], x.name, { type: x.blob.type }));
    if (navigator.canShare && navigator.canShare({ files })) { await navigator.share({ files, title }); return; }
    list.forEach((x) => downloadBlob(x.blob, x.name));
    return;
  }
  const files = [];
  for (const x of list) files.push(await writeTemp(x.blob, x.name));
  await Share.share({ title, files, dialogTitle: title });
}

export async function shareText(text, title = 'FileFit') {
  if (isNative) return Share.share({ title, text, dialogTitle: title });
  if (navigator.share) return navigator.share({ title, text });
  return null;
}

export async function clearTemp() {
  if (!isNative) return;
  try { await Filesystem.rmdir({ path: TMP_DIR, directory: Directory.Cache, recursive: true }); } catch { /* nothing to remove */ }
}

const DIRS = {
  documents: { directory: Directory.Documents, base: APP_DIR },
  pictures: { directory: Directory.ExternalStorage, base: 'Pictures/' + APP_DIR },
};

export async function listSaved() {
  if (!isNative) return [];
  const out = [];
  for (const [key, d] of Object.entries(DIRS)) {
    try {
      const r = await Filesystem.readdir({ path: d.base, directory: d.directory });
      for (const f of r.files) {
        if (f.type === 'directory') continue;
        out.push({ name: f.name, size: f.size, time: f.mtime, path: d.base + '/' + f.name, dir: key, saved: true });
      }
    } catch { /* folder does not exist yet */ }
  }
  return out.sort((a, b) => (b.time || 0) - (a.time || 0));
}

export async function readSaved(path, dir) {
  const d = DIRS[dir];
  if (!d) throw new AppError('file-missing');
  try {
    const r = await Filesystem.readFile({ path, directory: d.directory });
    return base64ToBlob(typeof r.data === 'string' ? r.data : await blobToBase64(r.data), mimeOf(path));
  } catch {
    throw new AppError('file-missing');
  }
}

export async function deleteSaved(path, dir) {
  const d = DIRS[dir];
  if (!d) return;
  try { await Filesystem.deleteFile({ path, directory: d.directory }); } catch { /* already gone */ }
  history.removeByPath(path, dir);
}
