import { B, tr } from '../lite.js';

const Area = (label, extra) => ({ k: 'text', t: 'area', label: label || B('Your text', 'আপনার লেখা'), paste: true, ...extra });
const Chips = (k, label, opts, def, extra) => ({ k, t: 'chips', label, opts, def: def ?? opts[0][0], ...extra });
const lines = (s) => s.split(/\r?\n/);

export default [
  {
    id: 'extracttext', cat: 'text', icon: 'search', name: B('Extract from text', 'লেখা থেকে বের করুন'), desc: B('Emails, links, numbers, hashtags, phone numbers', 'ইমেইল, লিংক, সংখ্যা, হ্যাশট্যাগ, ফোন নম্বর'),
    inputs: [Area(), Chips('kind', B('Find', 'খুঁজুন'), [['email', B('Emails', 'ইমেইল')], ['url', B('Links', 'লিংক')], ['num', B('Numbers', 'সংখ্যা')], ['tag', B('Hashtags', 'হ্যাশট্যাগ')], ['phone', B('Phones', 'ফোন')]])],
    sample: { text: 'Mail a@b.com or visit https://x.org #hi 01712345678', kind: 'email' },
    run(v) {
      if (!v.text) return null;
      const rx = { email: /[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/g, url: /https?:\/\/[^\s<>"')]+/g, num: /-?\d+(?:\.\d+)?/g, tag: /#[\p{L}\p{N}_]+/gu, phone: /(?:\+?88)?01[3-9]\d{8}|\+?\d[\d\s-]{8,14}\d/g }[v.kind];
      const found = [...new Set(v.text.match(rx) || [])];
      return { text: found.join('\n'), note: B(found.length + ' unique found', found.length + 'টি আলাদা পাওয়া গেছে') };
    },
  },
  {
    id: 'prefixsuffix', cat: 'text', icon: 'plus', name: B('Add prefix & suffix', 'প্রতি লাইনে আগে-পরে যোগ'), desc: B('Add text to the start or end of every line', 'প্রতিটি লাইনের শুরু বা শেষে লেখা যোগ'),
    inputs: [Area(), { k: 'pre', t: 'text', label: B('Add before each line', 'প্রতি লাইনের আগে') }, { k: 'suf', t: 'text', label: B('Add after each line', 'প্রতি লাইনের পরে') }],
    sample: { text: 'a\nb', pre: '- ', suf: ';' },
    run(v) { return v.text ? { text: lines(v.text).map((l) => (l ? (v.pre || '') + l + (v.suf || '') : l)).join('\n') } : null; },
  },
  {
    id: 'numberlines', cat: 'text', icon: 'list', name: B('Add line numbers', 'লাইন নম্বর যোগ'), desc: B('Number every line of text', 'প্রতিটি লাইনে নম্বর বসান'),
    inputs: [Area(), { k: 'start', t: 'number', label: B('Start from', 'শুরুর নম্বর'), def: 1 }, Chips('sep', B('After the number', 'নম্বরের পরে'), [['. ', '1.'], [') ', '1)'], [': ', '1:'], ['\t', 'Tab']], '. ')],
    sample: { text: 'a\nb', start: 1, sep: '. ' },
    run(v) {
      if (!v.text) return null;
      let n = Number.isFinite(v.start) ? Math.trunc(v.start) : 1;
      return { text: lines(v.text).map((l) => (l.trim() ? (n++) + v.sep + l : l)).join('\n') };
    },
  },
  {
    id: 'repeat', cat: 'text', icon: 'copy', name: B('Repeat text', 'লেখা বারবার'), desc: B('Repeat a word or line many times', 'কোনো শব্দ বা লাইন অনেকবার লিখুন'),
    inputs: [Area(), { k: 'n', t: 'number', label: B('Times (up to 1000)', 'কতবার (১০০০ পর্যন্ত)'), def: 3 }, Chips('sep', B('Between copies', 'দুই কপির মাঝে'), [['\n', B('New line', 'নতুন লাইন')], [' ', B('Space', 'স্পেস')], ['', B('Nothing', 'কিছু না')]])],
    sample: { text: 'Hi', n: 3, sep: '\n' },
    run(v) { const n = Math.min(1000, Math.max(1, Math.floor(v.n || 0))); return v.text && n ? { text: Array(n).fill(v.text).join(v.sep) } : null; },
  },
  {
    id: 'removetags', cat: 'text', icon: 'trash', name: B('Remove HTML tags', 'HTML ট্যাগ সরান'), desc: B('Get plain text out of HTML', 'HTML থেকে সাধারণ লেখা বের করুন'),
    inputs: [Area(B('HTML', 'HTML'))], sample: { text: '<p>Hello <b>world</b></p>' },
    run(v) { return v.text ? { text: v.text.replace(/<(script|style)[\s\S]*?<\/\1>/gi, '').replace(/<br\s*\/?>|<\/p>|<\/div>|<\/li>/gi, '\n').replace(/<[^>]+>/g, '').replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/\n{3,}/g, '\n\n').trim() } : null; },
  },
  {
    id: 'removepunct', cat: 'text', icon: 'trash', name: B('Remove punctuation', 'যতিচিহ্ন সরান'), desc: B('Strip punctuation, digits or emoji', 'যতিচিহ্ন, অঙ্ক বা ইমোজি মুছুন'),
    inputs: [Area(), Chips('what', B('Remove', 'যা মুছবেন'), [['punct', B('Punctuation', 'যতিচিহ্ন')], ['digits', B('Digits', 'অঙ্ক')], ['emoji', B('Emoji', 'ইমোজি')]])],
    sample: { text: 'Hello, world! 123 😀', what: 'punct' },
    run(v) {
      if (!v.text) return null;
      const rx = { punct: /[\p{P}\p{S}]/gu, digits: /[0-9০-৯]/g, emoji: /[\p{Extended_Pictographic}\uFE0F\u200D]/gu }[v.what];
      return { text: v.text.replace(rx, '') };
    },
  },
  {
    id: 'charfreq', cat: 'text', icon: 'chart', name: B('Character frequency', 'অক্ষরের সংখ্যা'), desc: B('How often each letter appears', 'কোন অক্ষর কতবার আছে'),
    inputs: [Area(), Chips('mode', B('Count', 'গণনা'), [['letters', B('Letters', 'অক্ষর')], ['words', B('Words', 'শব্দ')]])],
    sample: { text: 'banana', mode: 'letters' },
    run(v) {
      if (!v.text) return null;
      const items = v.mode === 'words' ? v.text.toLowerCase().split(/[^\p{L}\p{N}]+/u).filter(Boolean) : [...v.text.toLowerCase()].filter((c) => /[\p{L}\p{N}]/u.test(c));
      const map = new Map(); items.forEach((c) => map.set(c, (map.get(c) || 0) + 1));
      const top = [...map].sort((a, b) => b[1] - a[1] || String(a[0]).localeCompare(b[0])).slice(0, 30);
      return { rows: top.map(([k, c]) => [k, c + ' (' + (c / items.length * 100).toFixed(1) + '%)']), note: B(items.length + ' total, ' + map.size + ' different', 'মোট ' + items.length + 'টি, আলাদা ' + map.size + 'টি') };
    },
  },
  {
    id: 'palindrome', cat: 'text', icon: 'convert', name: B('Palindrome checker', 'প্যালিনড্রোম যাচাই'), desc: B('Reads the same forwards and backwards?', 'সামনে-পিছনে একই পড়া যায় কি না'),
    inputs: [{ k: 'x', t: 'text', label: B('Word or phrase', 'শব্দ বা বাক্য'), ph: 'Never odd or even' }],
    run(v) {
      const s = (v.x || '');
      const c = [...s.toLowerCase()].filter((ch) => /[\p{L}\p{N}]/u.test(ch));
      if (!c.length) return null;
      const ok = c.join('') === [...c].reverse().join('');
      return { rows: [[B('Palindrome?', 'প্যালিনড্রোম?'), ok ? B('Yes', 'হ্যাঁ') : B('No', 'না')], [B('Reversed', 'উল্টানো'), [...c].reverse().join('')]], note: B('Spaces, punctuation and case are ignored.', 'স্পেস, যতিচিহ্ন ও অক্ষরের ধরন ধরা হয়নি।') };
    },
  },
  {
    id: 'splitjoin', cat: 'text', icon: 'split', name: B('Split & join lines', 'লাইন ভাঙা ও জোড়া'), desc: B('Turn a list into one line or back', 'তালিকাকে এক লাইনে বা উল্টো করুন'),
    inputs: [Area(), Chips('mode', B('Action', 'কাজ'), [['join', B('Join lines', 'লাইন জোড়ুন')], ['split', B('Split into lines', 'লাইনে ভাঙুন')]]), { k: 'sep', t: 'text', label: B('Separator', 'বিভাজক'), def: ', ' }],
    sample: { text: 'a\nb\nc', mode: 'join', sep: ', ' },
    run(v) {
      if (!v.text) return null;
      if (v.mode === 'join') return { text: lines(v.text).map((l) => l.trim()).filter(Boolean).join(v.sep ?? '') };
      return { text: v.text.split(v.sep || ',').map((x) => x.trim()).filter(Boolean).join('\n') };
    },
  },
  {
    id: 'removedupchars', cat: 'text', icon: 'trash', name: B('Remove line breaks & tabs', 'লাইন ব্রেক ও ট্যাব সরান'), desc: B('Make text one smooth block', 'লেখাকে একটানা এক ব্লকে আনুন'),
    inputs: [Area(), Chips('what', B('Remove', 'যা সরাবেন'), [['nl', B('Line breaks', 'লাইন ব্রেক')], ['tab', B('Tabs', 'ট্যাব')], ['both', B('Both', 'দুটোই')]])],
    sample: { text: 'a\nb\tc', what: 'both' },
    run(v) {
      if (!v.text) return null;
      let s = v.text;
      if (v.what !== 'tab') s = s.replace(/\s*\r?\n\s*/g, ' ');
      if (v.what !== 'nl') s = s.replace(/\t+/g, ' ');
      return { text: s.replace(/ {2,}/g, ' ').trim() };
    },
  },
];
