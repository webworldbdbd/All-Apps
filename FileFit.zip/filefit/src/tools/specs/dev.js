import { B, has, fmt, isNum, tr, toAscii, pad2 } from '../lite.js';
import * as M from '../mathlib.js';

const N = (k, label, extra) => ({ k, t: 'number', label, ...extra });
const T = (k, label, def, extra) => ({ k, t: 'toggle', label, def, ...extra });
const Chips = (k, label, opts, def, extra) => ({ k, t: 'chips', label, opts, def: def ?? opts[0][0], ...extra });
const Area = (label, extra) => ({ k: 'text', t: 'area', label: label || B('Your text', 'আপনার লেখা'), paste: true, ...extra });
const GEN = B('Generate again', 'আবার তৈরি করুন');

/* ---------- crypto-safe random ---------- */
function rnd(n) {
  const lim = Math.floor(0x100000000 / n) * n;
  const a = new Uint32Array(1);
  do { crypto.getRandomValues(a); } while (a[0] >= lim);
  return a[0] % n;
}
const pickFrom = (s) => s[rnd(s.length)];
const clampInt = (x, lo, hi, d) => (isNum(x) ? Math.min(hi, Math.max(lo, Math.floor(x))) : d);

const toBytesStr = (s) => { let r = ''; new TextEncoder().encode(s).forEach((b) => { r += String.fromCharCode(b); }); return r; };
const fromBytesStr = (bin) => new TextDecoder('utf-8', { fatal: true }).decode(Uint8Array.from(bin, (c) => c.charCodeAt(0)));
const b64urlDecode = (s) => { let t = s.replace(/-/g, '+').replace(/_/g, '/'); while (t.length % 4) t += '='; return fromBytesStr(atob(t)); };

const COMMON = ['123456', 'password', '12345678', 'qwerty', '123456789', '12345', '1234', '111111', '1234567', 'dragon', '123123', 'baseball', 'abc123', 'football', 'monkey', 'letmein', 'shadow', 'master', '666666', 'qwertyuiop', '123321', 'mustang', '1234567890', 'michael', 'superman', 'iloveyou', 'admin', 'welcome', 'login', 'passw0rd', 'bangladesh', 'dhaka123', 'allah123'];
const ENT = (len, pool) => len * Math.log2(pool);

const HTML_ENT = { '&amp;': '&', '&lt;': '<', '&gt;': '>', '&quot;': '"', '&#39;': "'", '&apos;': "'", '&nbsp;': ' ', '&copy;': '©', '&reg;': '®', '&euro;': '€', '&hellip;': '…', '&mdash;': '—', '&ndash;': '–' };

const MORSE_REV = Object.fromEntries(Object.entries(M.MORSE).map(([k, v]) => [v, k]));

export default [
  {
    id: 'password', cat: 'dev', icon: 'key', name: B('Password generator', 'পাসওয়ার্ড জেনারেটর'), desc: B('Strong random passwords', 'শক্তিশালী র‍্যান্ডম পাসওয়ার্ড'), action: GEN,
    inputs: [N('len', B('Length', 'দৈর্ঘ্য'), { def: 16 }), T('up', B('Uppercase (A-Z)', 'বড় হাতের (A-Z)'), true), T('low', B('Lowercase (a-z)', 'ছোট হাতের (a-z)'), true), T('dig', B('Digits (0-9)', 'অঙ্ক (0-9)'), true), T('sym', B('Symbols (!@#$…)', 'চিহ্ন (!@#$…)'), true), T('sim', B('Avoid look-alikes (0 O 1 l I)', 'দেখতে একরকম অক্ষর বাদ (0 O 1 l I)'), false), N('count', B('How many', 'কয়টি'), { def: 1 })],
    run(v) {
      const len = clampInt(v.len, 4, 128, 16), count = clampInt(v.count, 1, 20, 1);
      const rm = (s) => (v.sim ? s.replace(/[0O1lI]/g, '') : s);
      const sets = [];
      if (v.up) sets.push(rm('ABCDEFGHIJKLMNOPQRSTUVWXYZ')); if (v.low) sets.push(rm('abcdefghijklmnopqrstuvwxyz'));
      if (v.dig) sets.push(rm('0123456789')); if (v.sym) sets.push('!@#$%^&*()-_=+[]{};:,.?');
      if (!sets.length) return { error: B('Turn on at least one character type', 'অন্তত একটি ধরন চালু করুন') };
      const pool = sets.join('');
      const out = [];
      for (let i = 0; i < count; i++) {
        const ch = sets.map(pickFrom);
        while (ch.length < len) ch.push(pickFrom(pool));
        for (let j = ch.length - 1; j > 0; j--) { const k = rnd(j + 1); [ch[j], ch[k]] = [ch[k], ch[j]]; }
        out.push(ch.slice(0, len).join(''));
      }
      return { text: out.join('\n'), note: B('About ' + Math.round(ENT(len, pool.length)) + ' bits of strength', 'প্রায় ' + Math.round(ENT(len, pool.length)) + ' বিট শক্তি') };
    },
  },
  {
    id: 'pin', cat: 'dev', icon: 'key', name: B('PIN generator', 'পিন জেনারেটর'), desc: B('Random numeric PIN codes', 'র‍্যান্ডম সংখ্যার পিন'), action: GEN,
    inputs: [N('len', B('Digits', 'অঙ্ক'), { def: 6 }), N('count', B('How many', 'কয়টি'), { def: 5 })],
    run(v) {
      const len = clampInt(v.len, 3, 20, 6), count = clampInt(v.count, 1, 50, 5);
      return { text: Array.from({ length: count }, () => Array.from({ length: len }, () => rnd(10)).join('')).join('\n') };
    },
  },
  {
    id: 'randstr', cat: 'dev', icon: 'key', name: B('Random string', 'র‍্যান্ডম স্ট্রিং'), desc: B('Random tokens, IDs and codes', 'র‍্যান্ডম টোকেন, আইডি ও কোড'), action: GEN,
    inputs: [N('len', B('Length', 'দৈর্ঘ্য'), { def: 20 }), N('count', B('How many', 'কয়টি'), { def: 5 }),
      Chips('set', B('Characters', 'অক্ষর'), [['alnum', B('Letters + digits', 'অক্ষর + অঙ্ক')], ['letters', B('Letters', 'অক্ষর')], ['digits', B('Digits', 'অঙ্ক')], ['hex', 'Hex'], ['b64', 'URL-safe']])],
    run(v) {
      const len = clampInt(v.len, 1, 256, 20), count = clampInt(v.count, 1, 50, 5);
      const A = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
      const pool = { alnum: A + '0123456789', letters: A, digits: '0123456789', hex: '0123456789abcdef', b64: A + '0123456789-_' }[v.set];
      return { text: Array.from({ length: count }, () => Array.from({ length: len }, () => pickFrom(pool)).join('')).join('\n') };
    },
  },
  {
    id: 'randnum', cat: 'dev', icon: 'dice', name: B('Random number', 'র‍্যান্ডম সংখ্যা'), desc: B('Random whole numbers in a range', 'নির্দিষ্ট পরিসরে র‍্যান্ডম সংখ্যা'), action: GEN,
    inputs: [N('min', B('From', 'থেকে'), { def: 1, neg: true }), N('max', B('To', 'পর্যন্ত'), { def: 100, neg: true }), N('count', B('How many', 'কয়টি'), { def: 1 }), T('uniq', B('No repeats', 'পুনরাবৃত্তি নয়'), false)],
    run(v) {
      if (!has(v, 'min', 'max')) return null;
      const lo = Math.ceil(v.min), hi = Math.floor(v.max);
      if (lo > hi) return { error: B('"From" must not be bigger than "To"', '"থেকে" "পর্যন্ত" এর চেয়ে বড় হতে পারবে না') };
      const range = hi - lo + 1;
      if (range > 4294967296) return { error: B('Range is too large', 'পরিসর খুব বড়') };
      const count = clampInt(v.count, 1, 1000, 1);
      if (v.uniq && count > range) return { error: B('Not enough different numbers in that range', 'এই পরিসরে এত আলাদা সংখ্যা নেই') };
      const out = []; const seen = new Set();
      while (out.length < count) { const x = lo + rnd(range); if (v.uniq) { if (seen.has(x)) continue; seen.add(x); } out.push(x); }
      return { text: out.join(count > 1 ? ', ' : '') };
    },
  },
  {
    id: 'uuid', cat: 'dev', icon: 'hash', name: B('UUID generator', 'UUID জেনারেটর'), desc: B('Random version 4 UUIDs', 'র‍্যান্ডম ভার্সন ৪ UUID'), action: GEN,
    inputs: [N('count', B('How many', 'কয়টি'), { def: 5 }), T('upper', B('Uppercase', 'বড় হাতের'), false), T('nodash', B('Remove dashes', 'ড্যাশ বাদ'), false)],
    run(v) {
      const count = clampInt(v.count, 1, 100, 5);
      const gen = () => {
        if (crypto.randomUUID) return crypto.randomUUID();
        const b = crypto.getRandomValues(new Uint8Array(16)); b[6] = (b[6] & 15) | 64; b[8] = (b[8] & 63) | 128;
        const h = [...b].map((x) => x.toString(16).padStart(2, '0')).join('');
        return `${h.slice(0, 8)}-${h.slice(8, 12)}-${h.slice(12, 16)}-${h.slice(16, 20)}-${h.slice(20)}`;
      };
      return { text: Array.from({ length: count }, () => { let u = gen(); if (v.nodash) u = u.replace(/-/g, ''); return v.upper ? u.toUpperCase() : u; }).join('\n') };
    },
  },
  {
    id: 'hash', cat: 'dev', icon: 'hash', name: B('Hash generator', 'হ্যাশ জেনারেটর'), desc: B('MD5, SHA-1, SHA-256, SHA-512', 'MD5, SHA-1, SHA-256, SHA-512'),
    inputs: [Area()], sample: { text: 'hello' },
    async run(v) {
      if (!v.text) return null;
      const data = new TextEncoder().encode(v.text);
      const hex = async (alg) => [...new Uint8Array(await crypto.subtle.digest(alg, data))].map((b) => b.toString(16).padStart(2, '0')).join('');
      return { rows: [['MD5', M.md5(v.text)], ['SHA-1', await hex('SHA-1')], ['SHA-256', await hex('SHA-256')], ['SHA-384', await hex('SHA-384')], ['SHA-512', await hex('SHA-512')]], note: B('MD5 and SHA-1 are not safe for passwords. Use them only for checksums.', 'MD5 ও SHA-1 পাসওয়ার্ডের জন্য নিরাপদ নয়। শুধু চেকসামের কাজে ব্যবহার করুন।') };
    },
  },
  {
    id: 'strength', cat: 'dev', icon: 'lock', name: B('Password strength checker', 'পাসওয়ার্ড শক্তি যাচাই'), desc: B('Check how strong a password is', 'পাসওয়ার্ড কতটা শক্তিশালী'),
    inputs: [{ k: 'pw', t: 'text', label: B('Password', 'পাসওয়ার্ড'), hint: B('Checked on your phone only. Nothing is sent anywhere.', 'শুধু আপনার ফোনেই যাচাই হয়। কিছু কোথাও পাঠানো হয় না।') }],
    run(v) {
      const p = v.pw || '';
      if (!p) return null;
      let pool = 0;
      if (/[a-z]/.test(p)) pool += 26; if (/[A-Z]/.test(p)) pool += 26; if (/\d/.test(p)) pool += 10; if (/[^A-Za-z0-9]/.test(p)) pool += 32;
      let bits = ENT(p.length, pool || 1);
      const tips = [];
      const common = COMMON.includes(p.toLowerCase());
      if (common) { bits = Math.min(bits, 10); tips.push(B('This is a very common password', 'এটি খুব পরিচিত পাসওয়ার্ড')); }
      if (/(.)\1{2,}/.test(p)) { bits *= 0.8; tips.push(B('Avoid repeating characters', 'একই অক্ষর বারবার নয়')); }
      if (/(0123|1234|2345|3456|4567|5678|6789|abcd|bcde|cdef|qwer|asdf)/i.test(p)) { bits *= 0.8; tips.push(B('Avoid simple sequences like 1234 or abcd', '1234 বা abcd এর মতো সহজ ক্রম নয়')); }
      if (p.length < 12) tips.push(B('Use 12 or more characters', '১২ বা বেশি অক্ষর ব্যবহার করুন'));
      if (!/[a-z]/.test(p) || !/[A-Z]/.test(p)) tips.push(B('Mix upper and lower case', 'বড় ও ছোট হাতের অক্ষর মেশান'));
      if (!/\d/.test(p)) tips.push(B('Add digits', 'অঙ্ক যোগ করুন'));
      if (!/[^A-Za-z0-9]/.test(p)) tips.push(B('Add symbols', 'চিহ্ন যোগ করুন'));
      const rate = bits < 28 ? B('Very weak', 'খুব দুর্বল') : bits < 36 ? B('Weak', 'দুর্বল') : bits < 60 ? B('Fair', 'মোটামুটি') : bits < 80 ? B('Strong', 'শক্তিশালী') : B('Very strong', 'অত্যন্ত শক্তিশালী');
      return { rows: [[B('Strength', 'শক্তি'), rate], [B('Estimated entropy', 'আনুমানিক এনট্রপি'), Math.round(bits) + ' bits'], [B('Length', 'দৈর্ঘ্য'), p.length]], note: B((tips.length ? 'Tips: ' + tips.map((x) => x.en).join('; ') + '. ' : '') + 'This is only an estimate. Real words, names and dates are easy to guess even when the result looks strong.', (tips.length ? 'পরামর্শ: ' + tips.map((x) => x.bn).join('; ') + '। ' : '') + 'এটি শুধু আনুমানিক হিসাব। আসল শব্দ, নাম ও তারিখ ফলাফল শক্তিশালী দেখালেও সহজে অনুমান করা যায়।') };
    },
  },
  {
    id: 'b64enc', cat: 'dev', icon: 'code', name: B('Base64 encoder', 'Base64 এনকোডার'), desc: B('Text to Base64', 'লেখা থেকে Base64'),
    inputs: [Area(), T('safe', B('URL-safe', 'URL-safe'), false)], sample: { text: 'হ্যালো hello' },
    run(v) {
      if (!v.text) return null;
      let o = btoa(toBytesStr(v.text));
      if (v.safe) o = o.replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
      return { text: o };
    },
  },
  {
    id: 'b64dec', cat: 'dev', icon: 'code', name: B('Base64 decoder', 'Base64 ডিকোডার'), desc: B('Base64 back to text', 'Base64 থেকে লেখা'),
    inputs: [Area(B('Base64 text', 'Base64 লেখা'))], sample: { text: 'aGVsbG8=' },
    run(v) {
      const s = (v.text || '').trim();
      if (!s) return null;
      try { return { text: b64urlDecode(s.replace(/\s+/g, '')) }; } catch { return { error: B('This is not valid Base64 text', 'এটি বৈধ Base64 লেখা নয়') }; }
    },
  },
  {
    id: 'urlenc', cat: 'dev', icon: 'link', name: B('URL encoder', 'URL এনকোডার'), desc: B('Make text safe for web addresses', 'লেখাকে ওয়েব ঠিকানার উপযোগী করুন'),
    inputs: [Area(), Chips('mode', B('Mode', 'ধরন'), [['comp', B('Part of a URL', 'URL এর অংশ')], ['full', B('Whole URL', 'পুরো URL')]])], sample: { text: 'a b&c=d' },
    run(v) { if (!v.text) return null; try { return { text: v.mode === 'full' ? encodeURI(v.text) : encodeURIComponent(v.text) }; } catch { return { error: B('Could not encode this text', 'লেখাটি এনকোড করা যায়নি') }; } },
  },
  {
    id: 'urldec', cat: 'dev', icon: 'link', name: B('URL decoder', 'URL ডিকোডার'), desc: B('Percent-encoded text back to normal', 'শতাংশ-কোড থেকে সাধারণ লেখা'),
    inputs: [Area(B('Encoded text', 'এনকোড করা লেখা'))], sample: { text: 'a%20b%26c' },
    run(v) { if (!v.text) return null; try { return { text: decodeURIComponent(v.text.replace(/\+/g, ' ')) }; } catch { return { error: B('This is not valid encoded text', 'এটি বৈধ এনকোড করা লেখা নয়') }; } },
  },
  {
    id: 'htmlenc', cat: 'dev', icon: 'code', name: B('HTML encoder', 'HTML এনকোডার'), desc: B('Escape & < > " characters', '& < > " চিহ্ন এস্কেপ করুন'),
    inputs: [Area()], sample: { text: '<a href="x">Tom & Jerry</a>' },
    run(v) { return v.text ? { text: v.text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;') } : null; },
  },
  {
    id: 'htmldec', cat: 'dev', icon: 'code', name: B('HTML decoder', 'HTML ডিকোডার'), desc: B('Turn &amp; &lt; &gt; back into characters', '&amp; &lt; &gt; আবার চিহ্নে ফেরান'),
    inputs: [Area(B('HTML entities', 'HTML এনটিটি'))], sample: { text: '&lt;b&gt;Tom &amp; Jerry&lt;/b&gt; &#169;' },
    run(v) {
      if (!v.text) return null;
      return { text: v.text.replace(/&#(\d+);/g, (_, n) => String.fromCodePoint(+n)).replace(/&#x([0-9a-f]+);/gi, (_, n) => String.fromCodePoint(parseInt(n, 16))).replace(/&[a-z]+;|&#39;/gi, (e) => HTML_ENT[e.toLowerCase()] ?? e) };
    },
  },
  {
    id: 'json', cat: 'dev', icon: 'code', name: B('JSON formatter', 'JSON ফরম্যাটার'), desc: B('Beautify and validate JSON', 'JSON সাজান ও যাচাই করুন'),
    inputs: [Area(B('JSON', 'JSON')), Chips('ind', B('Indent', 'ইন্ডেন্ট'), [['2', B('2 spaces', '২ স্পেস')], ['4', B('4 spaces', '৪ স্পেস')], ['tab', 'Tab']])], sample: { text: '{"a":1,"b":[1,2,{"c":true}]}' },
    run(v) {
      if (!v.text || !v.text.trim()) return null;
      try {
        const o = JSON.parse(v.text);
        const kind = Array.isArray(o) ? 'array (' + o.length + ')' : o && typeof o === 'object' ? 'object (' + Object.keys(o).length + ' keys)' : typeof o;
        return { text: JSON.stringify(o, null, v.ind === 'tab' ? '\t' : +v.ind), note: B('Valid JSON: ' + kind, 'বৈধ JSON: ' + kind) };
      } catch (e) { return { error: B('Invalid JSON: ' + e.message, 'JSON ভুল: ' + e.message) }; }
    },
  },
  {
    id: 'jsonmin', cat: 'dev', icon: 'code', name: B('JSON minifier', 'JSON মিনিফায়ার'), desc: B('Remove spaces from JSON', 'JSON থেকে বাড়তি স্পেস সরান'),
    inputs: [Area(B('JSON', 'JSON'))], sample: { text: '{ "a": 1,\n "b": [ 1, 2 ] }' },
    run(v) {
      if (!v.text || !v.text.trim()) return null;
      try { const out = JSON.stringify(JSON.parse(v.text)); return { text: out, note: B('Saved ' + (v.text.length - out.length) + ' characters', (v.text.length - out.length) + ' অক্ষর কমেছে') }; } catch (e) { return { error: B('Invalid JSON: ' + e.message, 'JSON ভুল: ' + e.message) }; }
    },
  },
  {
    id: 'regex', cat: 'dev', icon: 'search', name: B('Regex tester', 'Regex টেস্টার'), desc: B('Test regular expressions', 'রেগুলার এক্সপ্রেশন পরীক্ষা'),
    inputs: [{ k: 'p', t: 'text', label: B('Pattern', 'প্যাটার্ন'), ph: '\\d+' }, T('i', B('Ignore case (i)', 'ছোট-বড় এক ধরুন (i)'), false), T('m', B('Multiline (m)', 'মাল্টিলাইন (m)'), false), Area(B('Text to test', 'পরীক্ষার লেখা'))],
    sample: { p: '\\d+', text: 'a1 b22 c333' },
    run(v) {
      if (!v.p || !v.text) return null;
      let rx;
      try { rx = new RegExp(v.p, 'gu' + (v.i ? 'i' : '') + (v.m ? 'm' : '')); } catch (e) { return { error: B('Pattern error: ' + e.message, 'প্যাটার্নে ভুল: ' + e.message) }; }
      const text = v.text.slice(0, 50000);
      const out = []; let m; let guard = 0;
      while ((m = rx.exec(text)) && guard++ < 500) {
        out.push(guard + '. "' + m[0] + '" @' + m.index + (m.length > 1 ? '  ' + m.slice(1).map((g, k) => '$' + (k + 1) + '=' + g).join(' ') : ''));
        if (m[0] === '') rx.lastIndex++;
      }
      return { text: out.join('\n'), note: B(out.length + ' match(es)', out.length + 'টি মিল পাওয়া গেছে') };
    },
  },
  {
    id: 'jwt', cat: 'dev', icon: 'key', name: B('JWT decoder', 'JWT ডিকোডার'), desc: B('Read a JSON Web Token (not verified)', 'JWT টোকেনের ভেতরের তথ্য দেখুন (যাচাই হয় না)'),
    inputs: [Area(B('JWT token', 'JWT টোকেন'))], sample: { text: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0IiwibmFtZSI6IkFsaSIsImlhdCI6MTUxNjIzOTAyMn0.sig' },
    run(v) {
      const parts = (v.text || '').trim().split('.');
      if (parts.length < 2 || !parts[0]) return v.text && v.text.trim() ? { error: B('A JWT has three parts separated by dots', 'JWT এর তিনটি অংশ থাকে, ডট দিয়ে আলাদা') } : null;
      try {
        const head = JSON.parse(b64urlDecode(parts[0])), pay = JSON.parse(b64urlDecode(parts[1]));
        const rows = [];
        if (head.alg) rows.push([B('Algorithm', 'অ্যালগরিদম'), head.alg]);
        const dt = (s) => new Date(s * 1000).toISOString().replace('T', ' ').slice(0, 19) + ' UTC';
        if (isNum(pay.iat)) rows.push([B('Issued at', 'ইস্যুর সময়'), dt(pay.iat)]);
        if (isNum(pay.exp)) rows.push([B('Expires', 'মেয়াদ শেষ'), dt(pay.exp) + (pay.exp * 1000 < Date.now() ? ' (' + tr(B('expired', 'মেয়াদ উত্তীর্ণ')) + ')' : '')]);
        return { rows, text: JSON.stringify({ header: head, payload: pay }, null, 2), note: B('The signature is not verified here.', 'এখানে সিগনেচার যাচাই করা হয় না।') };
      } catch { return { error: B('Could not read this token', 'টোকেনটি পড়া যায়নি') }; }
    },
  },
  {
    id: 'text2bin', cat: 'dev', icon: 'code', name: B('Text to binary', 'লেখা থেকে বাইনারি'), desc: B('Convert text to 0s and 1s', 'লেখাকে ০ ও ১ এ রূপান্তর'),
    inputs: [Area()], sample: { text: 'Hi' },
    run(v) { return v.text ? { text: [...new TextEncoder().encode(v.text)].map((b) => b.toString(2).padStart(8, '0')).join(' ') } : null; },
  },
  {
    id: 'bin2text', cat: 'dev', icon: 'code', name: B('Binary to text', 'বাইনারি থেকে লেখা'), desc: B('Convert 0s and 1s to text', '০ ও ১ থেকে লেখা'),
    inputs: [Area(B('Binary (8 bits per character)', 'বাইনারি (প্রতি অক্ষরে ৮ বিট)'))], sample: { text: '01001000 01101001' },
    run(v) {
      const s = (v.text || '').replace(/\s+/g, '');
      if (!s) return null;
      if (!/^[01]+$/.test(s) || s.length % 8) return { error: B('Use only 0 and 1, in groups of 8', 'শুধু ০ ও ১ দিন, ৮টি করে') };
      try { return { text: fromBytesStr(s.match(/.{8}/g).map((b) => String.fromCharCode(parseInt(b, 2))).join('')) }; } catch { return { error: B('These bits are not valid text', 'এই বিটগুলো বৈধ লেখা নয়') }; }
    },
  },
  {
    id: 'text2hex', cat: 'dev', icon: 'code', name: B('Text to hex', 'লেখা থেকে হেক্স'), desc: B('Convert text to hexadecimal', 'লেখাকে হেক্সাডেসিমালে রূপান্তর'),
    inputs: [Area()], sample: { text: 'Hi' },
    run(v) { return v.text ? { text: [...new TextEncoder().encode(v.text)].map((b) => b.toString(16).padStart(2, '0')).join(' ') } : null; },
  },
  {
    id: 'hex2text', cat: 'dev', icon: 'code', name: B('Hex to text', 'হেক্স থেকে লেখা'), desc: B('Convert hexadecimal to text', 'হেক্সাডেসিমাল থেকে লেখা'),
    inputs: [Area(B('Hex bytes', 'হেক্স বাইট'))], sample: { text: '48 69' },
    run(v) {
      const s = (v.text || '').replace(/0x|[\s,]+/gi, '');
      if (!s) return null;
      if (!/^[0-9a-f]+$/i.test(s) || s.length % 2) return { error: B('Use pairs of hex digits (0-9, A-F)', 'হেক্স অঙ্কের জোড়া দিন (0-9, A-F)') };
      try { return { text: fromBytesStr(s.match(/../g).map((b) => String.fromCharCode(parseInt(b, 16))).join('')) }; } catch { return { error: B('These bytes are not valid text', 'এই বাইটগুলো বৈধ লেখা নয়') }; }
    },
  },
  {
    id: 'morse', cat: 'dev', icon: 'code', name: B('Morse code', 'মোর্স কোড'), desc: B('Text to Morse and back', 'লেখা থেকে মোর্স ও উল্টো'),
    inputs: [Area(), Chips('mode', B('Mode', 'ধরন'), [['enc', B('Text → Morse', 'লেখা → মোর্স')], ['dec', B('Morse → Text', 'মোর্স → লেখা')]])], sample: { text: 'SOS', mode: 'enc' },
    run(v) {
      if (!v.text) return null;
      if (v.mode === 'enc') return { text: v.text.toUpperCase().split(/\s+/).filter(Boolean).map((w) => [...w].map((c) => M.MORSE[c]).filter(Boolean).join(' ')).join(' / ') };
      return { text: v.text.trim().split(/\s*\/\s*|\s{3,}/).map((w) => w.split(/\s+/).map((c) => MORSE_REV[c] ?? '?').join('')).join(' ') };
    },
  },
  {
    id: 'caesar', cat: 'dev', icon: 'lock', name: B('Caesar cipher', 'সিজার সাইফার'), desc: B('Shift letters to hide a message', 'অক্ষর সরিয়ে বার্তা লুকান (ROT13 সহ)'),
    inputs: [Area(), N('shift', B('Shift (1-25)', 'শিফট (১-২৫)'), { def: 3, neg: true }), Chips('mode', B('Mode', 'ধরন'), [['enc', B('Encrypt', 'এনক্রিপ্ট')], ['dec', B('Decrypt', 'ডিক্রিপ্ট')]])], sample: { text: 'Hello', shift: 3, mode: 'enc' },
    run(v) {
      if (!v.text || !isNum(v.shift)) return null;
      const k = ((Math.trunc(v.shift) * (v.mode === 'dec' ? -1 : 1)) % 26 + 26) % 26;
      return { text: v.text.replace(/[a-z]/gi, (c) => { const b = c <= 'Z' ? 65 : 97; return String.fromCharCode((c.charCodeAt(0) - b + k) % 26 + b); }) };
    },
  },
  {
    id: 'emailval', cat: 'dev', icon: 'mail', name: B('Email validator', 'ইমেইল যাচাই'), desc: B('Check an email address format', 'ইমেইল ঠিকানার ফরম্যাট যাচাই'),
    inputs: [{ k: 'x', t: 'text', label: B('Email address', 'ইমেইল ঠিকানা'), ph: 'name@example.com' }],
    run(v) {
      const s = (v.x || '').trim();
      if (!s) return null;
      const m = /^([^\s@]+)@([^\s@]+)$/.exec(s);
      const issues = [];
      if (!m) issues.push(B('Needs one @ with text on both sides', '@ এর দুই পাশে লেখা থাকতে হবে'));
      else {
        const [, local, dom] = m;
        if (local.length > 64) issues.push(B('Name part is longer than 64 characters', '@ এর আগের অংশ ৬৪ অক্ষরের বেশি'));
        if (/^\.|\.$|\.\./.test(local)) issues.push(B('Name part has a misplaced dot', '@ এর আগের অংশে ডটের ভুল ব্যবহার'));
        if (!/^[a-z0-9-]+(\.[a-z0-9-]+)+$/i.test(dom) || /(^|\.)-|-(\.|$)/.test(dom)) issues.push(B('Domain looks invalid (example: gmail.com)', 'ডোমেইন ঠিক নয় (যেমন: gmail.com)'));
        else if (dom.split('.').pop().length < 2) issues.push(B('Domain ending is too short', 'ডোমেইনের শেষ অংশ খুব ছোট'));
      }
      return { rows: [[B('Format', 'ফরম্যাট'), issues.length ? B('Not valid', 'সঠিক নয়') : B('Valid', 'সঠিক')], ...(m ? [[B('Name part', 'নাম অংশ'), m[1]], [B('Domain', 'ডোমেইন'), m[2]]] : []), ...issues.map((x) => [B('Problem', 'সমস্যা'), x])], note: B('This checks the format only, not whether the mailbox exists.', 'এটি শুধু ফরম্যাট দেখে, ইনবক্স আছে কি না নয়।') };
    },
  },
  {
    id: 'urlval', cat: 'dev', icon: 'link', name: B('URL validator', 'URL যাচাই'), desc: B('Check and break down a web address', 'ওয়েব ঠিকানা যাচাই ও ভাগ করে দেখা'),
    inputs: [{ k: 'x', t: 'text', label: B('Web address', 'ওয়েব ঠিকানা'), ph: 'https://example.com/page?id=1' }],
    run(v) {
      const s = (v.x || '').trim();
      if (!s) return null;
      let u; let added = false;
      try { u = new URL(s); } catch { try { u = new URL('https://' + s); added = true; } catch { return { error: B('This is not a valid web address', 'এটি বৈধ ওয়েব ঠিকানা নয়') }; } }
      if (!/^https?:$/.test(u.protocol) && !added) return { rows: [[B('Format', 'ফরম্যাট'), B('Valid, but not a web link', 'সঠিক, তবে ওয়েব লিংক নয়')], [B('Protocol', 'প্রোটোকল'), u.protocol]] };
      if (!u.hostname.includes('.') && u.hostname !== 'localhost') return { error: B('The host name looks incomplete', 'হোস্টের নাম অসম্পূর্ণ মনে হচ্ছে') };
      const q = [...u.searchParams].map(([k, val]) => k + '=' + val).join('\n');
      return { rows: [[B('Format', 'ফরম্যাট'), B('Valid', 'সঠিক')], [B('Protocol', 'প্রোটোকল'), u.protocol.replace(':', '')], [B('Host', 'হোস্ট'), u.hostname], ...(u.port ? [[B('Port', 'পোর্ট'), u.port]] : []), [B('Path', 'পাথ'), u.pathname], ...(q ? [[B('Query', 'কোয়েরি'), q]] : []), ...(u.hash ? [[B('Fragment', 'ফ্রাগমেন্ট'), u.hash]] : [])], note: added ? B('No https:// was typed, so it was added to check.', 'https:// লেখা ছিল না, যাচাইয়ের জন্য যোগ করা হয়েছে।') : null };
    },
  },
  {
    id: 'coin', cat: 'dev', icon: 'dice', name: B('Coin flip', 'কয়েন টস'), desc: B('Heads or tails', 'হেড না টেইল'), action: B('Flip', 'টস করুন'),
    inputs: [N('n', B('Number of flips', 'কতবার টস'), { def: 1 })],
    run(v) {
      const n = clampInt(v.n, 1, 1000, 1);
      let h = 0; for (let i = 0; i < n; i++) if (rnd(2)) h++;
      if (n === 1) return { rows: [[B('Result', 'ফলাফল'), h ? B('Heads', 'হেড') : B('Tails', 'টেইল')]] };
      return { rows: [[B('Heads', 'হেড'), h], [B('Tails', 'টেইল'), n - h]] };
    },
  },
  {
    id: 'dice', cat: 'dev', icon: 'dice', name: B('Dice roller', 'পাশা খেলা'), desc: B('Roll one or more dice', 'এক বা একাধিক পাশা ছুড়ুন'), action: B('Roll', 'ছুড়ুন'),
    inputs: [N('n', B('Number of dice', 'পাশার সংখ্যা'), { def: 2 }), { k: 's', t: 'chips', label: B('Sides', 'পাশের সংখ্যা'), opts: ['4', '6', '8', '10', '12', '20', '100'].map((x) => [x, x]), def: '6' }],
    run(v) {
      const n = clampInt(v.n, 1, 20, 2), s = +v.s;
      const r = Array.from({ length: n }, () => 1 + rnd(s));
      return { rows: [[B('Rolls', 'ফলাফল'), r.join(', ')], [B('Total', 'মোট'), r.reduce((a, b) => a + b, 0)]] };
    },
  },
  {
    id: 'picker', cat: 'dev', icon: 'dice', name: B('Random picker', 'লটারি / র‍্যান্ডম বাছাই'), desc: B('Pick winners from a list', 'তালিকা থেকে বিজয়ী বাছাই'), action: B('Pick', 'বাছাই করুন'),
    inputs: [Area(B('Names (one per line)', 'নাম (প্রতি লাইনে একটি)')), N('n', B('How many to pick', 'কয়জন বাছাই'), { def: 1 })], sample: { text: 'Rahim\nKarim\nSalma\nNusrat', n: 2 },
    run(v) {
      const list = (v.text || '').split(/\r?\n/).map((x) => x.trim()).filter(Boolean);
      if (!list.length) return null;
      const n = clampInt(v.n, 1, list.length, 1);
      const pool = [...list]; const out = [];
      for (let i = 0; i < n; i++) out.push(pool.splice(rnd(pool.length), 1)[0]);
      return { rows: out.map((x, i) => [(i + 1) + '', x]) };
    },
  },
  {
    id: 'csv2json', cat: 'dev', icon: 'code', name: B('CSV to JSON', 'CSV থেকে JSON'), desc: B('Turn spreadsheet rows into JSON', 'স্প্রেডশিটের সারি থেকে JSON'),
    inputs: [Area(B('CSV', 'CSV')), Chips('d', B('Separator', 'বিভাজক'), [[',', B('Comma', 'কমা')], [';', B('Semicolon', 'সেমিকোলন')], ['\t', 'Tab']]), T('head', B('First row is the header', 'প্রথম সারি হেডার'), true)],
    sample: { text: 'name,age\nAli,30\nSara,25', d: ',', head: true },
    run(v) {
      if (!v.text || !v.text.trim()) return null;
      const rows = M.parseCsv(v.text, v.d);
      if (!rows.length) return null;
      if (!v.head) return { text: JSON.stringify(rows, null, 2) };
      const [h, ...rest] = rows;
      return { text: JSON.stringify(rest.map((r) => Object.fromEntries(h.map((k, i) => [k || 'col' + (i + 1), r[i] ?? '']))), null, 2), note: B(rest.length + ' row(s)', rest.length + 'টি সারি') };
    },
  },
];
