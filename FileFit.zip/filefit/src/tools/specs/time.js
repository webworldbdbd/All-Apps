import { B, has, fmt, isNum, parseISO, daysBetween, ymdDiff, addDays, addMonths, fmtDMY, dayName, weekdayOf, isLeap, dayOfYear, isoWeek, todayISO, pad2, tr } from '../lite.js';

const N = (k, label, extra) => ({ k, t: 'number', label, ...extra });
const D = (k, label, def, extra) => ({ k, t: 'date', label, def, ...extra });
const Chips = (k, label, opts, def, extra) => ({ k, t: 'chips', label, opts, def: def ?? opts[0][0], ...extra });
const bad = { error: B('Please pick a valid date', 'সঠিক তারিখ বাছাই করুন') };
const today = () => parseISO(todayISO());

export const ZONES = [
  ['Asia/Dhaka', B('Dhaka', 'ঢাকা')], ['UTC', B('UTC', 'UTC')], ['Asia/Kolkata', B('India (Kolkata)', 'ভারত (কলকাতা)')], ['Asia/Karachi', B('Pakistan (Karachi)', 'পাকিস্তান (করাচি)')],
  ['Asia/Dubai', B('Dubai', 'দুবাই')], ['Asia/Riyadh', B('Saudi Arabia (Riyadh)', 'সৌদি আরব (রিয়াদ)')], ['Asia/Kuala_Lumpur', B('Malaysia (Kuala Lumpur)', 'মালয়েশিয়া (কুয়ালালামপুর)')], ['Asia/Singapore', B('Singapore', 'সিঙ্গাপুর')],
  ['Asia/Tokyo', B('Tokyo', 'টোকিও')], ['Asia/Seoul', B('Seoul', 'সিউল')], ['Asia/Shanghai', B('China (Shanghai)', 'চীন (সাংহাই)')], ['Europe/Istanbul', B('Istanbul', 'ইস্তাম্বুল')],
  ['Europe/London', B('London', 'লন্ডন')], ['Europe/Paris', B('Paris', 'প্যারিস')], ['America/New_York', B('New York', 'নিউ ইয়র্ক')], ['America/Chicago', B('Chicago', 'শিকাগো')],
  ['America/Los_Angeles', B('Los Angeles', 'লস অ্যাঞ্জেলেস')], ['America/Toronto', B('Toronto', 'টরন্টো')], ['Australia/Sydney', B('Sydney', 'সিডনি')], ['Pacific/Auckland', B('Auckland', 'অকল্যান্ড')],
];

function partsIn(tz, ts) {
  const f = new Intl.DateTimeFormat('en-US', { timeZone: tz, hourCycle: 'h23', year: 'numeric', month: 'numeric', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric' });
  return Object.fromEntries(f.formatToParts(new Date(ts)).map((x) => [x.type, x.value]));
}
export function tzOffsetMs(tz, ts) {
  const sec = Math.floor(ts / 1000) * 1000;
  const p = partsIn(tz, sec);
  return Date.UTC(+p.year, +p.month - 1, +p.day, +p.hour % 24, +p.minute, +p.second) - sec;
}
export function zonedToUtc(y, mo, d, h, mi, tz) {
  const guess = Date.UTC(y, mo - 1, d, h, mi);
  const o1 = tzOffsetMs(tz, guess);
  let u = guess - o1;
  const o2 = tzOffsetMs(tz, u);
  if (o2 !== o1) u = guess - o2;
  return u;
}
export function offsetLabel(tz, ts) {
  const m = Math.round(tzOffsetMs(tz, ts) / 60000);
  const a = Math.abs(m);
  return 'UTC' + (m < 0 ? '−' : '+') + pad2(Math.floor(a / 60)) + ':' + pad2(a % 60);
}
export function clockIn(tz, ts) {
  const p = partsIn(tz, ts);
  return { y: +p.year, m: +p.month, d: +p.day, h: +p.hour % 24, mi: +p.minute, s: +p.second };
}

const HIJRI = [B('Muharram', 'মুহাররম'), B('Safar', 'সফর'), B("Rabi' al-awwal", 'রবিউল আউয়াল'), B("Rabi' al-thani", 'রবিউস সানি'), B('Jumada al-awwal', 'জমাদিউল আউয়াল'), B('Jumada al-thani', 'জমাদিউস সানি'), B('Rajab', 'রজব'), B("Sha'ban", 'শাবান'), B('Ramadan', 'রমজান'), B('Shawwal', 'শাওয়াল'), B("Dhu al-Qi'dah", 'জিলকদ'), B('Dhu al-Hijjah', 'জিলহজ')];
const SIGNS = [[1, 20, B('Capricorn', 'মকর')], [2, 19, B('Aquarius', 'কুম্ভ')], [3, 20, B('Pisces', 'মীন')], [4, 20, B('Aries', 'মেষ')], [5, 21, B('Taurus', 'বৃষ')], [6, 21, B('Gemini', 'মিথুন')], [7, 22, B('Cancer', 'কর্কট')], [8, 23, B('Leo', 'সিংহ')], [9, 23, B('Virgo', 'কন্যা')], [10, 23, B('Libra', 'তুলা')], [11, 22, B('Scorpio', 'বৃশ্চিক')], [12, 22, B('Sagittarius', 'ধনু')]];
const zodiac = (o) => { for (const [m, d, n] of SIGNS) if (o.m < m || (o.m === m && o.d <= d)) return n; return B('Capricorn', 'মকর'); };

function nextBirthday(dob, from) {
  let y = from.y;
  const mk = (yy) => ({ y: yy, m: dob.m, d: dob.m === 2 && dob.d === 29 && !isLeap(yy) ? 28 : dob.d });
  let nb = mk(y);
  if (daysBetween(from, nb) < 0) nb = mk(y + 1);
  return nb;
}

export default [
  {
    id: 'age', cat: 'time', icon: 'calendar', name: B('Age calculator', 'বয়স ক্যালকুলেটর'), desc: B('Exact age in years, months and days', 'বছর, মাস ও দিনে সঠিক বয়স'),
    inputs: [D('dob', B('Date of birth', 'জন্ম তারিখ'), ''), D('asof', B('Age on date', 'যে তারিখে বয়স'), 'today')],
    sample: { dob: '2000-05-20', asof: '2026-11-18' },
    run(v) {
      const a = parseISO(v.dob), b = parseISO(v.asof);
      if (!a || !b) return null;
      if (daysBetween(a, b) < 0) return { error: B('Birth date must be before the other date', 'জন্ম তারিখ অন্য তারিখের আগে হতে হবে') };
      const d = ymdDiff(a, b), days = daysBetween(a, b);
      const nb = nextBirthday(a, b);
      return { rows: [[B('Age', 'বয়স'), d.y + ' ' + tr(B('years', 'বছর')) + ' ' + d.m + ' ' + tr(B('months', 'মাস')) + ' ' + d.d + ' ' + tr(B('days', 'দিন'))],
        [B('Total months', 'মোট মাস'), d.y * 12 + d.m], [B('Total weeks', 'মোট সপ্তাহ'), Math.floor(days / 7)], [B('Total days', 'মোট দিন'), days.toLocaleString('en-US')],
        [B('Next birthday', 'পরের জন্মদিন'), fmtDMY(nb) + ' (' + dayName(nb) + ')'], [B('Days to next birthday', 'জন্মদিনের বাকি'), daysBetween(b, nb)], [B('Born on', 'জন্মেছিলেন'), dayName(a)]] };
    },
  },
  {
    id: 'datediff', cat: 'time', icon: 'calendar', name: B('Date difference', 'তারিখের ব্যবধান'), desc: B('Days, weeks and months between two dates', 'দুই তারিখের মধ্যে দিন, সপ্তাহ ও মাস'),
    inputs: [D('a', B('From', 'শুরু'), 'today'), D('b', B('To', 'শেষ'), '')],
    sample: { a: '2026-01-01', b: '2026-11-18' },
    run(v) {
      let a = parseISO(v.a), b = parseISO(v.b);
      if (!a || !b) return null;
      if (daysBetween(a, b) < 0) [a, b] = [b, a];
      const days = daysBetween(a, b), d = ymdDiff(a, b);
      return { rows: [[B('Days', 'দিন'), days.toLocaleString('en-US')], [B('Weeks and days', 'সপ্তাহ ও দিন'), Math.floor(days / 7) + ' w ' + (days % 7) + ' d'], [B('Years, months, days', 'বছর, মাস, দিন'), d.y + ' y ' + d.m + ' m ' + d.d + ' d'], [B('Hours', 'ঘণ্টা'), (days * 24).toLocaleString('en-US')]] };
    },
  },
  {
    id: 'adddays', cat: 'time', icon: 'calendar', name: B('Add or subtract days', 'দিন যোগ বা বিয়োগ'), desc: B('Find a date after or before some time', 'কয়েক দিন পরের বা আগের তারিখ'),
    inputs: [D('start', B('Start date', 'শুরুর তারিখ'), 'today'), Chips('op', B('Operation', 'ক্রিয়া'), [['add', B('Add', 'যোগ')], ['sub', B('Subtract', 'বিয়োগ')]]),
      N('days', B('Days', 'দিন'), { def: 0 }), N('weeks', B('Weeks', 'সপ্তাহ'), { def: 0 }), N('months', B('Months', 'মাস'), { def: 0 }), N('years', B('Years', 'বছর'), { def: 0 })],
    sample: { start: '2026-11-18', days: 45, weeks: 0, months: 0, years: 0 },
    run(v) {
      const s = parseISO(v.start);
      if (!s) return null;
      if (!has(v, 'days', 'weeks', 'months', 'years')) return null;
      const k = v.op === 'add' ? 1 : -1;
      let r = addMonths(s, k * (Math.trunc(v.years) * 12 + Math.trunc(v.months)));
      r = addDays(r, k * (Math.trunc(v.weeks) * 7 + Math.trunc(v.days)));
      return { rows: [[B('Result date', 'ফলাফলের তারিখ'), fmtDMY(r)], [B('Weekday', 'বার'), dayName(r)], [B('Days from start', 'শুরু থেকে দিন'), daysBetween(s, r)]] };
    },
  },
  {
    id: 'workdays', cat: 'time', icon: 'calendar', name: B('Working days', 'কর্মদিবস গণনা'), desc: B('Working days between two dates', 'দুই তারিখের মধ্যে কর্মদিবস'),
    inputs: [D('a', B('Start date', 'শুরুর তারিখ'), 'today'), D('b', B('End date', 'শেষের তারিখ'), ''),
      Chips('wk', B('Weekend', 'সাপ্তাহিক ছুটি'), [['fs', B('Fri + Sat', 'শুক্র + শনি')], ['f', B('Friday only', 'শুধু শুক্র')], ['ss', B('Sat + Sun', 'শনি + রবি')]]),
      { k: 'hol', t: 'area', label: B('Holidays (one per line, YYYY-MM-DD)', 'ছুটির দিন (প্রতি লাইনে একটি, YYYY-MM-DD)'), rows: 3, ph: '2026-12-16' }],
    sample: { a: '2026-11-01', b: '2026-11-30', hol: '' },
    run(v) {
      let a = parseISO(v.a), b = parseISO(v.b);
      if (!a || !b) return null;
      if (daysBetween(a, b) < 0) [a, b] = [b, a];
      const off = { fs: [5, 6], f: [5], ss: [6, 0] }[v.wk];
      const hol = new Set((v.hol || '').split(/\s+/).map(parseISO).filter(Boolean).map((o) => daysBetween(a, o)));
      const total = daysBetween(a, b) + 1;
      let work = 0, wkend = 0, hd = 0;
      for (let i = 0; i < total; i++) {
        const wd = weekdayOf(addDays(a, i));
        if (off.includes(wd)) wkend++; else if (hol.has(i)) hd++; else work++;
      }
      return { rows: [[B('Working days', 'কর্মদিবস'), work], [B('Weekend days', 'সাপ্তাহিক ছুটি'), wkend], [B('Holidays counted', 'গণনা করা ছুটি'), hd], [B('Total days (both ends included)', 'মোট দিন (দুই প্রান্তসহ)'), total]] };
    },
  },
  {
    id: 'weeknum', cat: 'time', icon: 'calendar', name: B('Week number', 'সপ্তাহ নম্বর'), desc: B('ISO week number and day of the year', 'বছরের কত নম্বর সপ্তাহ ও দিন'),
    inputs: [D('d', B('Date', 'তারিখ'), 'today')],
    run(v) {
      const o = parseISO(v.d);
      if (!o) return null;
      const w = isoWeek(o);
      return { rows: [[B('ISO week', 'ISO সপ্তাহ'), w.week + (w.year !== o.y ? ' (' + w.year + ')' : '')], [B('Day of the year', 'বছরের কত দিন'), dayOfYear(o) + ' / ' + (isLeap(o.y) ? 366 : 365)], [B('Quarter', 'ত্রৈমাসিক'), 'Q' + Math.ceil(o.m / 3)], [B('Weekday', 'বার'), dayName(o)]] };
    },
  },
  {
    id: 'weekday', cat: 'time', icon: 'calendar', name: B('Day of the week', 'কোন বার'), desc: B('Which weekday is any date', 'যেকোনো তারিখ কোন বার'),
    inputs: [D('d', B('Date', 'তারিখ'), 'today')],
    run(v) {
      const o = parseISO(v.d);
      if (!o) return null;
      const diff = daysBetween(today(), o);
      return { rows: [[B('Weekday', 'বার'), dayName(o)], [B('Date', 'তারিখ'), fmtDMY(o)], [B('From today', 'আজ থেকে'), diff === 0 ? B('Today', 'আজ') : diff > 0 ? diff + ' ' + tr(B('days ahead', 'দিন পরে')) : -diff + ' ' + tr(B('days ago', 'দিন আগে'))]] };
    },
  },
  {
    id: 'birthday', cat: 'time', icon: 'calendar', name: B('Birthday countdown', 'জন্মদিনের কাউন্টডাউন'), desc: B('Days left for the next birthday', 'পরের জন্মদিনে আর কত দিন'),
    inputs: [D('dob', B('Date of birth', 'জন্ম তারিখ'), '')],
    sample: { dob: '2000-05-20' },
    run(v) {
      const a = parseISO(v.dob);
      if (!a) return null;
      const t = today();
      if (daysBetween(a, t) < 0) return { error: B('Birth date is in the future', 'জন্ম তারিখ ভবিষ্যতে') };
      const nb = nextBirthday(a, t);
      const left = daysBetween(t, nb);
      return { rows: [[B('Days left', 'বাকি দিন'), left === 0 ? B('Today is your birthday!', 'আজই আপনার জন্মদিন!') : left], [B('Next birthday', 'পরের জন্মদিন'), fmtDMY(nb) + ' (' + dayName(nb) + ')'], [B('Turning', 'বয়স হবে'), nb.y - a.y], [B('Zodiac sign', 'রাশি'), zodiac(a)]] };
    },
  },
  {
    id: 'leapyear', cat: 'time', icon: 'calendar', name: B('Leap year checker', 'লিপ ইয়ার যাচাই'), desc: B('Is a year a leap year?', 'বছরটি লিপ ইয়ার কি না'),
    inputs: [N('y', B('Year', 'সাল'), { def: new Date().getFullYear() })],
    run(v) {
      if (!isNum(v.y) || !Number.isInteger(v.y) || v.y < 1) return null;
      let nx = v.y + 1; while (!isLeap(nx)) nx++;
      let pv = v.y - 1; while (pv > 0 && !isLeap(pv)) pv--;
      return { rows: [[B('Leap year?', 'লিপ ইয়ার?'), isLeap(v.y) ? B('Yes (366 days)', 'হ্যাঁ (৩৬৬ দিন)') : B('No (365 days)', 'না (৩৬৫ দিন)')], [B('Next leap year', 'পরের লিপ ইয়ার'), nx], [B('Previous leap year', 'আগের লিপ ইয়ার'), pv > 0 ? pv : '—']] };
    },
  },
  {
    id: 'timeadd', cat: 'time', icon: 'clock', name: B('Add or subtract time', 'সময় যোগ বা বিয়োগ'), desc: B('Add hours and minutes to a clock time', 'ঘড়ির সময়ে ঘণ্টা ও মিনিট যোগ বা বিয়োগ'),
    inputs: [{ k: 'start', t: 'time', label: B('Start time', 'শুরুর সময়'), def: '09:00' }, Chips('op', B('Operation', 'ক্রিয়া'), [['add', B('Add', 'যোগ')], ['sub', B('Subtract', 'বিয়োগ')]]), N('h', B('Hours', 'ঘণ্টা'), { def: 0 }), N('m', B('Minutes', 'মিনিট'), { def: 0 })],
    sample: { start: '09:00', h: 2, m: 30 },
    run(v) {
      const mm = /^(\d{2}):(\d{2})$/.exec(v.start || '');
      if (!mm || !has(v, 'h', 'm')) return null;
      const total = +mm[1] * 60 + +mm[2] + (v.op === 'add' ? 1 : -1) * (v.h * 60 + v.m);
      const day = Math.floor(total / 1440);
      const t = ((total % 1440) + 1440) % 1440;
      const h12 = ((Math.floor(t / 60) + 11) % 12) + 1;
      return { rows: [[B('Result (24-hour)', 'ফলাফল (২৪ ঘণ্টা)'), pad2(Math.floor(t / 60)) + ':' + pad2(t % 60)], [B('Result (12-hour)', 'ফলাফল (১২ ঘণ্টা)'), h12 + ':' + pad2(t % 60) + ' ' + (t < 720 ? 'AM' : 'PM')], [B('Day shift', 'দিনের পরিবর্তন'), day === 0 ? B('Same day', 'একই দিন') : (day > 0 ? '+' : '') + day]] };
    },
  },
  {
    id: 'timediff', cat: 'time', icon: 'clock', name: B('Time duration', 'সময়ের ব্যবধান'), desc: B('Hours between two clock times', 'দুই সময়ের মধ্যে কত ঘণ্টা'),
    inputs: [{ k: 'a', t: 'time', label: B('Start time', 'শুরুর সময়'), def: '09:00' }, { k: 'b', t: 'time', label: B('End time', 'শেষের সময়'), def: '17:30' }],
    sample: { a: '09:00', b: '17:30' },
    run(v) {
      const p = (s) => { const m = /^(\d{2}):(\d{2})$/.exec(s || ''); return m ? +m[1] * 60 + +m[2] : null; };
      const a = p(v.a), b = p(v.b);
      if (a == null || b == null) return null;
      let d = b - a; if (d < 0) d += 1440;
      return { rows: [[B('Duration', 'ব্যবধান'), Math.floor(d / 60) + ' h ' + (d % 60) + ' min'], [B('Total minutes', 'মোট মিনিট'), d], [B('Decimal hours', 'দশমিক ঘণ্টা'), fmt(d / 60, 2)]], note: b < a ? B('End time is earlier, so it is counted as the next day.', 'শেষের সময় আগে, তাই পরের দিন ধরা হয়েছে।') : null };
    },
  },
  {
    id: 'hijri', cat: 'time', icon: 'moon', name: B('Hijri date converter', 'হিজরি তারিখ'), desc: B('Gregorian to Hijri date', 'ইংরেজি তারিখ থেকে হিজরি তারিখ'),
    inputs: [D('d', B('Gregorian date', 'ইংরেজি তারিখ'), 'today')],
    run(v) {
      const o = parseISO(v.d);
      if (!o) return null;
      try {
        const f = new Intl.DateTimeFormat('en-u-ca-islamic-umalqura', { timeZone: 'UTC', day: 'numeric', month: 'numeric', year: 'numeric' });
        const p = Object.fromEntries(f.formatToParts(new Date(Date.UTC(o.y, o.m - 1, o.d, 12))).map((x) => [x.type, x.value]));
        const mo = parseInt(p.month, 10);
        return { rows: [[B('Hijri date', 'হিজরি তারিখ'), parseInt(p.day, 10) + ' ' + tr(HIJRI[mo - 1]) + ' ' + parseInt(p.year, 10) + ' AH'], [B('Weekday', 'বার'), dayName(o)]], note: B('Uses the Umm al-Qura calendar. The moon sighting in your country may differ by a day.', 'উম্মুল কুরা ক্যালেন্ডার অনুযায়ী। আপনার দেশের চাঁদ দেখার ওপর একদিন ব্যবধান হতে পারে।') };
      } catch { return { error: B('This device cannot show Hijri dates', 'এই ডিভাইসে হিজরি তারিখ দেখানো যায় না') }; }
    },
  },
  {
    id: 'timezone', cat: 'time', icon: 'globe', name: B('Time zone converter', 'টাইম জোন কনভার্টার'), desc: B('Convert a time between cities', 'এক শহরের সময় অন্য শহরে'),
    inputs: [D('d', B('Date', 'তারিখ'), 'today'), { k: 't', t: 'time', label: B('Time', 'সময়'), def: '12:00' },
      { k: 'from', t: 'select', label: B('From', 'যেখান থেকে'), def: 'Asia/Dhaka', opts: ZONES }, { k: 'to', t: 'select', label: B('To', 'যেখানে'), def: 'America/New_York', opts: ZONES }],
    sample: { d: '2026-11-18', t: '12:00', from: 'Asia/Dhaka', to: 'America/New_York' },
    run(v) {
      const o = parseISO(v.d), m = /^(\d{2}):(\d{2})$/.exec(v.t || '');
      if (!o || !m) return null;
      try {
        const u = zonedToUtc(o.y, o.m, o.d, +m[1], +m[2], v.from);
        const c = clockIn(v.to, u);
        const dayShift = daysBetween(o, { y: c.y, m: c.m, d: c.d });
        return { rows: [[B('Converted time', 'রূপান্তরিত সময়'), pad2(c.h) + ':' + pad2(c.mi)], [B('Date there', 'সেখানকার তারিখ'), fmtDMY({ y: c.y, m: c.m, d: c.d }) + (dayShift ? ' (' + (dayShift > 0 ? '+' : '') + dayShift + ' ' + tr(B('day', 'দিন')) + ')' : '')], [B('Offsets', 'অফসেট'), offsetLabel(v.from, u) + ' → ' + offsetLabel(v.to, u)]] };
      } catch { return { error: B('This device does not support that time zone', 'এই ডিভাইস সেই টাইম জোন সমর্থন করে না') }; }
    },
  },
  {
    id: 'daysuntil', cat: 'time', icon: 'calendar', name: B('Days until a date', 'তারিখ পর্যন্ত কত দিন'), desc: B('Countdown in days to an event', 'কোনো দিনের আগে কত দিন বাকি'),
    inputs: [D('d', B('Event date', 'ঘটনার তারিখ'), '')],
    sample: { d: '2026-12-25' },
    run(v) {
      const o = parseISO(v.d);
      if (!o) return null;
      const n = daysBetween(today(), o);
      const a = Math.abs(n);
      return { rows: [[n >= 0 ? B('Days left', 'বাকি দিন') : B('Days passed', 'পার হয়েছে'), a === 0 ? B('Today', 'আজ') : a], [B('Weeks and days', 'সপ্তাহ ও দিন'), Math.floor(a / 7) + ' w ' + (a % 7) + ' d'], [B('Weekday', 'বার'), dayName(o)]] };
    },
  },
];
