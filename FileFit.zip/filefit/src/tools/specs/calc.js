import { B, has, fmt, isNum, parseList, row } from '../lite.js';
import * as M from '../mathlib.js';

const N = (k, label, extra) => ({ k, t: 'number', label, ...extra });
const Chips = (k, label, opts, def, extra) => ({ k, t: 'chips', label, opts, def: def ?? opts[0][0], ...extra });
const f4 = (x) => fmt(x, 4);

const GRADES = {
  uni4: [['A+', 4], ['A', 3.75], ['A-', 3.5], ['B+', 3.25], ['B', 3], ['B-', 2.75], ['C+', 2.5], ['C', 2.25], ['D', 2], ['F', 0]],
  school5: [['A+', 5], ['A', 4], ['A-', 3.5], ['B', 3], ['C', 2], ['D', 1], ['F', 0]],
  us4: [['A+', 4], ['A', 4], ['A-', 3.7], ['B+', 3.3], ['B', 3], ['B-', 2.7], ['C+', 2.3], ['C', 2], ['C-', 1.7], ['D+', 1.3], ['D', 1], ['F', 0]],
};
const scaleChips = Chips('scale', B('Grading scale', 'গ্রেডিং স্কেল'), [['uni4', B('University 4.00', 'বিশ্ববিদ্যালয় ৪.০০')], ['school5', B('SSC/HSC 5.00', 'SSC/HSC ৫.০০')], ['us4', B('US 4.0', 'US ৪.০')]], 'uni4');

function bdGrade(p) {
  if (p >= 80) return ['A+', 5]; if (p >= 70) return ['A', 4]; if (p >= 60) return ['A-', 3.5];
  if (p >= 50) return ['B', 3]; if (p >= 40) return ['C', 2]; if (p >= 33) return ['D', 1]; return ['F', 0];
}
const letter = (p) => (p >= 90 ? 'A' : p >= 80 ? 'B' : p >= 70 ? 'C' : p >= 60 ? 'D' : 'F');

export default [
  {
    id: 'percentage', cat: 'calc', icon: 'percent', name: B('Percentage calculator', 'শতাংশ ক্যালকুলেটর'), desc: B('X% of Y, what percent, increase and decrease', 'X% এর মান, কত শতাংশ, বাড়া ও কমা'),
    inputs: [
      Chips('mode', B('Calculate', 'হিসাব'), [['of', B('A% of B', 'B এর A%')], ['is', B('A is what % of B', 'A কত % B এর')], ['inc', B('B + A%', 'B বাড়ুক A%')], ['dec', B('B − A%', 'B কমুক A%')]]),
      N('a', B('A', 'A')), N('b', B('B', 'B')),
    ],
    run(v) {
      if (!has(v, 'a', 'b')) return null;
      if (v.mode === 'of') return { rows: [[B('Result', 'ফলাফল'), f4(v.a * v.b / 100)]] };
      if (v.mode === 'is') return v.b === 0 ? { error: B('B cannot be zero', 'B শূন্য হতে পারবে না') } : { rows: [[B('Percentage', 'শতাংশ'), f4(v.a / v.b * 100) + '%']] };
      const k = v.mode === 'inc' ? 1 + v.a / 100 : 1 - v.a / 100;
      return { rows: [[B('Result', 'ফলাফল'), f4(v.b * k)], [B('Difference', 'পার্থক্য'), f4(v.b * k - v.b)]] };
    },
  },
  {
    id: 'percentchange', cat: 'calc', icon: 'chart', name: B('Percentage change', 'শতাংশ পরিবর্তন'), desc: B('Increase or decrease between two values', 'দুই মানের মধ্যে বাড়া বা কমা'),
    inputs: [N('a', B('Old value', 'আগের মান'), { neg: true }), N('b', B('New value', 'নতুন মান'), { neg: true })],
    run(v) {
      if (!has(v, 'a', 'b')) return null;
      if (v.a === 0) return { error: B('Old value cannot be zero', 'আগের মান শূন্য হতে পারবে না') };
      const p = (v.b - v.a) / Math.abs(v.a) * 100;
      return { rows: [[B('Change', 'পরিবর্তন'), (p >= 0 ? '+' : '') + f4(p) + '%'], [B('Difference', 'পার্থক্য'), f4(v.b - v.a)], [B('Direction', 'দিক'), p > 0 ? B('Increase', 'বৃদ্ধি') : p < 0 ? B('Decrease', 'হ্রাস') : B('No change', 'অপরিবর্তিত')]] };
    },
  },
  {
    id: 'average', cat: 'calc', icon: 'chart', name: B('Average calculator', 'গড় নির্ণয়'), desc: B('Mean, median, mode and range', 'গড়, মধ্যমা, প্রচুরক ও পরিসর'),
    inputs: [{ k: 'text', t: 'area', label: B('Numbers (space, comma or new line)', 'সংখ্যা (স্পেস, কমা বা নতুন লাইন)'), paste: true }],
    sample: { text: '4 8 15 16 23 42' },
    run(v) {
      const a = parseList(v.text);
      if (!a.length) return null;
      const s = [...a].sort((x, y) => x - y);
      const sum = a.reduce((x, y) => x + y, 0);
      const med = s.length % 2 ? s[(s.length - 1) / 2] : (s[s.length / 2 - 1] + s[s.length / 2]) / 2;
      const cnt = new Map(); a.forEach((x) => cnt.set(x, (cnt.get(x) || 0) + 1));
      const top = Math.max(...cnt.values());
      const mode = top === 1 ? B('No mode', 'প্রচুরক নেই') : [...cnt].filter(([, c]) => c === top).map(([x]) => x).join(', ');
      return { rows: [[B('Count', 'সংখ্যা'), a.length], [B('Sum', 'যোগফল'), f4(sum)], [B('Mean', 'গড়'), f4(sum / a.length)], [B('Median', 'মধ্যমা'), f4(med)], [B('Mode', 'প্রচুরক'), mode], [B('Smallest', 'সর্বনিম্ন'), f4(s[0])], [B('Largest', 'সর্বোচ্চ'), f4(s[s.length - 1])], [B('Range', 'পরিসর'), f4(s[s.length - 1] - s[0])]] };
    },
  },
  {
    id: 'stddev', cat: 'calc', icon: 'chart', name: B('Standard deviation', 'স্ট্যান্ডার্ড ডেভিয়েশন'), desc: B('Variance and standard deviation of a data set', 'তথ্যের ভেদাঙ্ক ও পরিমিত বিচ্যুতি'),
    inputs: [{ k: 'text', t: 'area', label: B('Numbers (space, comma or new line)', 'সংখ্যা (স্পেস, কমা বা নতুন লাইন)'), paste: true }],
    sample: { text: '2 4 4 4 5 5 7 9' },
    run(v) {
      const a = parseList(v.text);
      if (a.length < 2) return null;
      const mean = a.reduce((x, y) => x + y, 0) / a.length;
      const ss = a.reduce((x, y) => x + (y - mean) ** 2, 0);
      return { rows: [[B('Count', 'সংখ্যা'), a.length], [B('Mean', 'গড়'), f4(mean)], [B('Population variance', 'জনসংখ্যা ভেদাঙ্ক'), f4(ss / a.length)], [B('Population SD', 'জনসংখ্যা SD'), f4(Math.sqrt(ss / a.length))], [B('Sample variance', 'নমুনা ভেদাঙ্ক'), f4(ss / (a.length - 1))], [B('Sample SD', 'নমুনা SD'), f4(Math.sqrt(ss / (a.length - 1)))]] };
    },
  },
  {
    id: 'fraction', cat: 'calc', icon: 'calc', name: B('Fraction calculator', 'ভগ্নাংশ ক্যালকুলেটর'), desc: B('Add, subtract, multiply and divide fractions', 'ভগ্নাংশের যোগ, বিয়োগ, গুণ ও ভাগ'),
    inputs: [N('n1', B('Numerator 1', 'লব ১'), { neg: true }), N('d1', B('Denominator 1', 'হর ১')),
      Chips('op', B('Operation', 'ক্রিয়া'), [['+', '+'], ['-', '−'], ['*', '×'], ['/', '÷']]),
      N('n2', B('Numerator 2', 'লব ২'), { neg: true }), N('d2', B('Denominator 2', 'হর ২'))],
    run(v) {
      if (!has(v, 'n1', 'd1', 'n2', 'd2')) return null;
      if (v.d1 === 0 || v.d2 === 0) return { error: B('Denominator cannot be zero', 'হর শূন্য হতে পারবে না') };
      let n, d;
      if (v.op === '+') { n = v.n1 * v.d2 + v.n2 * v.d1; d = v.d1 * v.d2; }
      else if (v.op === '-') { n = v.n1 * v.d2 - v.n2 * v.d1; d = v.d1 * v.d2; }
      else if (v.op === '*') { n = v.n1 * v.n2; d = v.d1 * v.d2; }
      else { if (v.n2 === 0) return { error: B('Cannot divide by zero', 'শূন্য দিয়ে ভাগ করা যায় না') }; n = v.n1 * v.d2; d = v.d1 * v.n2; }
      [n, d] = M.simplify(n, d);
      const rows = [[B('Result', 'ফলাফল'), d === 1 ? String(n) : n + '/' + d], [B('Decimal', 'দশমিক'), f4(n / d)]];
      if (Math.abs(n) > d && d !== 1) { const w = Math.trunc(n / d); rows.push([B('Mixed number', 'মিশ্র ভগ্নাংশ'), w + ' ' + Math.abs(n % d) + '/' + d]); }
      return { rows };
    },
  },
  {
    id: 'ratio', cat: 'calc', icon: 'scale', name: B('Ratio calculator', 'অনুপাত ক্যালকুলেটর'), desc: B('Simplify a ratio or solve A:B = C:?', 'অনুপাত সরল করুন বা A:B = C:? মেলান'),
    inputs: [Chips('mode', B('Mode', 'ধরন'), [['simplify', B('Simplify A:B', 'A:B সরল')], ['solve', B('A:B = C:?', 'A:B = C:?')]]),
      N('a', B('A', 'A')), N('b', B('B', 'B')), N('c', B('C', 'C'), { when: (v) => v.mode === 'solve' })],
    run(v) {
      if (!has(v, 'a', 'b')) return null;
      if (v.mode === 'simplify') {
        if (!Number.isInteger(v.a) || !Number.isInteger(v.b)) return { error: B('Use whole numbers', 'পূর্ণ সংখ্যা দিন') };
        const g = M.gcd(v.a, v.b) || 1;
        return { rows: [[B('Simplest ratio', 'সরলতম অনুপাত'), v.a / g + ' : ' + v.b / g]] };
      }
      if (!isNum(v.c)) return null;
      if (v.a === 0) return { error: B('A cannot be zero', 'A শূন্য হতে পারবে না') };
      return { rows: [[B('Missing value', 'অনুপস্থিত মান'), f4(v.b * v.c / v.a)]] };
    },
  },
  {
    id: 'equation', cat: 'calc', icon: 'calc', name: B('Equation solver', 'সমীকরণ সমাধান'), desc: B('Linear and quadratic equations', 'একঘাত ও দ্বিঘাত সমীকরণ'),
    inputs: [Chips('mode', B('Type', 'ধরন'), [['lin', B('ax + b = 0', 'ax + b = 0')], ['quad', B('ax² + bx + c = 0', 'ax² + bx + c = 0')]]),
      N('a', B('a', 'a'), { neg: true }), N('b', B('b', 'b'), { neg: true }), N('c', B('c', 'c'), { neg: true, when: (v) => v.mode === 'quad' })],
    run(v) {
      if (!has(v, 'a', 'b')) return null;
      if (v.mode === 'lin') return v.a === 0 ? { error: B('a cannot be zero', 'a শূন্য হতে পারবে না') } : { rows: [['x', f4(-v.b / v.a)]] };
      if (!isNum(v.c)) return null;
      if (v.a === 0) return { error: B('a cannot be zero', 'a শূন্য হতে পারবে না') };
      const D = v.b * v.b - 4 * v.a * v.c;
      const rows = [[B('Discriminant', 'ডিসক্রিমিন্যান্ট'), f4(D)]];
      if (D > 0) rows.push(['x₁', f4((-v.b + Math.sqrt(D)) / (2 * v.a))], ['x₂', f4((-v.b - Math.sqrt(D)) / (2 * v.a))]);
      else if (D === 0) rows.push(['x', f4(-v.b / (2 * v.a))]);
      else { const re = -v.b / (2 * v.a), im = Math.sqrt(-D) / (2 * Math.abs(v.a)); rows.push(['x₁', f4(re) + ' + ' + f4(im) + 'i'], ['x₂', f4(re) + ' − ' + f4(im) + 'i']); }
      return { rows };
    },
  },
  {
    id: 'prime', cat: 'calc', icon: 'hash', name: B('Prime checker & factors', 'মৌলিক সংখ্যা ও গুণনীয়ক'), desc: B('Check prime, prime factors, next prime', 'মৌলিক কি না, মৌলিক উৎপাদক'),
    inputs: [N('n', B('Whole number', 'পূর্ণ সংখ্যা'), { hint: B('Up to 1,000,000,000,000', '১ লক্ষ কোটি পর্যন্ত') })],
    run(v) {
      if (!isNum(v.n)) return null;
      if (!Number.isInteger(v.n) || v.n < 1 || v.n > 1e12) return { error: B('Enter a whole number from 1 to 1,000,000,000,000', '১ থেকে ১,০০০,০০০,০০০,০০০ এর মধ্যে পূর্ণ সংখ্যা দিন') };
      const fs = M.factorize(v.n);
      const divs = fs.reduce((a, [, c]) => a * (c + 1), 1);
      const prev = M.prevPrime(v.n);
      return { rows: [[B('Is it prime?', 'মৌলিক?'), M.isPrime(v.n) ? B('Yes', 'হ্যাঁ') : B('No', 'না')],
        [B('Prime factors', 'মৌলিক উৎপাদক'), v.n === 1 ? '1' : fs.map(([p, c]) => (c > 1 ? p + '^' + c : p)).join(' × ')],
        [B('Number of divisors', 'ভাজকের সংখ্যা'), divs], [B('Next prime', 'পরের মৌলিক'), M.nextPrime(v.n)], [B('Previous prime', 'আগের মৌলিক'), prev ?? '—']] };
    },
  },
  {
    id: 'gcdlcm', cat: 'calc', icon: 'hash', name: B('GCD & LCM', 'গসাগু ও লসাগু'), desc: B('Greatest common divisor and least common multiple', 'গরিষ্ঠ সাধারণ গুণনীয়ক ও লঘিষ্ঠ সাধারণ গুণিতক'),
    inputs: [{ k: 'text', t: 'area', label: B('Whole numbers (space or comma)', 'পূর্ণ সংখ্যা (স্পেস বা কমা)'), rows: 3 }],
    sample: { text: '12 18 24' },
    run(v) {
      const a = parseList(v.text);
      if (a.length < 2) return null;
      if (a.some((x) => !Number.isInteger(x) || x <= 0)) return { error: B('Use positive whole numbers', 'ধনাত্মক পূর্ণ সংখ্যা দিন') };
      return { rows: [[B('GCD (গসাগু)', 'গসাগু (GCD)'), a.reduce(M.gcd)], [B('LCM (লসাগু)', 'লসাগু (LCM)'), a.reduce(M.lcm)]] };
    },
  },
  {
    id: 'factorial', cat: 'calc', icon: 'calc', name: B('Factorial, permutation, combination', 'ফ্যাক্টোরিয়াল, বিন্যাস, সমাবেশ'), desc: B('n!, nPr and nCr', 'n!, nPr ও nCr'),
    inputs: [N('n', B('n', 'n'), { hint: B('0 to 170', '০ থেকে ১৭০') }), N('r', B('r (optional)', 'r (ঐচ্ছিক)'))],
    run(v) {
      if (!isNum(v.n)) return null;
      if (!Number.isInteger(v.n) || v.n < 0 || v.n > 170) return { error: B('n must be a whole number from 0 to 170', 'n অবশ্যই ০ থেকে ১৭০ এর মধ্যে পূর্ণ সংখ্যা') };
      const big = (x) => { const s = x.toString(); return s.length > 40 ? s[0] + '.' + s.slice(1, 8) + 'e+' + (s.length - 1) + ' (' + s.length + ' digits)' : s.replace(/\B(?=(\d{3})+(?!\d))/g, ','); };
      const rows = [['n!', big(M.fact(v.n))]];
      if (isNum(v.r)) {
        if (!Number.isInteger(v.r) || v.r < 0 || v.r > v.n) return { error: B('r must be a whole number from 0 to n', 'r অবশ্যই ০ থেকে n এর মধ্যে পূর্ণ সংখ্যা') };
        rows.push(['nPr', big(M.nPr(v.n, v.r))], ['nCr', big(M.nCr(v.n, v.r))]);
      }
      return { rows };
    },
  },
  {
    id: 'power', cat: 'calc', icon: 'calc', name: B('Power & roots', 'ঘাত ও মূল'), desc: B('Power, square root, cube root, square and cube', 'ঘাত, বর্গমূল, ঘনমূল, বর্গ ও ঘন'),
    inputs: [N('a', B('Number', 'সংখ্যা'), { neg: true }), N('b', B('Power (for a^b)', 'ঘাত (a^b এর জন্য)'), { neg: true })],
    run(v) {
      if (!isNum(v.a)) return null;
      const rows = [];
      if (isNum(v.b)) rows.push([B('a ^ b', 'a ^ b'), fmt(Math.pow(v.a, v.b), 8)]);
      rows.push([B('Square a²', 'বর্গ a²'), fmt(v.a ** 2, 8)], [B('Cube a³', 'ঘন a³'), fmt(v.a ** 3, 8)], [B('Square root', 'বর্গমূল'), v.a < 0 ? '—' : fmt(Math.sqrt(v.a), 8)], [B('Cube root', 'ঘনমূল'), fmt(Math.cbrt(v.a), 8)], [B('Reciprocal 1/a', 'ব্যস্তক 1/a'), v.a === 0 ? '—' : fmt(1 / v.a, 8)]);
      return { rows };
    },
  },
  {
    id: 'pythagoras', cat: 'calc', icon: 'calc', name: B('Pythagoras theorem', 'পিথাগোরাস উপপাদ্য'), desc: B('Find the missing side of a right triangle', 'সমকোণী ত্রিভুজের অজানা বাহু'),
    inputs: [Chips('find', B('Find', 'নির্ণয়'), [['hyp', B('Hypotenuse', 'অতিভুজ')], ['leg', B('A leg', 'একটি বাহু')]]),
      N('a', B('Side a', 'বাহু a')), N('b', B('Side b', 'বাহু b'), { when: (v) => v.find === 'hyp' }), N('c', B('Hypotenuse c', 'অতিভুজ c'), { when: (v) => v.find === 'leg' })],
    run(v) {
      if (v.find === 'hyp') { if (!has(v, 'a', 'b')) return null; const c = Math.hypot(v.a, v.b); return { rows: [[B('Hypotenuse c', 'অতিভুজ c'), f4(c)], [B('Area', 'ক্ষেত্রফল'), f4(v.a * v.b / 2)], [B('Perimeter', 'পরিসীমা'), f4(v.a + v.b + c)]] }; }
      if (!has(v, 'a', 'c')) return null;
      if (v.c <= v.a) return { error: B('Hypotenuse must be longer than the other side', 'অতিভুজ অন্য বাহুর চেয়ে বড় হতে হবে') };
      const b = Math.sqrt(v.c * v.c - v.a * v.a);
      return { rows: [[B('Side b', 'বাহু b'), f4(b)], [B('Area', 'ক্ষেত্রফল'), f4(v.a * b / 2)], [B('Perimeter', 'পরিসীমা'), f4(v.a + b + v.c)]] };
    },
  },
  {
    id: 'area', cat: 'calc', icon: 'ruler', name: B('Area calculator', 'ক্ষেত্রফল নির্ণয়'), desc: B('Area and perimeter of common shapes', 'সাধারণ আকৃতির ক্ষেত্রফল ও পরিসীমা'),
    inputs: [
      Chips('shape', B('Shape', 'আকৃতি'), [['rect', B('Rectangle', 'আয়ত')], ['square', B('Square', 'বর্গ')], ['tri', B('Triangle', 'ত্রিভুজ')], ['circle', B('Circle', 'বৃত্ত')], ['trap', B('Trapezoid', 'ট্রাপিজিয়াম')], ['para', B('Parallelogram', 'সামান্তরিক')]]),
      N('l', B('Length', 'দৈর্ঘ্য'), { when: (v) => v.shape === 'rect' }), N('w', B('Width', 'প্রস্থ'), { when: (v) => v.shape === 'rect' }),
      N('s', B('Side', 'বাহু'), { when: (v) => v.shape === 'square' }),
      N('tb', B('Base', 'ভূমি'), { when: (v) => v.shape === 'tri' || v.shape === 'para' }), N('th', B('Height', 'উচ্চতা'), { when: (v) => v.shape === 'tri' || v.shape === 'para' || v.shape === 'trap' }),
      N('r', B('Radius', 'ব্যাসার্ধ'), { when: (v) => v.shape === 'circle' }),
      N('pa', B('Parallel side a', 'সমান্তরাল বাহু a'), { when: (v) => v.shape === 'trap' }), N('pb', B('Parallel side b', 'সমান্তরাল বাহু b'), { when: (v) => v.shape === 'trap' }),
    ],
    run(v) {
      const R = (a, p) => ({ rows: [[B('Area', 'ক্ষেত্রফল'), f4(a)], ...(p != null ? [[B('Perimeter / circumference', 'পরিসীমা'), f4(p)]] : [])] });
      if (v.shape === 'rect') return has(v, 'l', 'w') ? R(v.l * v.w, 2 * (v.l + v.w)) : null;
      if (v.shape === 'square') return has(v, 's') ? R(v.s * v.s, 4 * v.s) : null;
      if (v.shape === 'tri') return has(v, 'tb', 'th') ? R(v.tb * v.th / 2, null) : null;
      if (v.shape === 'circle') return has(v, 'r') ? R(Math.PI * v.r * v.r, 2 * Math.PI * v.r) : null;
      if (v.shape === 'trap') return has(v, 'pa', 'pb', 'th') ? R((v.pa + v.pb) / 2 * v.th, null) : null;
      return has(v, 'tb', 'th') ? R(v.tb * v.th, null) : null;
    },
  },
  {
    id: 'volume', cat: 'calc', icon: 'ruler', name: B('Volume calculator', 'আয়তন নির্ণয়'), desc: B('Volume and surface area of solids', 'ঘনবস্তুর আয়তন ও পৃষ্ঠতলের ক্ষেত্রফল'),
    inputs: [
      Chips('shape', B('Solid', 'বস্তু'), [['cube', B('Cube', 'ঘনক')], ['cuboid', B('Cuboid', 'আয়তঘন')], ['cyl', B('Cylinder', 'বেলন')], ['sphere', B('Sphere', 'গোলক')], ['cone', B('Cone', 'শঙ্কু')]]),
      N('s', B('Side', 'বাহু'), { when: (v) => v.shape === 'cube' }),
      N('l', B('Length', 'দৈর্ঘ্য'), { when: (v) => v.shape === 'cuboid' }), N('w', B('Width', 'প্রস্থ'), { when: (v) => v.shape === 'cuboid' }),
      N('r', B('Radius', 'ব্যাসার্ধ'), { when: (v) => ['cyl', 'sphere', 'cone'].includes(v.shape) }),
      N('h', B('Height', 'উচ্চতা'), { when: (v) => ['cuboid', 'cyl', 'cone'].includes(v.shape) }),
    ],
    run(v) {
      const R = (vol, sa) => ({ rows: [[B('Volume', 'আয়তন'), f4(vol)], [B('Surface area', 'পৃষ্ঠতলের ক্ষেত্রফল'), f4(sa)]] });
      if (v.shape === 'cube') return has(v, 's') ? R(v.s ** 3, 6 * v.s ** 2) : null;
      if (v.shape === 'cuboid') return has(v, 'l', 'w', 'h') ? R(v.l * v.w * v.h, 2 * (v.l * v.w + v.w * v.h + v.l * v.h)) : null;
      if (v.shape === 'cyl') return has(v, 'r', 'h') ? R(Math.PI * v.r ** 2 * v.h, 2 * Math.PI * v.r * (v.r + v.h)) : null;
      if (v.shape === 'sphere') return has(v, 'r') ? R(4 / 3 * Math.PI * v.r ** 3, 4 * Math.PI * v.r ** 2) : null;
      return has(v, 'r', 'h') ? R(Math.PI * v.r ** 2 * v.h / 3, Math.PI * v.r * (v.r + Math.hypot(v.r, v.h))) : null;
    },
  },
  {
    id: 'gpa', cat: 'calc', icon: 'cap', name: B('GPA calculator', 'GPA ক্যালকুলেটর'), desc: B('Term GPA from credits and grades', 'ক্রেডিট ও গ্রেড থেকে GPA'),
    inputs: [scaleChips, { k: 'courses', t: 'rows', label: B('Courses', 'বিষয়'), rows: 4, add: B('Add course', 'বিষয় যোগ'),
      cols: [{ k: 'cr', t: 'number', label: B('Credit', 'ক্রেডিট') }, { k: 'g', t: 'select', label: B('Grade', 'গ্রেড'), opts: (v) => GRADES[v.scale].map(([g, p]) => [g, g + ' (' + p + ')']) }] }],
    sample: { courses: [{ cr: 3, g: 'A' }, { cr: 4, g: 'B+' }] },
    run(v) {
      const map = Object.fromEntries(GRADES[v.scale]);
      const rows = v.courses.filter((r) => isNum(r.cr) && r.cr > 0 && r.g in map);
      if (!rows.length) return null;
      const cr = rows.reduce((a, r) => a + r.cr, 0);
      const pts = rows.reduce((a, r) => a + r.cr * map[r.g], 0);
      return { rows: [['GPA', fmt(pts / cr, 2)], [B('Total credits', 'মোট ক্রেডিট'), f4(cr)], [B('Total grade points', 'মোট গ্রেড পয়েন্ট'), f4(pts)]] };
    },
  },
  {
    id: 'cgpa', cat: 'calc', icon: 'cap', name: B('CGPA calculator', 'CGPA ক্যালকুলেটর'), desc: B('Cumulative GPA across semesters', 'সব সেমিস্টারের গড় CGPA'),
    inputs: [{ k: 'sems', t: 'rows', label: B('Semesters', 'সেমিস্টার'), rows: 4, add: B('Add semester', 'সেমিস্টার যোগ'),
      cols: [{ k: 'g', t: 'number', label: B('GPA', 'GPA') }, { k: 'cr', t: 'number', label: B('Credits (optional)', 'ক্রেডিট (ঐচ্ছিক)') }] }],
    sample: { sems: [{ g: 3.5, cr: 15 }, { g: 3.8, cr: 18 }] },
    run(v) {
      const rows = v.sems.filter((r) => isNum(r.g));
      if (!rows.length) return null;
      const weighted = rows.filter((r) => isNum(r.cr) && r.cr > 0);
      if (weighted.length) {
        const cr = weighted.reduce((a, r) => a + r.cr, 0);
        return { rows: [['CGPA', fmt(weighted.reduce((a, r) => a + r.g * r.cr, 0) / cr, 2)], [B('Total credits', 'মোট ক্রেডিট'), f4(cr)]] };
      }
      return { rows: [['CGPA', fmt(rows.reduce((a, r) => a + r.g, 0) / rows.length, 2)]], note: B('No credits given, so semesters are averaged equally.', 'ক্রেডিট না দেওয়ায় সব সেমিস্টারকে সমান ধরে গড় করা হয়েছে।') };
    },
  },
  {
    id: 'grade', cat: 'calc', icon: 'cap', name: B('Weighted grade', 'ওজনভিত্তিক গ্রেড'), desc: B('Course grade from scores and weights', 'স্কোর ও ওজন থেকে কোর্সের গ্রেড'),
    inputs: [{ k: 'items', t: 'rows', label: B('Assessments', 'মূল্যায়ন'), rows: 4, add: B('Add item', 'যোগ করুন'),
      cols: [{ k: 's', t: 'number', label: B('Score %', 'স্কোর %') }, { k: 'w', t: 'number', label: B('Weight %', 'ওজন %') }] }],
    sample: { items: [{ s: 80, w: 30 }, { s: 70, w: 70 }] },
    run(v) {
      const rows = v.items.filter((r) => isNum(r.s) && isNum(r.w) && r.w > 0);
      if (!rows.length) return null;
      const tw = rows.reduce((a, r) => a + r.w, 0);
      const sc = rows.reduce((a, r) => a + r.s * r.w, 0) / tw;
      return { rows: [[B('Weighted score', 'ওজনভিত্তিক স্কোর'), f4(sc) + '%'], [B('Letter grade', 'লেটার গ্রেড'), letter(sc)], [B('Total weight', 'মোট ওজন'), f4(tw) + '%']], note: tw !== 100 ? B('Weights do not add up to 100%, so the score is scaled to the weights entered.', 'ওজনের যোগফল ১০০% নয়, তাই দেওয়া ওজন অনুযায়ী স্কোর হিসাব করা হয়েছে।') : null };
    },
  },
  {
    id: 'marks', cat: 'calc', icon: 'cap', name: B('Marks calculator', 'নম্বর ক্যালকুলেটর'), desc: B('Total, percentage and grade from marks', 'নম্বর থেকে মোট, শতাংশ ও গ্রেড'),
    inputs: [{ k: 'subs', t: 'rows', label: B('Subjects', 'বিষয়'), rows: 5, add: B('Add subject', 'বিষয় যোগ'),
      cols: [{ k: 'ob', t: 'number', label: B('Obtained', 'প্রাপ্ত') }, { k: 'tot', t: 'number', label: B('Full marks', 'পূর্ণমান') }] }],
    sample: { subs: [{ ob: 78, tot: 100 }, { ob: 65, tot: 100 }] },
    run(v) {
      const rows = v.subs.filter((r) => isNum(r.ob) && isNum(r.tot) && r.tot > 0);
      if (!rows.length) return null;
      const ob = rows.reduce((a, r) => a + r.ob, 0), tot = rows.reduce((a, r) => a + r.tot, 0);
      const p = ob / tot * 100; const [g, pt] = bdGrade(p);
      return { rows: [[B('Total obtained', 'মোট প্রাপ্ত'), f4(ob) + ' / ' + f4(tot)], [B('Percentage', 'শতাংশ'), f4(p) + '%'], [B('Grade (SSC/HSC style)', 'গ্রেড (SSC/HSC ধাঁচ)'), g + ' (' + pt.toFixed(2) + ')']] };
    },
  },
  {
    id: 'attendance', cat: 'calc', icon: 'calendar', name: B('Attendance calculator', 'উপস্থিতি ক্যালকুলেটর'), desc: B('Attendance percent and classes needed', 'উপস্থিতির শতাংশ ও আর কত ক্লাস দরকার'),
    inputs: [N('total', B('Classes held so far', 'এ পর্যন্ত মোট ক্লাস')), N('att', B('Classes attended', 'উপস্থিত ছিলেন')), N('target', B('Required attendance %', 'প্রয়োজনীয় উপস্থিতি %'), { def: 75 })],
    run(v) {
      if (!has(v, 'total', 'att', 'target')) return null;
      if (v.total <= 0 || v.att < 0 || v.att > v.total || v.target <= 0 || v.target >= 100) return { error: B('Check the numbers: attended cannot be more than held, and target must be between 0 and 100.', 'সংখ্যা মিলিয়ে দেখুন: উপস্থিতি মোটের বেশি হতে পারে না, আর লক্ষ্য ০ থেকে ১০০ এর মধ্যে হতে হবে।') };
      const cur = v.att / v.total * 100;
      const rows = [[B('Current attendance', 'বর্তমান উপস্থিতি'), f4(cur) + '%']];
      if (cur < v.target) rows.push([B('Classes to attend in a row', 'টানা যত ক্লাসে থাকতে হবে'), Math.ceil((v.target * v.total - 100 * v.att) / (100 - v.target))]);
      else rows.push([B('Classes you can still miss', 'আরও যত ক্লাস মিস করা যাবে'), Math.floor(100 * v.att / v.target - v.total)]);
      return { rows };
    },
  },
];
