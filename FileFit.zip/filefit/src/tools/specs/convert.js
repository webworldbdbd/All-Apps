import { B, has, fmt, fmtSig, isNum, tr, toAscii, toBn, pad2 } from '../lite.js';
import * as M from '../mathlib.js';

const N = (k, label, extra) => ({ k, t: 'number', label, ...extra });

/* ---------- generic unit converter factory ---------- */
function unitTool(id, icon, name, desc, list, defFrom, defTo, note) {
  const opts = list.map(([k, label]) => [k, label]);
  const F = Object.fromEntries(list.map(([k, , f]) => [k, f]));
  const L = Object.fromEntries(list.map(([k, label]) => [k, label]));
  return {
    id, cat: 'convert', icon, name, desc,
    inputs: [N('x', B('Value', 'মান'), { def: 1, neg: true }), { k: 'from', t: 'select', label: B('From', 'যে একক থেকে'), opts, def: defFrom }, { k: 'to', t: 'select', label: B('To', 'যে এককে'), opts, def: defTo }],
    run(v) {
      if (!isNum(v.x)) return null;
      const base = v.x * F[v.from];
      const out = base / F[v.to];
      return {
        rows: [[B('Result', 'ফলাফল'), fmtSig(out) + ' ' + tr(L[v.to])], ...list.filter(([k]) => k !== v.from).map(([k, label, f]) => [label, fmtSig(base / f)])],
        note,
      };
    },
  };
}

const BD_LAND_NOTE = B('Bigha and katha sizes differ by region. This uses the common Dhaka standard (1 katha = 720 sq ft, 1 bigha = 20 katha).', 'অঞ্চলভেদে বিঘা ও কাঠার মাপ আলাদা হয়। এখানে ঢাকার প্রচলিত মান ধরা হয়েছে (১ কাঠা = ৭২০ বর্গফুট, ১ বিঘা = ২০ কাঠা)।');

const TEMP = [['c', '°C'], ['f', '°F'], ['k', 'K']];
const toK = { c: (x) => x + 273.15, f: (x) => (x - 32) * 5 / 9 + 273.15, k: (x) => x };
const fromK = { c: (x) => x - 273.15, f: (x) => (x - 273.15) * 9 / 5 + 32, k: (x) => x };

const FUEL = [['kml', 'km/L'], ['mpgus', 'mpg (US)'], ['mpguk', 'mpg (UK)'], ['l100', 'L/100 km']];
const fuelToKml = { kml: (x) => x, mpgus: (x) => x / 2.352145833, mpguk: (x) => x / 2.824809363, l100: (x) => 100 / x };
const fuelFromKml = { kml: (x) => x, mpgus: (x) => x * 2.352145833, mpguk: (x) => x * 2.824809363, l100: (x) => 100 / x };

const BASES = [['2', B('Binary (2)', 'বাইনারি (২)')], ['8', B('Octal (8)', 'অক্টাল (৮)')], ['10', B('Decimal (10)', 'দশমিক (১০)')], ['16', B('Hexadecimal (16)', 'হেক্সাডেসিমাল (১৬)')]];
const DIG = '0123456789abcdefghijklmnopqrstuvwxyz';
function parseBase(s, base) {
  let t = s.trim().toLowerCase().replace(/[\s_]/g, '');
  let neg = false;
  if (t.startsWith('-')) { neg = true; t = t.slice(1); }
  t = t.replace(/^0[xbo]/, '');
  if (!t) return null;
  let n = 0n;
  for (const ch of t) { const i = DIG.indexOf(ch); if (i < 0 || i >= base) return null; n = n * BigInt(base) + BigInt(i); }
  return neg ? -n : n;
}

export default [
  unitTool('length', 'ruler', B('Length converter', 'দৈর্ঘ্য কনভার্টার'), B('Metres, feet, inches, miles, hat and more', 'মিটার, ফুট, ইঞ্চি, মাইল, হাত ইত্যাদি'),
    [['mm', 'mm', 0.001], ['cm', 'cm', 0.01], ['m', 'm', 1], ['km', 'km', 1000], ['in', B('inch', 'ইঞ্চি'), 0.0254], ['ft', B('foot', 'ফুট'), 0.3048], ['yd', B('yard / gaj', 'গজ / yard'), 0.9144], ['hat', B('hat (cubit)', 'হাত'), 0.4572], ['mi', B('mile', 'মাইল'), 1609.344], ['nmi', B('nautical mile', 'নটিক্যাল মাইল'), 1852]], 'ft', 'm'),
  unitTool('mass', 'scale', B('Weight converter', 'ওজন কনভার্টার'), B('Kg, pound, maund, seer, bhori and more', 'কেজি, পাউন্ড, মণ, সের, ভরি ইত্যাদি'),
    [['mg', 'mg', 0.001], ['g', B('gram', 'গ্রাম'), 1], ['kg', B('kilogram', 'কেজি'), 1000], ['qt', B('quintal (100 kg)', 'কুইন্টাল (১০০ কেজি)'), 100000], ['t', B('tonne', 'টন'), 1e6], ['oz', B('ounce', 'আউন্স'), 28.349523125], ['lb', B('pound', 'পাউন্ড'), 453.59237], ['st', B('stone', 'স্টোন'), 6350.29318],
      ['maund', B('maund (40 seer)', 'মণ (৪০ সের)'), 37324.2], ['seer', B('seer', 'সের'), 933.105], ['chhatak', B('chhatak', 'ছটাক'), 58.319], ['bhori', B('bhori (tola)', 'ভরি (তোলা)'), 11.664]], 'kg', 'lb'),
  {
    id: 'temperature', cat: 'convert', icon: 'flash', name: B('Temperature converter', 'তাপমাত্রা কনভার্টার'), desc: B('Celsius, Fahrenheit and Kelvin', 'সেলসিয়াস, ফারেনহাইট ও কেলভিন'),
    inputs: [N('x', B('Value', 'মান'), { def: 25, neg: true }), { k: 'from', t: 'chips', label: B('From', 'যে একক থেকে'), opts: TEMP, def: 'c' }],
    run(v) {
      if (!isNum(v.x)) return null;
      const k = toK[v.from](v.x);
      if (k < 0) return { error: B('That is below absolute zero', 'এটি পরম শূন্যের নিচে') };
      return { rows: TEMP.filter(([u]) => u !== v.from).map(([u, l]) => [l, fmt(fromK[u](k), 2)]) };
    },
  },
  unitTool('areaconv', 'ruler', B('Area converter', 'ক্ষেত্রফল কনভার্টার'), B('Square metres, feet, acre, hectare', 'বর্গমিটার, বর্গফুট, একর, হেক্টর'),
    [['cm2', 'cm²', 0.0001], ['m2', 'm²', 1], ['km2', 'km²', 1e6], ['in2', 'in²', 0.00064516], ['ft2', B('sq ft', 'বর্গফুট'), 0.09290304], ['yd2', 'yd²', 0.83612736], ['ac', B('acre', 'একর'), 4046.8564224], ['ha', B('hectare', 'হেক্টর'), 10000], ['mi2', 'mi²', 2589988.110336]], 'ft2', 'm2'),
  unitTool('volumeconv', 'ruler', B('Volume converter', 'আয়তন কনভার্টার'), B('Litres, millilitres, gallons, cups', 'লিটার, মিলি, গ্যালন, কাপ'),
    [['ml', 'mL', 0.001], ['l', B('litre', 'লিটার'), 1], ['m3', 'm³', 1000], ['tsp', B('teaspoon (US)', 'চা চামচ (US)'), 0.00492892159375], ['tbsp', B('tablespoon (US)', 'টেবিল চামচ (US)'), 0.01478676478125], ['floz', 'fl oz (US)', 0.0295735295625], ['cup', B('cup (US)', 'কাপ (US)'), 0.2365882365], ['pt', B('pint (US)', 'পাইন্ট (US)'), 0.473176473], ['gal', B('gallon (US)', 'গ্যালন (US)'), 3.785411784], ['galuk', B('gallon (UK)', 'গ্যালন (UK)'), 4.54609]], 'l', 'gal'),
  unitTool('speed', 'bolt', B('Speed converter', 'গতি কনভার্টার'), B('km/h, mph, m/s, knots', 'কিমি/ঘণ্টা, মাইল/ঘণ্টা, মি/সে, নট'),
    [['ms', 'm/s', 1], ['kmh', 'km/h', 1 / 3.6], ['mph', 'mph', 0.44704], ['kn', B('knot', 'নট'), 0.514444444], ['fts', 'ft/s', 0.3048], ['mach', 'Mach', 340.29]], 'kmh', 'mph'),
  unitTool('datasize', 'file', B('Data size converter', 'ডেটা সাইজ কনভার্টার'), B('Bytes, KB, MB, GB, TB', 'বাইট, KB, MB, GB, TB'),
    [['bit', 'bit', 0.125], ['b', 'Byte', 1], ['kb', 'KB', 1024], ['mb', 'MB', 1048576], ['gb', 'GB', 1073741824], ['tb', 'TB', 1099511627776], ['pb', 'PB', 1125899906842624]], 'mb', 'kb', B('1 KB = 1024 bytes.', '১ KB = ১০২৪ বাইট।')),
  unitTool('timeunits', 'clock', B('Time unit converter', 'সময়ের একক কনভার্টার'), B('Seconds, minutes, hours, days, years', 'সেকেন্ড, মিনিট, ঘণ্টা, দিন, বছর'),
    [['ms', 'ms', 0.001], ['s', B('second', 'সেকেন্ড'), 1], ['min', B('minute', 'মিনিট'), 60], ['h', B('hour', 'ঘণ্টা'), 3600], ['d', B('day', 'দিন'), 86400], ['w', B('week', 'সপ্তাহ'), 604800], ['mo', B('month (30.44 d)', 'মাস (৩০.৪৪ দিন)'), 2629800], ['y', B('year (365.25 d)', 'বছর (৩৬৫.২৫ দিন)'), 31557600]], 'h', 'min'),
  unitTool('pressure', 'bolt', B('Pressure converter', 'চাপ কনভার্টার'), B('Pascal, bar, psi, atm, mmHg', 'প্যাসকেল, বার, psi, atm, mmHg'),
    [['pa', 'Pa', 1], ['kpa', 'kPa', 1000], ['bar', 'bar', 100000], ['atm', 'atm', 101325], ['psi', 'psi', 6894.757293168], ['mmhg', 'mmHg', 133.322387415]], 'psi', 'bar'),
  unitTool('energy', 'bolt', B('Energy converter', 'শক্তি কনভার্টার'), B('Joule, calorie, kWh, BTU', 'জুল, ক্যালরি, kWh, BTU'),
    [['j', 'J', 1], ['kj', 'kJ', 1000], ['cal', 'cal', 4.184], ['kcal', 'kcal', 4184], ['wh', 'Wh', 3600], ['kwh', 'kWh', 3600000], ['btu', 'BTU', 1055.05585]], 'kcal', 'kj'),
  unitTool('powerconv', 'bolt', B('Power converter', 'ক্ষমতা কনভার্টার'), B('Watt, kilowatt, horsepower', 'ওয়াট, কিলোওয়াট, অশ্বশক্তি'),
    [['w', 'W', 1], ['kw', 'kW', 1000], ['mw', 'MW', 1e6], ['hp', B('horsepower', 'হর্সপাওয়ার'), 745.69987158], ['btuh', 'BTU/h', 0.29307107]], 'hp', 'kw'),
  unitTool('angle', 'rotate', B('Angle converter', 'কোণ কনভার্টার'), B('Degrees, radians, gradians', 'ডিগ্রি, রেডিয়ান, গ্রেডিয়ান'),
    [['deg', B('degree °', 'ডিগ্রি °'), 1], ['rad', 'rad', 180 / Math.PI], ['grad', 'grad', 0.9], ['turn', B('turn', 'পূর্ণ ঘূর্ণন'), 360], ['arcmin', "arcmin ′", 1 / 60], ['arcsec', 'arcsec ″', 1 / 3600]], 'deg', 'rad'),
  {
    id: 'fuelecon', cat: 'convert', icon: 'fuel', name: B('Fuel economy converter', 'জ্বালানি দক্ষতা কনভার্টার'), desc: B('km/L, mpg and L/100 km', 'কিমি/লিটার, mpg ও L/100 কিমি'),
    inputs: [N('x', B('Value', 'মান')), { k: 'from', t: 'select', label: B('From', 'যে একক থেকে'), opts: FUEL, def: 'kml' }],
    run(v) {
      if (!isNum(v.x) || v.x <= 0) return null;
      const k = fuelToKml[v.from](v.x);
      return { rows: FUEL.filter(([u]) => u !== v.from).map(([u, l]) => [l, fmt(fuelFromKml[u](k), 2)]) };
    },
  },
  unitTool('land', 'ruler', B('Land converter (Bangladesh)', 'জমির পরিমাপ কনভার্টার'), B('Katha, bigha, shotangsho, acre, sq ft', 'কাঠা, বিঘা, শতাংশ, একর, বর্গফুট'),
    [['sqft', B('sq ft', 'বর্গফুট'), 1], ['sqm', B('sq metre', 'বর্গমিটার'), 10.7639104167], ['sqhat', B('sq hat', 'বর্গহাত'), 2.25], ['chhatak', B('chhatak', 'ছটাক'), 45], ['ganda', B('ganda', 'গণ্ডা'), 80], ['katha', B('katha', 'কাঠা'), 720], ['bigha', B('bigha', 'বিঘা'), 14400], ['shot', B('shotangsho (decimal)', 'শতাংশ'), 435.6], ['acre', B('acre', 'একর'), 43560], ['ha', B('hectare', 'হেক্টর'), 107639.104167]], 'katha', 'sqft', BD_LAND_NOTE),
  unitTool('gold', 'crown', B('Gold weight converter', 'সোনার ওজন কনভার্টার'), B('Bhori, ana, roti, gram, ounce', 'ভরি, আনা, রতি, গ্রাম, আউন্স'),
    [['g', B('gram', 'গ্রাম'), 1], ['mg', 'mg', 0.001], ['kg', B('kg', 'কেজি'), 1000], ['bhori', B('bhori (vori)', 'ভরি'), 11.664], ['ana', B('ana', 'আনা'), 11.664 / 16], ['roti', B('roti', 'রতি'), 11.664 / 96], ['ozt', B('troy ounce', 'ট্রয় আউন্স'), 31.1034768]], 'bhori', 'g', B('1 bhori = 11.664 g = 16 ana = 96 roti.', '১ ভরি = ১১.৬৬৪ গ্রাম = ১৬ আনা = ৯৬ রতি।')),
  {
    id: 'numbase', cat: 'convert', icon: 'code', name: B('Number base converter', 'সংখ্যা পদ্ধতি কনভার্টার'), desc: B('Binary, octal, decimal and hex', 'বাইনারি, অক্টাল, দশমিক ও হেক্স'),
    inputs: [{ k: 'x', t: 'text', label: B('Number', 'সংখ্যা'), def: '255' }, { k: 'base', t: 'chips', label: B('Number is in', 'সংখ্যাটি যে পদ্ধতিতে'), opts: BASES, def: '10' }],
    run(v) {
      if (!v.x || !v.x.trim()) return null;
      const n = parseBase(toAscii(v.x), +v.base);
      if (n == null) return { error: B('That is not a valid number in this system', 'এই পদ্ধতিতে এটি বৈধ সংখ্যা নয়') };
      return { rows: [[B('Binary', 'বাইনারি'), n.toString(2)], [B('Octal', 'অক্টাল'), n.toString(8)], [B('Decimal', 'দশমিক'), n.toString(10)], [B('Hexadecimal', 'হেক্সাডেসিমাল'), n.toString(16).toUpperCase()]] };
    },
  },
  {
    id: 'roman', cat: 'convert', icon: 'hash', name: B('Roman numerals', 'রোমান সংখ্যা'), desc: B('Numbers to Roman numerals and back', 'সংখ্যা থেকে রোমান ও রোমান থেকে সংখ্যা'),
    inputs: [{ k: 'x', t: 'text', label: B('Number (1-3999) or Roman numeral', 'সংখ্যা (১-৩৯৯৯) বা রোমান সংখ্যা'), def: '2026' }],
    run(v) {
      const s = toAscii(v.x || '').trim();
      if (!s) return null;
      if (/^\d+$/.test(s)) { const r = M.toRoman(+s); return r ? { rows: [[B('Roman numeral', 'রোমান সংখ্যা'), r]] } : { error: B('Use a number from 1 to 3999', '১ থেকে ৩৯৯৯ এর মধ্যে সংখ্যা দিন') }; }
      const n = M.fromRoman(s);
      return n ? { rows: [[B('Number', 'সংখ্যা'), n], [B('Bengali digits', 'বাংলা অঙ্ক'), toBn(n)]] } : { error: B('That is not a valid Roman numeral', 'এটি বৈধ রোমান সংখ্যা নয়') };
    },
  },
  {
    id: 'numwords', cat: 'convert', icon: 'text', name: B('Number to words', 'সংখ্যা থেকে কথায়'), desc: B('Amount in English and Bengali words (taka)', 'টাকার অঙ্ক ইংরেজি ও বাংলা কথায়'),
    inputs: [{ k: 'x', t: 'text', label: B('Amount', 'অঙ্ক'), def: '1250500', hint: B('Up to 15 digits and 2 decimals. Bengali digits work too.', '১৫ অঙ্ক ও ২ দশমিক পর্যন্ত। বাংলা অঙ্কও চলবে।') }],
    sample: { x: '1250500.50' },
    run(v) {
      const s = toAscii(v.x || '').replace(/[,\s]/g, '');
      if (!s) return null;
      const m = /^(\d{1,15})(?:\.(\d{1,2}))?$/.exec(s);
      if (!m) return { error: B('Enter a plain number, like 12500 or 1250.75', 'সাধারণ সংখ্যা দিন, যেমন ১২৫০০ বা ১২৫০.৭৫') };
      const ip = m[1].replace(/^0+(?=\d)/, '');
      const paisa = m[2] ? Number(m[2].padEnd(2, '0')) : 0;
      const en = M.wordsEn(ip), bn = M.wordsBn(ip);
      const cap = (x) => x.charAt(0).toUpperCase() + x.slice(1);
      const enP = paisa ? ' and ' + M.wordsEn(paisa) + ' paisa' : '';
      const bnP = paisa ? ' ' + M.wordsBn(paisa) + ' পয়সা' : '';
      return { rows: [[B('In English', 'ইংরেজিতে'), cap(en) + (m[2] ? ' point ' + m[2].split('').map((d) => M.wordsEn(d)).join(' ') : '')], [B('In Bengali', 'বাংলায়'), bn + (m[2] ? ' দশমিক ' + m[2].split('').map((d) => M.wordsBn(d)).join(' ') : '')],
        [B('Taka (English)', 'টাকা (ইংরেজি)'), 'Taka ' + cap(en) + enP + ' only'], [B('Taka (Bengali)', 'টাকা (বাংলা)'), bn + ' টাকা' + bnP + ' মাত্র'],
        [B('Lakh-crore style', 'লাখ-কোটি স্টাইল'), M.groupIndian(ip) + (m[2] ? '.' + m[2] : '')], [B('Bengali digits', 'বাংলা অঙ্কে'), toBn(M.groupIndian(ip) + (m[2] ? '.' + m[2] : ''))], [B('International style', 'আন্তর্জাতিক স্টাইল'), M.groupIntl(ip) + (m[2] ? '.' + m[2] : '')]] };
    },
  },
  {
    id: 'digits', cat: 'convert', icon: 'convert', name: B('Bengali ↔ English digits', 'বাংলা ↔ ইংরেজি অঙ্ক'), desc: B('Switch the digits inside any text', 'যেকোনো লেখার অঙ্ক বদলান'),
    inputs: [{ k: 'text', t: 'area', label: B('Text', 'লেখা'), paste: true }, { k: 'mode', t: 'chips', label: B('Convert to', 'রূপান্তর'), opts: [['bn', B('Bengali digits', 'বাংলা অঙ্ক')], ['en', B('English digits', 'ইংরেজি অঙ্ক')]], def: 'bn' }],
    sample: { text: 'Room 204, 2026' },
    run(v) { return v.text ? { text: v.mode === 'bn' ? toBn(v.text) : toAscii(v.text) } : null; },
  },
  {
    id: 'color', cat: 'convert', icon: 'palette', name: B('Colour converter', 'রং কনভার্টার'), desc: B('HEX, RGB, HSL and CMYK', 'HEX, RGB, HSL ও CMYK'),
    inputs: [{ k: 'x', t: 'text', label: B('Colour (#1668E3, rgb(22,104,227) or hsl(220,80%,50%))', 'রং (#1668E3, rgb(22,104,227) বা hsl(220,80%,50%))'), def: '#1668E3' }],
    run(v) {
      if (!v.x || !v.x.trim()) return null;
      const c = M.parseColor(v.x);
      if (!c) return { error: B('Could not read that colour', 'রংটি পড়া যায়নি') };
      const [h, s, l] = M.rgbToHsl(...c);
      const [cy, ma, ye, k] = M.rgbToCmyk(...c);
      return { color: M.rgbToHex(...c), rows: [['HEX', M.rgbToHex(...c)], ['RGB', `rgb(${c.join(', ')})`], ['HSL', `hsl(${h}, ${s}%, ${l}%)`], ['CMYK', `${cy}%, ${ma}%, ${ye}%, ${k}%`]] };
    },
  },
  {
    id: 'timestamp', cat: 'convert', icon: 'clock', name: B('Timestamp converter', 'টাইমস্ট্যাম্প কনভার্টার'), desc: B('Unix time to readable date and back', 'ইউনিক্স টাইম থেকে তারিখ ও উল্টো'),
    inputs: [{ k: 'x', t: 'text', label: B('Unix timestamp (seconds or ms) or a date', 'ইউনিক্স টাইমস্ট্যাম্প (সেকেন্ড বা মিলিসেকেন্ড) বা তারিখ'), def: () => String(Math.floor(Date.now() / 1000)), hint: B('Example: 1767225600 or 2026-12-31 18:00', 'যেমন: 1767225600 বা 2026-12-31 18:00') }],
    sample: { x: '1767225600' },
    run(v) {
      const s = toAscii(v.x || '').trim();
      if (!s) return null;
      let ms;
      if (/^-?\d+(\.\d+)?$/.test(s)) { const n = Number(s); ms = Math.abs(n) >= 1e11 ? n : n * 1000; } else ms = Date.parse(s.replace(' ', 'T'));
      if (!isFinite(ms)) return { error: B('Could not read that value', 'মানটি পড়া যায়নি') };
      const d = new Date(ms);
      if (isNaN(d.getTime())) return { error: B('That date is out of range', 'তারিখটি সীমার বাইরে') };
      const fmtZone = (tz) => new Intl.DateTimeFormat('en-GB', { timeZone: tz, dateStyle: 'medium', timeStyle: 'medium', hourCycle: 'h23' }).format(d);
      return { rows: [[B('Unix (seconds)', 'ইউনিক্স (সেকেন্ড)'), Math.floor(ms / 1000)], [B('Unix (milliseconds)', 'ইউনিক্স (মিলিসেকেন্ড)'), Math.floor(ms)], ['ISO 8601', d.toISOString()], ['UTC', fmtZone('UTC')], [B('Bangladesh time', 'বাংলাদেশ সময়'), fmtZone('Asia/Dhaka')], [B('This device', 'এই ডিভাইস'), d.toLocaleString()]] };
    },
  },
];
