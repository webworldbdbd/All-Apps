import { B, has, fmt, isNum } from '../lite.js';

const N = (k, label, extra) => ({ k, t: 'number', label, ...extra });
const Chips = (k, label, opts, def, extra) => ({ k, t: 'chips', label, opts, def: def ?? opts[0][0], ...extra });
const m2 = (x) => fmt(x, 2);

export default [
  {
    id: 'discount', cat: 'life', icon: 'tag', name: B('Discount calculator', 'ডিসকাউন্ট ক্যালকুলেটর'), desc: B('Final price after one or two discounts', 'এক বা দুই ছাড়ের পর দাম'),
    inputs: [N('price', B('Original price', 'আসল দাম')), N('d1', B('Discount %', 'ছাড় %')), N('d2', B('Extra discount % (optional)', 'অতিরিক্ত ছাড় % (ঐচ্ছিক)'))],
    run(v) {
      if (!has(v, 'price', 'd1') || v.d1 < 0 || v.d1 > 100) return null;
      const e = isNum(v.d2) ? v.d2 : 0;
      const fin = v.price * (1 - v.d1 / 100) * (1 - e / 100);
      return { rows: [[B('Final price', 'চূড়ান্ত দাম'), m2(fin)], [B('You save', 'আপনার সাশ্রয়'), m2(v.price - fin)], [B('Total discount', 'মোট ছাড়'), fmt((1 - fin / v.price) * 100, 2) + '%']] };
    },
  },
  {
    id: 'vat', cat: 'life', icon: 'tag', name: B('VAT / tax calculator', 'ভ্যাট / ট্যাক্স ক্যালকুলেটর'), desc: B('Add or remove VAT, GST or sales tax', 'ভ্যাট বা ট্যাক্স যোগ বা বাদ দিন'),
    inputs: [Chips('mode', B('Mode', 'ধরন'), [['add', B('Add tax', 'ট্যাক্স যোগ')], ['remove', B('Remove tax', 'ট্যাক্স বাদ')]]), N('amount', B('Amount', 'টাকার পরিমাণ')), N('rate', B('Tax rate %', 'ট্যাক্স হার %'), { def: 15 })],
    run(v) {
      if (!has(v, 'amount', 'rate')) return null;
      const net = v.mode === 'add' ? v.amount : v.amount / (1 + v.rate / 100);
      const gross = v.mode === 'add' ? v.amount * (1 + v.rate / 100) : v.amount;
      return { rows: [[B('Amount without tax', 'ট্যাক্স ছাড়া'), m2(net)], [B('Tax', 'ট্যাক্স'), m2(gross - net)], [B('Amount with tax', 'ট্যাক্সসহ'), m2(gross)]] };
    },
  },
  {
    id: 'tip', cat: 'life', icon: 'money', name: B('Bill split & tip', 'বিল ভাগ ও টিপ'), desc: B('Split a bill between people', 'বিল সবার মধ্যে ভাগ করুন'),
    inputs: [N('bill', B('Bill amount', 'বিলের পরিমাণ')), N('tip', B('Tip %', 'টিপ %'), { def: 0 }), N('people', B('People', 'কতজন'), { def: 2 })],
    run(v) {
      if (!has(v, 'bill', 'tip', 'people') || v.people < 1) return null;
      const tip = v.bill * v.tip / 100;
      return { rows: [[B('Tip', 'টিপ'), m2(tip)], [B('Total', 'মোট'), m2(v.bill + tip)], [B('Per person', 'জনপ্রতি'), m2((v.bill + tip) / Math.floor(v.people))]] };
    },
  },
  {
    id: 'profit', cat: 'life', icon: 'money', name: B('Profit & loss', 'লাভ-ক্ষতি'), desc: B('Profit or loss from cost and selling price', 'ক্রয়মূল্য ও বিক্রয়মূল্য থেকে লাভ-ক্ষতি'),
    inputs: [N('cp', B('Cost price', 'ক্রয়মূল্য')), N('sp', B('Selling price', 'বিক্রয়মূল্য'))],
    run(v) {
      if (!has(v, 'cp', 'sp') || v.cp <= 0) return null;
      const d = v.sp - v.cp;
      return { rows: [[d >= 0 ? B('Profit', 'লাভ') : B('Loss', 'ক্ষতি'), m2(Math.abs(d))], [B('Percentage of cost', 'ক্রয়মূল্যের শতাংশ'), fmt(Math.abs(d) / v.cp * 100, 2) + '%'], [B('Margin on selling price', 'বিক্রয়মূল্যে মার্জিন'), v.sp === 0 ? '—' : fmt(d / v.sp * 100, 2) + '%']] };
    },
  },
  {
    id: 'simpleinterest', cat: 'life', icon: 'money', name: B('Simple interest', 'সরল সুদ'), desc: B('Interest on a fixed amount over time', 'নির্দিষ্ট সময়ে সুদ'),
    inputs: [N('p', B('Principal', 'আসল')), N('r', B('Yearly rate %', 'বার্ষিক হার %')), N('y', B('Years', 'বছর'))],
    run(v) {
      if (!has(v, 'p', 'r', 'y')) return null;
      const i = v.p * v.r * v.y / 100;
      return { rows: [[B('Interest', 'সুদ'), m2(i)], [B('Total amount', 'মোট'), m2(v.p + i)]] };
    },
  },
  {
    id: 'compound', cat: 'life', icon: 'money', name: B('Compound interest', 'চক্রবৃদ্ধি সুদ'), desc: B('Growth with interest on interest', 'সুদের ওপর সুদসহ বৃদ্ধি'),
    inputs: [N('p', B('Principal', 'আসল')), N('r', B('Yearly rate %', 'বার্ষিক হার %')), N('y', B('Years', 'বছর')),
      { k: 'n', t: 'select', label: B('Compounded', 'চক্রবৃদ্ধি'), def: '12', opts: [['1', B('Yearly', 'বছরে একবার')], ['2', B('Half-yearly', 'ছয় মাসে')], ['4', B('Quarterly', 'তিন মাসে')], ['12', B('Monthly', 'প্রতি মাসে')], ['365', B('Daily', 'প্রতিদিন')]] }],
    run(v) {
      if (!has(v, 'p', 'r', 'y')) return null;
      const n = +v.n;
      const tot = v.p * Math.pow(1 + v.r / 100 / n, n * v.y);
      return { rows: [[B('Final amount', 'চূড়ান্ত পরিমাণ'), m2(tot)], [B('Interest earned', 'সুদ'), m2(tot - v.p)]] };
    },
  },
  {
    id: 'emi', cat: 'life', icon: 'money', name: B('Loan EMI calculator', 'লোন কিস্তি (EMI)'), desc: B('Monthly installment, total interest and payable', 'মাসিক কিস্তি, মোট সুদ ও পরিশোধ'),
    inputs: [N('p', B('Loan amount', 'ঋণের পরিমাণ')), N('r', B('Yearly interest %', 'বার্ষিক সুদ %')), N('t', B('Duration', 'মেয়াদ')),
      Chips('unit', B('Duration in', 'মেয়াদের একক'), [['y', B('Years', 'বছর')], ['m', B('Months', 'মাস')]])],
    run(v) {
      if (!has(v, 'p', 'r', 't') || v.p <= 0 || v.t <= 0) return null;
      const n = Math.round(v.unit === 'y' ? v.t * 12 : v.t);
      const r = v.r / 12 / 100;
      const emi = r === 0 ? v.p / n : v.p * r * Math.pow(1 + r, n) / (Math.pow(1 + r, n) - 1);
      return { rows: [[B('Monthly installment', 'মাসিক কিস্তি'), m2(emi)], [B('Total payable', 'মোট পরিশোধ'), m2(emi * n)], [B('Total interest', 'মোট সুদ'), m2(emi * n - v.p)], [B('Number of installments', 'কিস্তির সংখ্যা'), n]] };
    },
  },
  {
    id: 'savings', cat: 'life', icon: 'money', name: B('Savings goal', 'সঞ্চয় লক্ষ্য'), desc: B('How much to save each month', 'প্রতি মাসে কত জমাতে হবে'),
    inputs: [N('goal', B('Goal amount', 'লক্ষ্যের পরিমাণ')), N('have', B('Already saved', 'এখন যত জমেছে'), { def: 0 }), N('months', B('Months to reach it', 'কত মাসে চান'))],
    run(v) {
      if (!has(v, 'goal', 'have', 'months') || v.months < 1) return null;
      const need = v.goal - v.have;
      return need <= 0 ? { rows: [[B('Status', 'অবস্থা'), B('Goal already reached', 'লক্ষ্য পূরণ হয়ে গেছে')]] } : { rows: [[B('Save every month', 'প্রতি মাসে জমান'), m2(need / v.months)], [B('Still needed', 'আরও দরকার'), m2(need)]], note: B('Interest is not included.', 'সুদ ধরা হয়নি।') };
    },
  },
  {
    id: 'zakat', cat: 'life', icon: 'money', name: B('Zakat calculator', 'যাকাত ক্যালকুলেটর'), desc: B('2.5% of your zakatable wealth above nisab', 'নিসাবের বেশি সম্পদের ২.৫%'),
    inputs: [N('cash', B('Cash and bank savings', 'নগদ ও ব্যাংকে জমা'), { def: 0 }), N('gold', B('Value of gold', 'স্বর্ণের মূল্য'), { def: 0 }), N('silver', B('Value of silver', 'রৌপ্যের মূল্য'), { def: 0 }),
      N('biz', B('Business stock and goods', 'ব্যবসার পণ্য ও মজুদ'), { def: 0 }), N('recv', B('Money owed to you (sure to receive)', 'পাওনা (পাওয়া নিশ্চিত)'), { def: 0 }), N('debt', B('Debts you owe', 'আপনার ঋণ'), { def: 0 }),
      N('nisab', B('Nisab value today', 'আজকের নিসাবের মূল্য'), { hint: B('Value of 52.5 tola (612.36 g) of silver or 7.5 tola (87.48 g) of gold, at today\'s price', 'আজকের দামে ৫২.৫ ভরি রূপা বা ৭.৫ ভরি সোনার মূল্য') })],
    run(v) {
      if (!has(v, 'cash', 'gold', 'silver', 'biz', 'recv', 'debt', 'nisab')) return null;
      const net = v.cash + v.gold + v.silver + v.biz + v.recv - v.debt;
      const due = net >= v.nisab && net > 0;
      return { rows: [[B('Net zakatable wealth', 'যাকাতযোগ্য নিট সম্পদ'), m2(net)], [B('Reaches nisab?', 'নিসাব পূর্ণ?'), due ? B('Yes', 'হ্যাঁ') : B('No', 'না')], [B('Zakat due (2.5%)', 'যাকাত (২.৫%)'), due ? m2(net * 0.025) : '0']], note: B('This is a simple estimate. Ask a trusted scholar about your situation.', 'এটি সহজ হিসাব। আপনার ক্ষেত্রের জন্য নির্ভরযোগ্য আলেমের পরামর্শ নিন।') };
    },
  },
  {
    id: 'bmi', cat: 'life', icon: 'heart', name: B('BMI calculator', 'BMI ক্যালকুলেটর'), desc: B('Body mass index from weight and height', 'ওজন ও উচ্চতা থেকে BMI'),
    inputs: [Chips('unit', B('Units', 'একক'), [['metric', B('kg / cm', 'কেজি / সেমি')], ['imp', B('lb / in', 'পাউন্ড / ইঞ্চি')]]), N('w', B('Weight', 'ওজন')), N('h', B('Height', 'উচ্চতা'))],
    run(v) {
      if (!has(v, 'w', 'h') || v.w <= 0 || v.h <= 0) return null;
      const bmi = v.unit === 'metric' ? v.w / (v.h / 100) ** 2 : 703 * v.w / v.h ** 2;
      const cls = bmi < 18.5 ? B('Underweight', 'কম ওজন') : bmi < 25 ? B('Normal', 'স্বাভাবিক') : bmi < 30 ? B('Overweight', 'বেশি ওজন') : B('Obese', 'স্থূলতা');
      return { rows: [['BMI', fmt(bmi, 1)], [B('Category (WHO)', 'শ্রেণি (WHO)'), cls]], note: B('For South Asians, doctors often use lower cut-offs (overweight from 23). BMI is only a rough guide, not a diagnosis.', 'দক্ষিণ এশীয়দের জন্য চিকিৎসকরা প্রায়ই কম সীমা ধরেন (২৩ থেকে বেশি ওজন)। BMI শুধু মোটামুটি ধারণা, রোগ নির্ণয় নয়।') };
    },
  },
  {
    id: 'bmr', cat: 'life', icon: 'heart', name: B('Daily calorie need', 'দৈনিক ক্যালরি'), desc: B('BMR and daily calories by activity', 'BMR ও কাজ অনুযায়ী দৈনিক ক্যালরি'),
    inputs: [Chips('sex', B('Sex', 'লিঙ্গ'), [['m', B('Male', 'পুরুষ')], ['f', B('Female', 'নারী')]]), N('age', B('Age (years)', 'বয়স (বছর)')), N('w', B('Weight (kg)', 'ওজন (কেজি)')), N('h', B('Height (cm)', 'উচ্চতা (সেমি)')),
      { k: 'act', t: 'select', label: B('Activity', 'কাজের ধরন'), def: '1.375', opts: [['1.2', B('Little or no exercise', 'প্রায় ব্যায়াম নেই')], ['1.375', B('Light (1-3 days/week)', 'হালকা (সপ্তাহে ১-৩ দিন)')], ['1.55', B('Moderate (3-5 days/week)', 'মাঝারি (সপ্তাহে ৩-৫ দিন)')], ['1.725', B('Hard (6-7 days/week)', 'কঠোর (সপ্তাহে ৬-৭ দিন)')]] }],
    run(v) {
      if (!has(v, 'age', 'w', 'h') || v.age <= 0 || v.w <= 0 || v.h <= 0) return null;
      const bmr = 10 * v.w + 6.25 * v.h - 5 * v.age + (v.sex === 'm' ? 5 : -161);
      return { rows: [['BMR', fmt(bmr, 0) + ' kcal'], [B('Calories to maintain weight', 'ওজন ধরে রাখতে ক্যালরি'), fmt(bmr * +v.act, 0) + ' kcal']], note: B('Estimate using the Mifflin-St Jeor formula.', 'Mifflin-St Jeor সূত্রে আনুমানিক হিসাব।') };
    },
  },
  {
    id: 'idealweight', cat: 'life', icon: 'heart', name: B('Healthy weight range', 'সুস্থ ওজনের পরিসর'), desc: B('Weight range for your height', 'আপনার উচ্চতায় সুস্থ ওজন'),
    inputs: [Chips('sex', B('Sex', 'লিঙ্গ'), [['m', B('Male', 'পুরুষ')], ['f', B('Female', 'নারী')]]), N('h', B('Height (cm)', 'উচ্চতা (সেমি)'))],
    run(v) {
      if (!has(v, 'h') || v.h < 100 || v.h > 250) return null;
      const inch = v.h / 2.54;
      const devine = (v.sex === 'm' ? 50 : 45.5) + 2.3 * Math.max(0, inch - 60);
      const hm = (v.h / 100) ** 2;
      return { rows: [[B('Healthy BMI range', 'সুস্থ BMI অনুযায়ী'), fmt(18.5 * hm, 1) + ' – ' + fmt(24.9 * hm, 1) + ' kg'], [B('Devine formula', 'Devine সূত্র'), fmt(devine, 1) + ' kg']], note: B('A rough guide only. Ask a doctor for advice about your health.', 'শুধু মোটামুটি ধারণা। স্বাস্থ্য নিয়ে চিকিৎসকের পরামর্শ নিন।') };
    },
  },
  {
    id: 'water', cat: 'life', icon: 'water', name: B('Daily water intake', 'দৈনিক পানির পরিমাণ'), desc: B('Rough daily water need', 'দিনে আনুমানিক কত পানি দরকার'),
    inputs: [N('w', B('Weight (kg)', 'ওজন (কেজি)')), N('ex', B('Exercise minutes per day', 'প্রতিদিন ব্যায়াম (মিনিট)'), { def: 0 })],
    run(v) {
      if (!has(v, 'w', 'ex') || v.w <= 0) return null;
      const l = v.w * 0.033 + v.ex / 30 * 0.35;
      return { rows: [[B('Water per day', 'দিনে পানি'), fmt(l, 1) + ' L'], [B('Glasses (250 ml)', 'গ্লাস (২৫০ মিলি)'), Math.ceil(l * 4)]], note: B('A general estimate. Needs change with weather, health and diet.', 'সাধারণ হিসাব। আবহাওয়া, স্বাস্থ্য ও খাবারের ওপর প্রয়োজন বদলায়।') };
    },
  },
  {
    id: 'speeddt', cat: 'life', icon: 'clock', name: B('Speed, distance, time', 'গতি, দূরত্ব, সময়'), desc: B('Find any one from the other two', 'দুটি জানলে তৃতীয়টি বের করুন'),
    inputs: [Chips('find', B('Find', 'নির্ণয়'), [['speed', B('Speed', 'গতি')], ['dist', B('Distance', 'দূরত্ব')], ['time', B('Time', 'সময়')]]),
      N('d', B('Distance (km)', 'দূরত্ব (কিমি)'), { when: (v) => v.find !== 'dist' }), N('t', B('Time (hours)', 'সময় (ঘণ্টা)'), { when: (v) => v.find !== 'time' }), N('s', B('Speed (km/h)', 'গতি (কিমি/ঘণ্টা)'), { when: (v) => v.find !== 'speed' })],
    run(v) {
      if (v.find === 'speed') return has(v, 'd', 't') && v.t > 0 ? { rows: [[B('Speed', 'গতি'), fmt(v.d / v.t, 2) + ' km/h']] } : null;
      if (v.find === 'dist') return has(v, 't', 's') ? { rows: [[B('Distance', 'দূরত্ব'), fmt(v.s * v.t, 2) + ' km']] } : null;
      if (!has(v, 'd', 's') || v.s <= 0) return null;
      const h = v.d / v.s;
      return { rows: [[B('Time', 'সময়'), fmt(h, 2) + ' h'], [B('In hours and minutes', 'ঘণ্টা ও মিনিটে'), Math.floor(h) + ' h ' + Math.round((h - Math.floor(h)) * 60) + ' min']] };
    },
  },
  {
    id: 'fuelcost', cat: 'life', icon: 'fuel', name: B('Fuel cost calculator', 'জ্বালানি খরচ'), desc: B('Trip fuel and cost', 'যাত্রার জ্বালানি ও খরচ'),
    inputs: [N('d', B('Distance (km)', 'দূরত্ব (কিমি)')), N('m', B('Mileage (km per litre)', 'মাইলেজ (কিমি প্রতি লিটার)')), N('p', B('Fuel price per litre', 'প্রতি লিটারের দাম'))],
    run(v) {
      if (!has(v, 'd', 'm', 'p') || v.m <= 0) return null;
      const l = v.d / v.m;
      return { rows: [[B('Fuel needed', 'জ্বালানি লাগবে'), fmt(l, 2) + ' L'], [B('Cost', 'খরচ'), m2(l * v.p)], [B('Cost per km', 'প্রতি কিমি খরচ'), m2(l * v.p / v.d)]] };
    },
  },
];
