import { B, tr } from './lite.js';
import calc from './specs/calc.js';
import life from './specs/life.js';
import time from './specs/time.js';
import convert from './specs/convert.js';
import dev from './specs/dev.js';
import textx from './specs/textx.js';

// Tools with their own screens (keypad, live timers). They are listed here so the
// home screen, search and category pages treat them like every other tool.
export const SPECIAL = [
  { id: 'calculator', cat: 'calc', icon: 'calc', name: B('Calculator', 'ক্যালকুলেটর'), desc: B('Simple everyday calculator', 'সহজ দৈনন্দিন ক্যালকুলেটর') },
  { id: 'scientific', cat: 'calc', icon: 'calc', name: B('Scientific calculator', 'সায়েন্টিফিক ক্যালকুলেটর'), desc: B('Trigonometry, logarithms, powers', 'ত্রিকোণমিতি, লগারিদম, ঘাত') },
  { id: 'countdown', cat: 'time', icon: 'timer', name: B('Countdown timer', 'কাউন্টডাউন টাইমার'), desc: B('Count down from any time', 'যেকোনো সময় থেকে উল্টো গণনা') },
  { id: 'stopwatch', cat: 'time', icon: 'timer', name: B('Stopwatch', 'স্টপওয়াচ'), desc: B('Time with laps', 'ল্যাপসহ সময় মাপুন') },
  { id: 'pomodoro', cat: 'time', icon: 'timer', name: B('Pomodoro timer', 'পোমোডোরো টাইমার'), desc: B('Focus and break sessions', 'পড়া ও বিরতির সেশন') },
  { id: 'worldclock', cat: 'time', icon: 'globe', name: B('World clock', 'বিশ্ব ঘড়ি'), desc: B('Live time in cities around the world', 'বিশ্বের বিভিন্ন শহরের এখনকার সময়') },
];

export const SPECS = [...calc, ...life, ...time, ...convert, ...dev, ...textx];
export const SPECS_BY_ID = Object.fromEntries(SPECS.map((s) => [s.id, s]));
export const ALL_META = [...SPECS, ...SPECIAL].map((s) => ({ id: s.id, cat: s.cat, icon: s.icon, name: s.name, desc: s.desc }));
export const META_BY_ID = Object.fromEntries(ALL_META.map((m) => [m.id, m]));
export { B, tr };
