// Pure maths and encoding helpers (no DOM). Tested in Node.
import { toAscii } from './lite.js';

export const gcd = (a, b) => { a = Math.abs(a); b = Math.abs(b); while (b) [a, b] = [b, a % b]; return a; };
export const lcm = (a, b) => (a && b ? Math.abs(a / gcd(a, b) * b) : 0);

export function isPrime(n) {
  if (!Number.isInteger(n) || n < 2) return false;
  if (n < 4) return true;
  if (n % 2 === 0 || n % 3 === 0) return false;
  for (let i = 5; i * i <= n; i += 6) if (n % i === 0 || n % (i + 2) === 0) return false;
  return true;
}
export function factorize(n) {
  const out = [];
  for (let p = 2; p * p <= n; p += p === 2 ? 1 : 2) { let c = 0; while (n % p === 0) { n /= p; c++; } if (c) out.push([p, c]); }
  if (n > 1) out.push([n, 1]);
  return out;
}
export const nextPrime = (n) => { let x = Math.floor(n) + 1; while (!isPrime(x)) x++; return x; };
export const prevPrime = (n) => { let x = Math.floor(n) - 1; while (x >= 2 && !isPrime(x)) x--; return x >= 2 ? x : null; };

export function fact(n) { let r = 1n; for (let i = 2n; i <= BigInt(n); i++) r *= i; return r; }
export const nPr = (n, r) => { let x = 1n; for (let i = 0; i < r; i++) x *= BigInt(n - i); return x; };
export const nCr = (n, r) => { r = Math.min(r, n - r); let x = 1n; for (let i = 1; i <= r; i++) x = x * BigInt(n - r + i) / BigInt(i); return x; };

export function simplify(n, d) { const g = gcd(n, d) || 1; if (d < 0) { n = -n; d = -d; } return [n / g, d / g]; }

/* --------------------------------------------------- expression evaluator */
const FN = {
  sin: (x, deg) => Math.sin(deg ? x * Math.PI / 180 : x),
  cos: (x, deg) => Math.cos(deg ? x * Math.PI / 180 : x),
  tan: (x, deg) => Math.tan(deg ? x * Math.PI / 180 : x),
  asin: (x, deg) => (deg ? Math.asin(x) * 180 / Math.PI : Math.asin(x)),
  acos: (x, deg) => (deg ? Math.acos(x) * 180 / Math.PI : Math.acos(x)),
  atan: (x, deg) => (deg ? Math.atan(x) * 180 / Math.PI : Math.atan(x)),
  ln: Math.log, log: Math.log10, log2: Math.log2, sqrt: Math.sqrt, cbrt: Math.cbrt, abs: Math.abs, exp: Math.exp,
  floor: Math.floor, ceil: Math.ceil, round: Math.round,
};
export function evalExpr(src, { deg = true, ans = 0 } = {}) {
  const s = toAscii(src).replace(/×/g, '*').replace(/÷/g, '/').replace(/[−–]/g, '-').replace(/π/g, 'pi').replace(/√/g, 'sqrt');
  const tok = [];
  const rx = /\s*(\d+\.?\d*|\.\d+|[a-zA-Z][a-zA-Z0-9]*|[-+*/^()!%,])/y;
  let m; let last = 0;
  while (last < s.length && (m = (rx.lastIndex = last, rx.exec(s)))) { tok.push(m[1]); last = rx.lastIndex; }
  if (s.slice(last).trim()) throw new Error('syntax');
  let i = 0;
  const peek = () => tok[i];
  const isNumTok = (x) => x != null && /^[\d.]/.test(x);
  const isNameTok = (x) => x != null && /^[a-zA-Z]/.test(x);
  const startsPrimary = (x) => x != null && (isNumTok(x) || isNameTok(x) || x === '(');
  function expr() { let v = term(); while (peek() === '+' || peek() === '-') { const op = tok[i++]; const r = term(); v = op === '+' ? v + r : v - r; } return v; }
  function term() {
    let v = unary();
    for (;;) {
      const p = peek();
      if (p === '*' || p === '/') { i++; const r = unary(); v = p === '*' ? v * r : v / r; }
      else if (startsPrimary(p)) v *= unary();
      else break;
    }
    return v;
  }
  function unary() { if (peek() === '-') { i++; return -unary(); } if (peek() === '+') { i++; return unary(); } return power(); }
  function power() { const b = postfix(); if (peek() === '^') { i++; return Math.pow(b, unary()); } return b; }
  function postfix() {
    let v = primary();
    for (;;) {
      if (peek() === '!') { i++; if (!Number.isInteger(v) || v < 0 || v > 170) throw new Error('factorial'); let r = 1; for (let k = 2; k <= v; k++) r *= k; v = r; }
      else if (peek() === '%') { i++; v /= 100; }
      else break;
    }
    return v;
  }
  function primary() {
    const x = tok[i++];
    if (x == null) throw new Error('syntax');
    if (isNumTok(x)) return parseFloat(x);
    if (x === '(') { const v = expr(); if (tok[i++] !== ')') throw new Error('paren'); return v; }
    if (isNameTok(x)) {
      const k = x.toLowerCase();
      if (k === 'pi') return Math.PI;
      if (k === 'e') return Math.E;
      if (k === 'ans') return ans;
      if (FN[k]) {
        let arg;
        if (peek() === '(') { i++; arg = expr(); if (tok[i++] !== ')') throw new Error('paren'); } else arg = power();
        return FN[k](arg, deg);
      }
    }
    throw new Error('syntax');
  }
  const out = expr();
  if (i < tok.length) throw new Error('syntax');
  if (!isFinite(out)) throw new Error('math');
  return Number(out.toPrecision(12));
}

/* -------------------------------------------------------------- hashing */
export function md5(str) {
  const bytes = new TextEncoder().encode(str);
  const K = Array.from({ length: 64 }, (_, i) => Math.floor(Math.abs(Math.sin(i + 1)) * 4294967296) >>> 0);
  const S = [7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20, 4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, 6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21];
  const len = bytes.length;
  const padLen = Math.ceil((len + 9) / 64) * 64;
  const buf = new Uint8Array(padLen);
  buf.set(bytes); buf[len] = 0x80;
  const dv = new DataView(buf.buffer);
  dv.setUint32(padLen - 8, (len * 8) >>> 0, true);
  dv.setUint32(padLen - 4, Math.floor(len * 8 / 4294967296), true);
  let a0 = 0x67452301, b0 = 0xefcdab89, c0 = 0x98badcfe, d0 = 0x10325476;
  for (let off = 0; off < padLen; off += 64) {
    const M = Array.from({ length: 16 }, (_, i) => dv.getUint32(off + i * 4, true));
    let A = a0, Bv = b0, C = c0, D = d0;
    for (let i = 0; i < 64; i++) {
      let F, g;
      if (i < 16) { F = (Bv & C) | (~Bv & D); g = i; }
      else if (i < 32) { F = (D & Bv) | (~D & C); g = (5 * i + 1) % 16; }
      else if (i < 48) { F = Bv ^ C ^ D; g = (3 * i + 5) % 16; }
      else { F = C ^ (Bv | ~D); g = (7 * i) % 16; }
      F = (F + A + K[i] + M[g]) >>> 0;
      A = D; D = C; C = Bv;
      Bv = (Bv + ((F << S[i]) | (F >>> (32 - S[i])))) >>> 0;
    }
    a0 = (a0 + A) >>> 0; b0 = (b0 + Bv) >>> 0; c0 = (c0 + C) >>> 0; d0 = (d0 + D) >>> 0;
  }
  const out = new Uint8Array(16);
  const ov = new DataView(out.buffer);
  [a0, b0, c0, d0].forEach((x, i) => ov.setUint32(i * 4, x, true));
  return [...out].map((b) => b.toString(16).padStart(2, '0')).join('');
}

/* ------------------------------------------------------------- numerals */
export function toRoman(n) {
  if (!Number.isInteger(n) || n < 1 || n > 3999) return null;
  const T = [[1000, 'M'], [900, 'CM'], [500, 'D'], [400, 'CD'], [100, 'C'], [90, 'XC'], [50, 'L'], [40, 'XL'], [10, 'X'], [9, 'IX'], [5, 'V'], [4, 'IV'], [1, 'I']];
  let s = '';
  for (const [v, r] of T) while (n >= v) { s += r; n -= v; }
  return s;
}
export function fromRoman(str) {
  const s = str.toUpperCase().trim();
  if (!/^[MDCLXVI]+$/.test(s)) return null;
  const V = { I: 1, V: 5, X: 10, L: 50, C: 100, D: 500, M: 1000 };
  let n = 0;
  for (let i = 0; i < s.length; i++) { const a = V[s[i]], b = V[s[i + 1]] || 0; n += a < b ? -a : a; }
  return toRoman(n) === s ? n : null;
}

const ONES = ['zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten', 'eleven', 'twelve', 'thirteen', 'fourteen', 'fifteen', 'sixteen', 'seventeen', 'eighteen', 'nineteen'];
const TENS = ['', '', 'twenty', 'thirty', 'forty', 'fifty', 'sixty', 'seventy', 'eighty', 'ninety'];
const SCALES = ['', 'thousand', 'million', 'billion', 'trillion', 'quadrillion'];
function below1000(n) {
  const out = [];
  if (n >= 100) { out.push(ONES[Math.floor(n / 100)] + ' hundred'); n %= 100; }
  if (n >= 20) { out.push(TENS[Math.floor(n / 10)] + (n % 10 ? '-' + ONES[n % 10] : '')); } else if (n > 0) out.push(ONES[n]);
  return out.join(' ');
}
export function wordsEn(big) {
  let n = BigInt(big);
  if (n === 0n) return 'zero';
  const parts = [];
  let i = 0;
  while (n > 0n) { const chunk = Number(n % 1000n); if (chunk) parts.unshift(below1000(chunk) + (SCALES[i] ? ' ' + SCALES[i] : '')); n /= 1000n; i++; }
  return parts.join(' ');
}
const BN = ['শূন্য', 'এক', 'দুই', 'তিন', 'চার', 'পাঁচ', 'ছয়', 'সাত', 'আট', 'নয়', 'দশ', 'এগারো', 'বারো', 'তেরো', 'চৌদ্দ', 'পনেরো', 'ষোল', 'সতেরো', 'আঠারো', 'ঊনিশ',
  'বিশ', 'একুশ', 'বাইশ', 'তেইশ', 'চব্বিশ', 'পঁচিশ', 'ছাব্বিশ', 'সাতাশ', 'আঠাশ', 'ঊনত্রিশ', 'ত্রিশ', 'একত্রিশ', 'বত্রিশ', 'তেত্রিশ', 'চৌত্রিশ', 'পঁয়ত্রিশ', 'ছত্রিশ', 'সাঁইত্রিশ', 'আটত্রিশ', 'ঊনচল্লিশ',
  'চল্লিশ', 'একচল্লিশ', 'বিয়াল্লিশ', 'তেতাল্লিশ', 'চুয়াল্লিশ', 'পঁয়তাল্লিশ', 'ছেচল্লিশ', 'সাতচল্লিশ', 'আটচল্লিশ', 'ঊনপঞ্চাশ', 'পঞ্চাশ', 'একান্ন', 'বাহান্ন', 'তিপ্পান্ন', 'চুয়ান্ন', 'পঞ্চান্ন', 'ছাপ্পান্ন', 'সাতান্ন', 'আটান্ন', 'ঊনষাট',
  'ষাট', 'একষট্টি', 'বাষট্টি', 'তেষট্টি', 'চৌষট্টি', 'পঁয়ষট্টি', 'ছেষট্টি', 'সাতষট্টি', 'আটষট্টি', 'ঊনসত্তর', 'সত্তর', 'একাত্তর', 'বাহাত্তর', 'তিয়াত্তর', 'চুয়াত্তর', 'পঁচাত্তর', 'ছিয়াত্তর', 'সাতাত্তর', 'আটাত্তর', 'ঊনআশি',
  'আশি', 'একাশি', 'বিরাশি', 'তিরাশি', 'চুরাশি', 'পঁচাশি', 'ছিয়াশি', 'সাতাশি', 'আটাশি', 'ঊননব্বই', 'নব্বই', 'একানব্বই', 'বিরানব্বই', 'তিরানব্বই', 'চুরানব্বই', 'পঁচানব্বই', 'ছিয়ানব্বই', 'সাতানব্বই', 'আটানব্বই', 'নিরানব্বই'];
export function wordsBn(big) {
  const n = BigInt(big);
  if (n === 0n) return BN[0];
  const parts = [];
  const crore = n / 10000000n; let rest = n % 10000000n;
  if (crore > 0n) parts.push(wordsBn(crore) + ' কোটি');
  const lakh = rest / 100000n; rest %= 100000n;
  if (lakh > 0n) parts.push(BN[Number(lakh)] + ' লাখ');
  const th = rest / 1000n; rest %= 1000n;
  if (th > 0n) parts.push(BN[Number(th)] + ' হাজার');
  const hun = rest / 100n; rest %= 100n;
  if (hun > 0n) parts.push(BN[Number(hun)] + 'শ');
  if (rest > 0n) parts.push(BN[Number(rest)]);
  return parts.join(' ');
}
export function groupIndian(digits) {
  const s = String(digits);
  if (s.length <= 3) return s;
  const head = s.slice(0, -3).replace(/\B(?=(\d{2})+(?!\d))/g, ',');
  return head + ',' + s.slice(-3);
}
export const groupIntl = (digits) => String(digits).replace(/\B(?=(\d{3})+(?!\d))/g, ',');

/* ------------------------------------------------------------- colours */
export function parseColor(input) {
  const s = input.trim().toLowerCase();
  let m = /^#?([0-9a-f]{3}|[0-9a-f]{6})$/.exec(s);
  if (m) {
    let h = m[1];
    if (h.length === 3) h = h.split('').map((c) => c + c).join('');
    return [parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16)];
  }
  m = /^rgb\(?\s*(\d{1,3})[\s,]+(\d{1,3})[\s,]+(\d{1,3})\s*\)?$/.exec(s);
  if (m) { const r = [+m[1], +m[2], +m[3]]; return r.every((x) => x <= 255) ? r : null; }
  m = /^hsl\(?\s*(\d{1,3}(?:\.\d+)?)[\s,]+(\d{1,3}(?:\.\d+)?)%?[\s,]+(\d{1,3}(?:\.\d+)?)%?\s*\)?$/.exec(s);
  if (m) return hslToRgb(+m[1], +m[2], +m[3]);
  return null;
}
export function rgbToHsl(r, g, b) {
  r /= 255; g /= 255; b /= 255;
  const mx = Math.max(r, g, b), mn = Math.min(r, g, b);
  let h = 0, s = 0; const l = (mx + mn) / 2;
  if (mx !== mn) {
    const d = mx - mn;
    s = l > 0.5 ? d / (2 - mx - mn) : d / (mx + mn);
    if (mx === r) h = (g - b) / d + (g < b ? 6 : 0); else if (mx === g) h = (b - r) / d + 2; else h = (r - g) / d + 4;
    h *= 60;
  }
  return [Math.round(h), Math.round(s * 100), Math.round(l * 100)];
}
export function hslToRgb(h, s, l) {
  s /= 100; l /= 100;
  const k = (n) => (n + h / 30) % 12;
  const a = s * Math.min(l, 1 - l);
  const f = (n) => l - a * Math.max(-1, Math.min(k(n) - 3, Math.min(9 - k(n), 1)));
  return [Math.round(f(0) * 255), Math.round(f(8) * 255), Math.round(f(4) * 255)];
}
export const rgbToHex = (r, g, b) => '#' + [r, g, b].map((x) => x.toString(16).padStart(2, '0')).join('').toUpperCase();
export function rgbToCmyk(r, g, b) {
  r /= 255; g /= 255; b /= 255;
  const k = 1 - Math.max(r, g, b);
  if (k === 1) return [0, 0, 0, 100];
  return [(1 - r - k) / (1 - k), (1 - g - k) / (1 - k), (1 - b - k) / (1 - k), k].map((x) => Math.round(x * 100));
}

/* -------------------------------------------------------------- morse */
export const MORSE = { A: '.-', B: '-...', C: '-.-.', D: '-..', E: '.', F: '..-.', G: '--.', H: '....', I: '..', J: '.---', K: '-.-', L: '.-..', M: '--', N: '-.', O: '---', P: '.--.', Q: '--.-', R: '.-.', S: '...', T: '-', U: '..-', V: '...-', W: '.--', X: '-..-', Y: '-.--', Z: '--..',
  0: '-----', 1: '.----', 2: '..---', 3: '...--', 4: '....-', 5: '.....', 6: '-....', 7: '--...', 8: '---..', 9: '----.', '.': '.-.-.-', ',': '--..--', '?': '..--..', '!': '-.-.--', '/': '-..-.', '(': '-.--.', ')': '-.--.-', '&': '.-...', ':': '---...', ';': '-.-.-.', '=': '-...-', '+': '.-.-.', '-': '-....-', '_': '..--.-', '"': '.-..-.', '@': '.--.-.', "'": '.----.' };

/* ----------------------------------------------------------- CSV parse */
export function parseCsv(text, delim = ',') {
  const rows = []; let cur = []; let f = ''; let q = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (q) { if (c === '"' && text[i + 1] === '"') { f += '"'; i++; } else if (c === '"') q = false; else f += c; }
    else if (c === '"') q = true;
    else if (c === delim) { cur.push(f); f = ''; }
    else if (c === '\n' || c === '\r') { if (c === '\r' && text[i + 1] === '\n') i++; cur.push(f); rows.push(cur); cur = []; f = ''; }
    else f += c;
  }
  if (f || cur.length) { cur.push(f); rows.push(cur); }
  return rows.filter((r) => r.some((x) => x !== ''));
}
