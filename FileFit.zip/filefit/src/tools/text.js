// Pure text helpers. No DOM, no network - everything runs on the device.

const words = (s) => (s.trim() ? s.trim().split(/\s+/) : []);

export function stats(s) {
  const w = words(s);
  const chars = [...s].length;
  const noSpace = [...s.replace(/\s/g, '')].length;
  const sentences = s.split(/[.!?।]+/).filter((x) => x.trim()).length;
  const paragraphs = s.split(/\n\s*\n/).filter((x) => x.trim()).length;
  const lines = s ? s.split(/\r?\n/).length : 0;
  return {
    words: w.length, chars, noSpace, sentences, paragraphs, lines,
    readMin: w.length / 200, speakMin: w.length / 130,
  };
}

const lineList = (s) => s.split(/\r?\n/);

export function dedupeLines(s, { ignoreCase = true, trim = true, removeEmpty = true } = {}) {
  const seen = new Set();
  const out = [];
  let total = 0;
  for (const raw of lineList(s)) {
    const line = trim ? raw.trim() : raw;
    if (removeEmpty && !line.trim()) continue;
    total++;
    const key = ignoreCase ? line.toLowerCase() : line;
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(line);
  }
  return { text: out.join('\n'), removed: total - out.length, left: out.length };
}

export function sortLines(s, { mode = 'az', ignoreCase = true, removeEmpty = true } = {}) {
  let list = lineList(s).map((x) => x.replace(/\s+$/, ''));
  if (removeEmpty) list = list.filter((x) => x.trim());
  const cmp = (a, b) => a.localeCompare(b, undefined, { sensitivity: ignoreCase ? 'base' : 'variant', numeric: true });
  if (mode === 'az') list.sort(cmp);
  else if (mode === 'za') list.sort((a, b) => cmp(b, a));
  else if (mode === 'short') list.sort((a, b) => a.length - b.length || cmp(a, b));
  else if (mode === 'long') list.sort((a, b) => b.length - a.length || cmp(a, b));
  else if (mode === 'num') {
    const n = (x) => { const m = x.match(/-?\d+(\.\d+)?/); return m ? parseFloat(m[0]) : Infinity; };
    list.sort((a, b) => n(a) - n(b) || cmp(a, b));
  } else if (mode === 'random') {
    for (let i = list.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [list[i], list[j]] = [list[j], list[i]];
    }
  } else if (mode === 'flip') list.reverse();
  return list.join('\n');
}

const escapeRx = (x) => x.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

export function findReplace(s, find, rep, { caseSensitive = false, regex = false, whole = false } = {}) {
  if (!find) return { text: s, count: 0 };
  let src = regex ? find : escapeRx(find);
  if (whole) src = '(?<![\\p{L}\\p{N}_])(?:' + src + ')(?![\\p{L}\\p{N}_])';
  const rx = new RegExp(src, 'gu' + (caseSensitive ? '' : 'i'));
  let count = 0;
  const text = s.replace(rx, (...a) => {
    count++;
    if (!regex) return rep;
    const groups = a.slice(1, -2).filter((x) => typeof x === 'string' || x === undefined);
    return rep.replace(/\$(\d+|&)/g, (_, k) => (k === '&' ? a[0] : groups[Number(k) - 1] ?? ''));
  });
  return { text, count };
}

export function changeCase(s, mode) {
  if (mode === 'upper') return s.toUpperCase();
  if (mode === 'lower') return s.toLowerCase();
  if (mode === 'title') return s.toLowerCase().replace(/(^|[\s\-_("'\u201c\u2018[])(\p{L})/gu, (_, a, b) => a + b.toUpperCase());
  if (mode === 'sentence') return s.toLowerCase().replace(/(^\s*|[.!?\u0964]\s+|\n\s*)(\p{L})/gu, (_, a, b) => a + b.toUpperCase());
  if (mode === 'swap') return [...s].map((c) => (c === c.toUpperCase() ? c.toLowerCase() : c.toUpperCase())).join('');
  return s;
}

export function cleanText(s, { trimLines = true, collapse = true, emptyLines = false, joinLines = false } = {}) {
  let list = lineList(s);
  if (trimLines) list = list.map((x) => x.trim());
  if (collapse) list = list.map((x) => x.replace(/[ \t\u00a0]{2,}/g, ' '));
  if (emptyLines) list = list.filter((x) => x.trim());
  let out = list.join('\n');
  if (joinLines) out = out.split(/\n+/).map((x) => x.trim()).filter(Boolean).join(' ');
  return out;
}

function graphemes(s) {
  if (typeof Intl !== 'undefined' && Intl.Segmenter) return [...new Intl.Segmenter(undefined, { granularity: 'grapheme' }).segment(s)].map((x) => x.segment);
  return Array.from(s);
}

export function reverseText(s, mode = 'chars') {
  if (mode === 'chars') return graphemes(s).reverse().join('');
  if (mode === 'words') return lineList(s).map((l) => l.split(/\s+/).filter(Boolean).reverse().join(' ')).join('\n');
  return lineList(s).reverse().join('\n');
}

export function slugify(s, { sep = '-', lower = true } = {}) {
  return lineList(s).map((l) => {
    let x = l.normalize('NFC').trim();
    if (lower) x = x.toLowerCase();
    x = x.replace(/[^\p{L}\p{N}\p{M}]+/gu, sep);
    const e = escapeRx(sep);
    return x.replace(new RegExp('^' + e + '+|' + e + '+$', 'g'), '');
  }).filter(Boolean).join('\n');
}

export function dedupeWords(s, { ignoreCase = true } = {}) {
  const seen = new Set();
  const strip = (w) => w.replace(/^[^\p{L}\p{N}]+|[^\p{L}\p{N}]+$/gu, '');
  let removed = 0;
  const out = [];
  for (const line of lineList(s)) {
    const keep = [];
    for (const w of line.split(/\s+/).filter(Boolean)) {
      const core = strip(w);
      const key = ignoreCase ? core.toLowerCase() : core;
      if (key && seen.has(key)) { removed++; continue; }
      if (key) seen.add(key);
      keep.push(w);
    }
    if (keep.length) out.push(keep.join(' '));
  }
  return { text: out.join('\n'), removed };
}

const LOREM = ('lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua ut enim ad minim veniam quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur excepteur sint occaecat cupidatat non proident sunt in culpa qui officia deserunt mollit anim id est laborum').split(' ');
const pick = () => LOREM[Math.floor(Math.random() * LOREM.length)];
const cap = (x) => x.charAt(0).toUpperCase() + x.slice(1);

function sentence() {
  const n = 6 + Math.floor(Math.random() * 9);
  const w = Array.from({ length: n }, pick);
  if (n > 9) w[Math.floor(n / 2)] += ',';
  return cap(w.join(' ')) + '.';
}

export function lorem(unit = 'paragraphs', count = 3, startClassic = true) {
  count = Math.max(1, Math.min(unit === 'words' ? 1000 : 50, Math.floor(count) || 1));
  const classic = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.';
  if (unit === 'words') {
    const w = Array.from({ length: count }, pick);
    if (startClassic) LOREM.slice(0, Math.min(5, count)).forEach((x, i) => { w[i] = x; });
    return cap(w.join(' ')) + '.';
  }
  if (unit === 'sentences') {
    const list = Array.from({ length: count }, sentence);
    if (startClassic) list[0] = classic;
    return list.join(' ');
  }
  const paras = Array.from({ length: count }, () => Array.from({ length: 3 + Math.floor(Math.random() * 3) }, sentence).join(' '));
  if (startClassic) paras[0] = classic + ' ' + paras[0];
  return paras.join('\n\n');
}
