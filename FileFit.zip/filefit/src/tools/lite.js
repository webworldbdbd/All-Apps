// Tiny helpers shared by every tool spec. No imports, so it also runs in plain Node for tests.
export const B = (en, bn) => ({ en, bn });
export const curLang = () => (typeof document !== 'undefined' && document.documentElement && document.documentElement.lang) || 'en';
export const tr = (x) => (x == null ? '' : typeof x !== 'object' ? String(x) : x[curLang()] || x.en || '');
export const isNum = (x) => typeof x === 'number' && isFinite(x);
export const has = (v, ...ks) => ks.every((k) => isNum(v[k]));
export const row = (label, value) => [label, String(value)];

export function fmt(n, d = 2) {
  if (!isFinite(n)) return '—';
  const dd = Math.min(d, 20);
  let r = Number(n.toFixed(dd));
  if (r === 0) r = 0;
  return r.toLocaleString('en-US', { maximumFractionDigits: dd });
}
export function fmtSig(n) {
  if (!isFinite(n)) return '—';
  if (n === 0) return '0';
  const a = Math.abs(n);
  if (a >= 1e15 || a < 1e-6) return n.toExponential(6).replace(/\.?0+e/, 'e');
  return Number(n.toPrecision(10)).toLocaleString('en-US', { maximumFractionDigits: 10 });
}

/* ------------------------------------------------------------------ dates */
export const DAYS = [B('Sunday', 'রবিবার'), B('Monday', 'সোমবার'), B('Tuesday', 'মঙ্গলবার'), B('Wednesday', 'বুধবার'), B('Thursday', 'বৃহস্পতিবার'), B('Friday', 'শুক্রবার'), B('Saturday', 'শনিবার')];
export const MONTHS = [B('January', 'জানুয়ারি'), B('February', 'ফেব্রুয়ারি'), B('March', 'মার্চ'), B('April', 'এপ্রিল'), B('May', 'মে'), B('June', 'জুন'), B('July', 'জুলাই'), B('August', 'আগস্ট'), B('September', 'সেপ্টেম্বর'), B('October', 'অক্টোবর'), B('November', 'নভেম্বর'), B('December', 'ডিসেম্বর')];

export function parseISO(s) {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s || '');
  if (!m) return null;
  const o = { y: +m[1], m: +m[2], d: +m[3] };
  if (o.m < 1 || o.m > 12 || o.d < 1 || o.d > dim(o.y, o.m)) return null;
  return o;
}
export const dim = (y, m) => new Date(Date.UTC(y, m, 0)).getUTCDate();
export const utc = (o) => Date.UTC(o.y, o.m - 1, o.d);
export const fromUtc = (ms) => { const d = new Date(ms); return { y: d.getUTCFullYear(), m: d.getUTCMonth() + 1, d: d.getUTCDate() }; };
export const daysBetween = (a, b) => Math.round((utc(b) - utc(a)) / 86400000);
export const weekdayOf = (o) => new Date(utc(o)).getUTCDay();
export const isLeap = (y) => (y % 4 === 0 && y % 100 !== 0) || y % 400 === 0;
export const dayOfYear = (o) => daysBetween({ y: o.y, m: 1, d: 1 }, o) + 1;
export const addDays = (o, n) => fromUtc(utc(o) + n * 86400000);
export function addMonths(o, n) {
  const t = o.y * 12 + (o.m - 1) + n;
  const y = Math.floor(t / 12);
  const m = (t % 12 + 12) % 12 + 1;
  return { y, m, d: Math.min(o.d, dim(y, m)) };
}
export function ymdDiff(a, b) {
  let y = b.y - a.y, m = b.m - a.m, d = b.d - a.d;
  if (d < 0) { m--; const pm = b.m === 1 ? 12 : b.m - 1; const py = b.m === 1 ? b.y - 1 : b.y; d += dim(py, pm); }
  if (m < 0) { y--; m += 12; }
  return { y, m, d };
}
export function todayISO() {
  const n = new Date();
  const p = (x) => String(x).padStart(2, '0');
  return n.getFullYear() + '-' + p(n.getMonth() + 1) + '-' + p(n.getDate());
}
export const fmtDMY = (o) => o.d + ' ' + tr(MONTHS[o.m - 1]) + ' ' + o.y;
export const dayName = (o) => tr(DAYS[weekdayOf(o)]);
export function isoWeek(o) {
  const d = new Date(utc(o));
  const dn = d.getUTCDay() || 7;
  d.setUTCDate(d.getUTCDate() + 4 - dn);
  const y0 = Date.UTC(d.getUTCFullYear(), 0, 1);
  return { week: Math.ceil(((d - y0) / 86400000 + 1) / 7), year: d.getUTCFullYear() };
}
export const pad2 = (x) => String(x).padStart(2, '0');

/* ----------------------------------------------------------- number input */
const BN_DIGITS = '০১২৩৪৫৬৭৮৯';
export const toAscii = (s) => String(s).replace(/[০-৯]/g, (d) => BN_DIGITS.indexOf(d));
export const toBn = (s) => String(s).replace(/[0-9]/g, (d) => BN_DIGITS[+d]);
export function parseList(s) {
  return toAscii(s || '').split(/[\s,;]+/).filter(Boolean).map(Number).filter((x) => isFinite(x));
}
