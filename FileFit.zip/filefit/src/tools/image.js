import { AppError, checkAbort, getExt, stripExt, clamp } from '../core/util.js';

export const FMT = {
  jpg: { mime: 'image/jpeg', ext: 'jpg', lossy: true },
  png: { mime: 'image/png', ext: 'png', lossy: false },
  webp: { mime: 'image/webp', ext: 'webp', lossy: true },
};

export function fmtOfFile(file) {
  const m = (file.type || '').toLowerCase();
  const e = getExt(file.name || '');
  if (m.includes('jpeg') || m.includes('jpg') || e === 'jpg' || e === 'jpeg') return 'jpg';
  if (m.includes('png') || e === 'png') return 'png';
  if (m.includes('webp') || e === 'webp') return 'webp';
  return null;
}

/** original -> keep format. PNG in target-size mode becomes JPG (PNG cannot be compressed by quality). */
export function resolveFmt(file, chosen, mode) {
  if (chosen && chosen !== 'original') return chosen;
  const f = fmtOfFile(file);
  if (f === 'png') return mode === 'target' ? 'jpg' : 'png';
  return f || 'jpg';
}

function canvasOf(w, h) {
  const c = document.createElement('canvas');
  c.width = w; c.height = h;
  return c;
}

async function decodeViaImg(file) {
  const url = URL.createObjectURL(file);
  try {
    const img = await new Promise((res, rej) => {
      const i = new Image();
      i.onload = () => res(i);
      i.onerror = () => rej(new AppError('bad-image'));
      i.src = url;
    });
    const c = canvasOf(img.naturalWidth, img.naturalHeight);
    c.getContext('2d').drawImage(img, 0, 0);
    return c;
  } finally { URL.revokeObjectURL(url); }
}

/** Decode an image (EXIF rotation applied). Very large images are scaled down to stay within maxPixels. */
export async function decode(file, maxPixels = 25e6) {
  let src;
  try { src = await createImageBitmap(file, { imageOrientation: 'from-image' }); }
  catch {
    try { src = await decodeViaImg(file); } catch { throw new AppError('bad-image'); }
  }
  let w = src.width, h = src.height;
  const origW = w, origH = h;
  let downscaled = false;
  if (w * h > maxPixels) {
    const s = Math.sqrt(maxPixels / (w * h));
    w = Math.max(1, Math.floor(w * s)); h = Math.max(1, Math.floor(h * s));
    const c = canvasOf(w, h);
    c.getContext('2d').drawImage(src, 0, 0, w, h);
    if (src.close) src.close();
    src = c; downscaled = true;
  }
  return { src, w, h, origW, origH, downscaled };
}

export async function imageInfo(file) {
  const d = await decode(file, 1e9);
  const head = new Uint8Array(await file.slice(0, 65536).arrayBuffer());
  let exif = false;
  for (let i = 0; i < head.length - 6; i++) {
    if (head[i] === 0x45 && head[i + 1] === 0x78 && head[i + 2] === 0x69 && head[i + 3] === 0x66 && head[i + 4] === 0 && head[i + 5] === 0) { exif = true; break; }
  }
  if (d.src.close) d.src.close();
  return { w: d.origW, h: d.origH, mp: (d.origW * d.origH) / 1e6, fmt: fmtOfFile(file), size: file.size, modified: file.lastModified, exif, name: file.name, type: file.type };
}

function paint(src, crop, rot, fh, fv, w, h, bg) {
  const c = canvasOf(w, h);
  const g = c.getContext('2d');
  if (bg) { g.fillStyle = bg; g.fillRect(0, 0, w, h); }
  g.imageSmoothingEnabled = true;
  g.imageSmoothingQuality = 'high';
  g.translate(w / 2, h / 2);
  g.scale(fh ? -1 : 1, fv ? -1 : 1);
  g.rotate((rot * Math.PI) / 180);
  const sw = rot === 90 || rot === 270;
  const dw = sw ? h : w, dh = sw ? w : h;
  g.drawImage(src, crop.x, crop.y, crop.w, crop.h, -dw / 2, -dh / 2, dw, dh);
  return c;
}

function toBlob(canvas, mime, q) {
  return new Promise((res) => canvas.toBlob((b) => res(b), mime, q));
}

async function encodeCanvas(canvas, fmt, q) {
  const f = FMT[fmt];
  const blob = await toBlob(canvas, f.mime, f.lossy ? q : undefined);
  if (!blob || blob.type !== f.mime) throw new AppError('format-unsupported', fmt);
  return blob;
}

/**
 * One function behind every image tool.
 * o: { fmt, mode:'quality'|'target', quality(0-1), maxSide, percent, w, h, fit, crop, rotate, flipH, flipV,
 *      targetBytes, allowScale, suffix }
 */
export async function processImage(file, o, { signal, maxPixels } = {}) {
  const img = await decode(file, maxPixels);
  try {
    checkAbort(signal);
    // The crop box is measured on the full-size image; decode() may have scaled the image down.
    const k = img.origW ? img.w / img.origW : 1;
    const crop = o.crop ? {
      x: clamp(Math.round(o.crop.x * k), 0, img.w - 1), y: clamp(Math.round(o.crop.y * k), 0, img.h - 1),
      w: 0, h: 0,
    } : { x: 0, y: 0, w: img.w, h: img.h };
    if (o.crop) {
      crop.w = clamp(Math.round(o.crop.w * k), 1, img.w - crop.x);
      crop.h = clamp(Math.round(o.crop.h * k), 1, img.h - crop.y);
    }
    const rot = (((o.rotate || 0) % 360) + 360) % 360;
    const swap = rot === 90 || rot === 270;
    const tw = swap ? crop.h : crop.w;
    const th = swap ? crop.w : crop.h;
    let w = tw, h = th;
    if (o.percent) { w = Math.round((tw * o.percent) / 100); h = Math.round((th * o.percent) / 100); }
    else if (o.w || o.h) {
      if (o.fit) {
        const s = Math.min((o.w || Infinity) / tw, (o.h || Infinity) / th);
        w = Math.round(tw * s); h = Math.round(th * s);
      } else { w = o.w || tw; h = o.h || th; }
    }
    if (o.maxSide) {
      const s = Math.min(1, o.maxSide / Math.max(w, h));
      w = Math.round(w * s); h = Math.round(h * s);
    }
    w = Math.max(1, w); h = Math.max(1, h);

    const fmt = resolveFmt(file, o.fmt, o.mode);
    const bg = fmt === 'jpg' ? '#ffffff' : null;
    const render = (cw, ch) => paint(img.src, crop, rot, o.flipH, o.flipV, cw, ch, bg);
    let res;
    if (o.targetBytes) res = await toTargetSize(render, w, h, fmt, o.targetBytes, { signal, allowScale: o.allowScale !== false });
    else {
      const blob = await encodeCanvas(render(w, h), fmt, o.quality == null ? 0.8 : o.quality);
      res = { blob, w, h, reached: true };
    }
    const name = stripExt(file.name) + (o.suffix || '_filefit') + '.' + FMT[fmt].ext;
    return { ...res, fmt, name, downscaled: img.downscaled };
  } finally {
    if (img.src.close) img.src.close();
  }
}

/** Find the highest quality (and, if needed, smaller dimensions) that fits under targetBytes. */
export async function toTargetSize(render, w0, h0, fmt, target, { signal, allowScale = true } = {}) {
  let scale = 1;
  let best = null;
  for (let step = 0; step < 14; step++) {
    checkAbort(signal);
    const w = Math.max(1, Math.round(w0 * scale)), h = Math.max(1, Math.round(h0 * scale));
    const canvas = render(w, h);
    if (!FMT[fmt].lossy) {
      const b = await encodeCanvas(canvas, fmt);
      if (!best || b.size < best.blob.size) best = { blob: b, w, h, reached: false };
      if (b.size <= target) return { blob: b, w, h, reached: true };
    } else {
      const lo0 = await encodeCanvas(canvas, fmt, 0.05);
      if (!best || lo0.size < best.blob.size) best = { blob: lo0, w, h, reached: false };
      if (lo0.size <= target) {
        let lo = 0.05, hi = 0.95, pick = lo0;
        const hiBlob = await encodeCanvas(canvas, fmt, hi);
        if (hiBlob.size <= target) pick = hiBlob;
        else {
          for (let i = 0; i < 7; i++) {
            checkAbort(signal);
            const mid = (lo + hi) / 2;
            const b = await encodeCanvas(canvas, fmt, mid);
            if (b.size <= target) { pick = b; lo = mid; } else hi = mid;
          }
        }
        return { blob: pick, w, h, reached: true };
      }
    }
    if (!allowScale) break;
    const cur = best.blob.size;
    scale *= clamp(Math.sqrt(target / cur) * 0.92, 0.5, 0.92);
    if (scale < 0.04) break;
  }
  return best;
}

/** Interactive crop box. Returns {el, setAspect(r|null), getRect()} where getRect is in natural pixels. */
export function createCropper(file, onReady) {
  const wrap = document.createElement('div');
  wrap.className = 'cropper';
  const img = new Image();
  const stage = document.createElement('div');
  stage.className = 'crop-stage';
  const box = document.createElement('div');
  box.className = 'crop-box';
  const handles = ['nw', 'ne', 'sw', 'se'].map((c) => {
    const d = document.createElement('div');
    d.className = 'crop-handle ' + c; d.dataset.c = c;
    box.append(d);
    return d;
  });
  stage.append(img, box);
  wrap.append(stage);
  let W = 0, H = 0, nat = { w: 0, h: 0 };
  let rect = { x: 0, y: 0, w: 0, h: 0 };
  let aspect = null;
  const MIN = 28;
  const url = URL.createObjectURL(file);
  const show = () => {
    box.style.left = rect.x + 'px'; box.style.top = rect.y + 'px';
    box.style.width = rect.w + 'px'; box.style.height = rect.h + 'px';
  };
  const fit = () => {
    W = img.clientWidth; H = img.clientHeight;
    if (!W || !H) return;
    const w = W * 0.8;
    rect = { x: (W - w) / 2, y: (H - w * 0.8) / 2, w, h: w * 0.8 };
    if (rect.h > H * 0.9) { rect.h = H * 0.9; rect.y = (H - rect.h) / 2; }
    show();
  };
  img.onload = async () => {
    // natural size after EXIF orientation: ask the browser via a bitmap
    try { const b = await createImageBitmap(file, { imageOrientation: 'from-image' }); nat = { w: b.width, h: b.height }; b.close(); }
    catch { nat = { w: img.naturalWidth, h: img.naturalHeight }; }
    fit();
    if (onReady) onReady();
  };
  img.src = url;
  img.alt = '';
  img.draggable = false;

  function drag(el, move) {
    el.addEventListener('pointerdown', (e) => {
      e.preventDefault(); e.stopPropagation();
      el.setPointerCapture(e.pointerId);
      const sx = e.clientX, sy = e.clientY, st = { ...rect };
      const mv = (ev) => move(ev.clientX - sx, ev.clientY - sy, st);
      const up = () => { el.removeEventListener('pointermove', mv); el.removeEventListener('pointerup', up); el.removeEventListener('pointercancel', up); };
      el.addEventListener('pointermove', mv); el.addEventListener('pointerup', up); el.addEventListener('pointercancel', up);
    });
  }
  drag(box, (dx, dy, st) => {
    rect.x = clamp(st.x + dx, 0, W - st.w); rect.y = clamp(st.y + dy, 0, H - st.h); show();
  });
  handles.forEach((hd) => drag(hd, (dx, dy, st) => {
    const c = hd.dataset.c, left = c.includes('w'), top = c.includes('n');
    const ox = left ? st.x + st.w : st.x, oy = top ? st.y + st.h : st.y;
    const px = clamp((left ? st.x : st.x + st.w) + dx, 0, W);
    const py = clamp((top ? st.y : st.y + st.h) + dy, 0, H);
    let w = Math.abs(px - ox), h = Math.abs(py - oy);
    if (aspect) {
      w = Math.max(w, h * aspect);
      w = Math.min(w, left ? ox : W - ox, (top ? oy : H - oy) * aspect);
      h = w / aspect;
    }
    w = Math.max(w, MIN); h = Math.max(h, aspect ? MIN / aspect : MIN);
    rect = { x: left ? ox - w : ox, y: top ? oy - h : oy, w, h };
    rect.x = clamp(rect.x, 0, W - rect.w); rect.y = clamp(rect.y, 0, H - rect.h);
    show();
  }));

  return {
    el: wrap,
    setAspect(a) {
      aspect = a;
      if (!a || !W) return;
      const cx = rect.x + rect.w / 2, cy = rect.y + rect.h / 2;
      let w = Math.min(rect.w, W), h = w / a;
      if (h > H) { h = H; w = h * a; }
      rect = { x: clamp(cx - w / 2, 0, W - w), y: clamp(cy - h / 2, 0, H - h), w, h };
      show();
    },
    natural: () => nat,
    getRect() {
      const sx = nat.w / W, sy = nat.h / H;
      return { x: rect.x * sx, y: rect.y * sy, w: rect.w * sx, h: rect.h * sy };
    },
    destroy() { URL.revokeObjectURL(url); },
  };
}
