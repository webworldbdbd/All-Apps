import QRCode from 'qrcode';
import jsQR from 'jsqr';
import { decode } from './image.js';

const esc = (s) => String(s || '').replace(/([\\;,:"])/g, '\\$1');

export const builders = {
  text: (f) => f.text || '',
  url: (f) => {
    const u = (f.url || '').trim();
    if (!u) return '';
    return /^[a-z][a-z0-9+.-]*:/i.test(u) ? u : 'https://' + u;
  },
  wifi: (f) => (f.ssid ? 'WIFI:T:' + (f.security === 'nopass' ? 'nopass' : f.security || 'WPA') + ';S:' + esc(f.ssid) + ';' + (f.security === 'nopass' ? '' : 'P:' + esc(f.password) + ';') + (f.hidden ? 'H:true;' : '') + ';' : ''),
  contact: (f) => {
    if (!f.name && !f.phone && !f.email) return '';
    const lines = ['BEGIN:VCARD', 'VERSION:3.0', 'FN:' + (f.name || '')];
    if (f.org) lines.push('ORG:' + f.org);
    if (f.phone) lines.push('TEL:' + f.phone);
    if (f.email) lines.push('EMAIL:' + f.email);
    if (f.website) lines.push('URL:' + f.website);
    if (f.address) lines.push('ADR:;;' + f.address + ';;;;');
    lines.push('END:VCARD');
    return lines.join('\n');
  },
  email: (f) => {
    if (!f.to) return '';
    const q = [];
    if (f.subject) q.push('subject=' + encodeURIComponent(f.subject));
    if (f.body) q.push('body=' + encodeURIComponent(f.body));
    return 'mailto:' + f.to + (q.length ? '?' + q.join('&') : '');
  },
  phone: (f) => (f.phone ? 'tel:' + f.phone.replace(/\s+/g, '') : ''),
  sms: (f) => (f.phone ? 'SMSTO:' + f.phone.replace(/\s+/g, '') + ':' + (f.message || '') : ''),
};

export async function qrCanvas(text, { size = 720, fg = '#000000', bg = '#ffffff', ec = 'M', margin = 2 } = {}) {
  const c = document.createElement('canvas');
  await QRCode.toCanvas(c, text, { width: size, margin, errorCorrectionLevel: ec, color: { dark: fg, light: bg } });
  return c;
}

export async function qrBlob(text, opts = {}) {
  const c = await qrCanvas(text, { size: 1024, ...opts });
  return new Promise((res) => c.toBlob(res, 'image/png'));
}

function parseWifi(s) {
  const body = s.slice(5);
  const f = {};
  let key = '', val = '', inVal = false, i = 0;
  const flush = () => { if (key) f[key] = val; key = ''; val = ''; inVal = false; };
  for (; i < body.length; i++) {
    const ch = body[i];
    if (ch === '\\' && i + 1 < body.length) { (inVal ? (val += body[++i]) : (key += body[++i])); continue; }
    if (!inVal && ch === ':') { inVal = true; continue; }
    if (ch === ';') { flush(); continue; }
    if (inVal) val += ch; else key += ch;
  }
  flush();
  return { ssid: f.S || '', password: f.P || '', security: f.T || 'nopass', hidden: f.H === 'true' };
}

const SHORTENERS = /(^|\.)(bit\.ly|tinyurl\.com|t\.co|goo\.gl|ow\.ly|is\.gd|buff\.ly|cutt\.ly|rebrand\.ly|shorturl\.at|tiny\.cc)$/i;

export function urlRisks(raw) {
  const risks = [];
  let u;
  try { u = new URL(raw); } catch { return ['invalid']; }
  if (u.protocol === 'http:') risks.push('http');
  if (/^\d{1,3}(\.\d{1,3}){3}$/.test(u.hostname)) risks.push('ip');
  if (u.hostname.includes('xn--')) risks.push('punycode');
  if (u.username || u.password) risks.push('userinfo');
  if (SHORTENERS.test(u.hostname)) risks.push('shortener');
  if (!['http:', 'https:'].includes(u.protocol)) risks.push('scheme');
  return risks;
}

export function parsePayload(text) {
  const s = (text || '').trim();
  if (/^WIFI:/i.test(s)) return { type: 'wifi', ...parseWifi(s), raw: s };
  if (/^BEGIN:VCARD/i.test(s)) {
    const get = (k) => { const m = new RegExp('^' + k + '[^:]*:(.*)$', 'im').exec(s); return m ? m[1].trim() : ''; };
    return { type: 'contact', name: get('FN'), phone: get('TEL'), email: get('EMAIL'), org: get('ORG'), website: get('URL'), raw: s };
  }
  if (/^mailto:/i.test(s)) { const u = s.slice(7).split('?'); return { type: 'email', to: u[0], raw: s }; }
  if (/^tel:/i.test(s)) return { type: 'phone', phone: s.slice(4), raw: s };
  if (/^smsto?:/i.test(s)) { const p = s.replace(/^smsto?:/i, '').split(':'); return { type: 'sms', phone: p[0], message: p.slice(1).join(':'), raw: s }; }
  if (/^https?:\/\//i.test(s)) return { type: 'url', url: s, risks: urlRisks(s), raw: s };
  if (/^[a-z][a-z0-9+.-]*:\/\//i.test(s)) return { type: 'url', url: s, risks: urlRisks(s), raw: s };
  return { type: 'text', raw: s };
}

export async function decodeFromFile(file) {
  const d = await decode(file, 12e6);
  const c = document.createElement('canvas');
  c.width = d.w; c.height = d.h;
  const g = c.getContext('2d', { willReadFrequently: true });
  g.drawImage(d.src, 0, 0, d.w, d.h);
  if (d.src.close) d.src.close();
  const data = g.getImageData(0, 0, d.w, d.h);
  const r = jsQR(data.data, d.w, d.h, { inversionAttempts: 'attemptBoth' });
  return r ? r.data : null;
}

/** Starts the camera and scans until stop() is called. */
export async function startScanner(video, onCode) {
  const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: 'environment' }, width: { ideal: 1280 } }, audio: false });
  video.srcObject = stream;
  video.setAttribute('playsinline', 'true');
  await video.play();
  const track = stream.getVideoTracks()[0];
  const canvas = document.createElement('canvas');
  const g = canvas.getContext('2d', { willReadFrequently: true });
  let stopped = false, last = '', lastAt = 0, timer = 0;
  const tick = () => {
    if (stopped) return;
    if (video.readyState >= 2 && video.videoWidth) {
      const scale = Math.min(1, 720 / video.videoWidth);
      canvas.width = Math.round(video.videoWidth * scale);
      canvas.height = Math.round(video.videoHeight * scale);
      g.drawImage(video, 0, 0, canvas.width, canvas.height);
      const img = g.getImageData(0, 0, canvas.width, canvas.height);
      const r = jsQR(img.data, canvas.width, canvas.height, { inversionAttempts: 'dontInvert' });
      if (r && r.data && (r.data !== last || Date.now() - lastAt > 3000)) {
        last = r.data; lastAt = Date.now();
        onCode(r.data);
      }
    }
    timer = setTimeout(tick, 110);
  };
  tick();
  const caps = (track.getCapabilities && track.getCapabilities()) || {};
  return {
    torchSupported: !!caps.torch,
    async torch(on) { try { await track.applyConstraints({ advanced: [{ torch: !!on }] }); return true; } catch { return false; } },
    stop() { stopped = true; clearTimeout(timer); stream.getTracks().forEach((t) => t.stop()); video.srcObject = null; },
    resetLast() { last = ''; },
  };
}
