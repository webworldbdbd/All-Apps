import { PDFDocument, degrees } from 'pdf-lib';
import * as pdfjs from 'pdfjs-dist/legacy/build/pdf.mjs';
import workerSrc from 'pdfjs-dist/legacy/build/pdf.worker.min.mjs?url';
import JSZip from 'jszip';
import { AppError, checkAbort, stripExt, nextFrame } from '../core/util.js';
import { decode } from './image.js';

pdfjs.GlobalWorkerOptions.workerSrc = workerSrc;

const PDF_MIME = 'application/pdf';
export const A4 = [595.28, 841.89];
export const LETTER = [612, 792];

export const readBytes = async (file) => new Uint8Array(await file.arrayBuffer());
const asPdf = (bytes) => new Blob([bytes], { type: PDF_MIME });

export async function loadDoc(bytes) {
  try {
    return await PDFDocument.load(bytes, { updateMetadata: false });
  } catch (e) {
    if (/encrypt/i.test(e && e.message)) throw new AppError('pdf-encrypted');
    throw new AppError('pdf-invalid');
  }
}

/** pdf.js document (a copy of the bytes is passed because pdf.js transfers the buffer to its worker). */
export async function openViewer(bytes) {
  try {
    const task = pdfjs.getDocument({ data: bytes.slice(), isEvalSupported: false });
    const doc = await task.promise;
    doc.dispose = () => task.destroy(); // release the worker and memory
    return doc;
  } catch (e) {
    if (e && e.name === 'PasswordException') throw new AppError('pdf-encrypted');
    throw new AppError('pdf-invalid');
  }
}

export async function renderPage(doc, pageNo, { width, scale, canvas } = {}) {
  const page = await doc.getPage(pageNo);
  const base = page.getViewport({ scale: 1 });
  const s = scale || (width ? width / base.width : 1);
  const vp = page.getViewport({ scale: s });
  const c = canvas || document.createElement('canvas');
  c.width = Math.floor(vp.width); c.height = Math.floor(vp.height);
  const ctx = c.getContext('2d');
  ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, c.width, c.height);
  await page.render({ canvasContext: ctx, canvas: c, viewport: vp }).promise;
  page.cleanup();
  return c;
}

function canvasToBlob(c, type = 'image/jpeg', q = 0.8) {
  return new Promise((res) => c.toBlob(res, type, q));
}

/** "1-3, 5, 8-" -> [0,1,2,4,7,...] (0-based). Throws AppError('range-invalid') on bad input. */
export function parseRanges(text, total) {
  const out = [];
  const parts = String(text || '').split(/[,\s]+/).filter(Boolean);
  if (!parts.length) throw new AppError('range-invalid');
  for (const p of parts) {
    const m = /^(\d+)?(?:-(\d+)?)?$/.exec(p);
    if (!m || (!m[1] && !m[2])) throw new AppError('range-invalid');
    const hasDash = p.includes('-');
    const a = m[1] ? parseInt(m[1], 10) : 1;
    const b = hasDash ? (m[2] ? parseInt(m[2], 10) : total) : a;
    if (a < 1 || b < 1 || a > total || b > total) throw new AppError('range-out', total);
    if (a <= b) for (let i = a; i <= b; i++) out.push(i - 1);
    else for (let i = a; i >= b; i--) out.push(i - 1);
  }
  return out;
}

export function splitGroups(text, total) {
  const parts = String(text || '').split(',').map((s) => s.trim()).filter(Boolean);
  if (!parts.length) throw new AppError('range-invalid');
  return parts.map((p) => parseRanges(p, total));
}

export async function imagesToPdf(files, opt, { signal, progress } = {}) {
  const doc = await PDFDocument.create();
  const q = { high: 0.92, medium: 0.8, low: 0.6 }[opt.quality || 'medium'];
  for (let i = 0; i < files.length; i++) {
    checkAbort(signal);
    progress && progress(i / files.length, files[i].name);
    await nextFrame();
    const d = await decode(files[i], opt.maxPixels || 25e6);
    let { src, w, h } = d;
    const longSide = Math.max(w, h);
    const cap = opt.size === 'fit' ? 3000 : 2600;
    let cw = w, ch = h;
    if (longSide > cap) { const s = cap / longSide; cw = Math.round(w * s); ch = Math.round(h * s); }
    const c = document.createElement('canvas');
    c.width = cw; c.height = ch;
    const g = c.getContext('2d');
    g.fillStyle = '#fff'; g.fillRect(0, 0, cw, ch);
    g.imageSmoothingQuality = 'high';
    g.drawImage(src, 0, 0, cw, ch);
    if (src.close) src.close();
    const blob = await canvasToBlob(c, 'image/jpeg', q);
    const img = await doc.embedJpg(new Uint8Array(await blob.arrayBuffer()));
    const margin = opt.margin || 0;
    if (opt.size === 'fit') {
      const page = doc.addPage([cw * 0.75 + margin * 2, ch * 0.75 + margin * 2]);
      page.drawImage(img, { x: margin, y: margin, width: cw * 0.75, height: ch * 0.75 });
    } else {
      let [pw, ph] = opt.size === 'letter' ? LETTER : A4;
      if (cw > ch) [pw, ph] = [ph, pw];
      const page = doc.addPage([pw, ph]);
      const s = Math.min((pw - margin * 2) / cw, (ph - margin * 2) / ch);
      const dw = cw * s, dh = ch * s;
      page.drawImage(img, { x: (pw - dw) / 2, y: (ph - dh) / 2, width: dw, height: dh });
    }
  }
  doc.setProducer('FileFit'); doc.setCreator('FileFit');
  progress && progress(1);
  return asPdf(await doc.save());
}

export async function mergePdfs(files, { signal, progress } = {}) {
  const out = await PDFDocument.create();
  for (let i = 0; i < files.length; i++) {
    checkAbort(signal);
    progress && progress(i / files.length, files[i].name);
    await nextFrame();
    const src = await loadDoc(await readBytes(files[i]));
    const pages = await out.copyPages(src, src.getPageIndices());
    pages.forEach((p) => out.addPage(p));
  }
  out.setProducer('FileFit');
  progress && progress(1);
  return asPdf(await out.save());
}

async function subset(srcDoc, indices) {
  const out = await PDFDocument.create();
  const pages = await out.copyPages(srcDoc, indices);
  pages.forEach((p) => out.addPage(p));
  out.setProducer('FileFit');
  return asPdf(await out.save());
}

export async function extractPages(file, rangeText) {
  const src = await loadDoc(await readBytes(file));
  const idx = parseRanges(rangeText, src.getPageCount());
  return subset(src, idx);
}

/** mode 'each' -> one file per page; mode 'ranges' -> one file per comma-separated group. */
export async function splitPdf(file, { mode, ranges }, { signal, progress } = {}) {
  const src = await loadDoc(await readBytes(file));
  const total = src.getPageCount();
  const groups = mode === 'each' ? Array.from({ length: total }, (_, i) => [i]) : splitGroups(ranges, total);
  const base = stripExt(file.name);
  const out = [];
  for (let i = 0; i < groups.length; i++) {
    checkAbort(signal);
    progress && progress(i / groups.length);
    await nextFrame();
    const g = groups[i];
    const label = mode === 'each' ? 'page' + (g[0] + 1) : 'part' + (i + 1);
    out.push({ name: base + '_' + label + '.pdf', blob: await subset(src, g) });
  }
  progress && progress(1);
  return out;
}

export async function zipFiles(items) {
  const zip = new JSZip();
  items.forEach((x) => zip.file(x.name, x.blob));
  return zip.generateAsync({ type: 'blob', compression: 'STORE' });
}

/** pages: [{index, rotate}] in the new order (deleted pages are simply omitted). */
export async function organizePdf(file, pages) {
  const src = await loadDoc(await readBytes(file));
  const out = await PDFDocument.create();
  const copies = await out.copyPages(src, pages.map((p) => p.index));
  copies.forEach((cp, i) => {
    const extra = pages[i].rotate || 0;
    if (extra) cp.setRotation(degrees((cp.getRotation().angle + extra) % 360));
    out.addPage(cp);
  });
  out.setProducer('FileFit');
  return asPdf(await out.save());
}

/** level: 'light' (lossless re-save) | 'medium' | 'strong' (pages are re-rendered as JPEG, text is no longer selectable). */
export async function compressPdf(file, level, { signal, progress } = {}) {
  const bytes = await readBytes(file);
  let blob;
  if (level === 'light') {
    const d = await loadDoc(bytes);
    blob = asPdf(await d.save({ useObjectStreams: true }));
  } else {
    const dpi = level === 'medium' ? 150 : 100;
    const q = level === 'medium' ? 0.72 : 0.5;
    const viewer = await openViewer(bytes);
    const out = await PDFDocument.create();
    for (let n = 1; n <= viewer.numPages; n++) {
      checkAbort(signal);
      progress && progress((n - 1) / viewer.numPages, n + '/' + viewer.numPages);
      await nextFrame();
      const page = await viewer.getPage(n);
      const base = page.getViewport({ scale: 1 });
      let scale = dpi / 72;
      const maxSide = 3200;
      if (Math.max(base.width, base.height) * scale > maxSide) scale = maxSide / Math.max(base.width, base.height);
      const c = await renderPage(viewer, n, { scale });
      const jb = await canvasToBlob(c, 'image/jpeg', q);
      const img = await out.embedJpg(new Uint8Array(await jb.arrayBuffer()));
      const pg = out.addPage([base.width, base.height]);
      pg.drawImage(img, { x: 0, y: 0, width: base.width, height: base.height });
      c.width = c.height = 0;
    }
    await viewer.dispose();
    out.setProducer('FileFit');
    blob = asPdf(await out.save());
  }
  progress && progress(1);
  return { blob, smaller: blob.size < file.size };
}

export async function pdfInfo(file) {
  const bytes = await readBytes(file);
  const d = await loadDoc(bytes);
  const first = d.getPage(0);
  const { width, height } = first.getSize();
  const get = (fn) => { try { return fn() || ''; } catch { return ''; } };
  const date = (fn) => { try { const v = fn(); return v ? v.getTime() : 0; } catch { return 0; } };
  return {
    pages: d.getPageCount(), size: file.size, width: Math.round(width), height: Math.round(height),
    title: get(() => d.getTitle()), author: get(() => d.getAuthor()), producer: get(() => d.getProducer()),
    created: date(() => d.getCreationDate()), modified: date(() => d.getModificationDate()),
  };
}
