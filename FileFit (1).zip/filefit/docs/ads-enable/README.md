# Enabling AdMob later

1. `npm install @capacitor-community/admob@^8`
2. Copy `docs/ads-enable/ads.js` over `src/core/ads.js`
3. In `app.config.json` set `"ads": { "enabled": true, "testMode": false, ... }` with your REAL AdMob app id, banner id and interstitial id
4. Run `npm run android:init` again (it adds the AdMob app id and AD_ID permission to the Android project)
5. Update the privacy policy and Play Console "Data safety" / "Ads" answers to say the app shows ads (see store/data-safety.md)
