const {onCall,HttpsError}=require('firebase-functions/v2/https');
const {onSchedule}=require('firebase-functions/v2/scheduler');
const {defineSecret}=require('firebase-functions/params');
const v1=require('firebase-functions/v1');
const crypto=require('crypto');
const admin=require('firebase-admin');admin.initializeApp();
const db=admin.database(),R={region:'asia-southeast1'},OFF=6*36e5,DAY=864e5,DAILY_CAP=600; // Asia/Dhaka = UTC+6
const need=r=>{if(!r.auth)throw new HttpsError('unauthenticated','Login required');return r.auth.uid};
// Username: 3-20 chars of a-z0-9 (length limits are an assumption; change here if needed)
exports.claimUsername=onCall(R,async r=>{
 const uid=need(r),n=String((r.data&&r.data.username)||'');
 if(!/^[a-z0-9]{3,20}$/.test(n))throw new HttpsError('invalid-argument','Invalid username');
 const ud=db.ref(`users/${uid}/username`),old=(await ud.get()).val();if(old===n)return{ok:true};
 const t=await db.ref(`usernames/${n}`).transaction(v=>v===null||v===uid?uid:undefined);
 if(!t.committed)throw new HttpsError('already-exists','Username taken');
 await ud.set(n);
 if(old)await db.ref(`usernames/${old}`).transaction(v=>v===uid?null:undefined);
 return{ok:true}});
// Points: 1 per study minute, session must have just ended, duplicates ignored, daily cap enforced here
exports.submitSession=onCall(R,async r=>{
 const uid=need(r),end=Math.floor(Number(r.data&&r.data.end)),dur=Number(r.data&&r.data.dur),now=Date.now();
 if(!Number.isFinite(end)||!Number.isFinite(dur)||dur<6e4||dur>12*36e5||end>now+6e4||end<now-10*6e4)throw new HttpsError('invalid-argument','Rejected');
 const log=await db.ref(`pointsLog/${uid}/s${end}`).transaction(v=>v===null?now:undefined);
 if(!log.committed)return{ok:true,duplicate:true};
 const un=(await db.ref(`users/${uid}/username`).get()).val();if(!un)return{ok:true,ranked:false};
 const pts=Math.floor(dur/6e4),dk=Math.floor((end-1+OFF)/DAY);
 let add=0;
 await db.ref(`leaderboard/daily/${dk}/${uid}`).transaction(v=>{const p=v?v.p:0;add=Math.min(pts,DAILY_CAP-p);return add>0?{u:un,p:p+add}:v||undefined});
 if(add>0){const dt=new Date(end-1+OFF),wk=Math.floor((dk+5)/7),mk=`${dt.getUTCFullYear()}${String(dt.getUTCMonth()+1).padStart(2,'0')}`,bump=v=>({u:un,p:(v?v.p:0)+add}); // week starts Saturday (Asia/Dhaka)
  await Promise.all([db.ref(`leaderboard/weekly/${wk}/${uid}`).transaction(bump),db.ref(`leaderboard/monthly/${mk}/${uid}`).transaction(bump)])}
 return{ok:true}});

const PEPPER=defineSecret('ID_PEPPER');
const TPL={
 welcome:{en:['Welcome to StudyMate','Set up your profile and start studying.'],bn:['StudyMate-এ স্বাগতম','প্রোফাইল সাজিয়ে পড়া শুরু করুন।']},
 student:{en:['Student badge active','You can now post in the community.'],bn:['স্টুডেন্ট ব্যাজ চালু','এখন কমিউনিটিতে পোস্ট করতে পারবেন।']},
 profile:{en:['Complete your profile','Your profile is still incomplete.'],bn:['প্রোফাইল সম্পূর্ণ করুন','আপনার প্রোফাইল এখনো অসম্পূর্ণ।']},
 device:{en:['New device signed in','Your account was used on a new device.'],bn:['নতুন ডিভাইসে লগইন','আপনার অ্যাকাউন্ট একটি নতুন ডিভাইসে ব্যবহার হয়েছে।']},
 hidden:{en:['Post hidden','Your post was hidden after several reports.'],bn:['পোস্ট লুকানো হয়েছে','কয়েকটি রিপোর্টের পর আপনার পোস্ট লুকানো হয়েছে।']}};
async function notify(uid,k){
 const lang=(await db.ref(`users/${uid}/profile/lang`).get()).val()==='en'?'en':'bn',[title,body]=TPL[k][lang];
 await db.ref(`notifications/${uid}`).push({k,at:Date.now()});
 const t=(await db.ref(`users/${uid}/fcm`).get()).val();
 if(t)try{await admin.messaging().sendEach(Object.keys(t).map(token=>({token,notification:{title,body}})))}catch(e){}}
exports.onSignup=v1.region('asia-southeast1').auth.user().onCreate(async u=>{
 await notify(u.uid,'welcome');await db.ref(`jobs/profile/${u.uid}`).set(Date.now()+864e5)});
// one reminder, 24h after signup, only if the profile is still incomplete
exports.profileReminders=onSchedule({...R,schedule:'every 60 minutes'},async()=>{
 const s=await db.ref('jobs/profile').orderByValue().endAt(Date.now()).limitToFirst(200).get();
 for(const uid of Object.keys(s.val()||{})){
  const p=(await db.ref(`users/${uid}/profile`).get()).val()||{};
  if(![p.displayName,p.level,p.institution,p.cls,p.goal,p.photo].every(Boolean))await notify(uid,'profile');
  await db.ref(`jobs/profile/${uid}`).remove()}});
// Automatic "student" badge: format + age check only. NOT an official identity check.
// Only a keyed one-way hash of the number is kept (one number = one account). Number/DOB/documents are never stored.
exports.submitVerification=onCall({...R,secrets:[PEPPER]},async r=>{
 const uid=need(r),d=r.data||{};
 if((await db.ref(`users/${uid}/student`).get()).val())return{ok:true};
 const type=d.type,num=String(d.number||'').replace(/\D/g,''),dob=new Date(String(d.dob||'')+'T00:00:00Z');
 if(isNaN(dob)||dob>new Date()||dob.getUTCFullYear()<1950)throw new HttpsError('invalid-argument','dob');
 const minor=(Date.now()-dob)/(365.25*DAY)<18,lens=type==='birth'?[17]:type==='nid'?[10,13,17]:[];
 if(!lens.includes(num.length)||(minor&&type!=='birth'))throw new HttpsError('invalid-argument','format');
 if(num.length===17&&Number(num.slice(0,4))!==dob.getUTCFullYear())throw new HttpsError('invalid-argument','year');
 const h=crypto.createHmac('sha256',PEPPER.value()).update(`${type}:${num}`).digest('hex');
 const t=await db.ref(`idHashes/${h}`).transaction(v=>v===null||v===uid?uid:undefined);
 if(!t.committed)throw new HttpsError('already-exists','duplicate');
 await db.ref(`users/${uid}`).update({student:true,ageGroup:minor?'minor':'adult'});
 await notify(uid,'student');return{ok:true}});
// Community (text only). Posting/commenting/reporting need the student badge + a username.
const rate=async(uid,k,gap)=>{const t=await db.ref(`rate/${uid}/${k}`).transaction(v=>v&&Date.now()-v<gap?undefined:Date.now());if(!t.committed)throw new HttpsError('resource-exhausted','slow')};
const clean=(x,max)=>{x=String(x||'').replace(/[\u0000-\u001f\u007f]/g,' ').trim();if(!x||x.length>max)throw new HttpsError('invalid-argument','text');return x};
const pid=x=>{x=String(x||'');if(!/^[-\w]{10,30}$/.test(x))throw new HttpsError('invalid-argument','id');return x};
async function member(uid){const u=(await db.ref(`users/${uid}`).get()).val()||{};if(!u.student)throw new HttpsError('permission-denied','badge');if(!u.username)throw new HttpsError('failed-precondition','username');return u}
exports.createPost=onCall(R,async r=>{const uid=need(r),u=await member(uid),t=clean(r.data&&r.data.text,1000);await rate(uid,'post',3e4);
 const ref=db.ref('posts').push();await ref.set({uid,u:u.username,t,at:Date.now(),c:0});return{id:ref.key}});
exports.addComment=onCall(R,async r=>{const uid=need(r),u=await member(uid),id=pid(r.data&&r.data.postId),p=(await db.ref(`posts/${id}`).get()).val();
 if(!p||p.hidden)throw new HttpsError('not-found','post');const t=clean(r.data.text,500);await rate(uid,'comment',1e4);
 await db.ref(`comments/${id}`).push({uid,u:u.username,t,at:Date.now()});await db.ref(`posts/${id}/c`).transaction(v=>(v||0)+1);return{ok:true}});
// Auto-moderation: 3 reports from 3 different students hide a post (no human reviewer)
exports.reportPost=onCall(R,async r=>{const uid=need(r);await member(uid);const id=pid(r.data&&r.data.postId);
 const t=await db.ref(`reports/${id}/${uid}`).transaction(v=>v===null?Date.now():undefined);if(!t.committed)return{ok:true};
 const n=Object.keys((await db.ref(`reports/${id}`).get()).val()||{}).length;
 if(n>=3){const p=(await db.ref(`posts/${id}`).get()).val();if(p&&!p.hidden){await db.ref(`posts/${id}/hidden`).set(true);await notify(p.uid,'hidden')}}return{ok:true}});
exports.deletePost=onCall(R,async r=>{const uid=need(r),id=pid(r.data&&r.data.postId),p=(await db.ref(`posts/${id}`).get()).val();
 if(!p||p.uid!==uid)throw new HttpsError('permission-denied','owner');await db.ref(`posts/${id}`).remove();await db.ref(`comments/${id}`).remove();return{ok:true}});

// Max 2 devices per account (free and premium). Enforced here; the app asks the user to remove one.
const did=x=>{x=String(x||'');if(!/^[-\w]{16,64}$/.test(x))throw new HttpsError('invalid-argument','device');return x};
exports.registerDevice=onCall(R,async r=>{
 const uid=need(r),id=did(r.data&&r.data.deviceId),name=String((r.data&&r.data.name)||'').replace(/[^\w ·.-]/g,'').slice(0,40);
 let blocked=null,existed=false;
 const t=await db.ref(`users/${uid}/devices`).transaction(v=>{v=v||{};blocked=null;existed=!!v[id];
  if(existed){v[id].last=Date.now();return v}
  if(Object.keys(v).length>=2){blocked=Object.entries(v).map(([k,x])=>({id:k,name:x.name,last:x.last}));return}
  v[id]={name,at:Date.now(),last:Date.now()};return v});
 if(!t.committed&&blocked)throw new HttpsError('resource-exhausted','limit',{devices:blocked});
 if(t.committed&&!existed&&Object.keys(t.snapshot.val()||{}).length===2)await notify(uid,'device');
 return{ok:true}});
exports.removeDevice=onCall(R,async r=>{const uid=need(r);await db.ref(`users/${uid}/devices/${did(r.data&&r.data.deviceId)}`).remove();return{ok:true}});
