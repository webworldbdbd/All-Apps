# StudyMate (Capacitor + vanilla JS + Firebase)
## Build (আপনার কম্পিউটারে)
1. `npm install`
2. `npx cap add android`
3. Firebase Console > Authentication > Sign-in method: **Email/Password** ও **Google** চালু করুন।
4. Console > Project settings > Android app (`com.webworldbd.studymate`) যোগ করুন, **SHA-1** দিন (`./gradlew signingReport`), `google-services.json` নামিয়ে `android/app/` এ রাখুন (GitHub-এ commit করবেন না)।
5. Console > Realtime Database > Rules: `firebase/database.rules.json` এর বিষয়বস্তু বসিয়ে **Publish** করুন।
6. `npm run sync` → `npm run open` → Android Studio থেকে Signed AAB।
## Firebase যা যুক্ত
Email/Password (রেজিস্টার, লগইন, রিসেট, ভেরিফিকেশন মেইল), Google Sign-in, Logout, ব্যক্তিগত প্রোফাইল ও স্টাডি সেশন সিঙ্ক (`users/{uid}`; শুধু মালিক পড়তে/লিখতে পারে)।
## এখনো বাকি (Cloud Functions/Blaze প্ল্যান লাগবে)
ইউজারনেম রিজার্ভেশন, ২ ডিভাইস সীমা, লিডারবোর্ড পয়েন্ট যাচাই, ভেরিফায়েড/Premium, কমিউনিটি, নোটিফিকেশন, Admin Panel।
## স্টাডি টুলস (লোকাল, অফলাইন)
CGPA, Attendance (লক্ষ্য অনুযায়ী বাকি ক্লাস), Exam Manager (কাউন্টডাউন), Study Planner (সাপ্তাহিক), Notes (সার্চ, এডিট)। রিমাইন্ডার ও Export এখনো নেই।
## প্রোফাইল ও অ্যাকাউন্ট
প্রোফাইল এডিট + শতকরা, Cloudinary ছবি (আপলোড; **ছবি মুছতে সার্ভার লাগবে**, পুরোনো ছবি Cloudinary-তে থেকে যায়), অ্যাকাউন্ট ডিলিট, Help/FAQ, Privacy ও Terms (খসড়া, আইনজীবী/মালিক যাচাই করবেন)।
Cloudinary: Cloud name `qdfqfwlf` Dashboard থেকে মিলিয়ে নিন; Upload preset `StudyMate` এ ফোল্ডার, ফাইল টাইপ ও সাইজ সীমা দিন।
## Cloud Functions (Blaze প্ল্যান লাগবে)
`functions/` এ `claimUsername` (ইউনিক ইউজারনেম, সার্ভারে রিজার্ভ) ও `submitSession` (প্রতি মিনিটে ১ পয়েন্ট, ডুপ্লিকেট বাদ, দৈনিক সীমা ৬০০, সেশন সদ্য শেষ হতে হবে)।
ডেপ্লয়: `npm i -g firebase-tools` → `firebase login` → `cd functions && npm i && cd ..` → `firebase deploy --only functions,database`
ফাংশন ডেপ্লয় না করলে ইউজারনেম ও লিডারবোর্ড কাজ করবে না (বাকি সব চলবে)।
## Export ও রিমাইন্ডার
Settings থেকে JSON এক্সপোর্ট (Share শিট)। Exam যোগ করলে ১ দিন ও ১ ঘণ্টা আগে লোকাল নোটিফিকেশন (শুধু Android অ্যাপে)।
## দ্রুত শুরু
`google-services.json` প্রজেক্টের রুটে দেওয়া আছে। `npm install` এর পর `npm run setup-android` চালালে Android ফোল্ডার তৈরি হয়ে ফাইলটা সঠিক জায়গায় বসে যাবে। এটা GitHub-এ দেবেন না (`.gitignore` এ আছে)।
## অটো সিস্টেম (অ্যাডমিন প্যানেল ছাড়া) — Blaze লাগবে
- **সিক্রেট সেট (একবার):** `firebase functions:secrets:set ID_PEPPER` → লম্বা এলোমেলো লেখা দিন। এটা নিরাপদে রাখুন; হারালে "১ নম্বরে ১ অ্যাকাউন্ট" নিয়ম রিসেট হয়ে যায়।
- **ডেপ্লয়:** `firebase deploy --only functions,database`
- **স্টুডেন্ট ব্যাজ:** ফরম্যাট ও বয়স মেলানো, অটো। নম্বর/নথি/জন্মতারিখ রাখা হয় না, শুধু কী-যুক্ত হ্যাশ। এটা সরকারি পরিচয় যাচাই নয়। পেইড সার্ভিস পরে `submitVerification`-এ যুক্ত হবে।
- **অটো নোটিফিকেশন:** ওয়েলকাম, ব্যাজ চালু, ২৪ ঘণ্টা পরে অসম্পূর্ণ প্রোফাইলের রিমাইন্ডার (একবার), পোস্ট লুকানো। অ্যাপের ভেতরে ইনবক্স ও পুশ।
- **সবাইকে নোটিফিকেশন:** Firebase Console → Messaging → নতুন ক্যাম্পেইন (কোড লাগে না)।
- **What's New:** Console → Realtime Database → `announcements` এর নিচে নতুন চাইল্ড: `{at: <এখনকার মিলিসেকেন্ড>, en: "...", bn: "..."}`।
- **কমিউনিটি:** শুধু টেক্সট। ৩ জন আলাদা স্টুডেন্ট রিপোর্ট করলে পোস্ট অটো লুকায়। পোস্টে ৩০ সেকেন্ড ও মন্তব্যে ১০ সেকেন্ডের সীমা।
## লিডারবোর্ড, ব্লক, ডিভাইস
- দৈনিক/সাপ্তাহিক (শনিবার শুরু)/মাসিক টপ ১০। সাপ্তাহিক-মাসিক পয়েন্ট দৈনিক সীমা মেনেই যোগ হয়।
- ব্লক: পোস্ট/মন্তব্যে ব্লক করলে ওই ব্যবহারকারীর লেখা আর দেখা যায় না (ডিভাইসে সেভ থাকে)।
- ২ ডিভাইস: সার্ভার ফাংশনে গোনা হয়। তৃতীয় ডিভাইসে একটি সরাতে হয়। সেটিংস > ডিভাইস থেকে সরানো যায়। সীমাবদ্ধতা: অ্যাপ নিয়ম মানলেই কাজ করে; পরিবর্তিত অ্যাপ এড়াতে পারে।
## Blaze ছাড়া (এখনকার অবস্থা)
`src/app.js` এ `const SERVER=false` থাকলে ইউজারনেম, লিডারবোর্ড, কমিউনিটি, স্টুডেন্ট ব্যাজ, ২ ডিভাইস সীমা ও সার্ভার নোটিফিকেশন বন্ধ থাকে (বাটন "শীঘ্রই আসছে" দেখায়)। বাকি সব চলে।
শুধু Rules দেওয়া (Spark-এও ফ্রি): `firebase deploy --only database` অথবা Console > Rules এ `firebase/database.rules.json` বসিয়ে Publish।
পরে Blaze নিলে: `functions/` ডেপ্লয় করে `SERVER=true` করুন, তারপর `npm run sync`।
## Cloudflare Worker (Blaze ছাড়া সার্ভার)
`worker/` ফোল্ডারে সব সার্ভার কোড (ইউজারনেম, লিডারবোর্ড, ব্যাজ, কমিউনিটি, ডিভাইস, নোটিফিকেশন, ঘণ্টাভিত্তিক রিমাইন্ডার)।
১) `cd worker && npm install && npx wrangler login`
২) Firebase Console > Project settings > Service accounts > Generate new private key (ফাইল গোপন রাখুন, GitHub/চ্যাটে দেবেন না)
৩) `npx wrangler secret put SA_JSON < key.json` (তারপর key.json নিরাপদ জায়গায় রাখুন বা মুছুন)
৪) `npx wrangler secret put ID_PEPPER` (লম্বা এলোমেলো লেখা, হারাবেন না)
৫) `npx wrangler deploy` → URL পাবেন
৬) প্রজেক্টের `src/api-config.js` এ URL বসান (শেষে / ছাড়া)
৭) `npm run sync`। API_URL থাকলে অ্যাপে সার্ভার ফিচার নিজে চালু হয়।
`functions/` ফোল্ডার শুধু Firebase Blaze বিকল্পের জন্য; Worker ব্যবহার করলে লাগবে না।
## GitHub Actions দিয়ে APK (কম্পিউটারে Android Studio ছাড়া)
১) **প্রাইভেট** রিপোজিটরি বানিয়ে এই প্রজেক্টের সব ফাইল (`.github` ফোল্ডারসহ) তুলুন।
২) Settings > Secrets and variables > Actions > New secret: নাম `GOOGLE_SERVICES_JSON`, মান = `google-services.json` ফাইলের পুরো লেখা।
৩) Actions ট্যাব > Build Android APK > Run workflow। শেষে Artifacts থেকে `studymate-debug-apk` নামান (ZIP খুললে app-debug.apk)।
৪) প্রথম রানের "Ensure debug keystore and print SHA-1" ধাপের লগ থেকে SHA1 কপি করে Firebase > Project settings > Add fingerprint এ দিন, নতুন google-services.json নামিয়ে সিক্রেট বদলে আবার রান করুন (Google লগইনের জন্য)।
এটা টেস্ট APK। Play Store এর জন্য আলাদা সাইন করা AAB লাগবে।
