// StudyMate API on Cloudflare Workers. Verifies Firebase ID tokens, writes to Realtime Database with a service account.
const OFF=6*36e5,DAY=864e5,CAP=600; // Asia/Dhaka = UTC+6
const enc=new TextEncoder(),dec=new TextDecoder();
const b64u=s=>Uint8Array.from(atob(s.replace(/-/g,'+').replace(/_/g,'/')),c=>c.charCodeAt(0));
const b64e=b=>btoa(String.fromCharCode(...new Uint8Array(b))).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
class E extends Error{constructor(code,details){super(code);this.code=code;this.details=details}}
let jwks=null,jwksAt=0,at=null,atExp=0;
async function verify(env,tok){
 const [h,p,s]=String(tok||'').split('.');if(!s)throw new E('unauthenticated');
 let hd,pl;try{hd=JSON.parse(dec.decode(b64u(h)));pl=JSON.parse(dec.decode(b64u(p)))}catch(e){throw new E('unauthenticated')}
 if(!jwks||Date.now()-jwksAt>36e5){jwks=(await(await fetch('https://www.googleapis.com/service_accounts/v1/jwk/securetoken@system.gserviceaccount.com')).json()).keys;jwksAt=Date.now()}
 const k=jwks.find(x=>x.kid===hd.kid);if(!k||hd.alg!=='RS256')throw new E('unauthenticated');
 const key=await crypto.subtle.importKey('jwk',k,{name:'RSASSA-PKCS1-v1_5',hash:'SHA-256'},false,['verify']);
 if(!await crypto.subtle.verify('RSASSA-PKCS1-v1_5',key,b64u(s),enc.encode(h+'.'+p)))throw new E('unauthenticated');
 if(pl.aud!==env.PROJECT_ID||pl.iss!==`https://securetoken.google.com/${env.PROJECT_ID}`||pl.exp<Date.now()/1e3||!pl.sub)throw new E('unauthenticated');
 return pl.sub}
async function token(env){
 if(at&&Date.now()<atExp)return at;
 const sa=JSON.parse(env.SA_JSON),now=Math.floor(Date.now()/1e3);
 const h=b64e(enc.encode(JSON.stringify({alg:'RS256',typ:'JWT'}))),p=b64e(enc.encode(JSON.stringify({iss:sa.client_email,scope:'https://www.googleapis.com/auth/firebase.database https://www.googleapis.com/auth/userinfo.email https://www.googleapis.com/auth/firebase.messaging',aud:'https://oauth2.googleapis.com/token',iat:now,exp:now+3600})));
 const key=await crypto.subtle.importKey('pkcs8',b64u(sa.private_key.replace(/-----[^-]+-----|\s/g,'')),{name:'RSASSA-PKCS1-v1_5',hash:'SHA-256'},false,['sign']);
 const sig=b64e(await crypto.subtle.sign('RSASSA-PKCS1-v1_5',key,enc.encode(h+'.'+p)));
 const r=await(await fetch('https://oauth2.googleapis.com/token',{method:'POST',headers:{'content-type':'application/x-www-form-urlencoded'},body:`grant_type=${encodeURIComponent('urn:ietf:params:oauth:grant-type:jwt-bearer')}&assertion=${h}.${p}.${sig}`})).json();
 if(!r.access_token)throw new E('internal');at=r.access_token;atExp=Date.now()+(r.expires_in-120)*1e3;return at}
const D=env=>{
 const f=async(m,p,body,extra={},q='')=>fetch(`${env.DB_URL}/${p}.json${q}`,{method:m,headers:{authorization:'Bearer '+await token(env),'content-type':'application/json',...extra},body:body===undefined?undefined:JSON.stringify(body)});
 return{
  get:async(p,q)=>await(await f('GET',p,undefined,{},q)).json(),
  put:(p,v)=>f('PUT',p,v),del:p=>f('DELETE',p),
  push:async(p,v)=>(await(await f('POST',p,v)).json()).name,
  // transaction via ETag; fn returns the new value, or undefined to abort
  async tx(p,fn){for(let i=0;i<6;i++){const r=await f('GET',p,undefined,{'X-Firebase-ETag':'true'}),et=r.headers.get('etag'),old=await r.json(),nv=fn(old);
   if(nv===undefined)return{committed:false,val:old};
   const w=await f('PUT',p,nv,{'if-match':et});if(w.ok)return{committed:true,val:nv};if(w.status!==412)throw new E('internal')}
   throw new E('aborted')}}};
const TPL={
 welcome:{en:['Welcome to StudyMate','Set up your profile and start studying.'],bn:['StudyMate-এ স্বাগতম','প্রোফাইল সাজিয়ে পড়া শুরু করুন।']},
 student:{en:['Student badge active','You can now post in the community.'],bn:['স্টুডেন্ট ব্যাজ চালু','এখন কমিউনিটিতে পোস্ট করতে পারবেন।']},
 profile:{en:['Complete your profile','Your profile is still incomplete.'],bn:['প্রোফাইল সম্পূর্ণ করুন','আপনার প্রোফাইল এখনো অসম্পূর্ণ।']},
 device:{en:['New device signed in','Your account was used on a new device.'],bn:['নতুন ডিভাইসে লগইন','আপনার অ্যাকাউন্ট একটি নতুন ডিভাইসে ব্যবহার হয়েছে।']},
 hidden:{en:['Post hidden','Your post was hidden after several reports.'],bn:['পোস্ট লুকানো হয়েছে','কয়েকটি রিপোর্টের পর আপনার পোস্ট লুকানো হয়েছে।']}};
async function notify(c,uid,k){
 const lang=(await c.db.get(`users/${uid}/profile/lang`))==='en'?'en':'bn',[title,body]=TPL[k][lang];
 await c.db.push(`notifications/${uid}`,{k,at:Date.now()});
 const t=await c.db.get(`users/${uid}/fcm`);
 if(t){const a=await token(c.env);await Promise.all(Object.keys(t).map(tk=>fetch(`https://fcm.googleapis.com/v1/projects/${c.env.PROJECT_ID}/messages:send`,{method:'POST',headers:{authorization:'Bearer '+a,'content-type':'application/json'},body:JSON.stringify({message:{token:tk,notification:{title,body}}})}).catch(()=>{})))}}
const rate=async(c,k,gap)=>{const r=await c.db.tx(`rate/${c.uid}/${k}`,v=>v&&Date.now()-v<gap?undefined:Date.now());if(!r.committed)throw new E('resource-exhausted')};
const clean=(x,max)=>{x=String(x||'').replace(/[\u0000-\u001f\u007f]/g,' ').trim();if(!x||x.length>max)throw new E('invalid-argument');return x};
const pid=x=>{x=String(x||'');if(!/^[-\w]{10,30}$/.test(x))throw new E('invalid-argument');return x};
const did=x=>{x=String(x||'');if(!/^[-\w]{16,64}$/.test(x))throw new E('invalid-argument');return x};
async function member(c){const u=await c.db.get(`users/${c.uid}`)||{};if(!u.student)throw new E('permission-denied');if(!u.username)throw new E('failed-precondition');return u}
const H={
 async hello(c){if(await c.db.get(`users/${c.uid}/welcomed`))return{ok:true};await c.db.put(`users/${c.uid}/welcomed`,true);await notify(c,c.uid,'welcome');await c.db.put(`jobs/profile/${c.uid}`,Date.now()+DAY);return{ok:true}},
 // username: 3-20 chars of a-z0-9 (assumption; change the regex to adjust)
 async claimUsername(c){const n=String(c.d.username||'');if(!/^[a-z0-9]{3,20}$/.test(n))throw new E('invalid-argument');
  const old=await c.db.get(`users/${c.uid}/username`);if(old===n)return{ok:true};
  const t=await c.db.tx(`usernames/${n}`,v=>v===null||v===c.uid?c.uid:undefined);if(!t.committed)throw new E('already-exists');
  await c.db.put(`users/${c.uid}/username`,n);if(old)await c.db.tx(`usernames/${old}`,v=>v===c.uid?null:undefined);return{ok:true}},
 async submitSession(c){const end=Math.floor(Number(c.d.end)),dur=Number(c.d.dur),now=Date.now();
  if(!Number.isFinite(end)||!Number.isFinite(dur)||dur<6e4||dur>12*36e5||end>now+6e4||end<now-10*6e4)throw new E('invalid-argument');
  const lg=await c.db.tx(`pointsLog/${c.uid}/s${end}`,v=>v===null?now:undefined);if(!lg.committed)return{ok:true,duplicate:true};
  const un=await c.db.get(`users/${c.uid}/username`);if(!un)return{ok:true,ranked:false};
  const pts=Math.floor(dur/6e4),dk=Math.floor((end-1+OFF)/DAY);let add=0;
  await c.db.tx(`leaderboard/daily/${dk}/${c.uid}`,v=>{const p=v?v.p:0;add=Math.min(pts,CAP-p);return add>0?{u:un,p:p+add}:undefined});
  if(add>0){const dt=new Date(end-1+OFF),wk=Math.floor((dk+5)/7),mk=`${dt.getUTCFullYear()}${String(dt.getUTCMonth()+1).padStart(2,'0')}`,bump=v=>({u:un,p:(v?v.p:0)+add});
   await Promise.all([c.db.tx(`leaderboard/weekly/${wk}/${c.uid}`,bump),c.db.tx(`leaderboard/monthly/${mk}/${c.uid}`,bump)])}
  return{ok:true}},
 // Automatic badge: format + age check only. NOT an official identity check. Only a keyed hash is kept.
 async submitVerification(c){if(await c.db.get(`users/${c.uid}/student`))return{ok:true};
  const d=c.d,type=d.type,num=String(d.number||'').replace(/\D/g,''),dob=new Date(String(d.dob||'')+'T00:00:00Z');
  if(isNaN(dob)||dob>new Date()||dob.getUTCFullYear()<1950)throw new E('invalid-argument');
  const minor=(Date.now()-dob)/(365.25*DAY)<18,lens=type==='birth'?[17]:type==='nid'?[10,13,17]:[];
  if(!lens.includes(num.length)||(minor&&type!=='birth'))throw new E('invalid-argument');
  if(num.length===17&&Number(num.slice(0,4))!==dob.getUTCFullYear())throw new E('invalid-argument');
  const key=await crypto.subtle.importKey('raw',enc.encode(c.env.ID_PEPPER),{name:'HMAC',hash:'SHA-256'},false,['sign']);
  const h=[...new Uint8Array(await crypto.subtle.sign('HMAC',key,enc.encode(`${type}:${num}`)))].map(x=>x.toString(16).padStart(2,'0')).join('');
  const t=await c.db.tx(`idHashes/${h}`,v=>v===null||v===c.uid?c.uid:undefined);if(!t.committed)throw new E('already-exists');
  await c.db.put(`users/${c.uid}/student`,true);await c.db.put(`users/${c.uid}/ageGroup`,minor?'minor':'adult');
  await notify(c,c.uid,'student');return{ok:true}},
 async createPost(c){const u=await member(c),t=clean(c.d.text,1000);await rate(c,'post',3e4);return{id:await c.db.push('posts',{uid:c.uid,u:u.username,t,at:Date.now(),c:0})}},
 async addComment(c){const u=await member(c),id=pid(c.d.postId),p=await c.db.get(`posts/${id}`);if(!p||p.hidden)throw new E('not-found');
  const t=clean(c.d.text,500);await rate(c,'comment',1e4);await c.db.push(`comments/${id}`,{uid:c.uid,u:u.username,t,at:Date.now()});await c.db.tx(`posts/${id}/c`,v=>(v||0)+1);return{ok:true}},
 // auto-moderation: 3 reports from 3 different students hide a post
 async reportPost(c){await member(c);const id=pid(c.d.postId),t=await c.db.tx(`reports/${id}/${c.uid}`,v=>v===null?Date.now():undefined);if(!t.committed)return{ok:true};
  const n=Object.keys(await c.db.get(`reports/${id}`)||{}).length;
  if(n>=3){const p=await c.db.get(`posts/${id}`);if(p&&!p.hidden){await c.db.put(`posts/${id}/hidden`,true);await notify(c,p.uid,'hidden')}}return{ok:true}},
 async deletePost(c){const id=pid(c.d.postId),p=await c.db.get(`posts/${id}`);if(!p||p.uid!==c.uid)throw new E('permission-denied');await c.db.del(`posts/${id}`);await c.db.del(`comments/${id}`);return{ok:true}},
 // max 2 devices per account
 async registerDevice(c){const id=did(c.d.deviceId),name=String(c.d.name||'').replace(/[^\w ·.-]/g,'').slice(0,40);let blocked=null,existed=false;
  const t=await c.db.tx(`users/${c.uid}/devices`,v=>{v=v||{};blocked=null;existed=!!v[id];if(existed){v[id].last=Date.now();return v}
   if(Object.keys(v).length>=2){blocked=Object.entries(v).map(([k,x])=>({id:k,name:x.name,last:x.last}));return}
   v[id]={name,at:Date.now(),last:Date.now()};return v});
  if(!t.committed&&blocked)throw new E('resource-exhausted',{devices:blocked});
  if(t.committed&&!existed&&Object.keys(t.val).length===2)await notify(c,c.uid,'device');return{ok:true}},
 async removeDevice(c){await c.db.del(`users/${c.uid}/devices/${did(c.d.deviceId)}`);return{ok:true}}};
const cors=o=>({'access-control-allow-origin':o,'access-control-allow-headers':'authorization,content-type','access-control-allow-methods':'POST,OPTIONS',vary:'origin'});
export default{
 async fetch(req,env){const o=req.headers.get('origin')||'',ch=['https://localhost','capacitor://localhost','http://localhost'].includes(o)?cors(o):{};
  if(req.method==='OPTIONS')return new Response(null,{status:204,headers:ch});
  try{const fn=H[new URL(req.url).pathname.slice(1)];if(!fn||req.method!=='POST')throw new E('not-found');
   const uid=await verify(env,(req.headers.get('authorization')||'').slice(7)),c={env,uid,db:D(env),d:await req.json().catch(()=>({}))};
   return new Response(JSON.stringify(await fn(c)),{headers:{...ch,'content-type':'application/json'}})}
  catch(e){const code=e instanceof E?e.code:'internal';return new Response(JSON.stringify({error:code,details:e.details}),{status:code==='internal'?500:400,headers:{...ch,'content-type':'application/json'}})}},
 // hourly: one profile reminder 24h after signup, only if the profile is still incomplete
 async scheduled(ev,env){const c={env,db:D(env)};
  const jobs=await c.db.get('jobs/profile',`?orderBy=${encodeURIComponent('"$value"')}&endAt=${Date.now()}&limitToFirst=200`)||{};
  for(const uid of Object.keys(jobs)){const p=await c.db.get(`users/${uid}/profile`)||{};
   if(![p.displayName,p.level,p.institution,p.cls,p.goal,p.photo].every(Boolean))await notify(c,uid,'profile');await c.db.del(`jobs/profile/${uid}`)}}};
