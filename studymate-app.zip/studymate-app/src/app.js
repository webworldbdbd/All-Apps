import {I18N} from './i18n.js';
import {watchAuth,fbLogin,fbRegister,fbGoogle,fbReset,fbOut,ensureProfile,pushSession,pullSessions,loadProfile,saveProfile,delAccount,uploadPhoto,claimName,creditSession,myName,topDaily,topBoard,hello,API_URL,regDevice,rmDevice,getDevices,loadMeta,verifyId,mkPost,mkComment,rptPost,rmPost,listOf,saveToken} from './firebase.js'
import {PushNotifications} from '@capacitor/push-notifications';import {Capacitor} from '@capacitor/core';import {Filesystem,Directory,Encoding} from '@capacitor/filesystem';import {Share} from '@capacitor/share';import {LocalNotifications} from '@capacitor/local-notifications';
const $=s=>document.querySelector(s);
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const S={get(k,d){try{const v=localStorage.getItem('sm_'+k);return v?JSON.parse(v):d}catch(e){return d}},set(k,v){try{localStorage.setItem('sm_'+k,JSON.stringify(v))}catch(e){}}};
const VERSION='1.0.0',DAY=864e5,OFF=6*36e5; // Asia/Dhaka = UTC+6, no DST
let lang=S.get('lang',(navigator.language||'en').startsWith('bn')?'bn':'en');
let themePref=S.get('theme','system'),tab='home',sub=null;
const t=k=>I18N[lang][k]||k;
const nf=n=>lang==='bn'?String(n).replace(/\d/g,d=>'০১২৩৪৫৬৭৮৯'[d]):String(n);
const dayKey=ms=>Math.floor((ms+OFF)/DAY);
function applyTheme(){const d=themePref==='dark'||(themePref==='system'&&matchMedia('(prefers-color-scheme:dark)').matches);document.documentElement.dataset.t=d?'dark':'light'}
matchMedia('(prefers-color-scheme:dark)').addEventListener('change',applyTheme);
// split a session across Dhaka midnights
function split(end,dur){const o={};let e=end,r=dur;while(r>0){const ds=Math.floor((e-1+OFF)/DAY)*DAY-OFF,c=Math.min(r,e-ds);const k=dayKey(e-1);o[k]=(o[k]||0)+c;e=ds;r-=c}return o}
const sessions=()=>S.get('sessions',[]);
const todayMs=()=>{const k=dayKey(Date.now());return sessions().reduce((a,s)=>a+(split(s.end,s.dur)[k]||0),0)};
const hm=ms=>{const m=Math.floor(ms/6e4);return nf(Math.floor(m/60))+t('h')+' '+nf(m%60)+t('m')};
const tm=()=>S.get('timer',{running:false,startedAt:0,acc:0,subject:''});
const el=()=>{const x=tm();return x.acc+(x.running?Date.now()-x.startedAt:0)};
const clk=ms=>{const s=Math.floor(ms/1e3),p=n=>String(n).padStart(2,'0');return nf(p(Math.floor(s/3600))+':'+p(Math.floor(s/60)%60)+':'+p(s%60))};
const G={'A+':5,'A':4,'A-':3.5,'B':3,'C':2,'D':1,'F':0};
let rows=[{n:'',g:'A+'},{n:'',g:'A+'},{n:'',g:'A'}],gres=null;
function gpa(){if(!rows.length)return 0;if(rows.some(r=>r.g==='F'))return 0;return rows.reduce((a,r)=>a+G[r.g],0)/rows.length}
const tabs=[['home','⌂'],['study','✎'],['community','☺'],['ranking','♛'],['profile','☰']];
function nav(){$('#nav').innerHTML=tabs.map(([k,i])=>`<button data-tab="${k}" class="${tab===k&&!sub?'on':''}"><span>${i}</span>${t(k)}</button>`).join('')}
function view(){if(gate)return gateV();
 if(sub==='gpa')return gpaV();if(sub==='timer')return timerV();if(TV[sub])return TV[sub]();
 if(tab==='home')return `<h1>${t('hello')}</h1><div class="card"><div class="mut">${t('today')}</div><div class="big" id="td">${hm(todayMs())}</div>${S.get('goal',0)?`<div class="mut">${t('goal')}: ${hm(S.get('goal',0)*6e4)}</div>`:''}</div>
 ${newsV()}<p class="mut">${t('guest')}</p><h2>${t('tools')}</h2><div class="grid"><button class="tool" data-sub="timer">${t('timer')}<small>${t('timerD')}</small></button><button class="tool" data-sub="gpa">${t('gpa')}<small>${t('gpaD')}</small></button></div>`;
 if(tab==='study')return `<h1>${t('study')}</h1><div class="grid"><button class="tool" data-sub="timer">${t('timer')}<small>${t('timerD')}</small></button><button class="tool" data-sub="gpa">${t('gpa')}<small>${t('gpaD')}</small></button>
 ${[['cgpa','CGPA','সিজিপিএ'],['att','Attendance','উপস্থিতি'],['exam','Exam Manager','পরীক্ষা'],['plan','Study Planner','স্টাডি প্ল্যানার'],['notes','Notes','নোট']].map(([k,a,b])=>`<button class="tool" data-sub="${k}">${L(a,b)}</button>`).join('')}</div>`;
 if(tab==='community')return SERVER?commV():soonV(t('community'));
 if(tab==='ranking')return SERVER?rankV():soonV(t('ranking'));
 const b=(k,v,on)=>`<button class="${on?'on':''}" data-${k}="${v}">${t(v==='bn'?'bn':v)}</button>`;
 return `<h1>${t('set')}</h1>${accountV()}<div class="card"><div class="mut">${t('theme')}</div><div class="seg" style="margin-top:8px">${['light','dark','system'].map(v=>`<button class="${themePref===v?'on':''}" data-theme="${v}">${t(v)}</button>`).join('')}</div></div>
 <div class="card"><div class="mut">${t('lang')}</div><div class="seg" style="margin-top:8px"><button class="${lang==='bn'?'on':''}" data-lang="bn">বাংলা</button><button class="${lang==='en'?'on':''}" data-lang="en">English</button></div></div>
 <div class="card"><b>${t('about')}</b><p class="mut" style="margin-top:8px">StudyMate · ${t('tag')}<br>${t('owner')}: SHAFAET HOSSEN SARIP<br>${t('dev')}<br>${t('ver')}: ${VERSION}<br>${t('mail')}: <a href="mailto:saripofficialsupport@gmail.com">saripofficialsupport@gmail.com</a><br>${t('tg')}: <a href="https://t.me/saripsupportBD">t.me/saripsupportBD</a></p></div><div class="grid"><button class="tool" data-sub="help">${L('Help & FAQ','সাহায্য ও FAQ')}</button><button class="tool" data-sub="privacy">${L('Privacy Policy','গোপনীয়তা নীতি')}</button><button class="tool" data-sub="terms">${L('Terms & Conditions','শর্তাবলি')}</button><button class="tool" data-x="export">${L('Export my data (JSON)','আমার ডেটা এক্সপোর্ট (JSON)')}</button>${user&&SERVER?`<button class="tool" data-sub="devices">${L('Devices','ডিভাইস')}</button>`:''}</div>`;
}
function timerV(){const x=tm(),h=sessions().slice(-10).reverse();
 return `<div class="row"><button class="btn alt" data-back>←</button><h1 style="margin:0">${t('timer')}</h1></div>
 <div class="card" style="margin-top:12px"><input id="subj" maxlength="40" placeholder="${t('subject')}" value="${esc(x.subject)}"><div class="clock" id="clock">${clk(el())}</div>
 <div class="row"><button class="btn" style="flex:1" data-tm="${x.running?'pause':(x.acc?'resume':'start')}">${x.running?t('pause'):(x.acc?t('resume'):t('start'))}</button>
 <button class="btn alt" data-tm="reset">${t('reset')}</button></div>
 ${x.acc||x.running?`<button class="btn" style="width:100%;margin-top:8px;background:var(--ok)" data-tm="stop">${t('stop')}</button>`:''}<p class="mut" style="margin-top:8px">${t('minNote')}</p></div>
 <h2>${t('sessions')}</h2>${h.length?h.map(s=>`<div class="card row sp"><span>${esc(s.sub||'—')}</span><b>${hm(s.dur)}</b></div>`).join(''):`<p class="mut">${t('noData')}</p>`}`}
function gpaV(){const h=S.get('gpaHist',[]);
 return `<div class="row"><button class="btn alt" data-back>←</button><h1 style="margin:0">${t('gpa')}</h1></div>
 <div style="margin-top:12px">${rows.map((r,i)=>`<div class="row" style="margin-bottom:8px"><input data-rn="${i}" maxlength="40" placeholder="${t('subject')}" value="${esc(r.n)}"><select data-rg="${i}" style="width:90px">${Object.keys(G).map(g=>`<option ${g===r.g?'selected':''}>${g}</option>`).join('')}</select><button class="btn alt" data-rd="${i}">✕</button></div>`).join('')}</div>
 <div class="row"><button class="btn alt" data-radd>${t('add')}</button><button class="btn" data-gsave>${t('save')}</button></div>
 <div class="card" style="margin-top:12px"><div class="mut">${t('res')}</div><div class="big" id="gr">${nf(gpa().toFixed(2))}</div><p class="mut">${t('est')}</p></div>
 <h2>${t('history')}</h2>${h.length?h.map((x,i)=>`<div class="card row sp"><span>${nf(x.v)} · ${nf(x.n)} ${t('subject')}</span><button class="btn alt" data-hd="${i}">${t('del')}</button></div>`).join(''):`<p class="mut">${t('noData')}</p>`}`}
function render(){nav();$('#app').innerHTML=view();if(tab==='ranking'&&!sub&&user&&Date.now()-lbAt>3e4){lbAt=Date.now();loadLb()}if(tab==='community'&&!sub&&user&&prof.username&&Date.now()-postsAt>3e4){postsAt=Date.now();loadPosts()}}
document.addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;const d=b.dataset;
 if(d.tab){tab=d.tab;sub=null}else if(d.sub)sub=d.sub;else if('back' in d)sub=null;
 else if(d.theme){themePref=d.theme;S.set('theme',themePref);applyTheme()}
 else if(d.lang){lang=d.lang;S.set('lang',lang);if(user)saveProfile(user,{lang}).catch(()=>{});document.documentElement.lang=lang}
 else if(d.tm){const x=tm(),n=Date.now(),sj=($('#subj')||{}).value||x.subject;x.subject=sj;
  if(d.tm==='start'||d.tm==='resume'){x.running=true;x.startedAt=n}
  else if(d.tm==='pause'){x.acc+=n-x.startedAt;x.running=false}
  else if(d.tm==='reset'){x.running=false;x.acc=0;x.startedAt=0}
  else if(d.tm==='stop'){if(x.running)x.acc+=n-x.startedAt;if(x.acc>=6e4){const a=sessions();const ns={end:n,dur:x.acc,sub:sj.slice(0,40)};a.push(ns);S.set('sessions',a);cloudSave(ns)}x.running=false;x.acc=0;x.startedAt=0}
  S.set('timer',x)}
 else if(d.auth){doAuth(d.auth);return}
 else if('radd' in d)rows.push({n:'',g:'A'});
 else if(d.rd){rows.splice(+d.rd,1)}
 else if('gsave' in d){const h=S.get('gpaHist',[]);h.unshift({v:gpa().toFixed(2),n:rows.length,at:Date.now()});S.set('gpaHist',h.slice(0,50))}
 else if(d.hd){const h=S.get('gpaHist',[]);h.splice(+d.hd,1);S.set('gpaHist',h)}
 else return;render()});
document.addEventListener('input',e=>{const d=e.target.dataset;if(d.rn!==undefined)rows[+d.rn].n=e.target.value.slice(0,40)});
document.addEventListener('change',e=>{const d=e.target.dataset;if(d.rg!==undefined){rows[+d.rg].g=e.target.value;const g=$('#gr');if(g)g.textContent=nf(gpa().toFixed(2))}});
setInterval(()=>{const c=$('#clock');if(c)c.textContent=clk(el());const d=$('#td');if(d)d.textContent=hm(todayMs())},1000);

Object.assign(I18N.en,{acct:"Account",email:"Email",password:"Password",login:"Log in",register:"Create account",logout:"Log out",google:"Continue with Google",forgot:"Forgot password?",haveAcc:"I have an account",noAcc:"Create account",verifySent:"Account created. Check your email to verify it.",resetSent:"Password reset email sent.",eInv:"Wrong email or password.",eUse:"This email is already registered. Log in instead.",eWeak:"Password must be at least 6 characters.",eMail:"Enter a valid email address.",eMany:"Too many attempts. Try again later.",eNet:"No internet connection.",eGen:"Something went wrong. Try again.",migrate:"Upload the study sessions saved on this device to your account?"});
Object.assign(I18N.bn,{acct:"অ্যাকাউন্ট",email:"ইমেইল",password:"পাসওয়ার্ড",login:"লগইন",register:"অ্যাকাউন্ট খুলুন",logout:"লগআউট",google:"Google দিয়ে চালিয়ে যান",forgot:"পাসওয়ার্ড ভুলে গেছেন?",haveAcc:"আমার অ্যাকাউন্ট আছে",noAcc:"অ্যাকাউন্ট খুলুন",verifySent:"অ্যাকাউন্ট তৈরি হয়েছে। যাচাই করতে ইমেইল দেখুন।",resetSent:"পাসওয়ার্ড রিসেটের ইমেইল পাঠানো হয়েছে।",eInv:"ইমেইল বা পাসওয়ার্ড ভুল।",eUse:"এই ইমেইল আগেই নিবন্ধিত। লগইন করুন।",eWeak:"পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে।",eMail:"সঠিক ইমেইল ঠিকানা দিন।",eMany:"অনেকবার চেষ্টা হয়েছে। পরে আবার চেষ্টা করুন।",eNet:"ইন্টারনেট সংযোগ নেই।",eGen:"কিছু একটা সমস্যা হয়েছে। আবার চেষ্টা করুন।",migrate:"এই ডিভাইসে সেভ করা পড়ার সেশনগুলো আপনার অ্যাকাউন্টে আপলোড করবেন?"});
let user=null,authMode='login',amsg='',busy=false,aem='';
const AE={'auth/invalid-credential':'eInv','auth/wrong-password':'eInv','auth/user-not-found':'eInv','auth/email-already-in-use':'eUse','auth/weak-password':'eWeak','auth/invalid-email':'eMail','auth/too-many-requests':'eMany','auth/network-request-failed':'eNet'};
function accountV(){
 const m=amsg?`<p class="mut" style="margin:8px 0">${t(amsg)}</p>`:'';
 if(user)return signedV(m);
 const reg=authMode==='register';
 return `<div class="card"><b>${t(reg?'register':'login')}</b>
 <input id="aem" type="email" autocomplete="email" placeholder="${t('email')}" value="${esc(aem)}" style="margin:10px 0 8px">
 <input id="apw" type="password" autocomplete="${reg?'new-password':'current-password'}" placeholder="${t('password')}" style="margin-bottom:10px">${m}
 <button class="btn" style="width:100%" data-auth="${reg?'register':'login'}">${t(reg?'register':'login')}</button>
 <button class="btn alt" style="width:100%;margin-top:8px" data-auth="google">${t('google')}</button>
 <div class="row sp" style="margin-top:10px"><button class="btn alt" data-auth="mode">${t(reg?'haveAcc':'noAcc')}</button>${reg?'':`<button class="btn alt" data-auth="reset">${t('forgot')}</button>`}</div></div>`}
async function doAuth(a){
 const em=$('#aem'),pw=$('#apw');if(em)aem=em.value.trim();
 if(a==='mode'){authMode=authMode==='login'?'register':'login';amsg='';return render()}
 if(a==='logout'){amsg='';try{await fbOut()}catch(e){}return}
 if(a==='uname'&&user){const n=val('pu').trim().toLowerCase();if(!/^[a-z0-9]{3,20}$/.test(n)){amsg='eUser';return render()}
  try{await claimName(n);prof.username=n;amsg='saved'}catch(e){amsg=/already-exists/.test((e&&e.code)||'')?'eTaken':'eGen'}return render()}
 if(a==='psave'&&user){const g=Math.max(0,Math.min(1440,Math.round(+val('pg')||0)));const p={displayName:val('pn').trim().slice(0,60),level:val('pl'),institution:val('pi').trim().slice(0,80),cls:val('pk').trim().slice(0,40),goal:g};
  try{await saveProfile(user,p);Object.assign(prof,p);S.set('goal',g);amsg='saved'}catch(e){amsg='eGen'}return render()}
 if(a==='delacc'&&user){if(!confirm(L('Delete your account and cloud data? This cannot be undone.','অ্যাকাউন্ট ও ক্লাউড ডেটা মুছবেন? এটি ফেরানো যাবে না।')))return;
  try{await delAccount(user);amsg=''}catch(e){amsg=e&&e.code==='auth/requires-recent-login'?'eRecent':'eGen'}return render()}
 if(busy)return;busy=true;amsg='';
 try{
  if(a==='login')await fbLogin(aem,pw.value);
  else if(a==='register'){await fbRegister(aem,pw.value);amsg='verifySent'}
  else if(a==='google')await fbGoogle();
  else if(a==='reset'){if(!aem)throw{code:'auth/invalid-email'};await fbReset(aem);amsg='resetSent'}
 }catch(e){amsg=AE[e&&e.code]||'eGen'}
 busy=false;render()}
function cloudSave(s){if(user){pushSession(user.uid,s).catch(()=>{});if(SERVER)creditSession(s).catch(()=>{})}}
async function syncDown(u){
 const cloud=await pullSessions(u.uid),local=sessions(),have=new Set(cloud.map(x=>x.end));
 const onlyLocal=local.filter(x=>!have.has(x.end));
 if(onlyLocal.length&&confirm(t('migrate')))for(const x of onlyLocal)await pushSession(u.uid,x);
 const mp=new Map();[...cloud,...local].forEach(x=>mp.set(x.end,x));
 S.set('sessions',[...mp.values()].sort((a,b)=>a.end-b.end));render()}
watchAuth(async u=>{user=u;if(!u){prof={};gate=null}render();if(u){try{await ensureProfile(u);prof=await loadProfile(u);Object.assign(prof,await loadMeta(u));saveProfile(u,{lang}).catch(()=>{});if(SERVER){hello().catch(()=>{});initPush(u);checkDevice(u)}if(prof.goal)S.set('goal',prof.goal);render();await syncDown(u)}catch(e){}}});

const L=(a,b)=>lang==='bn'?b:a;
const hdr=x=>`<div class="row"><button class="btn alt" data-back>←</button><h1 style="margin:0">${x}</h1></div>`;
const inp=(id,ph,v='')=>`<input id="${id}" maxlength="80" placeholder="${ph}" value="${esc(v)}" style="margin-bottom:8px">`;
const delB=(k,i)=>`<button class="btn alt" data-x="del" data-k="${k}" data-i="${i}">✕</button>`;
const val=id=>($('#'+id)||{}).value||'';
const empty=()=>`<p class="mut">${t('noData')}</p>`;
let cg=[{g:'',c:''}],editN=null;
const cgv=()=>{let tc=0,tp=0;cg.forEach(r=>{const g=parseFloat(r.g),c=parseFloat(r.c);if(g>=0&&g<=5&&c>0){tc+=c;tp+=g*c}});return tc?tp/tc:0};
const nlist=q=>{const a=S.get('notes',[]).map((n,i)=>({...n,i})).filter(n=>(n.t+n.b+n.s).toLowerCase().includes(q.toLowerCase()));
 return a.length?a.map(n=>`<div class="card"><div class="row sp"><b>${esc(n.t)}</b><div class="row"><button class="btn alt" data-x="nedit" data-i="${n.i}">✎</button>${delB('notes',n.i)}</div></div><div class="mut">${esc(n.s)}</div><p style="white-space:pre-wrap;margin-top:6px">${esc(n.b)}</p></div>`).join(''):empty()};
const TV={
cgpa(){return hdr(L('CGPA Calculator','সিজিপিএ ক্যালকুলেটর'))+`<div style="margin-top:12px">${cg.map((r,i)=>`<div class="row" style="margin-bottom:8px"><input data-cg="g" data-i="${i}" inputmode="decimal" placeholder="${L('GPA (0-5)','জিপিএ (০-৫)')}" value="${esc(r.g)}"><input data-cg="c" data-i="${i}" inputmode="decimal" placeholder="${L('Credits','ক্রেডিট')}" value="${esc(r.c)}"><button class="btn alt" data-x="cgdel" data-i="${i}">✕</button></div>`).join('')}</div><button class="btn alt" data-x="cgadd">${L('Add semester','সেমিস্টার যোগ করুন')}</button><div class="card" style="margin-top:12px"><div class="mut">CGPA</div><div class="big" id="cgr">${nf(cgv().toFixed(2))}</div><p class="mut">${L("Estimate only. Your institution's grading rules decide the official CGPA.",'এটি আনুমানিক। চূড়ান্ত সিজিপিএ আপনার প্রতিষ্ঠানের নিয়মে হবে।')}</p></div>`},
att(){const a=S.get('att',[]);return hdr(L('Attendance','উপস্থিতি'))+`<div class="card" style="margin-top:12px">${inp('an',L('Subject','বিষয়'))}<div class="row"><input id="at" type="number" min="1" max="99" value="75" style="width:90px"><span class="mut" style="flex:1">${L('Target %','লক্ষ্য %')}</span><button class="btn" data-x="attadd">${t('add')}</button></div></div>`+(a.length?a.map((s,i)=>{
 const p=s.tot?Math.round(s.att*1000/s.tot)/10:0,n=Math.ceil((s.tg*s.tot-100*s.att)/(100-s.tg)),sk=Math.floor((100*s.att-s.tg*s.tot)/s.tg);
 const msg=!s.tot?'':p>=s.tg?L(`You can miss ${sk} more class(es).`,`আরও ${nf(sk)}টি ক্লাস মিস করতে পারবেন।`):L(`Attend ${n} more class(es) in a row to reach your target.`,`লক্ষ্যে পৌঁছাতে টানা ${nf(n)}টি ক্লাস করতে হবে।`);
 return `<div class="card"><div class="row sp"><b>${esc(s.n)}</b>${delB('att',i)}</div><div class="big">${nf(p)}%</div><p class="mut">${L('Present','উপস্থিত')} ${nf(s.att)} / ${nf(s.tot)} · ${L('Absent','অনুপস্থিত')} ${nf(s.tot-s.att)} · ${L('Target','লক্ষ্য')} ${nf(s.tg)}%<br>${msg}</p><div class="row"><button class="btn" style="flex:1" data-x="att" data-i="${i}" data-v="1">${L('Present','উপস্থিত')}</button><button class="btn alt" style="flex:1" data-x="att" data-i="${i}" data-v="0">${L('Absent','অনুপস্থিত')}</button></div></div>`}).join(''):empty())},
exam(){const a=S.get('exams',[]).map((e,i)=>({...e,i})).sort((x,y)=>(x.d+x.tm).localeCompare(y.d+y.tm));
 return hdr(L('Exam Manager','পরীক্ষা ম্যানেজার'))+`<div class="card" style="margin-top:12px">${inp('en',L('Exam name','পরীক্ষার নাম'))}${inp('es',L('Subject','বিষয়'))}<div class="row"><input id="ed" type="date"><input id="et" type="time"></div><button class="btn" style="width:100%;margin-top:8px" data-x="examadd">${t('add')}</button></div>`+(a.length?a.map(e=>{const d=Math.ceil((new Date(e.d+'T'+(e.tm||'00:00'))-Date.now())/DAY);
 return `<div class="card row sp"><div><b>${esc(e.n)}</b><div class="mut">${esc(e.s)} · ${esc(e.d)} ${esc(e.tm)}</div><div>${d>=0?L(`${d} day(s) left`,`${nf(d)} দিন বাকি`):L('Completed','সম্পন্ন')}</div></div>${delB('exams',e.i)}</div>`}).join(''):empty())},
plan(){const a=S.get('plan',[]),D=L('Sun Mon Tue Wed Thu Fri Sat','রবি সোম মঙ্গল বুধ বৃহ শুক্র শনি').split(' ');
 return hdr(L('Study Planner','স্টাডি প্ল্যানার'))+`<div class="card" style="margin-top:12px">${inp('ps',L('Subject','বিষয়'))}<select id="pd" style="margin-bottom:8px">${D.map((x,i)=>`<option value="${i}">${x}</option>`).join('')}</select><div class="row"><input id="pa" type="time"><input id="pb" type="time"></div><button class="btn" style="width:100%;margin-top:8px" data-x="planadd">${t('add')}</button></div>`+(a.length?D.map((x,di)=>{const it=a.map((p,i)=>({...p,i})).filter(p=>p.d===di).sort((p,q)=>p.a.localeCompare(q.a));
 return it.length?`<h2>${x}</h2>`+it.map(p=>`<div class="card row sp"><div><b>${esc(p.s)}</b><div class="mut">${esc(p.a)} – ${esc(p.b)}</div></div>${delB('plan',p.i)}</div>`).join(''):''}).join(''):empty())},
notes(){const a=S.get('notes',[]),e=editN!=null?a[editN]:null;
 return hdr(L('Notes','নোট'))+`<div class="card" style="margin-top:12px">${inp('nt',L('Title','শিরোনাম'),e?e.t:'')}${inp('ns',L('Subject','বিষয়'),e?e.s:'')}<textarea id="nb" maxlength="5000" rows="5" placeholder="${L('Write your note','নোট লিখুন')}" style="margin-bottom:8px">${e?esc(e.b):''}</textarea><button class="btn" style="width:100%" data-x="nsave">${t('save').replace(/.*/,L('Save note','নোট সেভ করুন'))}</button></div>${inp('nq',L('Search notes','নোট খুঁজুন'))}<div id="nl">${nlist('')}</div>`}};
document.addEventListener('click',e=>{
 if(e.target.closest('[data-back],[data-sub],[data-tab]'))editN=null;
 const b=e.target.closest('[data-x]');if(!b)return;const d=b.dataset,i=+d.i,x=d.x;
 if(x==='del'&&['att','exams','plan','notes'].includes(d.k)){const a=S.get(d.k,[]);if(d.k==='exams')unremind(a[i]);a.splice(i,1);S.set(d.k,a)}
 else if(x==='cgadd')cg.push({g:'',c:''});
 else if(x==='cgdel'){cg.splice(i,1);if(!cg.length)cg.push({g:'',c:''})}
 else if(x==='attadd'){const n=val('an').trim(),tg=+val('at');if(!n||!(tg>=1&&tg<=99))return;const a=S.get('att',[]);a.push({n,tot:0,att:0,tg});S.set('att',a)}
 else if(x==='att'){const a=S.get('att',[]);a[i].tot++;if(d.v==='1')a[i].att++;S.set('att',a)}
 else if(x==='examadd'){const n=val('en').trim(),dt=val('ed');if(!n||!dt)return;const a=S.get('exams',[]);const ex={n,s:val('es').trim(),d:dt,tm:val('et'),nid:(Date.now()%1e8)*2};a.push(ex);S.set('exams',a);remind(ex)}
 else if(x==='planadd'){const s=val('ps').trim(),p=val('pa'),q=val('pb');if(!s||!p||!q)return;const a=S.get('plan',[]);a.push({s,d:+val('pd'),a:p,b:q});S.set('plan',a)}
 else if(x==='nsave'){const t1=val('nt').trim(),b1=val('nb');if(!t1&&!b1)return;const a=S.get('notes',[]),n={t:t1||L('Untitled','শিরোনামহীন'),s:val('ns').trim(),b:b1};if(editN!=null)a[editN]=n;else a.unshift(n);editN=null;S.set('notes',a)}
 else if(x==='nedit')editN=i;
 else if(x==='export'){exportData();return}
 else return;render()});
document.addEventListener('input',e=>{const d=e.target.dataset;
 if(d.cg){cg[+d.i][d.cg]=e.target.value.slice(0,6);const r=$('#cgr');if(r)r.textContent=nf(cgv().toFixed(2))}
 if(e.target.id==='nq')$('#nl').innerHTML=nlist(e.target.value)});

Object.assign(I18N.en,{saved:"Saved.",ePhoto:"Photo upload failed. Use an image under 10 MB.",eRecent:"Your data was removed. For security, log in again and tap Delete account once more."});
Object.assign(I18N.bn,{saved:"সেভ হয়েছে।",ePhoto:"ছবি আপলোড হয়নি। ১০ এমবির কম ছবি দিন।",eRecent:"আপনার ডেটা মুছে গেছে। নিরাপত্তার জন্য আবার লগইন করে আরেকবার অ্যাকাউন্ট মুছুন চাপুন।"});
const LV=['SSC','HSC','Polytechnic','College','University','Other'];
let prof={};
const pcent=()=>{const f=[prof.displayName,prof.level,prof.institution,prof.cls,prof.goal,prof.photo];return Math.round(f.filter(Boolean).length*100/f.length)};
const okPhoto=u=>typeof u==='string'&&u.startsWith('https://res.cloudinary.com/');
function signedV(m){return `<div class="card"><div class="row">${okPhoto(prof.photo)?`<img src="${esc(prof.photo)}" alt="" style="width:64px;height:64px;border-radius:50%;object-fit:cover">`:''}<div><b>${t('acct')}</b><div class="mut">${esc(user.email||'')}</div><div class="mut">${L('Profile','প্রোফাইল')} ${nf(pcent())}%</div></div></div>
 <div class="row" style="margin:10px 0 8px;display:${SERVER?'flex':'none'}"><input id="pu" maxlength="20" placeholder="${L('Username (a-z, 0-9)','ইউজারনেম (a-z, 0-9)')}" value="${esc(prof.username||'')}"><button class="btn" data-auth="uname">${L('Claim','নিন')}</button></div><input id="pf" type="file" accept="image/*" style="margin:0 0 8px">${inp('pn',L('Full name','পুরো নাম'),prof.displayName||'')}
 <select id="pl" style="margin-bottom:8px"><option value="">${L('Education level','শিক্ষাস্তর')}</option>${LV.map(x=>`<option ${prof.level===x?'selected':''}>${x}</option>`).join('')}</select>
 ${inp('pi',L('Institution','প্রতিষ্ঠান'),prof.institution||'')}${inp('pk',L('Class / semester','শ্রেণি / সেমিস্টার'),prof.cls||'')}
 <input id="pg" type="number" min="0" max="1440" placeholder="${L('Daily study goal (minutes)','দৈনিক পড়ার লক্ষ্য (মিনিট)')}" value="${prof.goal||''}" style="margin-bottom:8px">${m}
 <button class="btn" style="width:100%" data-auth="psave">${L('Save profile','প্রোফাইল সেভ করুন')}</button>
 <div class="row" style="margin-top:8px"><button class="btn alt" style="flex:1" data-auth="logout">${t('logout')}</button><button class="btn bad" style="flex:1" data-auth="delacc">${L('Delete account','অ্যাকাউন্ট মুছুন')}</button></div></div>`}
document.addEventListener('change',async e=>{if(e.target.id!=='pf'||!user)return;const f=e.target.files[0];
 if(!f||!f.type.startsWith('image/')||f.size>10e6){amsg='ePhoto';return render()}
 try{const r=await uploadPhoto(f);prof.photo=r.url;prof.photoId=r.id;await saveProfile(user,{photo:r.url,photoId:r.id});amsg='saved'}catch(x){amsg='ePhoto'}render()});
const pg=(title,ps)=>hdr(title)+`<div style="margin-top:12px">${ps.map(p=>`<div class="card"><p>${p}</p></div>`).join('')}</div>`;
TV.help=()=>pg(L('Help & FAQ','সাহায্য ও FAQ'),[
 L('<b>Do I need an account?</b><br>No. Guest mode works offline. An account adds cloud sync of your study sessions.','<b>অ্যাকাউন্ট লাগবে কি?</b><br>না। গেস্ট মোড অফলাইনে চলে। অ্যাকাউন্টে পড়ার সেশন ক্লাউডে সিঙ্ক হয়।'),
 L('<b>Is my GPA official?</b><br>No. Results are estimates. Your board or institution decides official results.','<b>জিপিএ কি অফিসিয়াল?</b><br>না। এটি আনুমানিক। চূড়ান্ত ফলাফল বোর্ড বা প্রতিষ্ঠান ঠিক করে।'),
 L('<b>How do I delete my account?</b><br>Settings, then Delete account.','<b>অ্যাকাউন্ট কীভাবে মুছব?</b><br>সেটিংসে গিয়ে অ্যাকাউন্ট মুছুন চাপুন।'),
 L('<b>Report a problem</b><br>Email <a href="mailto:saripofficialsupport@gmail.com">saripofficialsupport@gmail.com</a> or message <a href="https://t.me/saripsupportBD">t.me/saripsupportBD</a>.','<b>সমস্যা জানান</b><br>ইমেইল করুন <a href="mailto:saripofficialsupport@gmail.com">saripofficialsupport@gmail.com</a> অথবা মেসেজ দিন <a href="https://t.me/saripsupportBD">t.me/saripsupportBD</a>।')]);
TV.privacy=()=>pg(L('Privacy Policy','গোপনীয়তা নীতি'),[
 L('<b>Draft: the owner must review this before publishing.</b>','<b>খসড়া: প্রকাশের আগে মালিককে যাচাই করতে হবে।</b>'),
 L('We collect your email, name, the profile details you choose to add, a profile photo if you upload one, and your study sessions. Guest data stays on your device.','আমরা আপনার ইমেইল, নাম, আপনার দেওয়া প্রোফাইল তথ্য, আপলোড করা ছবি এবং পড়ার সেশন সংগ্রহ করি। গেস্টের ডেটা শুধু আপনার ডিভাইসে থাকে।'),
 L('Data is stored with Google Firebase and Cloudinary (photo). Only you can read your private data. Other students never see your email or profile details.','ডেটা Google Firebase ও Cloudinary (ছবি)-তে থাকে। আপনার ব্যক্তিগত ডেটা শুধু আপনি পড়তে পারেন। অন্য শিক্ষার্থীরা আপনার ইমেইল বা প্রোফাইল তথ্য দেখে না।'),
 L('StudyMate is for students, including minors. We collect only what the app needs. You can delete your account and cloud data in Settings.','StudyMate শিক্ষার্থীদের জন্য, নাবালকসহ। অ্যাপের প্রয়োজনের বেশি তথ্য নেওয়া হয় না। সেটিংস থেকে অ্যাকাউন্ট ও ক্লাউড ডেটা মুছতে পারবেন।')]);
TV.terms=()=>pg(L('Terms & Conditions','শর্তাবলি'),[
 L('<b>Draft: the owner must review this before publishing.</b>','<b>খসড়া: প্রকাশের আগে মালিককে যাচাই করতে হবে।</b>'),
 L('StudyMate is a study aid by WebWorldBD. Calculators give estimates, not official results.','StudyMate, WebWorldBD-র একটি পড়াশোনার সহায়ক অ্যাপ। ক্যালকুলেটর আনুমানিক ফল দেয়, অফিসিয়াল ফল নয়।'),
 L('Use the app lawfully and respectfully. Accounts that abuse the service may be suspended.','অ্যাপ আইনসম্মত ও সম্মানজনকভাবে ব্যবহার করুন। অপব্যবহারকারী অ্যাকাউন্ট স্থগিত হতে পারে।'),
 L('Contact: saripofficialsupport@gmail.com','যোগাযোগ: saripofficialsupport@gmail.com')]);

Object.assign(I18N.en,{eUser:"Username must be 3-20 characters: a-z and 0-9 only.",eTaken:"This username is taken."});
Object.assign(I18N.bn,{eUser:"ইউজারনেম ৩-২০ অক্ষরের হতে হবে: শুধু a-z ও 0-9।",eTaken:"এই ইউজারনেম আগেই নেওয়া হয়েছে।"});
let lb=null,lbAt=0;
async function loadLb(){try{lb=await topBoard(lbKind,boardKey(lbKind))}catch(e){lb=[]}render()}
function rankV(){const h=`<h1>${t('ranking')}</h1>`;if(!user)return h+`<div class="card">${t('lockR')}</div>`;
 return h+`<div class="seg" style="margin-bottom:10px">${['daily','weekly','monthly'].map(k=>`<button class="${lbKind===k?'on':''}" data-lb="${k}">${L({daily:'Daily',weekly:'Weekly',monthly:'Monthly'}[k],{daily:'দৈনিক',weekly:'সাপ্তাহিক',monthly:'মাসিক'}[k])}</button>`).join('')}</div><p class="mut" style="margin-bottom:10px">${L('Top 10 · 1 point per study minute, checked on the server. Set a username to appear here.','শীর্ষ ১০ · প্রতি মিনিট পড়ায় ১ পয়েন্ট, সার্ভারে যাচাই করা। এখানে আসতে ইউজারনেম দিন।')}</p>`+(lb&&lb.length?lb.map((r,i)=>`<div class="card row sp"><span>${nf(i+1)}. @${esc(r.u)}</span><b>${nf(r.p)}</b></div>`).join(''):empty())}
async function remind(e){try{if(!Capacitor.isNativePlatform())return;const p=await LocalNotifications.requestPermissions();if(p.display!=='granted')return;
 const at=new Date(e.d+'T'+(e.tm||'08:00')),n=[];[[864e5,L('tomorrow','আগামীকাল')],[36e5,L('in 1 hour','১ ঘণ্টা পরে')]].forEach(([ms,w],i)=>{const when=new Date(at-ms);if(when>Date.now())n.push({id:e.nid+i,title:'StudyMate',body:`${e.n}: ${w}`,schedule:{at:when}})});
 if(n.length)await LocalNotifications.schedule({notifications:n})}catch(x){}}
function unremind(e){if(e&&e.nid&&Capacitor.isNativePlatform())LocalNotifications.cancel({notifications:[{id:e.nid},{id:e.nid+1}]}).catch(()=>{})}
async function exportData(){
 if(!confirm(L('Export your own data as a JSON file?','আপনার নিজের ডেটা JSON ফাইলে এক্সপোর্ট করবেন?')))return;
 const o={app:'StudyMate',exportedAt:new Date().toISOString(),data:{}};
 ['sessions','gpaHist','att','exams','plan','notes','goal'].forEach(k=>o.data[k]=S.get(k,null));
 if(user)o.account={email:user.email,profile:prof};
 const txt=JSON.stringify(o,null,2),name='studymate-export.json';
 try{if(Capacitor.isNativePlatform()){const w=await Filesystem.writeFile({path:name,data:txt,directory:Directory.Cache,encoding:Encoding.UTF8});await Share.share({title:name,url:w.uri})}
 else{const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([txt],{type:'application/json'}));a.download=name;a.click()}}catch(e){alert(L('Export failed.','এক্সপোর্ট হয়নি।'))}}

let posts=null,postsAt=0,inbox=null,cur=null,cms=null,news=null;
async function loadPosts(){postsAt=Date.now();try{posts=await listOf('posts',30)}catch(e){posts=[]}render()}
async function initPush(u){if(!Capacitor.isNativePlatform())return;try{const p=await PushNotifications.requestPermissions();if(p.receive!=='granted')return;await PushNotifications.removeAllListeners();PushNotifications.addListener('registration',t=>saveToken(u,t.value).catch(()=>{}));await PushNotifications.register()}catch(e){}}
function newsV(){return (user&&SERVER?`<button class="btn alt" data-sub="inbox" style="margin-bottom:10px">🔔 ${L('Notifications','নোটিফিকেশন')}</button>`:'')+(news?`<div class="card"><b>${L("What's new",'নতুন কী')}</b><p class="mut" style="margin-top:6px">${esc(news[lang]||news.en||'')}</p></div>`:'')}
function commV(){const h=`<h1>${t('community')}</h1>`;if(!user)return h+`<div class="card">${t('lockC')}</div>`;
 if(!prof.username)return h+`<div class="card">${L('Set a username in Settings (Profile) to use the community.','কমিউনিটি ব্যবহার করতে সেটিংস (প্রোফাইল) থেকে ইউজারনেম নিন।')}</div>`;
 const top=prof.student?`<div class="card"><textarea id="cp" maxlength="1000" rows="3" placeholder="${L('Share a study tip or question','পড়াশোনা নিয়ে কিছু লিখুন')}" style="margin-bottom:8px"></textarea><button class="btn" style="width:100%" data-c="post">${L('Post','পোস্ট')}</button></div>`
 :`<div class="card"><b>${L('Student badge needed to post','পোস্ট করতে স্টুডেন্ট ব্যাজ লাগবে')}</b><p class="mut" style="margin:6px 0 10px">${L('You can read posts now. Get the badge to post and comment.','এখন পোস্ট পড়তে পারবেন। পোস্ট ও মন্তব্য করতে ব্যাজ নিন।')}</p><button class="btn" data-sub="verify">${L('Get badge','ব্যাজ নিন')}</button></div>`;
 const vis=(posts||[]).filter(x=>!x.hidden&&!blk().includes(x.uid));
 return h+top+(blk().length?`<button class="btn alt" data-c="unblk" style="margin-bottom:10px">${L('Unblock all','সবাইকে আনব্লক')} (${nf(blk().length)})</button>`:'')+(vis.length?vis.map(x=>`<div class="card"><div class="row sp"><b>@${esc(x.u)}</b><span class="mut">${nf(x.c||0)} 💬</span></div><p style="white-space:pre-wrap;margin:6px 0">${esc(x.t)}</p><div class="row"><button class="btn alt" data-c="open" data-id="${esc(x.id)}">${L('Comments','মন্তব্য')}</button>${x.uid!==user.uid?`<button class="btn alt" data-c="blk" data-u="${esc(x.uid)}">${L('Block','ব্লক')}</button>`:''}${x.uid===user.uid?`<button class="btn alt" data-c="rm" data-id="${esc(x.id)}">${t('del')}</button>`:(prof.student?`<button class="btn alt" data-c="rpt" data-id="${esc(x.id)}">${L('Report','রিপোর্ট')}</button>`:'')}</div></div>`).join(''):empty())}
TV.verify=()=>hdr(L('Student badge','স্টুডেন্ট ব্যাজ'))+`<div class="card" style="margin-top:12px"><p class="mut" style="margin-bottom:10px">${L("Under 18: birth registration only. 18+: birth registration or NID. We check the number format and your age, then keep only a one-way code so one number cannot be used on many accounts. We do not keep the number, any document or your date of birth. This is not an official identity check. If you are under 18, use it with your guardian's knowledge.",'১৮ বছরের নিচে: শুধু জন্মনিবন্ধন। ১৮+: জন্মনিবন্ধন বা NID। আমরা নম্বরের ফরম্যাট ও বয়স মেলাই, তারপর শুধু একটা একমুখী কোড রাখি যাতে এক নম্বর অনেক অ্যাকাউন্টে না চলে। নম্বর, নথি বা জন্মতারিখ রাখা হয় না। এটি সরকারি পরিচয় যাচাই নয়। ১৮ বছরের নিচে হলে অভিভাবকের জানা অবস্থায় ব্যবহার করুন।')}</p>
<select id="vt" style="margin-bottom:8px"><option value="birth">${L('Birth registration','জন্মনিবন্ধন')}</option><option value="nid">NID</option></select>
<input id="vn" inputmode="numeric" maxlength="17" placeholder="${L('Number','নম্বর')}" style="margin-bottom:8px"><input id="vd" type="date" style="margin-bottom:8px"><button class="btn" style="width:100%" data-c="ver">${L('Verify','যাচাই করুন')}</button></div>`;
TV.post=()=>cur?hdr(L('Post','পোস্ট'))+`<div class="card" style="margin-top:12px"><b>@${esc(cur.u)}</b><p style="white-space:pre-wrap;margin-top:6px">${esc(cur.t)}</p></div>`+(prof.student?`<div class="card"><textarea id="cm" maxlength="500" rows="2" placeholder="${L('Write a comment','মন্তব্য লিখুন')}" style="margin-bottom:8px"></textarea><button class="btn" style="width:100%" data-c="cmt">${L('Comment','মন্তব্য করুন')}</button></div>`:'')+((cms||[]).length?cms.filter(c=>!blk().includes(c.uid)).map(c=>`<div class="card"><div class="row sp"><b>@${esc(c.u)}</b>${c.uid!==user.uid?`<button class="btn alt" data-c="blk" data-u="${esc(c.uid)}">${L('Block','ব্লক')}</button>`:''}</div><p style="white-space:pre-wrap;margin-top:4px">${esc(c.t)}</p></div>`).join(''):empty()):'';
const NT={device:['New device signed in','নতুন ডিভাইসে লগইন'],welcome:['Welcome to StudyMate','StudyMate-এ স্বাগতম'],student:['Student badge active','স্টুডেন্ট ব্যাজ চালু'],profile:['Complete your profile','প্রোফাইল সম্পূর্ণ করুন'],hidden:['A post of yours was hidden','আপনার একটি পোস্ট লুকানো হয়েছে']};
TV.inbox=()=>hdr(L('Notifications','নোটিফিকেশন'))+`<div style="margin-top:12px">${(inbox||[]).length?inbox.map(n=>`<div class="card">${esc(NT[n.k]?L(...NT[n.k]):n.k)}</div>`).join(''):empty()}</div>`;
const em=x=>{const c=(x&&x.code)||'';return /permission-denied/.test(c)?L('Get the student badge first.','আগে স্টুডেন্ট ব্যাজ নিন।'):/resource-exhausted/.test(c)?L('Slow down. Try again shortly.','একটু পরে আবার চেষ্টা করুন।'):/already-exists/.test(c)?L('This number is already used by another account.','এই নম্বর অন্য অ্যাকাউন্টে ব্যবহৃত হয়েছে।'):/invalid-argument/.test(c)?L('Number, date of birth and rules do not match. Check and try again.','নম্বর, জন্মতারিখ ও নিয়ম মিলছে না। দেখে আবার চেষ্টা করুন।'):L('Could not complete. Try again.','সম্পন্ন হয়নি। আবার চেষ্টা করুন।')};
document.addEventListener('click',async e=>{
 if(e.target.closest('[data-sub="devices"]')&&user)getDevices(user).then(a=>{devs=a;render()}).catch(()=>{});
 if(e.target.closest('[data-sub="inbox"]')&&user)listOf(`notifications/${user.uid}`,30).then(a=>{inbox=a;render()}).catch(()=>{});
 const b=e.target.closest('[data-c]');if(!b)return;const d=b.dataset,c=d.c;
 try{
  if(c==='post'){const v=val('cp').trim();if(!v)return;await mkPost({text:v});await loadPosts()}
  else if(c==='rm'){if(!confirm(L('Delete this post?','পোস্টটি মুছবেন?')))return;await rmPost({postId:d.id});await loadPosts()}
  else if(c==='rpt'){await rptPost({postId:d.id});alert(L('Reported. Thank you.','রিপোর্ট করা হয়েছে। ধন্যবাদ।'))}
  else if(c==='open'){cur=(posts||[]).find(x=>x.id===d.id);cms=(await listOf(`comments/${d.id}`,50)).reverse();sub='post';render()}
  else if(c==='cmt'){const v=val('cm').trim();if(!v||!cur)return;await mkComment({postId:cur.id,text:v});cms=(await listOf(`comments/${cur.id}`,50)).reverse();render()}
  else if(c==='blk'){if(!confirm(L('Block this user? You will no longer see their posts and comments.','এই ব্যবহারকারীকে ব্লক করবেন? তাদের পোস্ট ও মন্তব্য আর দেখবেন না।')))return;S.set('blocked',[...new Set([...blk(),d.u])]);sub=null;render()}
  else if(c==='unblk'){S.set('blocked',[]);render()}
  else if(c==='rmdev'){if(d.id===devId()){await fbOut();return}await rmDevice({deviceId:d.id});if(gate)await checkDevice(user);else{devs=await getDevices(user);render()}}
  else if(c==='ver'){await verifyId({type:val('vt'),number:val('vn'),dob:val('vd')});prof.student=true;sub=null;tab='community';postsAt=0;render()}
 }catch(x){alert(em(x))}});
listOf('announcements',1).then(a=>{news=a[0]||null;render()}).catch(()=>{});

let lbKind='daily',gate=null,devs=null;
const blk=()=>S.get('blocked',[]);
const boardKey=k=>{const dk=dayKey(Date.now());if(k==='daily')return dk;if(k==='weekly')return Math.floor((dk+5)/7);const d=new Date(Date.now()+OFF);return `${d.getUTCFullYear()}${String(d.getUTCMonth()+1).padStart(2,'0')}`};
const devId=()=>{let d=S.get('devId',null);if(!d){d=(crypto.randomUUID?crypto.randomUUID():String(Date.now())+Math.random().toString(36).slice(2)).replace(/[^-\w]/g,'').slice(0,40);S.set('devId',d)}return d};
async function checkDevice(u){try{await regDevice({deviceId:devId(),name:`${Capacitor.getPlatform()} · ${devId().slice(0,4)}`});gate=null}catch(e){if(/resource-exhausted/.test((e&&e.code)||''))gate=(e.details&&e.details.devices)||[]}render()}
function gateV(){return `<h1>${L('Device limit reached','ডিভাইস সীমা পূর্ণ')}</h1><div class="card"><p class="mut">${L('This account is active on 2 devices. Remove one to continue on this device.','এই অ্যাকাউন্ট ২টি ডিভাইসে চালু আছে। এই ডিভাইসে চালিয়ে যেতে একটি সরান।')}</p></div>${gate.map(x=>`<div class="card row sp"><span>${esc(x.name||'')}</span><button class="btn bad" data-c="rmdev" data-id="${esc(x.id)}">${L('Remove','সরান')}</button></div>`).join('')}<button class="btn alt" style="width:100%" data-auth="logout">${t('logout')}</button>`}
TV.devices=()=>hdr(L('Devices','ডিভাইস'))+`<div style="margin-top:12px">${(devs||[]).length?devs.map(x=>`<div class="card row sp"><span>${esc(x.name||'')}${x.id===devId()?' ✓':''}</span><button class="btn alt" data-c="rmdev" data-id="${esc(x.id)}">${L('Remove','সরান')}</button></div>`).join(''):empty()}</div>`;
document.addEventListener('click',e=>{const b=e.target.closest('[data-lb]');if(!b)return;lbKind=b.dataset.lb;lb=null;lbAt=0;render()});

// Set to true only after the server part (functions/) is deployed on a Firebase Blaze plan.
const SERVER=!!API_URL;
const soonV=x=>`<h1>${x}</h1><div class="card">${L('Coming soon. This feature needs the server part, which is not switched on yet.','শীঘ্রই আসছে। এই ফিচারের জন্য সার্ভারের অংশ লাগে, যা এখনো চালু করা হয়নি।')}</div>`;
applyTheme();document.documentElement.lang=lang;$('#pw').textContent=I18N.en.pw;render();
setTimeout(()=>{const s=$('#splash');s.style.opacity=0;setTimeout(()=>s.remove(),400)},1200);
