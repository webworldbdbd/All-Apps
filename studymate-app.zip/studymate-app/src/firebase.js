import {initializeApp} from 'firebase/app';
import {getAuth,initializeAuth,indexedDBLocalPersistence,onAuthStateChanged,createUserWithEmailAndPassword,signInWithEmailAndPassword,signOut,sendPasswordResetEmail,sendEmailVerification,GoogleAuthProvider,signInWithCredential,signInWithPopup,deleteUser} from 'firebase/auth';
import {getDatabase,ref,get,set,serverTimestamp,update,query,orderByChild,limitToLast} from 'firebase/database'
import {API_URL} from './api-config.js';
import {Capacitor} from '@capacitor/core';
import {FirebaseAuthentication} from '@capacitor-firebase/authentication';
import {firebaseConfig} from './firebase-config.js';
const native=Capacitor.isNativePlatform();
const app=initializeApp(firebaseConfig);
const auth=native?initializeAuth(app,{persistence:indexedDBLocalPersistence}):getAuth(app);
const db=getDatabase(app);
export const watchAuth=cb=>onAuthStateChanged(auth,cb);
export const fbLogin=(e,p)=>signInWithEmailAndPassword(auth,e,p);
export async function fbRegister(e,p){const c=await createUserWithEmailAndPassword(auth,e,p);sendEmailVerification(c.user).catch(()=>{});return c}
export const fbReset=e=>sendPasswordResetEmail(auth,e);
export async function fbGoogle(){
 if(native){const r=await FirebaseAuthentication.signInWithGoogle();return signInWithCredential(auth,GoogleAuthProvider.credential(r.credential.idToken))}
 return signInWithPopup(auth,new GoogleAuthProvider())}
export async function fbOut(){if(native)try{await FirebaseAuthentication.signOut()}catch(e){}return signOut(auth)}
export async function ensureProfile(u){const r=ref(db,`users/${u.uid}/profile`);const s=await get(r);
 if(!s.exists())await set(r,{email:String(u.email||'').slice(0,254),displayName:String(u.displayName||'').slice(0,60),createdAt:serverTimestamp()})}
export const pushSession=(uid,s)=>set(ref(db,`users/${uid}/sessions/s${s.end}`),{end:s.end,dur:s.dur,sub:s.sub||''});
export async function pullSessions(uid){const s=await get(ref(db,`users/${uid}/sessions`));return s.exists()?Object.values(s.val()):[]}
export const loadProfile=async u=>{const s=await get(ref(db,`users/${u.uid}/profile`));return s.exists()?s.val():{}};
export const saveProfile=(u,p)=>update(ref(db,`users/${u.uid}/profile`),p);
export async function delAccount(u){await update(ref(db),{[`users/${u.uid}/profile`]:null,[`users/${u.uid}/sessions`]:null});await deleteUser(u)}
export async function uploadPhoto(file){
 const b=await createImageBitmap(file),sc=Math.min(1,512/Math.max(b.width,b.height)),c=document.createElement('canvas');
 c.width=Math.round(b.width*sc);c.height=Math.round(b.height*sc);c.getContext('2d').drawImage(b,0,0,c.width,c.height);
 const blob=await new Promise(r=>c.toBlob(r,'image/jpeg',.8)),f=new FormData();
 f.append('file',blob);f.append('upload_preset','StudyMate');f.append('folder','studymate/profile_photos');
 const r=await fetch('https://api.cloudinary.com/v1_1/qdfqfwlf/image/upload',{method:'POST',body:f});
 if(!r.ok)throw new Error('upload');const j=await r.json();return{url:j.secure_url,id:j.public_id}}
export {API_URL};
export const claimName=n=>call('claimUsername')({username:n});
export const creditSession=x=>call('submitSession')({end:x.end,dur:x.dur});
export const myName=async u=>{const s=await get(ref(db,`users/${u.uid}/username`));return s.exists()?s.val():''};
export async function topDaily(dk){const s=await get(query(ref(db,`leaderboard/daily/${dk}`),orderByChild('p'),limitToLast(10)));const a=[];s.forEach(c=>{a.push(c.val())});return a.reverse()}
const call=n=>async d=>{const t=await auth.currentUser.getIdToken(),r=await fetch(`${API_URL}/${n}`,{method:'POST',headers:{'content-type':'application/json',authorization:'Bearer '+t},body:JSON.stringify(d||{})}),j=await r.json().catch(()=>({}));if(!r.ok){const e=new Error(j.error||'internal');e.code=j.error||'internal';e.details=j.details;throw e}return j};
export const hello=()=>call('hello')({});
export const verifyId=call('submitVerification'),mkPost=call('createPost'),mkComment=call('addComment'),rptPost=call('reportPost'),rmPost=call('deletePost');
export async function loadMeta(u){const v=(await get(ref(db,`users/${u.uid}`))).val()||{};return{username:v.username||'',student:!!v.student}}
export async function listOf(path,n=20){const s=await get(query(ref(db,path),orderByChild('at'),limitToLast(n)));const a=[];s.forEach(c=>{a.push({id:c.key,...c.val()})});return a.reverse()}
export const saveToken=(u,t)=>set(ref(db,`users/${u.uid}/fcm/${t}`),true);
export const regDevice=call('registerDevice'),rmDevice=call('removeDevice');
export async function getDevices(u){const v=(await get(ref(db,`users/${u.uid}/devices`))).val()||{};return Object.entries(v).map(([id,x])=>({id,...x}))}
export async function topBoard(kind,key){const s=await get(query(ref(db,`leaderboard/${kind}/${key}`),orderByChild('p'),limitToLast(10)));const a=[];s.forEach(c=>{a.push(c.val())});return a.reverse()}
