export const API_URL=''; // put your Worker URL here after deploying, e.g. https://studymate-api.YOURNAME.workers.dev
