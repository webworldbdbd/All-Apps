// Web API keys are identifiers, not secrets. Security comes from database.rules.json + Auth.
export const firebaseConfig={
apiKey:"AIzaSyATiC7UJdxHrm98AtGxYSRX4aOga6COdXqU",
authDomain:"studymate-webworldbd.firebaseapp.com",
databaseURL:"https://studymate-webworldbd-default-rtdb.asia-southeast1.firebasedatabase.app",
projectId:"studymate-webworldbd",
storageBucket:"studymate-webworldbd.firebasestorage.app",
messagingSenderId:"258581366072",
appId:"1:258581366072:web:eeb533c151ef4d65baedcd",
measurementId:"G-2DZRL3QBL9"};
